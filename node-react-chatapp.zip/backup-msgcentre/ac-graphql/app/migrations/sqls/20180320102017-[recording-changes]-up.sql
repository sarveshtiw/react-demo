-- ac_conf_did table changes
ALTER TABLE `ac_conf_did` CHANGE `id_did` `did` BIGINT UNSIGNED;

-- ac_conf_instance table changes
ALTER TABLE `ac_conf_instance` ADD COLUMN is_deleted TINYINT(1) DEFAULT 0;
ALTER TABLE `ac_conf_instance` ADD COLUMN deleted_at TIMESTAMP NULL DEFAULT NULL;
ALTER TABLE `ac_conf_instance` MODIFY COLUMN ac_server_ip CHAR(20) NOT NULL;

-- ac_shared_did table changes
ALTER TABLE ac_shared_did DROP COLUMN city_name;
ALTER TABLE ac_shared_did ADD COLUMN id_city INT UNSIGNED;
ALTER TABLE `ac_shared_did` ADD COLUMN is_deleted TINYINT(1) DEFAULT 0;
ALTER TABLE `ac_shared_did` ADD COLUMN deleted_at TIMESTAMP NULL DEFAULT NULL;

-- ac_participant table changes
ALTER TABLE `ac_participant` MODIFY COLUMN callervoicevol VARCHAR(100) NULL;

-- ac_did_audio table changes
ALTER TABLE `ac_did_audio` CHANGE `id_did` `did` BIGINT UNSIGNED;