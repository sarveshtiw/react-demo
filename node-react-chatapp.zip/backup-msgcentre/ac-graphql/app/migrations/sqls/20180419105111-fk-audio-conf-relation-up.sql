/* Replace with your SQL commands */
ALTER TABLE ac_conf DROP FOREIGN KEY fk_conf_acaudio;