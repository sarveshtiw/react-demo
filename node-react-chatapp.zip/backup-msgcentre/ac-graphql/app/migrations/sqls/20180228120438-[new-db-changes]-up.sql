/* Replace with your SQL commands */
DROP TABLE IF EXISTS `ac_conf_did`;
DROP TABLE IF EXISTS `ac_conf_participiant`;
DROP TABLE IF EXISTS `ac_conf_recurrence_daily_detail`;
DROP TABLE IF EXISTS `ac_conf_recurrence_weekly_detail`;
DROP TABLE IF EXISTS `ac_conf_recurrence_monthly_detail`;
DROP TABLE IF EXISTS `ac_conf_recurrence_yearly_detail`;
DROP TABLE IF EXISTS `ac_conf`;
DROP TABLE IF EXISTS `ac_did_audio`;
DROP TABLE IF EXISTS `ac_audio`;
DROP TABLE IF EXISTS `ac_pop`;
DROP TABLE IF EXISTS `ac_shared_did_rates`;
DROP TABLE IF EXISTS `ac_shared_did_to_user`;
DROP TABLE IF EXISTS `ac_shared_did`;
DROP TABLE IF EXISTS `ac_audio`;

CREATE TABLE `ac_audio` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_amp_company` int(11) DEFAULT NULL,
  `id_amp_user_profile` int(11) DEFAULT NULL,
  `audio_description` varchar(255) CHARACTER SET latin1 NOT NULL,
  `is_default_audio` tinyint(1) DEFAULT NULL COMMENT '1 means default and 0 means not default',
  `audio_file_id` varchar(50) CHARACTER SET latin1 NOT NULL,
  `audio_type` tinyint(1) DEFAULT NULL COMMENT '1 means `audio welcome msg` and 2 means `in call audio msg`',
  `created_at` timestamp NULL DEFAULT NULL,
  `modified_by` int(11) NOT NULL,
  `modified_at` timestamp NULL DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT '0' COMMENT '1 means deleted and 0 means undeleted',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;


/*Table structure for table `ac_pop` */
CREATE TABLE `ac_pop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_amp_country_master` int(10) DEFAULT NULL,
  `description` varchar(384) CHARACTER SET latin1 DEFAULT NULL,
  `xfer_did` varchar(96) CHARACTER SET latin1 DEFAULT NULL,
  `event_server_address` char(120) CHARACTER SET latin1 DEFAULT NULL,
  `internal_event_address` char(120) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `ac_pop` */
insert  into `ac_pop`(`id`,`id_amp_country_master`,`description`,`xfer_did`,`event_server_address`,`internal_event_address`) values (1,241,'London','','amp.asergis.in:7379','192.168.103.74:7379'),(3,105,'Delhi','911166411575','amp.asergis.in:7379','192.168.103.74:7379'),(5,105,'Bangalore','918061275475','amp.asergis.in:7379','192.168.103.74:7379'),(7,105,'Mumbai','912261502575','amp.asergis.in:7379','192.168.103.74:7379'),(9,208,'Singapore','','amp.asergis.in:7379','192.168.103.74:7379');

/*Table structure for table `ac_autodial` */

DROP TABLE IF EXISTS `ac_autodial`;

CREATE TABLE `ac_autodial` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `id_ac_conf` int(10) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `call_date` datetime DEFAULT NULL,
  `attempts` int(10) DEFAULT '0',
  `phone_number` varchar(32) NOT NULL,
  `intl_code` varchar(50) NOT NULL,
  `id_cms_contact` int(10) unsigned DEFAULT NULL,
  `call_id` varchar(32) DEFAULT NULL,
  `type` enum('M','A') NOT NULL DEFAULT 'M',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `ac_autodial` */

/*Table structure for table `ac_conf` */
CREATE TABLE `ac_conf` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_amp_user_profile` int(10) unsigned DEFAULT NULL,
  `id_amp_company` int(10) unsigned DEFAULT NULL,
  `conf_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `participant_limit` int(11) NOT NULL,
  `conf_leaderpin` bigint(20) NOT NULL,
  `conf_participant_pin` bigint(20) NOT NULL,
  `id_ac_pop` int(11) NOT NULL,
  `conf_start_time` datetime DEFAULT NULL,
  `conf_end_time` datetime DEFAULT NULL,
  `auto_dial` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `generate_new_pin` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `send_invites` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `record_conf` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `participiant_on_mute` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `participiant_on_hold` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `end_conf_leader_hangs_up` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `play_sound` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `participiant_name_announced` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
	`deaf_members` tinyint(1) DEFAULT '0',
	`announce_members` tinyint(1) DEFAULT '0',
  `enable_touch_tone` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `play_music_on_hold` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `participiant_position_announced` tinyint(1) DEFAULT '0',
  `qa_available` tinyint(1) DEFAULT '0',
  `live_status` tinyint(1) DEFAULT '0' COMMENT '1 means live and 0 means non-live',
  `conf_recurrence_type` enum('none','daily','weekly','monthly','yearly') COLLATE utf8_unicode_ci DEFAULT 'none',
  `conf_end_date_option` tinyint(1) DEFAULT NULL COMMENT '1 means no end date, 2 means end after n occurence and 3 means end by any date',
  `conf_end_after_occurence` tinyint(1) DEFAULT NULL,
  `conf_end_date` date DEFAULT NULL,
  `started_node` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(10) unsigned DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_pop_server` (`id_ac_pop`),
  CONSTRAINT `ac_conf_ibfk_1` FOREIGN KEY (`id_ac_pop`) REFERENCES `ac_pop` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=169 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

/*Table structure for table `ac_conf_did` */
CREATE TABLE `ac_conf_did` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_ac_conf` int(10) unsigned NOT NULL,
  `id_did` int(10) unsigned NOT NULL,
  `did_type` enum('shared','dedicated') CHARACTER SET latin1 DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT '0' COMMENT '1 means deleted and 0 means undeleted',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_ac_conf` (`id_ac_conf`),
  CONSTRAINT `ac_conf_did_ibfk_1` FOREIGN KEY (`id_ac_conf`) REFERENCES `ac_conf` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `ac_conf_did` */

/*Table structure for table `ac_conf_instance` */

DROP TABLE IF EXISTS `ac_conf_instance`;
CREATE TABLE `ac_conf_instance` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `id_ac_conf` int(10) NOT NULL DEFAULT '0',
  `ac_server_ip` int(10) NOT NULL DEFAULT '0',
  `starttime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `endtime` timestamp NULL DEFAULT NULL,
  `conf_report_sent` tinyint(4) NOT NULL DEFAULT '0',
  `id_recording_file` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `ac_conf_instance` */

/*Table structure for table `ac_conf_participiant` */
CREATE TABLE `ac_conf_participiant` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_ac_conf` int(10) unsigned NOT NULL,
  `id_cms_contact` int(10) unsigned NOT NULL,
  `is_deleted` tinyint(1) DEFAULT '0' COMMENT '1 means deleted and 0 means undeleted',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_ac_conf` (`id_ac_conf`),
  CONSTRAINT `ac_conf_participiant_ibfk_1` FOREIGN KEY (`id_ac_conf`) REFERENCES `ac_conf` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `ac_conf_participiant` */

/*Table structure for table `ac_conf_recurrence_daily_detail` */
CREATE TABLE `ac_conf_recurrence_daily_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_ac_conf` int(10) unsigned NOT NULL,
  `daily_option` enum('daily','weekday') CHARACTER SET latin1 DEFAULT 'daily',
  `daily_day_no` int(11) DEFAULT '0',
  `is_deleted` tinyint(1) DEFAULT '0' COMMENT '1 means deleted 0 means undeleted',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_ac_conf` (`id_ac_conf`),
  CONSTRAINT `ac_conf_recurrence_daily_detail_ibfk_1` FOREIGN KEY (`id_ac_conf`) REFERENCES `ac_conf` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `ac_conf_recurrence_daily_detail` */

/*Table structure for table `ac_conf_recurrence_monthly_detail` */
CREATE TABLE `ac_conf_recurrence_monthly_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_ac_conf` int(10) unsigned NOT NULL,
  `monthly_option` enum('day','weekly') CHARACTER SET latin1 DEFAULT 'day',
  `monthly_day` tinyint(3) unsigned DEFAULT NULL,
  `monthly_every_month` tinyint(3) unsigned DEFAULT NULL,
  `monthly_week` varchar(25) CHARACTER SET latin1 DEFAULT NULL,
  `monthly_day_of_week` varchar(25) CHARACTER SET latin1 DEFAULT NULL,
  `monthly_of_every_month` tinyint(3) unsigned DEFAULT NULL,
  `is_deleted` tinyint(4) DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_ac_conf` (`id_ac_conf`),
  CONSTRAINT `ac_conf_recurrence_monthly_detail_ibfk_1` FOREIGN KEY (`id_ac_conf`) REFERENCES `ac_conf` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `ac_conf_recurrence_monthly_detail` */

/*Table structure for table `ac_conf_recurrence_weekly_detail` */
CREATE TABLE `ac_conf_recurrence_weekly_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_ac_conf` int(10) unsigned NOT NULL,
  `recur_every_week` tinyint(1) NOT NULL DEFAULT '0',
  `weekly_monday` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `weekly_tuesday` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `weekly_wednesday` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `weekly_thursday` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `weekly_friday` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `weekly_saturday` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `weekly_sunday` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `is_deleted` tinyint(1) DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ac_conf_recurrence_weekly_detail_ibfk_1` (`id_ac_conf`),
  CONSTRAINT `ac_conf_recurrence_weekly_detail_ibfk_1` FOREIGN KEY (`id_ac_conf`) REFERENCES `ac_conf` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `ac_conf_recurrence_weekly_detail` */

/*Table structure for table `ac_conf_recurrence_yearly_detail` */
CREATE TABLE `ac_conf_recurrence_yearly_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_ac_conf` int(10) unsigned NOT NULL,
  `recur_every_year` tinyint(4) unsigned DEFAULT NULL COMMENT '1 means yes and 0 means no',
  `yearly_option` enum('monthly','weekly') CHARACTER SET latin1 DEFAULT 'monthly',
  `yearly_on_month` enum('january','february','march','april','may','june','july','august','september','october','november','december') CHARACTER SET latin1 DEFAULT 'january',
  `yearly_on_month_day` tinyint(4) unsigned DEFAULT NULL,
  `yearly_week` enum('first','second','third','fourth','last') CHARACTER SET latin1 DEFAULT 'first',
  `yearly_day_of_week` enum('day','weekday','weekend day','sunday','monday','tuesday','wednesday','thursday','friday','saturday') CHARACTER SET latin1 DEFAULT 'monday',
  `yearly_of_every_month` enum('january','february','march','april','may','june','july','august','september','october','november','december') CHARACTER SET latin1 DEFAULT 'january',
  `is_deleted` tinyint(1) DEFAULT NULL COMMENT '1 means deleted and 0 means undeleted',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_ac_conf` (`id_ac_conf`),
  CONSTRAINT `ac_conf_recurrence_yearly_detail_ibfk_1` FOREIGN KEY (`id_ac_conf`) REFERENCES `ac_conf` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `ac_customer` */

DROP TABLE IF EXISTS `ac_customer`;

CREATE TABLE `ac_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_amp_user_profile` int(11) DEFAULT NULL,
  `id_amp_company` int(11) DEFAULT NULL,
  `max_participants` int(11) DEFAULT NULL,
  `id_ac_pop_default` int(11) DEFAULT NULL,
  `allow_pop_change` tinyint(4) DEFAULT '0',
  `pin_length` int(11) DEFAULT NULL,
  `allow_recording` tinyint(4) DEFAULT '0',
  `on_hold_audio` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `ac_customer` */

/*Table structure for table `ac_did_audio` */
CREATE TABLE `ac_did_audio` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_did` int(11) DEFAULT NULL,
  `id_ac_audio` int(10) unsigned NOT NULL,
  `did_type` enum('dedicated','shared') COLLATE utf8_unicode_ci DEFAULT 'dedicated',
  `last_modified_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_ac_audio` (`id_ac_audio`),
  CONSTRAINT `ac_did_audio_ibfk_1` FOREIGN KEY (`id_ac_audio`) REFERENCES `ac_audio` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `ac_did_audio` */

/*Table structure for table `ac_participant` */
DROP TABLE IF EXISTS `ac_participant`;
CREATE TABLE `ac_participant` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fs_call_id` varchar(50) CHARACTER SET latin1 NOT NULL,
  `starttime` datetime DEFAULT NULL,
  `endtime` datetime DEFAULT NULL,
  `callerid` varchar(64) CHARACTER SET latin1 DEFAULT NULL,
  `called_number` varchar(64) CHARACTER SET latin1 DEFAULT NULL,
  `id_ac_conf` int(10) unsigned DEFAULT NULL,
  `is_moderator` tinyint(4) NOT NULL DEFAULT '0',
  `callermute` tinyint(4) NOT NULL DEFAULT '0',
  `callervoicevol` varchar(100) CHARACTER SET latin1 NOT NULL,
  `callername` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `confmute` tinyint(4) NOT NULL DEFAULT '0',
  `confvol` varchar(3) CHARACTER SET latin1 NOT NULL DEFAULT '0',
  `initial_user` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `outbound_fs_call_id` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `name_audio_file` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniqueid` (`fs_call_id`),
  KEY `ac_participant_id_ac_conf_key` (`id_ac_conf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `ac_participant` */

/*Table structure for table `ac_pop_server` */
DROP TABLE IF EXISTS `ac_pop_server`;
CREATE TABLE `ac_pop_server` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `id_ac_pop` int(10) NOT NULL DEFAULT '0',
  `asterisk_ip` char(15) NOT NULL DEFAULT '',
  `asterisk_id` char(30) NOT NULL DEFAULT '',
  `active` tinyint(4) DEFAULT '0',
  `disabled` tinyint(4) DEFAULT '0',
  `server_type` char(5) NOT NULL DEFAULT 'AC',
  `salt` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Index 2` (`asterisk_ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `ac_pop_server` */

/*Table structure for table `ac_pop_xfer` */

DROP TABLE IF EXISTS `ac_pop_xfer`;

CREATE TABLE `ac_pop_xfer` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `id_ac_pop_from` int(10) NOT NULL DEFAULT '0',
  `id_ac_pop_to` int(10) NOT NULL DEFAULT '0',
  `method` char(10) NOT NULL DEFAULT '',
  `detail` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `ac_pop_xfer` */

/*Table structure for table `ac_pop_xfer_call` */

DROP TABLE IF EXISTS `ac_pop_xfer_call`;

CREATE TABLE `ac_pop_xfer_call` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `call_type` tinyint(4) NOT NULL DEFAULT '0',
  `caller_id` varchar(32) NOT NULL DEFAULT '',
  `called_number` varchar(32) NOT NULL DEFAULT '',
  `xfer_id` varchar(32) NOT NULL DEFAULT '',
  `asterisk_id` varchar(32) NOT NULL DEFAULT '',
  `did_aleg` varchar(32) NOT NULL DEFAULT '',
  `did_bleg` varchar(32) NOT NULL DEFAULT '',
  `xfer_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `conf_data` varchar(128) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `ac_pop_xfer_call` */

/*Table structure for table `ac_pop_xfer_did` */

DROP TABLE IF EXISTS `ac_pop_xfer_did`;

CREATE TABLE `ac_pop_xfer_did` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_ac_pop` int(10) unsigned NOT NULL DEFAULT '0',
  `id_cc_card` int(10) unsigned NOT NULL DEFAULT '0',
  `id_ac_conf` int(10) unsigned NOT NULL DEFAULT '0',
  `did_mode` char(1) NOT NULL DEFAULT '',
  `pin_type` char(2) NOT NULL DEFAULT '',
  `did` char(16) NOT NULL DEFAULT '',
  `active` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `caller_id` char(16) NOT NULL DEFAULT '',
  `inbound_did` char(32) NOT NULL DEFAULT '',
  KEY `Index 1` (`id`),
  KEY `Index 2` (`id_ac_pop`),
  KEY `Index 3` (`did`),
  KEY `Index 4` (`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `ac_pop_xfer_did` */

/*Table structure for table `ac_shared_did` */
CREATE TABLE `ac_shared_did` (
  `id` int(10) unsigned NOT NULL,
  `toll_free` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `description` text CHARACTER SET latin1 NOT NULL,
  `active` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `id_country` int(11) DEFAULT NULL,
  `city_name` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `ac_shared_did` */

/*Table structure for table `ac_shared_did_rates` */
CREATE TABLE `ac_shared_did_rates` (
  `id` int(10) unsigned NOT NULL,
  `id_ac_shared_did` int(10) unsigned NOT NULL,
  `id_currency` int(11) NOT NULL,
  `monthly` float DEFAULT NULL,
  `per_minute` float DEFAULT NULL,
  `setup_charge` float DEFAULT NULL,
  `active_from` datetime DEFAULT NULL,
  `active_to` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_ac_shared_did` (`id_ac_shared_did`),
  KEY `id` (`id`),
  CONSTRAINT `ac_shared_did_rates_ibfk_1` FOREIGN KEY (`id_ac_shared_did`) REFERENCES `ac_shared_did` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `ac_shared_did_rates` */

/*Table structure for table `ac_shared_did_to_user` */
CREATE TABLE `ac_shared_did_to_user` (
  `id` int(10) unsigned NOT NULL,
  `id_ac_shared_did` int(10) unsigned NOT NULL,
  `id_customer` int(11) NOT NULL,
  `per_minute_cost` float DEFAULT NULL,
  `setup_charge` float DEFAULT NULL,
  `monthly_charge` float DEFAULT NULL,
  `active_from_dt` datetime DEFAULT NULL,
  `active_to_dt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_ac_shared_did` (`id_ac_shared_did`),
  KEY `id` (`id`),
  CONSTRAINT `ac_shared_did_to_user_ibfk_1` FOREIGN KEY (`id_ac_shared_did`) REFERENCES `ac_shared_did` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `ac_shared_did_to_user` */