ALTER TABLE ac_audio MODIFY COLUMN audio_type TINYINT(1) COMMENT '1 means `welcome audio message` and 2 means `in call audio message and 3 means on hold audio message`';

ALTER TABLE ac_conf_recurrence_monthly_detail DROP monthly_day_of_week;
ALTER TABLE ac_conf_recurrence_monthly_detail DROP monthly_week;
ALTER TABLE ac_conf_recurrence_monthly_detail ADD monthly_day_of_week ENUM('First', 'Second', 'Third', 'Fourth', 'Last') DEFAULT NULL AFTER monthly_every_month;
ALTER TABLE ac_conf_recurrence_monthly_detail ADD monthly_week ENUM('day', 'weekday', 'weekend day', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday') DEFAULT NULL AFTER monthly_day_of_week;

TRUNCATE ac_conf_instance;
ALTER TABLE ac_conf_instance MODIFY COLUMN id_ac_conf INT UNSIGNED; 
ALTER TABLE ac_conf_instance ADD CONSTRAINT `fk_confInstance_conf` FOREIGN KEY (id_ac_conf) REFERENCES ac_conf(id) ON DELETE NO ACTION
ON UPDATE NO ACTION;

TRUNCATE ac_participant;
ALTER TABLE ac_participant ADD CONSTRAINT `fk_acParticipant_conf` FOREIGN KEY (id_ac_conf) REFERENCES ac_conf(id) ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE ac_pop_server ADD CONSTRAINT `fk_acpopserver_acpop` FOREIGN KEY (id_ac_pop) REFERENCES ac_pop(id) ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE ac_pop_xfer ADD CONSTRAINT `fk_acpopxferfrom_acpop` FOREIGN KEY (id_ac_pop_from) REFERENCES ac_pop(id) ON DELETE NO ACTION
ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_acpopxferTo_acpop` FOREIGN KEY (id_ac_pop_to) REFERENCES ac_pop(id) ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE ac_pop_xfer_did MODIFY COLUMN id_ac_pop INT SIGNED;
ALTER TABLE ac_pop_xfer_did ADD CONSTRAINT `fk_acpopxferdid_acpop` FOREIGN KEY (id_ac_pop) REFERENCES ac_pop(id) ON DELETE NO ACTION
ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_idacconf_acconf` FOREIGN KEY (id_ac_conf) REFERENCES ac_conf(id) ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE ac_autodial MODIFY COLUMN id_ac_conf INT UNSIGNED;
ALTER TABLE ac_autodial ADD CONSTRAINT `fk_acautodial_acconf` FOREIGN KEY (id_ac_conf) REFERENCES ac_conf(id) ON DELETE NO ACTION
ON UPDATE NO ACTION;