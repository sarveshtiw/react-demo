DROP TABLE IF EXISTS `ac_call_audio_message`;
DROP TABLE IF EXISTS `ac_welcome_audio_message`;
/*Table structure for table `ac_audio` */

DROP TABLE IF EXISTS `ac_audio`;

CREATE TABLE `ac_audio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_amp_company` int(11) DEFAULT NULL,
  `id_amp_user_profile` int(11) DEFAULT NULL,
  `audio_description` varchar(255) NOT NULL,
  `is_default_audio` tinyint(1) DEFAULT NULL,
  `audio_file_id` varchar(50) NOT NULL,
  `audio_type` tinyint(1) DEFAULT NULL COMMENT '1 means `audio welcome msg` and 2 means `in call audio message`',
  `created_at` timestamp NULL DEFAULT NULL,
  `modified_by` int(11) NOT NULL,
  `modified_at` timestamp NULL DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL COMMENT '1 means deleted and 0 means undeleted',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `ac_conf` */

DROP TABLE IF EXISTS `ac_conf`;

CREATE TABLE `ac_conf` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_amp_user_profile` int(10) unsigned DEFAULT NULL,
  `id_amp_company` int(10) unsigned DEFAULT NULL,
  `conf_name` varchar(255) DEFAULT NULL,
  `participant_limit` varchar(5) DEFAULT NULL,
  `conf_leaderpin` varchar(20) DEFAULT NULL,
  `conf_participant_pin` varchar(20) DEFAULT NULL,
  `id_pop_server` int(11) DEFAULT NULL,
  `conf_date` date DEFAULT NULL,
  `conf_time` time DEFAULT NULL,
  `conf_duration` varchar(50) DEFAULT NULL,
  `auto_dial` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `generate_new_pin` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `send_invites` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `record_conf` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `participiant_on_mute` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `participiant_on_hold` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `end_conf_leader_hangs_up` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `play_sound` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `participiant_name_announced` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `enable_touch_tone` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `play_music_on_hold` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `conf_recurrence_type` enum('none','daily','weekly','monthly','yearly') DEFAULT 'none',
  `conf_end_date_option` tinyint(4) DEFAULT NULL COMMENT '1 means yes and 0 means no',
  `conf_end_after_occurence` tinyint(4) DEFAULT NULL,
  `conf_end_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(10) unsigned DEFAULT NULL,
  `is_deleted` tinyint(4) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `deleted_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=latin1;

/*Table structure for table `ac_conf_did` */

DROP TABLE IF EXISTS `ac_conf_did`;

CREATE TABLE `ac_conf_did` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_ac_conf` int(10) unsigned NOT NULL,
  `id_did` int(10) unsigned NOT NULL,
  `did_type` enum('shared','dedicated') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;

/*Table structure for table `ac_conf_participiant` */

DROP TABLE IF EXISTS `ac_conf_participiant`;

CREATE TABLE `ac_conf_participiant` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_ac_conf` int(10) unsigned NOT NULL,
  `id_cms_contact` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=latin1;

/*Table structure for table `ac_conf_recurrence_daily_detail` */

DROP TABLE IF EXISTS `ac_conf_recurrence_daily_detail`;

CREATE TABLE `ac_conf_recurrence_daily_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_ac_conf` int(10) unsigned NOT NULL,
  `daily_every_day` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `daily_every_weekday` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `daily_monday` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `daily_tuesday` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `daily_wednesday` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `daily_thursday` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `daily_friday` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `daily_saturday` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `daily_sunday` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `is_deleted` tinyint(4) DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

/*Table structure for table `ac_conf_recurrence_monthly_detail` */

DROP TABLE IF EXISTS `ac_conf_recurrence_monthly_detail`;

CREATE TABLE `ac_conf_recurrence_monthly_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_ac_conf` int(11) NOT NULL,
  `monthly_option` enum('day','weekly') DEFAULT 'day',
  `monthly_day` tinyint(3) unsigned DEFAULT NULL,
  `monthly_every_month` tinyint(3) unsigned DEFAULT NULL,
  `monthly_week_no` tinyint(3) unsigned DEFAULT NULL,
  `monthly_day_of_week` tinyint(3) unsigned DEFAULT NULL,
  `monthly_of_every_month` tinyint(3) unsigned DEFAULT NULL,
  `is_deleted` tinyint(4) DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `ac_conf_recurrence_weekly_detail` */

DROP TABLE IF EXISTS `ac_conf_recurrence_weekly_detail`;

CREATE TABLE `ac_conf_recurrence_weekly_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_ac_conf` int(11) unsigned NOT NULL DEFAULT '0',
  `recur_every_week` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `weekly_monday` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `weekly_tuesday` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `weekly_wednesday` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `weekly_thursday` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `weekly_friday` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `weekly_saturday` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `weekly_sunday` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `is_deleted` tinyint(4) DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `ac_conf_recurrence_yearly_detail` */

DROP TABLE IF EXISTS `ac_conf_recurrence_yearly_detail`;

CREATE TABLE `ac_conf_recurrence_yearly_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_ac_conf` int(10) unsigned DEFAULT NULL,
  `recur_every_year` tinyint(4) unsigned DEFAULT NULL COMMENT '1 means yes and 0 means no',
  `yearly_option` enum('monthly','weekly') DEFAULT 'monthly',
  `yearly_on_month` tinyint(4) unsigned DEFAULT NULL,
  `yearly_on_month_day` tinyint(4) unsigned DEFAULT NULL,
  `yearly_week_no` tinyint(4) unsigned DEFAULT NULL,
  `yearly_day_of_week` tinyint(4) unsigned DEFAULT NULL,
  `yearly_of_every_month` tinyint(4) unsigned DEFAULT NULL,
  `is_deleted` tinyint(4) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `ac_welcome_audio_message` */

DROP TABLE IF EXISTS `ac_welcome_audio_message`;

CREATE TABLE `ac_welcome_audio_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_amp_user_profile` int(11) NOT NULL,
  `id_amp_company` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `default_messagefile` int(11) NOT NULL,
  `welcome_audio_message_file_id` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) NOT NULL,
  `modified_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` tinyint(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `migrations` */

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `run_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;