/*Table structure for table `ac_audio` */
DROP TABLE IF EXISTS `ac_conf_did`;
DROP TABLE IF EXISTS `ac_conf_participiant`;
DROP TABLE IF EXISTS `ac_conf_recurrence_daily_detail`;
DROP TABLE IF EXISTS `ac_conf_recurrence_weekly_detail`;
DROP TABLE IF EXISTS `ac_conf_recurrence_monthly_detail`;
DROP TABLE IF EXISTS `ac_conf_recurrence_yearly_detail`;
DROP TABLE IF EXISTS `ac_conf`;
DROP TABLE IF EXISTS `ac_did_audio`;
DROP TABLE IF EXISTS `ac_audio`;
DROP TABLE IF EXISTS `ac_pop`;
DROP TABLE IF EXISTS `ac_shared_did_rates`;
DROP TABLE IF EXISTS `ac_shared_did_to_user`;
DROP TABLE IF EXISTS `ac_shared_did`;

CREATE TABLE `ac_audio` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_amp_company` INT(11) DEFAULT NULL,
  `id_amp_user_profile` INT(11) DEFAULT NULL,
  `audio_description` VARCHAR(255) CHARACTER SET latin1 NOT NULL,
  `is_default_audio` TINYINT(1) DEFAULT NULL COMMENT '1 means default and 0 means not default',
  `audio_file_id` VARCHAR(50) CHARACTER SET latin1 NOT NULL,
  `audio_type` TINYINT(1) DEFAULT NULL COMMENT '1 means `audio welcome msg` and 2 means `in call audio msg`',
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `modified_by` INT(11) NOT NULL,
  `modified_at` TIMESTAMP NULL DEFAULT NULL,
  `is_deleted` TINYINT(1) DEFAULT '0' COMMENT '1 means deleted and 0 means undeleted',
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=INNODB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

/*Table structure for table `ac_pop` */
CREATE TABLE `ac_pop` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `id_amp_country_master` INT(10) DEFAULT NULL,
  `description` VARCHAR(384) CHARACTER SET latin1 DEFAULT NULL,
  `xfer_did` VARCHAR(96) CHARACTER SET latin1 DEFAULT NULL,
  `event_server_address` CHAR(120) CHARACTER SET latin1 DEFAULT NULL,
  `internal_event_address` CHAR(120) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=INNODB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `ac_pop` (`id`, `id_amp_country_master`, `description`, `xfer_did`, `event_server_address`, `internal_event_address`) VALUES('1','241','London','','amp.asergis.in:7379','192.168.103.74:7379');
INSERT INTO `ac_pop` (`id`, `id_amp_country_master`, `description`, `xfer_did`, `event_server_address`, `internal_event_address`) VALUES('3','105','Delhi','911166411575','amp.asergis.in:7379','192.168.103.74:7379');
INSERT INTO `ac_pop` (`id`, `id_amp_country_master`, `description`, `xfer_did`, `event_server_address`, `internal_event_address`) VALUES('5','105','Bangalore','918061275475','amp.asergis.in:7379','192.168.103.74:7379');
INSERT INTO `ac_pop` (`id`, `id_amp_country_master`, `description`, `xfer_did`, `event_server_address`, `internal_event_address`) VALUES('7','105','Mumbai','912261502575','amp.asergis.in:7379','192.168.103.74:7379');
INSERT INTO `ac_pop` (`id`, `id_amp_country_master`, `description`, `xfer_did`, `event_server_address`, `internal_event_address`) VALUES('9','208','Singapore','','amp.asergis.in:7379','192.168.103.74:7379');

/*Table structure for table `ac_conf` */
CREATE TABLE `ac_conf` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_amp_user_profile` INT(10) UNSIGNED DEFAULT NULL,
  `id_amp_company` INT(10) UNSIGNED DEFAULT NULL,
  `conf_name` VARCHAR(255) COLLATE utf8_unicode_ci NOT NULL,
  `participant_limit` INT(11) NOT NULL,
  `conf_leaderpin` BIGINT(20) NOT NULL,
  `conf_participant_pin` BIGINT(20) NOT NULL,
  `id_ac_pop` INT(11) NOT NULL,
  `conf_date` DATE DEFAULT NULL,
  `conf_time` TIME DEFAULT NULL,
  `conf_duration` VARCHAR(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auto_dial` TINYINT(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `generate_new_pin` TINYINT(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `send_invites` TINYINT(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `record_conf` TINYINT(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `participiant_on_mute` TINYINT(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `participiant_on_hold` TINYINT(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `end_conf_leader_hangs_up` TINYINT(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `play_sound` TINYINT(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `participiant_name_announced` TINYINT(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `enable_touch_tone` TINYINT(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `play_music_on_hold` TINYINT(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `live_status` TINYINT(1) DEFAULT '0' COMMENT '1 means live and 0 means non-live',
  `conf_recurrence_type` ENUM('none','daily','weekly','monthly','yearly') COLLATE utf8_unicode_ci DEFAULT 'none',
  `conf_end_date_option` TINYINT(1) DEFAULT NULL COMMENT '1 means no end date, 2 means end after n occurence and 3 means end by any date',
  `conf_end_after_occurence` TINYINT(1) DEFAULT NULL,
  `conf_end_date` DATE DEFAULT NULL,
  `started_node` VARCHAR(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` INT(10) UNSIGNED DEFAULT NULL,
  `is_deleted` TINYINT(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_pop_server` (`id_ac_pop`),
  CONSTRAINT `ac_conf_ibfk_1` FOREIGN KEY (`id_ac_pop`) REFERENCES `ac_pop` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=INNODB AUTO_INCREMENT=135 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

/*Table structure for table `ac_conf_did` */
CREATE TABLE `ac_conf_did` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_ac_conf` INT(10) UNSIGNED NOT NULL,
  `id_did` INT(10) UNSIGNED NOT NULL,
  `did_type` ENUM('shared','dedicated') CHARACTER SET latin1 DEFAULT NULL,
  `is_deleted` TINYINT(1) DEFAULT '0' COMMENT '1 means deleted and 0 means undeleted',
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_ac_conf` (`id_ac_conf`),
  CONSTRAINT `ac_conf_did_ibfk_1` FOREIGN KEY (`id_ac_conf`) REFERENCES `ac_conf` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=INNODB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `ac_conf_participiant` */
CREATE TABLE `ac_conf_participiant` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_ac_conf` INT(10) UNSIGNED NOT NULL,
  `id_cms_contact` INT(10) UNSIGNED NOT NULL,
  `is_deleted` TINYINT(1) DEFAULT '0' COMMENT '1 means deleted and 0 means undeleted',
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_ac_conf` (`id_ac_conf`),
  CONSTRAINT `ac_conf_participiant_ibfk_1` FOREIGN KEY (`id_ac_conf`) REFERENCES `ac_conf` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=INNODB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `ac_conf_recurrence_daily_detail` */
CREATE TABLE `ac_conf_recurrence_daily_detail` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_ac_conf` INT(10) UNSIGNED NOT NULL,
  `daily_option` ENUM('daily','weekday') CHARACTER SET latin1 DEFAULT 'daily',
  `daily_day_no` INT(11) DEFAULT '0',
  `is_deleted` TINYINT(1) DEFAULT '0' COMMENT '1 means deleted 0 means undeleted',
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_ac_conf` (`id_ac_conf`),
  CONSTRAINT `ac_conf_recurrence_daily_detail_ibfk_1` FOREIGN KEY (`id_ac_conf`) REFERENCES `ac_conf` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=INNODB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `ac_conf_recurrence_monthly_detail` */
CREATE TABLE `ac_conf_recurrence_monthly_detail` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_ac_conf` INT(10) UNSIGNED NOT NULL,
  `monthly_option` ENUM('day','weekly') CHARACTER SET latin1 DEFAULT 'day',
  `monthly_day` TINYINT(3) UNSIGNED DEFAULT NULL,
  `monthly_every_month` TINYINT(3) UNSIGNED DEFAULT NULL,
  `monthly_week` VARCHAR(25) CHARACTER SET latin1 DEFAULT NULL,
  `monthly_day_of_week` VARCHAR(25) CHARACTER SET latin1 DEFAULT NULL,
  `monthly_of_every_month` TINYINT(3) UNSIGNED DEFAULT NULL,
  `is_deleted` TINYINT(4) DEFAULT '0',
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_ac_conf` (`id_ac_conf`),
  CONSTRAINT `ac_conf_recurrence_monthly_detail_ibfk_1` FOREIGN KEY (`id_ac_conf`) REFERENCES `ac_conf` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=INNODB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `ac_conf_recurrence_weekly_detail` */
CREATE TABLE `ac_conf_recurrence_weekly_detail` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_ac_conf` INT(10) UNSIGNED NOT NULL,
  `recur_every_week` TINYINT(1) NOT NULL DEFAULT '0',
  `weekly_monday` TINYINT(1) NOT NULL DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `weekly_tuesday` TINYINT(1) NOT NULL DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `weekly_wednesday` TINYINT(1) NOT NULL DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `weekly_thursday` TINYINT(1) NOT NULL DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `weekly_friday` TINYINT(1) NOT NULL DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `weekly_saturday` TINYINT(1) NOT NULL DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `weekly_sunday` TINYINT(1) NOT NULL DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `is_deleted` TINYINT(1) DEFAULT '0',
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ac_conf_recurrence_weekly_detail_ibfk_1` (`id_ac_conf`),
  CONSTRAINT `ac_conf_recurrence_weekly_detail_ibfk_1` FOREIGN KEY (`id_ac_conf`) REFERENCES `ac_conf` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=INNODB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `ac_conf_recurrence_yearly_detail` */
CREATE TABLE `ac_conf_recurrence_yearly_detail` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_ac_conf` INT(10) UNSIGNED NOT NULL,
  `recur_every_year` TINYINT(4) UNSIGNED DEFAULT NULL COMMENT '1 means yes and 0 means no',
  `yearly_option` ENUM('monthly','weekly') CHARACTER SET latin1 DEFAULT 'monthly',
  `yearly_on_month` ENUM('january','february','march','april','may','june','july','august','september','october','november','december') CHARACTER SET latin1 DEFAULT 'january',
  `yearly_on_month_day` TINYINT(4) UNSIGNED DEFAULT NULL,
  `yearly_week` ENUM('first','second','third','fourth','last') CHARACTER SET latin1 DEFAULT 'first',
  `yearly_day_of_week` ENUM('day','weekday','weekend day','sunday','monday','tuesday','wednesday','thursday','friday','saturday') CHARACTER SET latin1 DEFAULT 'monday',
  `yearly_of_every_month` ENUM('january','february','march','april','may','june','july','august','september','october','november','december') CHARACTER SET latin1 DEFAULT 'january',
  `is_deleted` TINYINT(1) DEFAULT NULL COMMENT '1 means deleted and 0 means undeleted',
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_ac_conf` (`id_ac_conf`),
  CONSTRAINT `ac_conf_recurrence_yearly_detail_ibfk_1` FOREIGN KEY (`id_ac_conf`) REFERENCES `ac_conf` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=INNODB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `ac_did_audio` */
CREATE TABLE `ac_did_audio` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_did` INT(11) DEFAULT NULL,
  `id_ac_audio` INT(10) UNSIGNED NOT NULL,
  `did_type` ENUM('dedicated','shared') COLLATE utf8_unicode_ci DEFAULT 'dedicated',
  `last_modified_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_ac_audio` (`id_ac_audio`),
  CONSTRAINT `ac_did_audio_ibfk_1` FOREIGN KEY (`id_ac_audio`) REFERENCES `ac_audio` (`id`)
) ENGINE=INNODB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



/*Table structure for table `ac_shared_did` */
CREATE TABLE `ac_shared_did` (
  `id` INT(10) UNSIGNED NOT NULL,
  `toll_free` TINYINT(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `description` TEXT CHARACTER SET latin1 NOT NULL,
  `active` TINYINT(1) DEFAULT '0' COMMENT '1 means yes and 0 means no',
  `id_country` INT(11) DEFAULT NULL,
  `city_name` VARCHAR(100) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=INNODB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `ac_shared_did_rates` */
CREATE TABLE `ac_shared_did_rates` (
  `id` INT(10) UNSIGNED NOT NULL,
  `id_ac_shared_did` INT(10) UNSIGNED NOT NULL,
  `id_currency` INT(11) NOT NULL,
  `monthly` FLOAT DEFAULT NULL,
  `per_minute` FLOAT DEFAULT NULL,
  `setup_charge` FLOAT DEFAULT NULL,
  `active_from` DATETIME DEFAULT NULL,
  `active_to` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_ac_shared_did` (`id_ac_shared_did`),
  KEY `id` (`id`),
  CONSTRAINT `ac_shared_did_rates_ibfk_1` FOREIGN KEY (`id_ac_shared_did`) REFERENCES `ac_shared_did` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=INNODB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `ac_shared_did_to_user` */
CREATE TABLE `ac_shared_did_to_user` (
  `id` INT(10) UNSIGNED NOT NULL,
  `id_ac_shared_did` INT(10) UNSIGNED NOT NULL,
  `id_customer` INT(11) NOT NULL,
  `per_minute_cost` FLOAT DEFAULT NULL,
  `setup_charge` FLOAT DEFAULT NULL,
  `monthly_charge` FLOAT DEFAULT NULL,
  `active_from_dt` DATETIME DEFAULT NULL,
  `active_to_dt` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_ac_shared_did` (`id_ac_shared_did`),
  KEY `id` (`id`),
  CONSTRAINT `ac_shared_did_to_user_ibfk_1` FOREIGN KEY (`id_ac_shared_did`) REFERENCES `ac_shared_did` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=INNODB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

