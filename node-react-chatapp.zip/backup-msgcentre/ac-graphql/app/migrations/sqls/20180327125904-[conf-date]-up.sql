/* Replace with your SQL commands */
ALTER TABLE ac_conf ADD COLUMN conf_date DATETIME NOT NULL AFTER id_ac_pop;