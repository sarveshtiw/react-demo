ALTER TABLE ac_conf_recurrence_yearly_detail drop yearly_on_month, drop yearly_day_of_week, drop yearly_week, drop yearly_of_every_month;

ALTER TABLE ac_conf_recurrence_yearly_detail ADD yearly_on_month ENUM('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December') DEFAULT NULL AFTER yearly_on_month_day;
ALTER TABLE ac_conf_recurrence_yearly_detail ADD yearly_day_of_week ENUM('First', 'Second', 'Third', 'Fourth', 'Last') DEFAULT NULL AFTER yearly_on_month_day; 
ALTER TABLE ac_conf_recurrence_yearly_detail ADD yearly_week ENUM('day', 'weekday', 'weekend day', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday') DEFAULT NULL AFTER yearly_day_of_week;
ALTER TABLE ac_conf_recurrence_yearly_detail ADD yearly_of_every_month ENUM ('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December') DEFAULT NULL AFTER yearly_week;


ALTER TABLE ac_conf_recurrence_monthly_detail DROP monthly_day_of_week, DROP monthly_week;

ALTER TABLE ac_conf_recurrence_monthly_detail ADD monthly_day_of_week ENUM('First', 'Second', 'Third', 'Fourth', 'Last') DEFAULT NULL AFTER monthly_every_month;
ALTER TABLE ac_conf_recurrence_monthly_detail ADD monthly_week ENUM('day', 'weekday', 'weekend day', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday') DEFAULT NULL AFTER monthly_day_of_week;