/* Replace with your SQL commands */
ALTER TABLE ac_shared_did ADD COLUMN did CHAR(20) DEFAULT NULL AFTER id;