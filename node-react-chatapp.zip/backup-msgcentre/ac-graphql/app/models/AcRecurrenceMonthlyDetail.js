module.exports = function(sequelize, DataTypes) {
    var AcRecurrenceMonthlyDetail = sequelize.define("AcRecurrenceMonthlyDetail", {
        id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
        id_ac_conf: { type: DataTypes.INTEGER, allowNull: false, foreignKey: true },
        monthly_option: { type: DataTypes.ENUM('day', 'weekly'), defaultValues: 'day' },
        monthly_day: { type: DataTypes.INTEGER, defaultValues: 0 },
        monthly_every_month: { type: DataTypes.INTEGER, defaultValues: 0 },
        monthly_day_of_week: { type: DataTypes.ENUM('First', 'Second', 'Third', 'Fourth', 'Last'), defaultValue: null },
        monthly_week: { type: DataTypes.ENUM('day', 'weekday', 'weekend day', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'), defaultValue: null },
        monthly_of_every_month: { type: DataTypes.INTEGER, defaultValue: 0 },
        is_deleted: { type: DataTypes.INTEGER, allowNull: true },
        deleted_at: { type: DataTypes.DATE, allowNull: true }
    }, {
        tableName: 'ac_conf_recurrence_monthly_detail'
    });
    return AcRecurrenceMonthlyDetail;
};