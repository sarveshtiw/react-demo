module.exports = function(sequelize, DataTypes) {
    var AcConfDid = sequelize.define("AcConfDid", {
        id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
        id_ac_conf: { type: DataTypes.INTEGER, allowNull: false, foreignKey: true },
        did: { type: DataTypes.INTEGER, allowNull: false },
        did_type: { type: DataTypes.ENUM('dedicated','shared'), allowNull: false, defaultValue: 'dedicated' },
        is_deleted: { type: DataTypes.INTEGER, allowNull: false, defaultValue: false },
        deleted_at: { type: DataTypes.INTEGER, allowNull: false, defaultValue: null }
    }, {
        tableName: 'ac_conf_did'
    });
    return AcConfDid;
};