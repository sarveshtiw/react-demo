module.exports = function(sequelize, DataTypes) {
    var AcConfParticipiant = sequelize.define("AcConfParticipiant", {
        id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
        id_ac_conf: { type: DataTypes.INTEGER, allowNull: false, foreignKey: true },
        id_cms_contact: { type: DataTypes.INTEGER, allowNull: false },
        is_deleted: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
        deleted_at: { type: DataTypes.INTEGER, allowNull: false, defaultValue: null }
    }, {
        tableName: 'ac_conf_participiant'
    });
    return AcConfParticipiant;
};