module.exports = function(sequelize, DataTypes) {
    var AcRecurrenceYearlyDetail = sequelize.define("AcRecurrenceYearlyDetail", {
        id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
        id_ac_conf: { type: DataTypes.INTEGER, allowNull: false, foreignKey: true },
        yearly_option: { type: DataTypes.ENUM('monthly', 'weekly'), defaultValue: 'monthly' },
        recur_every_year: { type: DataTypes.INTEGER, defaultValue: 0 },
        yearly_on_month: { type: DataTypes.ENUM('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'), defaultValue: null },
        yearly_on_month_day: { type: DataTypes.INTEGER, defaultValue: 0 },
        yearly_day_of_week: { type: DataTypes.ENUM('First', 'Second', 'Third', 'Fourth', 'Last'), defaultValue: null },
        yearly_week: { type: DataTypes.ENUM('day', 'weekday', 'weekend day', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'), defaultValue: null },
        yearly_of_every_month: { type: DataTypes.ENUM('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'), defaultValue: null },
        is_deleted: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
        deleted_at: { type: DataTypes.DATE, allowNull: true }
    }, {
        tableName: 'ac_conf_recurrence_yearly_detail'
    });
    return AcRecurrenceYearlyDetail;
};