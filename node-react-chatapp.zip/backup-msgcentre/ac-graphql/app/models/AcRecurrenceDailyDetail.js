module.exports = function(sequelize, DataTypes) {
    var AcRecurrenceDailyDetail = sequelize.define("AcRecurrenceDailyDetail", {
        id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
        id_ac_conf: { type: DataTypes.INTEGER, allowNull: false, foreignKey: true },
        daily_option: { type: DataTypes.ENUM('daily', 'weekday'), defaultValue: 'daily' },
        daily_day_no: { type: DataTypes.INTEGER, defaultValue: 0 },
        is_deleted: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
        deleted_at: { type: DataTypes.DATE, allowNull: true }
    }, {
        tableName: 'ac_conf_recurrence_daily_detail'
    });
    return AcRecurrenceDailyDetail;
};