module.exports = function(sequelize, DataTypes) {
    var AcDidAudio = sequelize.define("AcDidAudio", {
        id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
        did: { type: DataTypes.INTEGER, allowNull: false },
        id_ac_audio: { type: DataTypes.INTEGER, allowNull: false },
        did_type: { type: DataTypes.ENUM('dedicated','shared'), allowNull: false, defaultValue: 'dedicated' },
        last_modified_at: { type: DataTypes.DATE, allowNull: false }
    }, {
        tableName: 'ac_did_audio'
    });
    return AcDidAudio;
}