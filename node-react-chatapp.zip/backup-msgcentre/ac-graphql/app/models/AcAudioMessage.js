module.exports = function(sequelize, DataTypes) {
    var AcAudioMessage = sequelize.define("AcAudioMessage", {
        id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
        id_amp_user_profile: { type: DataTypes.INTEGER, allowNull: false },
        id_amp_company: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
        audio_description: { type: DataTypes.STRING, allowNull: false },
        is_default_audio: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false },
        audio_file_id: { type: DataTypes.STRING, allowNull: false, defaultValue: null },
        audio_duration: { type: DataTypes.TIME, allowNull: false, defaultValue: null },
        audio_type: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 1 },
        created_at: { type: DataTypes.DATE, allowNull: false, defaultValue: new Date() },
        modified_by: { type: DataTypes.INTEGER, allowNull: false },
        modified_at: { type: DataTypes.DATE, allowNull: false, defaultValue: new Date() },
        is_deleted: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
        deleted_at: { type: DataTypes.DATE, allowNull: true }
    }, {
        tableName: 'ac_audio'
    });

    AcAudioMessage.associate = models => {       
        models.AcAudioMessage.hasMany(models.AcDidAudio, { foreignKey: 'id_ac_audio', constraints: false, as: 'audioDid' });
        models.AcAudioMessage.hasMany(models.AudioConference, { foreignKey: 'id_ac_audio', constraints: false, as: 'audioConf' });        
    };
    return AcAudioMessage;
};