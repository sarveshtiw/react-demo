module.exports = function(sequelize, DataTypes) {
    var AcConfInstance = sequelize.define("AcConfInstance", {
        id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
        id_ac_conf: { type: DataTypes.INTEGER, allowNull: false },
        ac_server_ip: { type: DataTypes.INTEGER, allowNull: false },
        starttime: { type: DataTypes.DATE, allowNull: false },
        endtime: { type: DataTypes.DATE, allowNull: true },
        conf_report_sent: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
        id_recording_file: { type: DataTypes.STRING, allowNull: true },
        is_deleted: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
        deleted_at: { type: DataTypes.DATE, allowNull: true }
    }, {
        tableName: 'ac_conf_instance'
    });
    return AcConfInstance;
};