module.exports = function(sequelize, DataTypes) {
    var AcSharedDid = sequelize.define("AcSharedDid", {
        id: { type: DataTypes.INTEGER, primaryKey: true },
        did: { type: DataTypes.STRING, allowNull: false },
        toll_free: { type: DataTypes.BOOLEAN, allowNull: false,defaultValue: false },
        description: { type: DataTypes.STRING, allowNull: true },
        id_country: { type: DataTypes.INTEGER, allowNull: false },
        id_city: { type: DataTypes.INTEGER, allowNull: false },
        active: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false },
        is_deleted: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: 0 },
    }, {
        tableName: 'ac_shared_did'
    });
    return AcSharedDid;
};