module.exports = function(sequelize, DataTypes) {
    var AcParticipant = sequelize.define("AcParticipant", {
        id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
        fs_call_id: { type: DataTypes.STRING, allowNull: false },
        starttime: { type: DataTypes.DATE, allowNull: true },
        endtime: { type: DataTypes.DATE, allowNull: true },
        callerid: { type: DataTypes.STRING, allowNull: true },
        called_number: { type: DataTypes.STRING, allowNull: true },
        id_ac_conf: { type: DataTypes.INTEGER, allowNull: true },
        is_moderator: { type: DataTypes.INTEGER, allowNull: false },
        callermute: { type: DataTypes.INTEGER, allowNull: false },
        callervoicevol: { type: DataTypes.STRING, allowNull: false },
        callername: { type: DataTypes.STRING, allowNull: true },
        confmute: { type: DataTypes.INTEGER, allowNull: false },
        confvol: { type: DataTypes.STRING, allowNull: false },
        initial_user: { type: DataTypes.INTEGER, allowNull: false },
        outbound_fs_call_id: { type: DataTypes.STRING, allowNull: true },
        name_audio_file: { type: DataTypes.INTEGER, allowNull: true }
    }, {
        tableName: 'ac_participant'
    });
    return AcParticipant;
};