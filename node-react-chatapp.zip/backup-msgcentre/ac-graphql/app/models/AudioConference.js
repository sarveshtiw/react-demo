module.exports = function(sequelize, DataTypes) {
    var AudioConference = sequelize.define("AudioConference", {
        id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
        id_amp_user_profile: { type: DataTypes.INTEGER },
        id_amp_company: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
        conf_name: { type: DataTypes.STRING, allowNull: false },
        participant_limit: { type: DataTypes.INTEGER, allowNull: false },
        conf_leaderpin: { type: DataTypes.INTEGER, allowNull: false },
        conf_participant_pin: { type: DataTypes.INTEGER, allowNull: false },
        id_ac_pop: { type: DataTypes.INTEGER, allowNull: false },
        conf_date: { type: DataTypes.DATE, allowNull: false },
        conf_start_time: { type: DataTypes.DATE, allowNull: true },
        conf_end_time: { type: DataTypes.DATE, allowNull: true, defaultValue: null },
        auto_dial: { type: DataTypes.BOOLEAN, defaultValue: 0 },
        generate_new_pin: { type: DataTypes.BOOLEAN, defaultValue: 0 },
        send_invites: { type: DataTypes.BOOLEAN, defaultValue: 0 },
        record_conf: { type: DataTypes.BOOLEAN, defaultValue: 0 },
        participiant_on_mute: { type: DataTypes.BOOLEAN, defaultValue: 0 },
        participiant_on_hold: { type: DataTypes.BOOLEAN, defaultValue: 0 },
        end_conf_leader_hangs_up: { type: DataTypes.BOOLEAN, defaultValue: 0 },
        play_sound: { type: DataTypes.BOOLEAN, defaultValue: 0 },
        participiant_name_announced: { type: DataTypes.BOOLEAN, defaultValue: 0 },
        enable_touch_tone: { type: DataTypes.BOOLEAN, defaultValue: 0 },
        play_music_on_hold: { type: DataTypes.BOOLEAN, defaultValue: 0 },
        conf_recurrence_type: { type: DataTypes.ENUM('none', 'daily', 'weekly', 'monthly', 'yearly'), defaultValue: 'none' },
        conf_end_date_option: { type: DataTypes.BOOLEAN, defaultValue: 0 },
        conf_end_after_occurence: { type: DataTypes.BOOLEAN, defaultValue: 0 },
        conf_end_date: { type: DataTypes.DATE, allowNull: true, defaultValue: null },
        created_at: { type: DataTypes.DATE, allowNull: false, defaultValue: new Date() },
        modified_by: { type: DataTypes.INTEGER, allowNull: false },
        modified_at: { type: DataTypes.DATE, allowNull: false, defaultValue: new Date() },
        is_deleted: { type: DataTypes.BOOLEAN, defaultValue: 0 },
        deleted_at: { type: DataTypes.DATE, allowNull: true }
    }, {
        tableName: 'ac_conf'
    });

    AudioConference.associate = models => {
        models.AudioConference.hasOne(models.AcRecurrenceDailyDetail, { foreignKey: 'id_ac_conf', constraints: true, as: 'daily' });
        models.AudioConference.hasOne(models.AcRecurrenceWeeklyDetail, { foreignKey: 'id_ac_conf', constraints: true, as: 'weekly' });
        models.AudioConference.hasOne(models.AcRecurrenceMonthlyDetail, { foreignKey: 'id_ac_conf', constraints: true, as: 'monthly' });
        models.AudioConference.hasOne(models.AcRecurrenceYearlyDetail, { foreignKey: 'id_ac_conf', constraints: true, as: 'yearly' });
        models.AudioConference.hasMany(models.AcConfParticipiant, { foreignKey: 'id_ac_conf', constraints: false, as: 'participiants' });
        models.AudioConference.hasMany(models.AcConfDid, { foreignKey: 'id_ac_conf', constraints: false, as: 'dids' });
        models.AudioConference.hasMany(models.AcConfInstance, { foreignKey: 'id_ac_conf', constraints: false, as: 'confInstance' });
    };
    return AudioConference;
};