module.exports = function(sequelize, DataTypes) {
    var AcRecurrenceWeeklyDetail = sequelize.define("AcRecurrenceWeeklyDetail", {
        id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
        id_ac_conf: { type: DataTypes.INTEGER, allowNull: false, foreignKey: true },
        recur_every_week: { type: DataTypes.INTEGER, defaultValues: 0 },
        weekly_monday: { type: DataTypes.BOOLEAN, defaultValue: false },
        weekly_tuesday: { type: DataTypes.BOOLEAN, defaultValue: false },
        weekly_wednesday: { type: DataTypes.BOOLEAN, defaultValue: false },
        weekly_thursday: { type: DataTypes.BOOLEAN, defaultValue: false },
        weekly_friday: { type: DataTypes.BOOLEAN, defaultValue: false },
        weekly_saturday: { type: DataTypes.BOOLEAN, defaultValue: false },
        weekly_sunday: { type: DataTypes.BOOLEAN, defaultValue: false },
        is_deleted: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
        deleted_at: { type: DataTypes.DATE, allowNull: true }
    }, {
        tableName: 'ac_conf_recurrence_weekly_detail'
    });
    return AcRecurrenceWeeklyDetail;
};