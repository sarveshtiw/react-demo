if (process.env.NODE_ENV === 'local') {
    require('dotenv').config();
}
const app = require('express')();
const { graphqlExpress, graphiqlExpress } = require('apollo-server-express');
const Playground = require('graphql-playground-middleware-express').default;
const cors = require('cors');
const bodyParser = require('body-parser');
const bearerToken = require('express-bearer-token');
const { formatErr } = require('./utils');
const { server } = require('./config');
const schema = require('./schema');
const auth = require('./lib');
const healthChecks = require('./lib/healthChecks');

app.use(cors());
app.get('/healthz/liveness', healthChecks.liveness);
app.get('/healthz/readiness', healthChecks.readiness);

app.use(bearerToken());
const buildOptions = async(req, res) => {
    const user = req.token ? auth.getUserFromToken(req.token) : null;
    return {
        context: { user },
        schema
    }
}

app.use('/graphql', bodyParser.json(), graphqlExpress(buildOptions));
app.use('/graphiql', Playground({ endpoint: '/graphql' }));

app.listen(server.port, server.host, () => {
    console.log('info', `Running a GraphQL API server at ${server.host}:${server.port}/graphql`);
});