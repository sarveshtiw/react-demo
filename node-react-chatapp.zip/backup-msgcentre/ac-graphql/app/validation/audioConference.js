const Joi = require('joi');
const moment = require('moment');
const dateFormat = require('dateformat');
let ErrorArr = [];

/********************************************** Starts: Validation schema  ***************************************************/
// Make Schema for validate create conference
var d = new Date();
let didSchema = Joi.object().keys({
    did: Joi.number().required(),
    did_type: Joi.string().required()
});

let participantSchema = Joi.object().keys({
    id: Joi.number().required(),
    name: Joi.string().required(),
    email: Joi.string().email().required()
});
let schemaCreateConference = Joi.object().keys({
    conf_name: Joi.string().min(5).max(100).required().trim().regex(/^[\w\-\s]+$/),
    participant_limit: Joi.number().min(2).max(500).required(),
    conf_leaderpin: Joi.number().required(),
    conf_participant_pin: Joi.number().required(),
    id_ac_pop: Joi.number().required(),
    auto_dial: Joi.boolean().required(),
    generate_new_pin: Joi.boolean().optional(),
    send_invites: Joi.boolean().required(),
    record_conf: Joi.boolean().required(),
    participiant_on_mute: Joi.boolean().required(),
    participiant_on_hold: Joi.boolean().required(),
    end_conf_leader_hangs_up: Joi.boolean().required(),
    play_sound: Joi.boolean().required(),
    participiant_name_announced: Joi.boolean().required(),
    enable_touch_tone: Joi.boolean().required(),
    play_music_on_hold: Joi.boolean().required(),
    conf_recurrence_type: Joi.string().required().valid('none', 'daily', 'weekly', 'monthly', 'yearly'),
    daily_recurrence_option: Joi.when('conf_recurrence_type', {
        is: 'daily',
        then: Joi.object({
            daily_option: Joi.string().required().valid('daily', 'weekday'),
            daily_day_no: Joi.number().required().min(1).max(99)
        }).required(),
        otherwise: Joi.optional()
    }), 
    weekly_recurrence_option: Joi.when('conf_recurrence_type', {
        is: 'weekly',
        then: Joi.object({
            recur_every_week: Joi.number().required().min(1).max(99),
            weekly_monday: Joi.boolean().required(),
            weekly_tuesday: Joi.boolean().required(),
            weekly_wednesday: Joi.boolean().required(),
            weekly_thursday: Joi.boolean().required(),
            weekly_friday: Joi.boolean().required(),
            weekly_saturday: Joi.boolean().required(),
            weekly_sunday: Joi.boolean().required()
        }).required(),
        otherwise: Joi.optional()
    }),
    monthly_recurrence_option: Joi.when('conf_recurrence_type', {
        is: 'monthly',
        then: Joi.object({
            monthly_option: Joi.string().required().valid('day', 'weekly'),
            monthly_day: Joi.number().optional().min(1).max(31),
            monthly_every_month: Joi.number().optional().min(1).max(99),
            monthly_day_of_week: Joi.string().optional().valid('First', 'Second', 'Third', 'Fourth', 'Last'),
            monthly_week: Joi.string().optional().valid('day', 'weekday', 'weekend day', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'),
            monthly_of_every_month: Joi.number().optional().min(1).max(99),
        }).required(),
        otherwise: Joi.optional()
    }),       
    yearly_recurrence_option: Joi.when('conf_recurrence_type', {
        is: 'yearly',
        then: Joi.object({
            recur_every_year: Joi.number().required().min(1).max(99),
            yearly_option: Joi.string().required().valid('monthly', 'weekly'),
            yearly_on_month: Joi.string().optional().valid('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'),
            yearly_on_month_day: Joi.number().optional().min(1).max(31),
            yearly_day_of_week: Joi.string().optional().valid('First', 'Second', 'Third', 'Fourth', 'Last'),
            yearly_week: Joi.string().optional().valid('day', 'weekday', 'weekend day', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'),
            yearly_of_every_month: Joi.string().optional().valid('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December')
        }).required(),
        otherwise: Joi.optional()
    }),
    conf_start_time: Joi.optional(),
    conf_end_time: Joi.optional(),   
    selectedParticipant: Joi.array().items(participantSchema).optional(),
    dids: Joi.array().items(didSchema).optional(),
    conf_end_date_option: Joi.number().required().valid(1, 2, 3),
    conf_end_after_occurence: Joi.number().optional().min(2).max(999),
    conf_end_date: Joi.date().optional(),
    conf_date: Joi.date().optional(),
    leader_name: Joi.string().trim().required(),
    id_ac_audio: Joi.number().optional(),
});

let schemaUpdateConference = Joi.object().keys({
    id: Joi.number().required(),
    conf_name: Joi.string().min(5).max(100).required().trim().regex(/^[\w\-\s]+$/),
    participant_limit: Joi.number().min(2).max(500).required(),
    conf_leaderpin: Joi.number().required(),
    conf_participant_pin: Joi.number().required(),
    id_ac_pop: Joi.number().required(),
    auto_dial: Joi.boolean().required(),
    generate_new_pin: Joi.boolean().optional(),
    send_invites: Joi.boolean().required(),
    record_conf: Joi.boolean().required(),
    participiant_on_mute: Joi.boolean().required(),
    participiant_on_hold: Joi.boolean().required(),
    end_conf_leader_hangs_up: Joi.boolean().required(),
    play_sound: Joi.boolean().required(),
    participiant_name_announced: Joi.boolean().required(),
    enable_touch_tone: Joi.boolean().required(),
    play_music_on_hold: Joi.boolean().required(),
    conf_recurrence_type: Joi.string().required().valid('none', 'daily', 'weekly', 'monthly', 'yearly'),
    daily_recurrence_option: Joi.when('conf_recurrence_type', {
        is: 'daily',
        then: Joi.object({
            daily_option: Joi.string().required().valid('daily', 'weekday'),
            daily_day_no: Joi.number().required().min(1).max(99)
        }).required(),
        otherwise: Joi.optional()
    }),
    weekly_recurrence_option: Joi.when('conf_recurrence_type', {
        is: 'weekly',
        then: Joi.object({
            recur_every_week: Joi.number().required().min(1).max(99),
            weekly_monday: Joi.boolean().required(),
            weekly_tuesday: Joi.boolean().required(),
            weekly_wednesday: Joi.boolean().required(),
            weekly_thursday: Joi.boolean().required(),
            weekly_friday: Joi.boolean().required(),
            weekly_saturday: Joi.boolean().required(),
            weekly_sunday: Joi.boolean().required()
        }).required(),
        otherwise: Joi.optional()
    }),
    monthly_recurrence_option: Joi.when('conf_recurrence_type', {
        is: 'monthly',
        then: Joi.object({
            monthly_option: Joi.string().required().valid('day', 'weekly'),
            monthly_day: Joi.number().optional().min(1).max(31),
            monthly_every_month: Joi.number().optional().min(1).max(99),
            monthly_day_of_week: Joi.string().optional().valid('First', 'Second', 'Third', 'Fourth', 'Last'),
            monthly_week: Joi.string().optional().valid('day', 'weekday', 'weekend day', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'),
            monthly_of_every_month: Joi.number().optional().min(1).max(99),
        }).required(),
        otherwise: Joi.optional()
    }),       
    yearly_recurrence_option: Joi.when('conf_recurrence_type', {
        is: 'yearly',
        then: Joi.object({
            recur_every_year: Joi.number().required().min(1).max(99),
            yearly_option: Joi.string().required().valid('monthly', 'weekly'),
            yearly_on_month: Joi.string().optional().valid('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'),
            yearly_on_month_day: Joi.number().optional().min(1).max(31),
            yearly_day_of_week: Joi.string().optional().valid('First', 'Second', 'Third', 'Fourth', 'Last'),
            yearly_week: Joi.string().optional().valid('day', 'weekday', 'weekend day', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'),
            yearly_of_every_month: Joi.string().optional().valid('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December')
        }).required(),
        otherwise: Joi.optional()
    }),
    conf_start_time: Joi.optional(),
    conf_end_time: Joi.optional(),   
    selectedParticipant: Joi.array().items(participantSchema).optional(),
    dids: Joi.array().items(didSchema).optional(),
    conf_end_date_option: Joi.number().required().valid(1, 2, 3),
    conf_end_after_occurence: Joi.number().optional().min(2).max(999),
    conf_end_date: Joi.date().optional(),
    conf_date: Joi.date().optional(),
    id_ac_audio: Joi.number().optional(),
});

let filterSchema = Joi.object().keys({
    id:Joi.string().required(),
    value:Joi.string().required()
});

let sortedSchema = Joi.object().keys({
    id:Joi.string().required(),
    desc:Joi.boolean().required()
});

let schemaListConference = Joi.object().keys({
    page: Joi.number().required(),
    pageSize: Joi.number().required(),    
    sorted: Joi.array().items(sortedSchema).optional(),
    filtered: Joi.array().items(filterSchema).optional()
});

let schemaDetailConference = Joi.object().keys({
    id: Joi.number().required()
});

let schemaDeleteConference = Joi.object().keys({
    id: Joi.number().required()
});

// function for validate schema schemaCreateConference
const validateCreateConference = (inputCreateConference) => {
    return Joi.validate(inputCreateConference, schemaCreateConference);
}

// function for validate schema schemaUpdateConference
const validateUpdateConference = (inputUpdateConference) => {
    return Joi.validate(inputUpdateConference, schemaUpdateConference);
}

// function for validate schema schemaListConference
const validateListConference = (inputListConference) => {
    return Joi.validate(inputListConference, schemaListConference);
}

// function for validate schema schemaDetailConference
const validateDetailConference = (inputDetailConference) => {
    return Joi.validate(inputDetailConference, schemaDetailConference);
}

// function for validate schema schemaDeleteConference
const validateDeleteConference = (inputDeleteConference) => {
    return Joi.validate(inputDeleteConference, schemaDeleteConference);
}

module.exports = {
    validateCreateConference,
    validateUpdateConference,
    validateListConference,
    validateDetailConference,
    validateDeleteConference
}