const Joi = require('joi');
/********************************************** Starts: Validation schema  ***************************************************/

// Make Schema for validation for cdr (call detail record)
let filterSchema = Joi.object().keys({
    id:Joi.string().required(),
    value:Joi.string().required()
});

let sortedSchema = Joi.object().keys({
    id:Joi.string().required(),
    desc:Joi.boolean().required()
});

let schemaCdr = Joi.object().keys({
    id_ac_conf: Joi.number().required(),
    page: Joi.number().required(),
    pageSize: Joi.number().required(),
    sorted: Joi.array().items(sortedSchema).optional(),
    filtered: Joi.array().items(filterSchema).optional()
});

// Make Schema for validation to get live participant users
let schemaLiveParticipantList = Joi.object().keys({
    id_ac_conf: Joi.number().required()
});

/********************************************** Starts: Validation function  ***************************************************/
// function for validate schema schemaCdr
const validateConferenceCdr = (inputCdr) => {
    return Joi.validate(inputCdr, schemaCdr);
}

// function for validate schema schemaLiveParticipantList
const validateConferenceLiveParticipantList = (inputLiveParticipantList) => {
    return Joi.validate(inputLiveParticipantList, schemaLiveParticipantList);
}

module.exports = {
    validateConferenceCdr,
    validateConferenceLiveParticipantList
}