const Joi = require('joi');
/********************************************** Starts: Validation schema  ***************************************************/

// Make Schema for validation for conference recording list
let filterSchema = Joi.object().keys({
    id:Joi.string().required(),
    value:Joi.string().required()
});

let sortedSchema = Joi.object().keys({
    id:Joi.string().required().optional(),
    desc:Joi.boolean().required()
});

let schemaConferenceRecordingList = Joi.object().keys({
    id_ac_conf: Joi.number().required(),
    page: Joi.number().required(),
    pageSize: Joi.number().required(),    
    sorted: Joi.array().items(sortedSchema).optional(),
    filtered: Joi.array().items(filterSchema).optional()
});

// Make Schema for validation for delete conference recording data
let schemaConferenceRecordingDelete = Joi.object().keys({
    id: Joi.number().required()
});

/********************************************** Starts: Validation function  ***************************************************/
// function for validate schema schemaConferenceRecordingList
const validateConferenceRecordingList = (inputConferenceRecordingList) => {
    return Joi.validate(inputConferenceRecordingList, schemaConferenceRecordingList);
}

// function for validate schema schemaConferenceRecordingDelete
const validateConferenceRecordingDelete = (inputConferenceRecordingDelete) => {
    return Joi.validate(inputConferenceRecordingDelete, schemaConferenceRecordingDelete);
}

module.exports = {
    validateConferenceRecordingList,
    validateConferenceRecordingDelete
}