// include all validation files
const audioConference = require("./audioConference");
const audioMessage = require("./audioMessage");
const recordingList = require("./recordingList");
const cdr = require("./cdr");

module.exports = {
    audioConference,
    audioMessage,
    recordingList,
    cdr
};