const BaseJoi = require('joi');
const dateFormat = require('dateformat');
const Extension = require('joi-date-extensions');
const Joi = BaseJoi.extend(Extension);
/********************************************** Starts: Validation schema  ***************************************************/

let filterSchema = Joi.object().keys({
    id:Joi.string().required(),
    value:Joi.string().required()
});

let sortedSchema = Joi.object().keys({
    id:Joi.string().required(),
    desc:Joi.boolean().required()
});

// Make Schema for validation for audio message list
let schemaListAudioMessage = Joi.object().keys({
    page: Joi.number().required(),
    pageSize: Joi.number().required(),
    audio_type: Joi.number().required(),
    sorted: Joi.array().items(sortedSchema).optional(),
    filtered: Joi.array().items(filterSchema).optional()
});

// Make Schema for validate add audio message
let schemaAddAudioMessage = Joi.object().keys({    
    audio_description: Joi.string().min(5).max(100).required().trim().regex(/^[\w\-\s]+$/),
    audio_type: Joi.number().required().valid(1,2,3),
    is_default_audio: Joi.boolean().required(),
    audio_file_id: Joi.string().required(),
    dids: Joi.array().items(Joi.number()).optional(),
    audio_duration: Joi.date().format("HH:mm:ss").required()
});


// Make Schema for validate update audio message
let schemaEditAudioMessage = Joi.object().keys({
    id: Joi.number().required(),
    audio_description: Joi.string().min(5).max(100).required().trim().regex(/^[\w\-\s]+$/),
    audio_type: Joi.number().required().valid(1,2,3),
    is_default_audio: Joi.boolean().required(),
    audio_file_id: Joi.string().required(),
    dids: Joi.array().items(Joi.number()).optional(),
    audio_duration: Joi.date().format("HH:mm:ss").required()
});

// Make Schema for validate delete audio message
let schemaDeleteAudioMessage = Joi.object().keys({
    id: Joi.number().required()
});

/********************************************** Starts: Validation function  ***************************************************/

// function for validate schema schemaWelcomeAudioMessageList

const validateListAudioMessage = (inputListAudioMessage) => {
    return Joi.validate(inputListAudioMessage, schemaListAudioMessage);
}

// function for validate schema schemaAddWelcomeAudioMessage
const validateAddAudioMessage = (inputAddAudioMessage) => {
    return Joi.validate(inputAddAudioMessage, schemaAddAudioMessage);
}

// function for validate schema schemaEditWelcomeAudioMessage
const validateEditAudioMessage = (inputEditAudioMessage) => {
    return Joi.validate(inputEditAudioMessage, schemaEditAudioMessage);
}

// function for validate scheme schemaDeleteWelcomeAudioMessage
const validateDeleteAudioMessage = (inputDeleteAudioMessage) => {
    return Joi.validate(inputDeleteAudioMessage, schemaDeleteAudioMessage);
}

module.exports = {
    validateAddAudioMessage,
    validateEditAudioMessage,
    validateDeleteAudioMessage,
    validateListAudioMessage
}