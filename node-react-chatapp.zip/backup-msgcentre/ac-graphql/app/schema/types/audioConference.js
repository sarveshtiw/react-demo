module.exports = `
    type audioConference {
        id: Int,
        conf_name: String,
        participant_limit: Int,
        conf_leaderpin: String,
        conf_participant_pin: String,
        id_ac_pop: Int,
        conf_date: String,
        conf_start_time : String,
        conf_end_time: String,
        conf_duration: String,
        auto_dial: Boolean,
        generate_new_pin: Boolean,
        send_invites: Boolean,
        record_conf: Boolean,
        participiant_on_mute: Boolean,
        participiant_on_hold: Boolean,
        end_conf_leader_hangs_up: Boolean,
        play_sound: Boolean,
        participiant_name_announced: Boolean,
        enable_touch_tone: Boolean,
        play_music_on_hold:  Boolean,                
        conf_recurrence_type: String,        
        hidden: Boolean,        
        participiants: [Int],
        dids: [Int],
        live_status: Int,
        conf_end_date_option:  Int,
        conf_end_after_occurence:  Int,
        conf_end_date:  String,
    }

    type audioConferenceDetail {
        id: Int,
        conf_name: String,
        participant_limit: Int,
        conf_leaderpin: String,
        conf_participant_pin: String,
        id_ac_pop: Int,
        conf_date: String,
        conf_start_time : String,
        conf_end_time: String,
        conf_duration: String,
        auto_dial: Boolean,
        generate_new_pin: Boolean,
        send_invites: Boolean,
        record_conf: Boolean,
        participiant_on_mute: Boolean,
        participiant_on_hold: Boolean,
        end_conf_leader_hangs_up: Boolean,
        play_sound: Boolean,
        participiant_name_announced: Boolean,
        enable_touch_tone: Boolean,
        play_music_on_hold:  Boolean,                
        conf_recurrence_type: String,        
        hidden: Boolean,        
        participiants: [Int],
        dids: [Int],
        live_status: Int,
        daily_recurrence_option : dailyConfData,
        weekly_recurrence_option: weeklyConfData,
        monthly_recurrence_option: monthlyConfData,
        yearly_recurrence_option: yearlyConfData,
        conf_end_date_option:  Int,
        conf_end_after_occurence:  Int,
        conf_end_date:  String,
    }

    type dailyConfData {
        daily_option: String
        daily_day_no: Int
    }
   
    type weeklyConfData {
        recur_every_week: Int,
        weekly_monday : Boolean,
        weekly_tuesday : Boolean,
        weekly_wednesday : Boolean,
        weekly_thursday : Boolean,
        weekly_friday : Boolean,
        weekly_saturday : Boolean,
        weekly_sunday : Boolean
    } 
    
    type monthlyConfData {
        monthly_option: String,
        monthly_day: Int,
        monthly_every_month: Int,
        monthly_week: String,
        monthly_day_of_week: String,
        monthly_of_every_month: Int
    }

    type yearlyConfData {
        recur_every_year: Int,
        yearly_option: String,
        yearly_on_month: String,
        yearly_on_month_day: Int,
        yearly_week: String,
        yearly_day_of_week: String,
        yearly_of_every_month: String,
    }     

    type commonOutput {
        message:String
    }

    input dailyRecurrenceObject {
        daily_option : String!,
        daily_day_no: Int!
    },

    input weeklyRecurrenceObject {
        recur_every_week: Int!,
        weekly_monday : Boolean!,
        weekly_tuesday : Boolean!,
        weekly_wednesday : Boolean!,
        weekly_thursday : Boolean!,
        weekly_friday : Boolean!,
        weekly_saturday : Boolean!,
        weekly_sunday : Boolean!,
    }

    input monthlyRecurrenceObject {
        monthly_option: String!,       
        monthly_day: Int,
        monthly_every_month: Int,
        monthly_week: String,
        monthly_day_of_week: String,
        monthly_of_every_month: Int
    }

    input yearlyRecurrenceObject {
        recur_every_year: Int!,
        yearly_option: String!,                
        yearly_on_month: String,
        yearly_on_month_day: Int,
        yearly_week: String,
        yearly_day_of_week: String,
        yearly_of_every_month: String,
    }    

    input updateAudioConference {
        id: Int!,
        conf_name: String!,
        participant_limit: Int!,
        conf_leaderpin: String!,
        conf_participant_pin: String!,
        id_ac_pop: Int!,
        conf_date: String,
        conf_start_time : String,        
        conf_end_time: String,
        conf_duration: String,
        auto_dial: Boolean!,
        generate_new_pin: Boolean,
        send_invites: Boolean!,
        record_conf: Boolean!,
        participiant_on_mute: Boolean!,
        participiant_on_hold: Boolean!,
        end_conf_leader_hangs_up: Boolean!,
        play_sound: Boolean!,
        participiant_name_announced: Boolean!,
        enable_touch_tone: Boolean!,
        play_music_on_hold:  Boolean!,
        conf_recurrence_type: String!
        delParticipiants: [Int],
        participiants: [Int],
        dids: [Int],
        delDids: [Int],
        daily_recurrence_option: dailyRecurrenceObject,
        weekly_recurrence_option: weeklyRecurrenceObject,
        monthly_recurrence_option: monthlyRecurrenceObject,   
        yearly_recurrence_option: yearlyRecurrenceObject,
        conf_end_date_option:  Int!,
        conf_end_after_occurence:  Int,
        conf_end_date:  String,
        id_ac_audio:Int
    }

    input createAudioConference {
        conf_name: String!,
        leader_name: String!,
        participant_limit: Int!,
        conf_leaderpin: String!,
        conf_participant_pin: String!,
        id_ac_pop: Int!,
        conf_date: String,
        on_hold_audio_id: String,
        conf_start_time : String, 
        conf_end_time: String,
        auto_dial:Boolean!,
        generate_new_pin: Boolean,
        send_invites: Boolean!,
        record_conf: Boolean!,
        participiant_on_mute: Boolean!,
        participiant_on_hold: Boolean!,
        end_conf_leader_hangs_up: Boolean!,
        play_sound: Boolean!,
        participiant_name_announced: Boolean!,       
        enable_touch_tone: Boolean!,
        play_music_on_hold:  Boolean!,
        conf_recurrence_type: String!
        selectedParticipant: [participantObj],
        dids: [didObj],
        daily_recurrence_option: dailyRecurrenceObject,
        weekly_recurrence_option: weeklyRecurrenceObject,
        monthly_recurrence_option: monthlyRecurrenceObject,   
        yearly_recurrence_option: yearlyRecurrenceObject,
        conf_end_date_option:  Int!,
        conf_end_after_occurence:  Int,
        conf_end_date:  String,
        id_ac_audio:Int
    }    

    input didObj {
        did: Int!,
        did_type: String!,        
    }
    
    input participantObj {
        id: Int!,
        email : String!,
        name : String!
    }

    input conferenceDetail {
        id: Int!
    }

    input deleteAudioConference {
        id : Int!
    }

    input aconfListInput{
        page:Int!,
        pageSize:Int!,
        sorted:[sortedObj]
        filtered:[filteredObj]
    }

    input sortedObj{
        id:String!,
        desc:Boolean!
    }

    input filteredObj{
        id:String!,
        value:String!
    }
    
    type conferenceListOutput{
        error:String,
        result:[audioConference],
        pages:Int        
    }

    type conferenceDetailOutput {
        details: audioConferenceDetail
    }
    
    type pins {
        pins: [Int]
    }  

    type Query {
        getAudioConferences (input: aconfListInput) : conferenceListOutput,
        getAudioConferenceDetailById (input: conferenceDetail) : conferenceDetailOutput,    
        checkPin(pin: [Int]) : pins
    }  
       
    type Mutation {
        createAudioConference(input: createAudioConference) : commonOutput,
        deleteAudioConference(input: deleteAudioConference) : commonOutput,
        updateAudioConference(input: updateAudioConference) : commonOutput
    }
`;