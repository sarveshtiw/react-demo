module.exports = `
    type audioMessage {
        id: Int,
        audio_description: String,
        audio_file_id: String,
        audio_file_url: String,
        audio_type: Int,
        audio_duration: String
        added_date: String,
        audioDid : [didObject],
        audioConf: [confObj]
    }

    type didObject {
        did : Int
    }

    type confObj {
        id: Int,
        conf_name: String
    }

    input inputAddAudioMessage {
        audio_description: String!,
        is_default_audio: Boolean!,
        audio_file_id: String!,
        audio_type: Int!,
        audio_duration: String!,   
        dids: [Int]
    }

    input inputEditAudioMessage {
        id: Int!,
        audio_description: String!,
        is_default_audio: Boolean!,
        audio_file_id: String!,
        audio_type: Int!,
        audio_duration: String!,
        dids: [Int]
    }

    input inputDeleteAudioMessage {
        id: Int!
    }

    input audioMessageList {
        page:Int!,
        pageSize:Int!,
        audio_type:Int,
        sorted:[sortedObj]
        filtered:[filteredObj]
    }
    
    type audioMessageListOutput{
        result:[audioMessage],
        pages:Int
    }

    type Query {
        getAudioMessages (input: audioMessageList) : audioMessageListOutput
    }
   
    type Mutation {
        addAudioMessage(input : inputAddAudioMessage) : commonOutput
        editAudioMessage(input : inputEditAudioMessage) : commonOutput
        deleteAudioMessage(input : inputDeleteAudioMessage) : commonOutput
    }
`;