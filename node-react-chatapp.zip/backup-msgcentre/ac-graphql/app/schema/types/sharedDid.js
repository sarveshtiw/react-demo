module.exports = `
    type sharedDid {
        id: Int,
        toll_free: Int,
        did: String,
        description: String,
        active: Boolean,
        country_name: String,
        city_name: String
    }

    input sharedDidList {
        page:Int!,
        pageSize:Int!,
        sorted:[sortedObj]
        filtered:[filteredObj]
    }
    
    type sharedDidListOutput{
        error:String,
        result:[sharedDid],
        pages:Int
    }

    type Query {
        getSharedDids (input: sharedDidList) : sharedDidListOutput
    }    
`;