module.exports = `
    type cdr {
        id: Int,
        fs_call_id: String,
        starttime: String,
        endtime: String,
        callerid: String,
        called_number: String,
        id_ac_conf: Int,
        is_moderator: Int,
        callermute: Int,        
        callervoicevol: String,
        callername: String,
        confmute: Int,
        confvol: String,
        initial_user: Int,
        outbound_fs_call_id: String,
        name_audio_file: String,
        bridge_charge: String,
        inbound_charge: String,
        misc_charge: String,
        total_cost: String,
        dialled_no:String
        fs_call_id: String,
        caller_id: String,
        called_number: String
    }

    input cdrList {
        id_ac_conf : Int!,
        page:Int!,
        pageSize:Int!,
        sorted:[sortedObj]
        filtered:[filteredObj]
    }

    input liveParticipantData {
        id_ac_conf : Int!
    }
    
    type cdrListOutput{
        error:String,
        result:[cdr],
        pages:Int
    }

    type liveParticipantOutput{
        result:[cdr]
    }
    type Query{
        getCdr (input: cdrList) : cdrListOutput
        getLiveParticipantsById (input: liveParticipantData) : liveParticipantOutput
    }
`;