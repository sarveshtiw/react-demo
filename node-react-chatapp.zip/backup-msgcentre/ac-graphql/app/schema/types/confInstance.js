module.exports = `
    type confInstance {
        id: Int,
        id_ac_conf: Int,
        ac_server_ip: Int,
        starttime: String,
        endtime: String,
        conf_report_sent: Int,
        recording_file_url: String
    }

    input confRecordingList {
        id_ac_conf : Int,
        page:Int!,
        pageSize:Int!,
        sorted:[sortedObj]
        filtered:[filteredObj]
    }
    
    type confRecordingListOutput{
        error:String,
        result:[confInstance],
        pages:Int
    }

    input deleteConferenceRecording {
        id : Int!
    }

    type Query{
        getConferenceRecordingById (input: confRecordingList) : confRecordingListOutput
    }
    type Mutation{
        deleteConferenceRecording (input : deleteConferenceRecording) : commonOutput
    }
`;