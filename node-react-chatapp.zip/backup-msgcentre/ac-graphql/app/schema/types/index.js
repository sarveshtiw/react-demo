const { mergeTypes } = require('merge-graphql-schemas');
const audioConference = require('./audioConference');
const audioMessage = require('./audioMessage');
const sharedDid = require('./sharedDid');
const confInstance = require('./confInstance');
const cdr = require('./cdr');

const types = [
    audioConference,
    audioMessage,
    sharedDid,
    confInstance,
    cdr
]
module.exports = mergeTypes(types);