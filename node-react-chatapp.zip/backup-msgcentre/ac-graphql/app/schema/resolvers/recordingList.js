const axios = require('axios');
const constant = require('./../../lib/constant');
const model = require('../../models');
const DEFAULT_CURSOR = 0;
const { fileStorageServerLink } = require('../../config').microservicesLinks;
const conferenceRecordingList = require('../../validation').recordingList;


module.exports = {
    Query: {
        getConferenceRecordingById: async(obj, args, context, info) => {
            try {
                // validate recording list request
                if (conferenceRecordingList.validateConferenceRecordingList(args.input).error) {
                    throw new Error(conferenceRecordingList.validateConferenceRecordingList(args.input).error.details[0].message);
                }
                const limit = args.input.limit || constant.DEFAULT_LIMIT;
                let orderBy = ['id', 'desc'],
                    whereBy = { id_ac_conf: args.input.id_ac_conf };

                // sorting results
                if (args.input.sorted && args.input.sorted.length > 0) {
                    typeof args.input.sorted[0].id === "string" ? args.input.sorted[0].id.toLowerCase() : args.input.sorted[0].id;
                    args.input.sorted[0].desc = args.input.sorted[0].desc ? "desc" : "asc";
                    orderBy[0] = args.input.sorted[0].id;
                    orderBy[1] = args.input.sorted[0].desc;
                }

                // filtered results
                if (args.input.filtered && args.input.filtered.length > 0) {
                    args.input.filtered.map((row, index) => {
                        switch (row.id) {
                            default: whereBy[row.id] = row.value;
                        }
                    });
                }

                const confRecordings = await model.AcConfInstance.findAndCountAll({
                    where: whereBy,
                    offset: ((args.input.page) * args.input.pageSize),
                    limit: args.input.pageSize,
                    order: [orderBy],
                    raw: true
                });

                let confRecordingList = [],
                    recordingFileArr = [],
                    result = [],
                    pages = 0;
                let fileObject = {};
                if (confRecordings.rows.length > 0) {                    
                    if(process.env.FILE_STORAGE_MANAGER_SERVICE_HOST && process.env.FILE_STORAGE_MANAGER_SERVICE_PORT){                        
                        //push all file url in array
                        confRecordings.rows.forEach(fileId => {
                            recordingFileArr.push(fileId.id_recording_file);
                        });
                        // getting file url from file storage API
                        var recordingFileUrls = await axios.post(fileStorageServerLink + 'files-get', {
                            files: recordingFileArr
                        });
                        
                        // check errors
                        /*
                        if (recordingFileUrls.data.errors.length > 0) {
                            throw new Error(recordingFileUrls.data.errors);
                        }    
                        */                        
                        if(recordingFileUrls.data.length >0){
                            recordingFileUrls.data.forEach( row => {
                                fileObject[row.fileId] = row.url;
                            });
                        }                        
                    }
                    result = confRecordings.rows.map(row => {
                        if (fileObject.hasOwnProperty([row.id_recording_file])) {
                            return {...row, recording_file_url: fileObject[row.id_recording_file] }
                        }
                        return {...row, recording_file_url: "" };
                    });
                }

                return { result, pages: Math.ceil(confRecordings.count / args.input.pageSize) };
            } catch (err) {
                throw new Error(err);
            }
        }
    },
    Mutation: {
        deleteConferenceRecording: async(obj, args, context, info) => {
            try {
                // validate delete recording list
                if (conferenceRecordingList.validateConferenceRecordingDelete(args.input).error) {
                    throw new Error(conferenceRecordingList.validateConferenceRecordingDelete(args.input).error.details[0].message);
                }
                let is_remove = await model.AcConfInstance.update({ is_deleted: 1, deleted_at: new Date() }, { where: { id: args.input.id, is_deleted: 0 } });
                if (is_remove[0]) {
                    return { message: constant.SUCCESS };
                }                
                return { message: `${constant.INVALID} conference id` };
            } catch (err) {
                throw new Error(err);
            }
        },
    }
}