/*
@Author : Manoj Kumar Pandey
@Date : 04/01/2018
@Description : Audio Conference queries and mutation
*/
const model = require('../../models');
const dateFormat = require('dateformat');
const conferenceValidation = require('../../validation').audioConference;
const constant = require('./../../lib/constant');
const DEFAULT_CURSOR = 0;
const moment = require('moment');
const axios = require('axios');
const { emailApiServerLink } = require('../../config/index').microservicesLinks;

module.exports = {
    Query: {
        getAudioConferences: async(obj, args, context, info) => {
            try {                             
                // validate conference list request
                if (conferenceValidation.validateListConference(args.input).error) {
                    throw new Error(conferenceValidation.validateListConference(args.input).error.details[0].message);
                }
                // checking logged-in user role to get the date
                let whereUser;
                if (context.user.rid == constant.ADMIN_ROLE) {
                    whereUser = { is_deleted : 0}; // for admin
                } else {
                    whereUser = { id_amp_user_profile: context.user.id }; // for user
                }

                const limit = args.input.limit || constant.DEFAULT_LIMIT;

                let orderBy = ['modified_at', 'desc'],
                    whereBy = {...whereUser };
                
                // sorting results
                if (args.input.sorted && args.input.sorted.length > 0) {
                    typeof args.input.sorted[0].id === "string" ? args.input.sorted[0].id.toLowerCase() : args.input.sorted[0].id;
                    args.input.sorted[0].desc = args.input.sorted[0].desc ? "desc" : "asc";
                    orderBy[0] = args.input.sorted[0].id;
                    orderBy[1] = args.input.sorted[0].desc;
                }

                // filtered results
                if (args.input.filtered && args.input.filtered.length > 0) {
                    args.input.filtered.map((row, index) => {
                        switch (row.id) {
                            case 'conf_name':
                                whereBy[row.id] = { $like: `%${row.value}%` };
                                break;
                            case 'conf_date':
                                whereBy[row.id] = { $gte: dateFormat(row.value, 'yyyy-mm-dd') };
                                break;
                            default:
                                whereBy[row.id] = row.value;
                        }
                    })
                }

                conferenceObj = await model.AudioConference.findAndCountAll({
                    where: whereBy,
                    offset: ((args.input.page) * args.input.pageSize),
                    limit: args.input.pageSize,
                    order: [orderBy],
                    raw: true
                });

                if (conferenceObj) {
                    var conferenceObjArr = conferenceObj.rows.map(async(confData, index) => {
                        let confObj = {
                            ...confData,
                            hidden: false
                        }
                            // get participants list
                        let participantsList = await model.AcConfParticipiant.findAll({ where: { id_ac_conf: confData.id }, attributes: ["id_cms_contact"], raw: true });

                        let participantsArr = [];
                        if (participantsList.length > 0) {
                            participantsList.forEach(participantId => {
                                participantsArr.push(participantId.id_cms_contact);
                            });
                        }
                        confObj.participiants = participantsArr;

                        // get dids list
                        let didsList = await model.AcConfDid.findAll({ where: { id_ac_conf: confData.id }, attributes: ["did"], raw: true });
                        let didsArr = [];
                        if (didsList.length > 0) {
                            didsList.forEach(didId => {
                                didsArr.push(didId.did);
                            });
                        }
                        confObj.dids = didsArr;
                        return (confObj);
                    });
                }
                return { result: conferenceObjArr, pages: Math.ceil(conferenceObj.count / args.input.pageSize) };
            } catch (err) {
                throw new Error(err);
            }
        },
        getAudioConferenceDetailById: async(obj, args, context, info) => {
            try {
                // validate input fields for conference detail
                if (conferenceValidation.validateDetailConference(args.input).error) {
                    throw new Error(conferenceValidation.validateDetailConference(args.input).error.details[0].message);
                }
                
                const confData = await model.AudioConference.findOne({
                    include: [{
                            model: model.AcRecurrenceDailyDetail,
                            as: 'daily',
                            required: false,
                            where: {
                                is_deleted: 0
                            }
                        },
                        {
                            model: model.AcRecurrenceWeeklyDetail,
                            as: 'weekly',
                            required: false,
                            where: {
                                is_deleted: 0
                            }
                        },
                        {
                            model: model.AcRecurrenceMonthlyDetail,
                            as: 'monthly',
                            required: false,
                            where: {
                                is_deleted: 0
                            }
                        },
                        {
                            model: model.AcRecurrenceYearlyDetail,
                            as: 'yearly',
                            required: false,
                            where: {
                                is_deleted: 0
                            }
                        }
                    ],
                    where: { is_deleted: 0, id: args.input.id },
                    raw: true
                });
                // if conference not found
                if (!confData) {
                    return { message: `${constant.INVALID} conference id` };
                }
                let confObj = {
                    ...confData,
                    hidden: false
                }                
                // recurrence data set in object
                if (confData.conf_recurrence_type === 'daily') {
                    confObj.daily_recurrence_option = {}
                    confObj.daily_recurrence_option.daily_option = confData['daily.daily_option'];
                    confObj.daily_recurrence_option.daily_day_no = confData['daily.daily_day_no'];
                } else if (confData.conf_recurrence_type === 'weekly') {
                    confObj.weekly_recurrence_option = {}
                    confObj.weekly_recurrence_option.recur_every_week = confData['weekly.recur_every_week'];
                    confObj.weekly_recurrence_option.weekly_sunday = confData['weekly.weekly_sunday'];
                    confObj.weekly_recurrence_option.weekly_monday = confData['weekly.weekly_monday'];
                    confObj.weekly_recurrence_option.weekly_tuesday = confData['weekly.weekly_tuesday'];
                    confObj.weekly_recurrence_option.weekly_wednesday = confData['weekly.weekly_wednesday'];
                    confObj.weekly_recurrence_option.weekly_thursday = confData['weekly.weekly_thursday'];
                    confObj.weekly_recurrence_option.weekly_friday = confData['weekly.weekly_friday'];
                    confObj.weekly_recurrence_option.weekly_saturday = confData['weekly.weekly_saturday'];
                    confObj.weekly_recurrence_option.weekly_sunday = confData['weekly.weekly_sunday'];
                } else if (confData.conf_recurrence_type === 'monthly') {
                    confObj.monthly_recurrence_option = {}                    
                    confObj.monthly_recurrence_option.monthly_option = confData['monthly.monthly_option'];
                    confObj.monthly_recurrence_option.monthly_day = confData['monthly.monthly_day'];
                    confObj.monthly_recurrence_option.monthly_every_month = confData['monthly.monthly_every_month']
                    confObj.monthly_recurrence_option.monthly_week = confData['monthly.monthly_week']
                    confObj.monthly_recurrence_option.monthly_day_of_week = confData['monthly.monthly_day_of_week'];
                    confObj.monthly_recurrence_option.monthly_of_every_month = confData['monthly.monthly_of_every_month'];
                } else if (confData.conf_recurrence_type === 'yearly') {
                    confObj.yearly_recurrence_option = {}
                    confObj.yearly_recurrence_option.recur_every_year = confData['yearly.recur_every_year'];
                    confObj.yearly_recurrence_option.yearly_option = confData['yearly.yearly_option'];
                    confObj.yearly_recurrence_option.yearly_on_month = confData['yearly.yearly_on_month'];
                    confObj.yearly_recurrence_option.yearly_on_month_day = confData['yearly.yearly_on_month_day'];
                    confObj.yearly_recurrence_option.yearly_week = confData['yearly.yearly_week'];
                    confObj.yearly_recurrence_option.yearly_day_of_week = confData['yearly.yearly_day_of_week'];
                    confObj.yearly_recurrence_option.yearly_of_every_month = confData['yearly.yearly_of_every_month'];
                }
                // get participants list
                let participantsList = await model.AcConfParticipiant.findAll({ where: { id_ac_conf: args.input.id, is_deleted: 0 }, attributes: ["id_cms_contact"], raw: true });
                let participantsArr = [];
                if (participantsList.length > 0) {
                    participantsList.forEach(participantId => {
                        participantsArr.push(participantId.id_cms_contact);
                    });
                }
                confObj.participiants = participantsArr;
                // get dids list
                let didsList = await model.AcConfDid.findAll({ where: { id_ac_conf: args.input.id, is_deleted: 0 }, attributes: ["did"], raw: true });
                let didsArr = [];
                if (didsList.length > 0) {
                    didsList.forEach(didId => {
                        didsArr.push(didId.did);
                    });
                }
                confObj.dids = didsArr;
                return { details: confObj };
            } catch (err) {
                throw new Error(err);
            }
        },
        checkPin: async(obj, args, context, info) => {
            try {
                let allPins = new Set(args.pin);
                const userPins = await model.AudioConference.findAll({
                    attributes: ['conf_leaderpin', 'conf_participant_pin'],
                    raw: true,
                    where: {
                        $or: {
                            conf_leaderpin: { $in: args.pin },
                            conf_participant_pin: { $in: args.pin },
                        }
                    }
                }).then((result) => {
                    result.forEach(function(element) {
                        allPins.delete(parseInt(element.conf_leaderpin));
                        allPins.delete(parseInt(element.conf_participant_pin));
                    }, this);
                    return result;
                });
                return { pins: [...allPins] };
            } catch (err) {
                throw new Error(err);
            }
        }
    },
    Mutation: {
        createAudioConference: async(obj, args, context, info) => {
            try {
                // validate input fields for conference
                if (conferenceValidation.validateCreateConference(args.input).error) {
                    console.log(conferenceValidation.validateCreateConference(args.input).error.details[0].path);
                    throw new Error(conferenceValidation.validateCreateConference(args.input).error.details[0].message);
                }
                /*
                //validate participant and leader pin length               
                if (args.input.conf_leaderpin.toString().length < constant.DEFAULT_LEADER_PIN_LENGTH || args.input.conf_leaderpin.toString().length > constant.DEFAULT_LEADER_PIN_LENGTH) {
                    throw new Error(`Leader pin length should be ${constant.DEFAULT_LEADER_PIN_LENGTH}`);
                }

                if (args.input.conf_participant_pin.toString().length < constant.DEFAULT_PARTICIPANT_PIN_LENGTH || args.input.conf_participant_pin.toString().length > constant.DEFAULT_PARTICIPANT_PIN_LENGTH) {
                    throw new Error(`Participant pin length should be ${constant.DEFAULT_PARTICIPANT_PIN_LENGTH}`);
                }
                */
                const insObj = args.input;
                insObj.id_amp_company = context.user.cid || 0;
                insObj.id_amp_user_profile = context.user.id;
                insObj.modified_by = context.user.id;
                args.input.conf_start_time = (args.input.conf_start_time == "" ? null : args.input.conf_start_time);
                args.input.conf_end_time = (args.input.conf_end_time == "" ? null : args.input.conf_end_time);                
                const confObj = await model.AudioConference.findOrCreate({
                    where: {
                        $or: {
                            conf_name: args.input.conf_name,
                            conf_leaderpin: args.input.conf_leaderpin,
                            conf_participant_pin: args.input.conf_participant_pin,
                        },
                        is_deleted: 0,
                        id_amp_company: context.user.cid
                    },
                    defaults: insObj,
                    raw: true
                });

                // return error with existing check                
                if (confObj[1] == false) {
                    if (confObj[0].conf_name == args.input.conf_name) {
                        throw new Error(`Coference name "${args.input.conf_name}" is ${constant.ALREADY_EXIST.toLowerCase()} `);
                    }
                    if (confObj[0].conf_leaderpin == args.input.conf_leaderpin) {
                        throw new Error(`Coference leader pin "${args.input.conf_leaderpin}" is ${constant.ALREADY_EXIST.toLowerCase()} `);
                    }
                    if (confObj[0].conf_participant_pin == args.input.conf_participant_pin) {
                        throw new Error(`Coference participant pin "${args.input.conf_participant_pin}" is ${constant.ALREADY_EXIST.toLowerCase()} `);
                    }
                }

                if (confObj[1]) {
                    let conf_id = confObj[0].dataValues.id;
                    if (args.input.conf_recurrence_type === 'daily') {
                        args.input.daily_recurrence_option.id_ac_conf = conf_id;
                        const confDailyObj = await model.AcRecurrenceDailyDetail.create(args.input.daily_recurrence_option);
                    }
                    if (args.input.conf_recurrence_type === 'weekly') {
                        args.input.weekly_recurrence_option.id_ac_conf = conf_id;
                        const confWeeklyObj = await model.AcRecurrenceWeeklyDetail.create(args.input.weekly_recurrence_option);
                    }
                    if (args.input.conf_recurrence_type === 'monthly') {
                        args.input.monthly_recurrence_option.id_ac_conf = conf_id;
                        const confMonthlyObj = await model.AcRecurrenceMonthlyDetail.create(args.input.monthly_recurrence_option);
                    }
                    if (args.input.conf_recurrence_type === 'yearly') {
                        args.input.yearly_recurrence_option.id_ac_conf = conf_id;
                        const confYearlyObj = await model.AcRecurrenceYearlyDetail.create(args.input.yearly_recurrence_option);
                    }
                    
                    // add participiants for conference
                    if (args.input.selectedParticipant && args.input.selectedParticipant.length > 0) {                        
                        let participiantsArr = [];
                        // create participiants object                        
                        args.input.selectedParticipant.forEach(function(participiant) {
                            participiantsArr.push({ "id_ac_conf": conf_id, "id_cms_contact": participiant.id });
                        });
                        const participiantsAdd = await model.AcConfParticipiant.bulkCreate(participiantsArr);
                    }

                    // add Dids for conference
                    if (args.input.dids && args.input.dids.length > 0) {
                        let didsArr = [];
                        args.input.dids.forEach( (did) => {
                            didsArr.push({ "id_ac_conf": conf_id, "did": did.did, "did_type": did.did_type });
                        });
                        const dedicatedDidAdd = await model.AcConfDid.bulkCreate(didsArr);
                    }
                    
                    // send email to participants
                    if (args.input.selectedParticipant && args.input.selectedParticipant.length > 0 && process.env.EMAIL_SERVICE_SERVICE_HOST && process.env.EMAIL_SERVICE_SERVICE_PORT) {
                        var dids = '';
                        if(args.input.dids && args.input.dids.length >0){
                            dids = args.input.dids.map(didId => didId.did);
                            dids = dids.join();
                        }
                        const emailSend = axios.post(emailApiServerLink + 'send-mail', {
                            "service": constant.EMAIL_SERVICE_NAME,
                            "template": "participantInvitation",
                            "templateData": {
                                "conf_name": args.input.conf_name,
                                "dids": dids,
                                "conf_leaderpin": args.input.conf_leaderpin,
                                "conf_participant_pin": args.input.conf_leaderpin,
                                "conf_date": args.input.conf_start_time,
                                "conf_time": args.input.conf_end_time,
                                "leader_name": args.input.leader_name
                            },
                            "subject": "Synthesis - New Meeting Invite",
                            "users": args.input.selectedParticipant
                        }).catch((err) => {
                            console.log(err);
                        });
                    }
                }
                return { message: constant.SUCCESS };
            } catch (err) {
                console.log(err.message);
                throw new Error(err);
            }
        }, 
        updateAudioConference: async(obj, args, context, info) => {
            try {
                // validate input fields for conference
                if (conferenceValidation.validateUpdateConference(args.input).error) {
                    throw new Error(conferenceValidation.validateUpdateConference(args.input).error.details[0].message);
                }
                /*
                //validate participant and leader pin length               
                if (args.input.conf_leaderpin.toString().length < constant.DEFAULT_LEADER_PIN_LENGTH || args.input.conf_leaderpin.toString().length > constant.DEFAULT_LEADER_PIN_LENGTH) {
                    throw new Error(`Leader pin length should be ${constant.DEFAULT_LEADER_PIN_LENGTH}`);
                }
                if (args.input.conf_participant_pin.toString().length < constant.DEFAULT_PARTICIPANT_PIN_LENGTH || args.input.conf_participant_pin.toString().length > constant.DEFAULT_PARTICIPANT_PIN_LENGTH) {
                    throw new Error(`Participant pin length should be ${constant.DEFAULT_PARTICIPANT_PIN_LENGTH}`);
                }
                */
                let getConf = await model.AudioConference.find({
                    where: { id: args.input.id, is_deleted: 0},
                    raw: true
                });
                if (getConf) {
                    //check already exist check for conf name, leader pin or participant pin
                    let checkExist = await model.AudioConference.findOne({
                        where: {
                            $or: { conf_name: args.input.conf_name, conf_leaderpin: args.input.conf_leaderpin, conf_participant_pin: args.input.conf_participant_pin },
                            id: { $ne: args.input.id },
                            is_deleted: 0,
                            id_amp_company: context.user.id_amp_company
                        },
                        raw: true
                    });

                    // return error with existing check
                    if (checkExist) {
                        if (checkExist.conf_name == args.input.conf_name) {
                            throw new Error(`Coference name "${args.input.conf_name}" is ${constant.ALREADY_EXIST.toLowerCase()} `);
                        }
                        if (checkExist.conf_leaderpin == args.input.conf_leaderpin) {
                            throw new Error(`Coference leader pin "${args.input.conf_leaderpin}" is ${constant.ALREADY_EXIST.toLowerCase()} `);
                        }
                        if (checkExist.conf_participant_pin == args.input.conf_participant_pin) {
                            throw new Error(`Coference participant pin "${args.input.conf_participant_pin}" is ${constant.ALREADY_EXIST.toLowerCase()} `);
                        }
                    }
                    args.input.modified_at = new Date();
                    args.input.modified_by = context.user.id;
                    // update conference data
                    let updateData = await model.AudioConference.update(args.input, { where: { id: args.input.id, is_deleted: 0 } });
                    let recType, recData, updateRec;

                    // set model and recurrence option data
                    if (args.input.conf_recurrence_type === 'daily') {
                        recType = model.AcRecurrenceDailyDetail;
                        recData = args.input.daily_recurrence_option;
                    } else if (args.input.conf_recurrence_type === 'weekly') {
                        recType = model.AcRecurrenceWeeklyDetail;
                        recData = args.input.weekly_recurrence_option;
                    } else if (args.input.conf_recurrence_type === 'monthly') {
                        recType = model.AcRecurrenceMonthlyDetail;
                        recData = args.input.monthly_recurrence_option;
                    } else if (args.input.conf_recurrence_type === 'yearly') {
                        recType = model.AcRecurrenceYearlyDetail;
                        recData = args.input.yearly_recurrence_option;
                    }

                    // update recurrence data
                    if (getConf.conf_recurrence_type === args.input.conf_recurrence_type) {
                        if (args.input.conf_recurrence_type !== "none") {
                            updateRec = await recType.update(recData, { where: { id_ac_conf: args.input.id } });
                        }
                        return { message: constant.SUCCESS };
                    } else {
                        let rec;
                        if (getConf.conf_recurrence_type === 'daily') {
                            rec = model.AcRecurrenceDailyDetail;
                        } else if (getConf.conf_recurrence_type === 'weekly') {
                            rec = model.AcRecurrenceWeeklyDetail;
                        } else if (getConf.conf_recurrence_type === 'monthly') {
                            rec = model.AcRecurrenceMonthlyDetail;
                        } else if (getConf.conf_recurrence_type === 'yearly') {
                            rec = model.AcRecurrenceYearlyDetail;
                        }
                        // update previous recurrence is_deleted status                        
                        if(getConf.conf_recurrence_type !=="none"){
                            updateRec = await rec.update({ is_deleted: 1, deleted_at: new Date() }, { where: { id_ac_conf: args.input.id } });
                        }
                        if (args.input.conf_recurrence_type !== "none") {
                            recData.id_ac_conf = args.input.id;
                            let recAdd = await recType.findOrCreate({
                                where: { id_ac_conf: args.input.id },
                                defaults: recData,
                                raw: true
                            });
                            if (recAdd[1] == false) {
                                recData.is_deleted = 0;
                                recData.deleted_at = null;
                                let addNewDeleteParticipiants = await recType.update(recData, {
                                    where: { id_ac_conf: args.input.id }
                                });
                            }
                        }
                        return { message: constant.SUCCESS };
                    }

                    //delete participiants
                    if (args.input.delParticipiants && args.input.delParticipiants.length > 0) {
                        let is_update = await model.AcConfParticipiant.update({
                            is_deleted: 1,
                            deleted_at: new Date()
                        }, {
                            where: { id_cms_contact: { $in: args.input.delParticipiants }, is_deleted: 0, id_ac_conf: args.input.id }
                        });
                    }

                    // add new dids
                    if (args.input.participiants && args.input.participiants.length > 0) {
                        args.input.participiants.map(async function(pId) {
                            let addNewParticipiants = await model.AcConfParticipiant.findOrCreate({
                                where: { id_ac_conf: args.input.id, id_cms_contact: pId },
                                defaults: {
                                    id_ac_conf: args.input.id,
                                    id_cms_contact: pId,
                                    is_deleted: 0,
                                    deleted_at: 'NULL'
                                },
                                raw: true
                            });
                            if (addNewParticipiants[1] == false) {
                                let addNewDeleteParticipiants = await model.AcConfParticipiant.update({
                                    is_deleted: 0,
                                    deleted_at: 'NULL'
                                }, {
                                    where: { id_ac_conf: args.input.id, id_cms_contact: pId }
                                });
                            }
                        });
                    }

                    // add new dids
                    if (args.input.dids && args.input.dids.length > 0) {
                        args.input.dids.map(async function(did) {
                            let addNewDids = await model.AcConfDid.findOrCreate({
                                where: { id_ac_conf: args.input.id, did: did },
                                defaults: {
                                    id_ac_conf: args.input.id,
                                    did: did,
                                    is_deleted: 0,
                                    deleted_at: 'NULL'
                                },
                                raw: true
                            });
                            if (addNewDids[1] == false) {
                                let addNewDeleteDids = await model.AcConfDid.update({
                                    is_deleted: 0,
                                    deleted_at: 'NULL'
                                }, {
                                    where: { id_ac_conf: args.input.id, did: did }
                                });
                            }
                        });
                    }
                    //delete dids
                    if (args.input.delDids && args.input.delDids.length > 0) {
                        let is_update = await model.AcConfDid.update({
                            is_deleted: 1,
                            deleted_at: new Date()
                        }, {
                            where: { did: { $in: args.input.delDids }, is_deleted: 0, id_ac_conf: args.input.id }
                        });
                    }
                    return { message: constant.SUCCESS };
                }
                throw new Error(`${constant.INVALID} conference id`);
            } catch (err) {
                return err
            }
        },
        deleteAudioConference: async(obj, args, context, info) => {
            try {
                // validate input fields for delete conference
                if (conferenceValidation.validateDeleteConference(args.input).error) {
                    throw new Error(conferenceValidation.validateDeleteConference(args.input).error.details[0].message);
                }

                let is_remove = await model.AudioConference.update({ is_deleted: 1, deleted_at: new Date() }, { where: { id: args.input.id, is_deleted: 0 } });
                if (is_remove[0]) {
                    return { message: constant.SUCCESS };
                }
                return { message: `${constant.INVALID} conference id` };
            } catch (err) {
                throw new Error(err);
            }
        },
    }
}