const { mergeResolvers } = require('merge-graphql-schemas');
const audioConference = require('./audioConference');
const audioMessage = require('./audioMessage');
const sharedDid = require('./sharedDid');
const recordingList = require('./recordingList');
const cdr = require('./cdr');

const resolvers = [
    audioConference,
    audioMessage,
    sharedDid,
    recordingList,
    cdr
]
module.exports = mergeResolvers(resolvers);