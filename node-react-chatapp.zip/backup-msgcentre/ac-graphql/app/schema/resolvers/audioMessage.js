const axios = require('axios');
const {
    fileStorageServerLink
} = require('../../config/index').microservicesLinks;
const model = require('../../models');
const audioMessageValidation = require('../../validation').audioMessage;
const constant = require('./../../lib/constant');
const DEFAULT_CURSOR = 0;
const dateFormat = require('dateformat');

module.exports = {
    Query: {
        getAudioMessages: async (obj, args, context, info) => {
            try {
                const limit = args.input.limit || constant.DEFAULT_LIMIT;
                const cursor = args.input.cursor || DEFAULT_CURSOR;
                // validate request
                if (audioMessageValidation.validateListAudioMessage(args.input).error) {
                    throw new Error(audioMessageValidation.validateListAudioMessage(args.input).error.details[0].message);
                }

                // checking logged-in user role to get the date
                let whereBy = {is_deleted: 0,audio_type:args.input.audio_type};
                if (context.user.rid != constant.ADMIN_ROLE) {
                    whereBy = {
                        ...whereBy, id_amp_user_profile: context.user.id
                    }; // for user
                }
                // sorting result
                let orderBy = ['id', 'asc'];
                if (args.input.sorted && args.input.sorted.length > 0) {
                    typeof args.input.sorted[0].id === "string" ? args.input.sorted[0].id.toLowerCase() : args.input.sorted[0].id;
                    args.input.sorted[0].desc = args.input.sorted[0].desc ? "desc" : "asc";
                    orderBy[0] = args.input.sorted[0].id;
                    orderBy[1] = args.input.sorted[0].desc;
                }

                //filtered result
                if (args.input.filtered && args.input.filtered.length > 0) {
                    args.input.filtered.map((row, index) => {
                        switch (row.id) {
                            case 'audio_description':
                                whereBy[row.id] = {
                                    $like: `%${row.value}%`
                                };
                                break;
                            case 'audio_type':
                            whereBy[row.id] = {
                                $like: `%${row.value}%`
                            };
                            break;
                            default:
                                whereBy[row.id] = row.value;
                        }
                    })
                }
                var associationObj;                
                if(args.input.audio_type == 1){                    
                    associationObj = {
                        model: model.AcDidAudio,
                        attributes: ['did'],
                        as: 'audioDid'
                    }
                }
                else if(args.input.audio_type == 3){
                    associationObj = {
                        model: model.AudioConference,
                        attributes: ['id','conf_name'],
                        as: 'audioConf'
                    }
                }
                
                const audioMessageList = await model.AcAudioMessage.findAndCountAll({
                    attributes: ['id', 'audio_description', 'audio_duration', 'audio_type', 'created_at', 'audio_file_id'],
                    include: associationObj,
                    where: whereBy,
                    offset: ((args.input.page) * args.input.pageSize),
                    limit: args.input.pageSize,
                    order: [orderBy]
                });
                const audioFile = [];
                const acAudioFileArr = [];
                let result = [];
                let fileObject = {};
                //let audioFileUrls;
                if (audioMessageList.rows.length > 0) {
                    // push all audio file in url
                    audioMessageList.rows.forEach(data => {
                        audioFile.push(data.audio_file_id);
                    });
                    // sending request to file storage API to get audio file url                  
                    /*
                    if (process.env.FILE_STORAGE_MANAGER_SERVICE_HOST && process.env.FILE_STORAGE_MANAGER_SERVICE_PORT) {
                        let audioFileUrls = await axios.post(fileStorageServerLink + 'files-get', {
                            files: audioFile
                        });
                        console.log(audioFileUrls.data);
                        // check errors
                        /*
                        if (audioFileUrls.data.errors.length > 0) {
                            throw new Error(audioFileUrls.data.errors);
                        } 
                        if (audioFileUrls.data.length > 0) {
                            audioFileUrls.data.forEach(row => {
                                fileObject[row.fileId] = row.url;
                            });
                        }
                    }
                    */
                    result = audioMessageList.rows.map(row => {
                        added_date = dateFormat(row.created_at, "dd/mm/yyyy");
                        audio_file_url = '';
                        if (fileObject.hasOwnProperty([row.audio_file_id])) {
                            audio_file_url = fileObject[row.audio_file_id];
                        }                        
                        return { ...row.dataValues,
                            added_date,
                            audio_file_url
                        }
                    });
                }
                return {
                    result,
                    pages: Math.ceil(audioMessageList.count / args.input.pageSize)
                };
            } catch (err) {
                console.log(err.message);
                throw new Error(err);
            }
        }
    },
    Mutation: {
        addAudioMessage: async (obj, args, context, info) => {
            try {
                // validate request
                if (audioMessageValidation.validateAddAudioMessage(args.input).error) {
                    throw new Error(audioMessageValidation.validateAddAudioMessage(args.input).error.details[0].message);
                }

                args.input.id_amp_user_profile = context.user.id;
                args.input.id_amp_company = context.user.cid || 0;
                args.input.modified_by = context.user.id;
                // add audio message
                const audioMessage = await model.AcAudioMessage.create(args.input);

                if (audioMessage) {
                    // add new dids 
                    if (args.input.audio_type ==1 && args.input.dids && args.input.dids.length > 0) {
                        args.input.dids.map(async function (did) {
                            let addNewDids = await model.AcDidAudio.findOrCreate({
                                where: {
                                    did: did
                                },
                                defaults: {
                                    id_ac_audio: audioMessage.dataValues.id,
                                    did: did,
                                    last_modified_at: new Date()
                                },
                                raw: true
                            });
                            if (addNewDids[1] == false) {
                                let addNewDeleteDids = await model.AcDidAudio.update({
                                    id_ac_audio: audioMessage.dataValues.id,
                                    last_modified_at: new Date()
                                }, {
                                    where: {
                                        did: did
                                    }
                                });
                            }
                        });
                    }
                    return {
                        message: constant.SUCCESS
                    };
                }

                return {
                    message: constant.DB_ERROR
                };
            } catch (err) {
                throw new Error(err);
            }
        },
        editAudioMessage: async (obj, args, context, info) => {
            try {
                // validation
                if (audioMessageValidation.validateEditAudioMessage(args.input).error) {
                    throw new Error(audioMessageValidation.validateEditAudioMessage(args.input).error.details[0].message);
                }
                args.input.modified_by = context.user.id;
                args.input.modified_at = new Date();
                //update audio message
                let is_update = await model.AcAudioMessage.update(args.input, {
                    where: {
                        id: args.input.id,
                        is_deleted: 0
                    }
                });
                if (is_update[0]) {
                    // add new dids
                    if (args.input.audio_type == 1 && args.input.dids && args.input.dids.length > 0) {
                        args.input.dids.map(async function (did) {
                            let addNewDids = await model.AcDidAudio.findOrCreate({
                                where: {
                                    did: did
                                },
                                defaults: {
                                    id_ac_audio: args.input.id,
                                    did: did,
                                    last_modified_at: new Date()
                                },
                                raw: true
                            });
                            if (addNewDids[1] == false) {
                                let addNewDeleteDids = await model.AcDidAudio.update({
                                    id_ac_audio: args.input.id,
                                    last_modified_at: new Date()
                                }, {
                                    where: {
                                        did: did
                                    }
                                });
                            }
                        });
                    }
                    // delete remaining dids of Audio file which doesn't exist in dids array
                    if (args.input.dids && args.input.dids.length > 0) {
                        let deleteDids = await model.AcDidAudio.destroy({
                            where: {
                                did: {
                                    $notIn: args.input.dids
                                },
                                id_ac_audio: args.input.id
                            }
                        });
                    }
                    return {
                        message: constant.SUCCESS
                    };
                }
                return {
                    message: `${constant.INVALID} audio id`
                };
            } catch (err) {
                throw new Error(err);
            }
        },
        deleteAudioMessage: async (obj, args, context, info) => {
            try {
                // validate delete request
                if (audioMessageValidation.validateDeleteAudioMessage(args.input).error) {
                    throw new Error(audioMessageValidation.validateDeleteAudioMessage(args.input).error.details[0].message);
                }
                let is_remove = await model.AcAudioMessage.update({
                    is_deleted: 1,
                    deleted_at: new Date()
                }, {
                    where: {
                        id: args.input.id,
                        is_deleted: 0
                    }
                });
                if (is_remove[0]) {
                    // delete did relation
                    await model.AcDidAudio.destroy({
                        where: {
                            id_ac_audio: args.input.id
                        }
                    });
                    return {
                        message: constant.SUCCESS
                    };
                }
                return {
                    message: `${constant.INVALID} audio id`
                };
            } catch (err) {
                throw new Error(err);
            }
        }
    }
}