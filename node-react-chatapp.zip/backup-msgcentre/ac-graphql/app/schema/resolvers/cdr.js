const constant = require('./../../lib/constant');
const model = require('../../models');
const DEFAULT_CURSOR = 0;
const cdr = require('../../validation').cdr;

module.exports = {
    Query: {
        getCdr: async(obj, args, context, info) => {
            try {
                // validate recording list request
                 if (cdr.validateConferenceCdr(args.input).error) {
                    throw new Error(cdr.validateConferenceCdr(args.input).error.details[0].message);
                }
                const limit = args.input.limit || constant.DEFAULT_LIMIT;
                let orderBy = ['id', 'desc'],
                    whereBy = { id_ac_conf: args.input.id_ac_conf };
                
                // sorting result
                if (args.input.sorted && args.input.sorted.length > 0) {
                    typeof args.input.sorted[0].id === "string" ? args.input.sorted[0].id.toLowerCase() : args.input.sorted[0].id;
                    args.input.sorted[0].desc = args.input.sorted[0].desc ? "desc" : "asc";
                    orderBy[0] = args.input.sorted[0].id;
                    orderBy[1] = args.input.sorted[0].desc;
                }
                
                // filtered result
                if (args.input.filtered && args.input.filtered.length > 0) {
                    args.input.filtered.map((row, index) => {
                        switch (row.id) {
                            default: whereBy[row.id] = row.value;
                        }
                    });
                }

                let result = [];
                let pages = 0;
                const cdrList = await model.AcParticipant.findAndCountAll({
                    where: whereBy,
                    offset: ((args.input.page) * args.input.pageSize),
                    limit: args.input.pageSize,
                    order: [orderBy],
                    raw: true
                });

                if (cdrList.rows.length > 0) {
                    result = cdrList.rows.map(row => {
                        return {
                            ...row,
                            bridge_charge: "$0.00",
                            inbound_charge: "$0.00",
                            misc_charge: "$0.00",
                            total_cost: "$0.00",
                            dialled_no: "202-555-0101"
                        }
                    });
                }
                return { result, pages: Math.ceil(cdrList.count / args.input.pageSize) };
            } catch (err) {
                throw new Error(err);
            }
        },
        getLiveParticipantsById: async(obj, args, context, info) => {
            try {
                // validate recording list request
                if (cdr.validateConferenceLiveParticipantList(args.input).error) {
                    throw new Error(cdr.validateConferenceLiveParticipantList(args.input).error.details[0].message);
                }
                // get live participant data
                let orderBy = ['id', 'desc'],
                    whereBy = { id_ac_conf: args.input.id_ac_conf, endtime: null };

                let result = [];
                let pages = 0;
                const cdrList = await model.AcParticipant.findAll({
                    where: whereBy,
                    order: [orderBy],
                    raw: true
                });
                return { result: cdrList };
            } catch (err) {
                throw new Error(err);
            }
        }
    }
}