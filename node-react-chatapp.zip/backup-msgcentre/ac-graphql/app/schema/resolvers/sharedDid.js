const axios = require('axios');
const constant = require('./../../lib/constant');
const model = require('../../models');
const DEFAULT_CURSOR = 0;
const { multiDbAccessManagerLink } = require('../../config').microservicesLinks;

module.exports = {
    Query: {
        getSharedDids: async(obj, args, context, info) => {
            try {
                const limit = args.input.limit || constant.DEFAULT_LIMIT;
                let orderBy = ['id', 'desc'],
                    whereBy = {};
                // sorting result
                if (args.input.sorted && args.input.sorted.length > 0) {
                    typeof args.input.sorted[0].id === "string" ? args.input.sorted[0].id.toLowerCase() : args.input.sorted[0].id;
                    args.input.sorted[0].desc = args.input.sorted[0].desc ? "desc" : "asc";
                    orderBy[0] = args.input.sorted[0].id;
                    orderBy[1] = args.input.sorted[0].desc;
                }
                //filtered result
                if (args.input.filtered && args.input.filtered.length > 0) {
                    args.input.filtered.map((row, index) => {
                        switch (row.id) {
                            case 'city_name':
                                whereBy[row.id] = { $like: `%${row.value}%` };
                                break;
                            default:
                                whereBy[row.id] = row.value;
                        }
                    })
                }

                const sharedDids = await model.AcSharedDid.findAndCountAll({
                    where: whereBy,
                    offset: ((args.input.page) * args.input.pageSize),
                    limit: args.input.pageSize,
                    order: [orderBy],
                    raw: true
                });

                const countryIds = [];
                const cityIds = [];
                let sharedDidsArr = [];
                if (sharedDids.rows.length > 0 && process.env.MULTI_DB_ACCESS_MANAGER_SERVICE_HOST && process.env.MULTI_DB_ACCESS_MANAGER_SERVICE_HOST) {
                    //getting country and city name from multi db access manager service
                    sharedDids.rows.forEach(data => {
                        countryIds.push(data.id_country);
                    });

                    sharedDids.rows.forEach(data => {
                        cityIds.push(data.id_city);
                    });

                    const countryData = await axios.post(`${multiDbAccessManagerLink}country`, {
                        'country_id': countryIds
                    });

                    const cityData = await axios.post(`${multiDbAccessManagerLink}city`, {
                        'city_id': cityIds
                    });

                    const countryObj = {};
                    const cityObj = {};
                    if (countryData.data.length > 0) {
                        countryData.data.forEach(country => {
                            countryObj[country.id] = country.country_name;
                        });
                    }

                    if (cityData.data.length > 0) {
                        cityData.data.forEach(city => {
                            cityObj[city.id] = city.name
                        });
                    }

                    if (sharedDids) {
                        // return results
                        sharedDidsArr = sharedDids.rows.map(async(didData, index) => {
                            let confObj = {
                                id: didData.id,
                                did: didData.did,
                                toll_free: didData.toll_free,
                                description: didData.description,
                                active: didData.active,
                                country_name: (countryObj[didData.id_country] == null ? '' : countryObj[didData.id_country]),
                                city_name: (cityObj[didData.id_city] == null ? '' : cityObj[didData.id_city])
                            }
                            return (confObj);
                        });
                    }
                }
                return { result: sharedDidsArr, pages: Math.ceil(sharedDids.count / args.input.pageSize) };
            } catch (err) {
                console.log(err);
                throw new Error(err);
            }
        }
    }
}