## Audio Conference backend Application
=======================================

## Introduction
This is a backend App for Audio Conference app developed in GraphQL.

## How to run
This application requires node to be installed on your system. Please check [upstream documentation](https://nodejs.org/en/download/)
for how to install node on your system.

### Development build
In application root path run following commands
```bash
cd app
npm install
npm start
```
### Production build
Run following commands
```bash
cd app 
npm install --only=production
npm start
```

## Dependencies
This application required following connections to run:
- MySQL
- file-storage-manager
- email-service

## Environment variables
Environment variables is the main mechanism of manipulating application settings. Currently application recognizes
following environment variables:

| Variable              | Default value | Description          |
| --------------------- | ------------- | -------------------- |
| NODE_ENV              | null          | Sets current environment. Allows application to manipulate some settings automatically |
| HOST                  | 0.0.0.0       | Address to listen on |
| PORT                  | 3000          | Port to listen on    |
| MYSQL_SERVICE_HOST    | localhost     | Database address     |
| MYSQL_SERVICE_PORT    | 3306          | Database port        |
| APP_DB_NAME           | null          | Database name        |
| APP_DB_USER           | null          | Database user        |
| APP_DB_PASS           |               | Database password    |
| FILE_STORAGE_MANAGER_SERVICE_SCHEME | http | Set file storage scheme |
| FILE_STORAGE_MANAGER_SERVICE_HOST | null   | Set file storage host   |
| FILE_STORAGE_MANAGER_SERVICE_PORT | null   | Set file storage port   |
| FILE_STORAGE_MANAGER_SERVICE_PATH | /      | Set file storage path   |
| EMAIL_SERVICE_SERVICE_SCHEME | http        | Set email API scheme    |
| EMAIL_SERVICE_SERVICE_HOST | null          | Set email API host      |
| EMAIL_SERVICE_SERVICE_PORT | null          | Set email API port      |
| EMAIL_SERVICE_SERVICE_PATH | /             | Set email API path      |
| MULTI_DB_ACCESS_MANAGER_SERVICE_SCHEME | http        | Sets multi-db-access-scheme |
| MULTI_DB_ACCESS_MANAGER_SERVICE_HOST | null          | Sets multi-db-access-host |
| MULTI_DB_ACCESS_MANAGER_SERVICE_PORT | null          | Sets multi-db-access-port |
| MULTI_DB_ACCESS_MANAGER_SERVICE_PATH | /             | Sets multi-db-access-path |    

## API Documentation
You can get API docs on {API_HOST_ADDRESS}/graphiql
