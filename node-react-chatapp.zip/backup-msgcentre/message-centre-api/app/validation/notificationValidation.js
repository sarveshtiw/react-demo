const Joi = require('joi');
let ErrorArr = [];

/********************************************** Starts: Validation schema  ***************************************************/
// Make Schema for validate schemavalidatesaveRoomInvitation
let schemavalidatesaveRoomInvitation = Joi.object().keys({
    indexName: Joi.string().required(),
    companyId: Joi.number().integer().required(),
    documentName: Joi.string().required(),
    jid: Joi.string().required(),
    name: Joi.string().required(),
    bare: Joi.string().required(),
    local: Joi.string().required(),
    nick: Joi.string().empty(""),
    password: Joi.string().empty(""),
    description: Joi.string().empty(""),
    role: Joi.string().empty(""),
    affilation: Joi.string().empty(""),
});

let schemavalidatesaveInvitation = Joi.object().keys({
    indexName: Joi.string().required(),
    companyId: Joi.number().integer().required(),
    documentName: Joi.string().required(),
    body: Joi.string().required(),
    from_bare: Joi.string().required(),
    from_full: Joi.string().required(),
    from_local: Joi.string().required(),
    to_bare: Joi.string().required(),
    to_full: Joi.string().required(),
    to_local: Joi.string().required(),
    type: Joi.string().empty(""),
    id: Joi.string().required(),
    status: Joi.boolean().valid(true, false).required(),
    createdOn: Joi.date().required(),
});

// Make Schema for validate schemaUpdateRoom
let schemavalidateupdateNotification = Joi.object().keys({
    indexName: Joi.string().required(),
    companyId: Joi.number().integer().required(),
    jid: Joi.string().required(),
    id: Joi.string().required(),
    status: Joi.boolean().valid(true, false).required()
});

// Make Schema for validate schemaLeaveRoom
let schemaLeaveRoom = Joi.object().keys({
    indexName: Joi.string().required(),
    companyId: Joi.number().integer().required(),
    documentName: Joi.string().required(),
    bare: Joi.string().required()
});

// Make Schema for validate schemaGetNotifications
let schemavalidategetNotificationList = Joi.object().keys({
    indexName: Joi.string().required(),
    companyId: Joi.number().integer().required(),
    jid: Joi.string().required(),
    from: Joi.number().integer().min(0),
    size: Joi.number().integer().min(5),
    sort: Joi.string().empty(""),
    orderBy: Joi.string().empty("")
});

let schemaValidateAddNotification = Joi.object().keys({
    indexName: Joi.string().required(),
    companyId: Joi.number().integer().required(),
    id: Joi.string().required(),
    body: Joi.string().required(),
    type: Joi.string().required(),
    from: Joi.object().keys({
        bare: Joi.string().required(),
        full: Joi.string().required(),
        local: Joi.string().required()
    }),
    to: Joi.object().keys({
        bare: Joi.string().required(),
        full: Joi.string().required(),
        local: Joi.string().required()
    }),
    time: Joi.number().required()
});
/********************************************** Starts: Validation function  ***************************************************/

// function for validate scheme validatesaveRoomInvitation
const validatesaveRoomInvitation = (ServiceTypeInput) => { // Validate validatesaveRoomInvitation API
    return Joi.validate(ServiceTypeInput, schemavalidatesaveRoomInvitation);
}

// function for validate scheme validatesaveInvitation
const validatesaveInvitation = (ServiceTypeInput) => { // Validate validatesaveInvitation API
    return Joi.validate(ServiceTypeInput, schemavalidatesaveInvitation);
}

// function for validate scheme validateupdateNotification
const validateupdateNotification = (ServiceTypeInput) => { // Validate validateupdateNotification API
    return Joi.validate(ServiceTypeInput, schemavalidateupdateNotification);
}

// function for validate scheme validateGetNotifications
const validategetNotificationList = (ServiceTypeInput) => { // Validate validateGetRoom API
    return Joi.validate(ServiceTypeInput, schemavalidategetNotificationList);
}

// function for validate scheme validateLeaveRoom
const validateLeaveRoom = (ServiceTypeInput) => { // Validate validateLeaveRoom API
    return Joi.validate(ServiceTypeInput, schemaLeaveRoom);
}

const validateAddNotification = (ServiceTypeInput) => {
    return Joi.validate(ServiceTypeInput, schemaValidateAddNotification);
}

module.exports = {
    validatesaveRoomInvitation,
    validateupdateNotification,
    validategetNotificationList,
    validateLeaveRoom,
    validatesaveInvitation,
    validateAddNotification
}