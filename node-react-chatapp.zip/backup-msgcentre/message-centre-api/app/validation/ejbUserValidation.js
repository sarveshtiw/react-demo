const Joi = require('joi');

/********************************************** Starts: Validation schema  ***************************************************/
// Make Schema for validation for open graph
let schemaSaveRegister = Joi.object().keys({
    user: Joi.string().required(),
    host: Joi.string().required(),
    password: Joi.string().required(),
});

// Make Schema for validation for open graph
let schemaUnregisterUser = Joi.object().keys({
    user: Joi.string().required(),
    host: Joi.string().required(),
});

// Make Schema for validation for open graph
let schemaChangePassword = Joi.object().keys({
    user: Joi.string().required(),
    host: Joi.string().required(),
    newpassword: Joi.string().required(),
});

// Make Schema for validation for open graph
let schemaSetNickname = Joi.object().keys({
    user: Joi.string().required(),
    host: Joi.string().required(),
    nickname: Joi.string().required(),
});


/********************************************** Starts: Validation function  ***************************************************/

// function for validate scheme validateregisterUser
const validateregisterUser = (ServiceTypeInput) => { // Validate validateregisterUser API
    return Joi.validate(ServiceTypeInput, schemaSaveRegister);
}

// function for validate scheme validateUnregisterUser
const validateUnregisterUser = (ServiceTypeInput) => { // Validate validateUnregisterUser API
    return Joi.validate(ServiceTypeInput, schemaUnregisterUser);
}

// function for validate scheme validatechangePassword
const validatechangePassword = (ServiceTypeInput) => { // Validate validateUnregisterUser API
    return Joi.validate(ServiceTypeInput, schemaChangePassword);
}

// function for validate scheme validateaccountExists
const validateaccountExists = (ServiceTypeInput) => { // Validate validateaccountExists API
    return Joi.validate(ServiceTypeInput, schemaUnregisterUser);
}

// function for validate scheme validatesetNickname
const validatesetNickname = (ServiceTypeInput) => { // Validate validatesetNickname API
    return Joi.validate(ServiceTypeInput, schemaSetNickname);
}

module.exports = {
    validateregisterUser,
    validateUnregisterUser,
    validatechangePassword,
    validateaccountExists,
    validatesetNickname,
}