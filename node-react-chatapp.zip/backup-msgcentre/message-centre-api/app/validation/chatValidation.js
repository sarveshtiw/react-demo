const Joi = require('joi');
let ErrorArr = [];

/********************************************** Starts: Validation schema  ***************************************************/
// Make Schema for validate schemaSaveChat
let schemaSaveChat = Joi.object().keys({
    indexName: Joi.string().required(),
    companyId: Joi.number().integer().required(),
    type: Joi.string(), 
    id: Joi.string(),
    body: Joi.string().required(),
    fromName: Joi.string().required(),
    fromJID: Joi.string().required(),
    toName: Joi.string().required(),
    toJID: Joi.string().required(),
    isAttachment: Joi.boolean().valid(true, false),
    isEdited: Joi.boolean().valid(true, false),
    isFavourite: Joi.boolean().valid(true, false),
    isDeleted: Joi.boolean().valid(true, false),
    isLocation: Joi.boolean().valid(true, false),
    createdOn: Joi.number()
});

// Make Schema for validate schemaUpdateChat
let schemaupdateChat = Joi.object().keys({
    indexName: Joi.string().required(),
    companyId: Joi.number().integer().required(),
    chatId: Joi.string().required(),
    chatFields: Joi.array().items([
        Joi.object().keys({
            key: Joi.string().required(),
            value: Joi.any().empty("")
        })
      ]).required()
});

let schemaGetChatMessages = Joi.object().keys({
    indexName: Joi.string().required(),
    companyId: Joi.number().integer().required(),
    fromJid: Joi.string().required(), 
    toJid: Joi.string().required(), 
    scrollId: Joi.string().empty(""),
    size: Joi.number().integer().min(5),
    sort: Joi.string().empty(""),
    orderBy: Joi.string().empty(""),
    type: Joi.string().required(""),
    fromDate: Joi.string().empty("")
});

let schemaGetFileUrl = Joi.object().keys({
    files: Joi.string().required()
});

let schemaGetCategoryChatMessages = Joi.object().keys({
    indexName: Joi.string().required(),
    companyId: Joi.number().integer().required(),
    fromJid: Joi.string().required(), 
    toJid: Joi.string().required(), 
    scrollId: Joi.string().empty(""),
    size: Joi.number().integer().min(5),
    sort: Joi.string().empty(""),
    orderBy: Joi.string().empty(""),
    type: Joi.string().required(""),
});

// Make Schema for validate schemaUpdateChat
let schemaEmailChat = Joi.object().keys({
    indexName: Joi.string().required(),
    companyId: Joi.number().integer().required(),
    fromJid: Joi.string().required(),
    fromName: Joi.string().required(),
    chatIds: Joi.array().required()
});

/********************************************** Starts: Validation function  ***************************************************/

// function for validate scheme validateSaveChat
const validateSaveChat = (ServiceTypeInput) => { // Validate validateSaveChat API
    return Joi.validate(ServiceTypeInput, schemaSaveChat);
}

// function for validate scheme validateUpdateChat
const validateUpdateChat = (ServiceTypeInput) => { // Validate schemaUpdateChat API
    return Joi.validate(ServiceTypeInput, schemaupdateChat);
}

// function for validate scheme validateGetChatMessages
const validateGetChatMessages = (ServiceTypeInput) => { // Validate schemaUpdateChat API
    return Joi.validate(ServiceTypeInput, schemaGetChatMessages);
}


// function for validate scheme validateGetCategoryChatMessages
const validateGetCategoryChatMessages = (ServiceTypeInput) => { // Validate schemaUpdateChat API
    return Joi.validate(ServiceTypeInput, schemaGetCategoryChatMessages);
}

// function for validate scheme validateGetFileUrl
const validateGetFileUrl = (ServiceTypeInput) => { 
    return Joi.validate(ServiceTypeInput, schemaGetFileUrl);
}
// function for validate scheme validateEmailChat
const validateEmailChat = (ServiceTypeInput) => { 
    return Joi.validate(ServiceTypeInput, schemaEmailChat);
}

module.exports = {
    validateSaveChat,
    validateUpdateChat,
    validateGetChatMessages,
    validateGetCategoryChatMessages,
    validateGetFileUrl,
    validateEmailChat
}