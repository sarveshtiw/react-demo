const Joi = require('joi');
let ErrorArr = [];

/********************************************** Starts: Validation schema  ***************************************************/
// Make Schema for validate schemaSaveRoom
let schemaSaveRoom = Joi.object().keys({
    indexName: Joi.string().required(),
    companyId: Joi.number().integer().required(),
    jid: Joi.string().required(),
    name: Joi.string().required(),
    bare: Joi.string().required(),
    local: Joi.string().required(),
    nick: Joi.string().empty(""),
    password: Joi.string().empty(""),
    description: Joi.string().empty(""),
    role: Joi.string().empty(""),
    affilation: Joi.string().empty(""),
    fromDate: Joi.number().required(),
    archiveDate: Joi.number().required(),
});

// Make Schema for validate schemaUpdateRoom
let schemaUpdateRoom = Joi.object().keys({
    indexName: Joi.string().required(),
    companyId: Joi.number().integer().required(),
    jid: Joi.string().required(),
    conferenceName: Joi.string().required(),
    conferenceFields: Joi.array().items([
        Joi.object().keys({
            key: Joi.string().required(),
            value: Joi.any().empty("")
        })
      ]).required()
});

// Make Schema for validate schemaGetRoom
let schemaGetRoom = Joi.object().keys({
    companyId: Joi.number().integer().required(),
    jid: Joi.string().required(), 
    from: Joi.number().integer().min(0),
    size: Joi.number().integer().min(5),
    sort: Joi.string().empty(""),
    orderBy: Joi.string().empty("")
});


// Make Schema for validate schemaGetTotalRoomMembersInfo

let schemaTotalRoomMembersInfo = Joi.object().keys({
    indexName: Joi.string().required(),
    companyId: Joi.number().integer().required(),
    conferenceName: Joi.string().required(),
});


// Make Schema for validate schemaDeleteRoom

let schemaDeleteRoom = Joi.object().keys({
    indexName: Joi.string().required(),
    companyId: Joi.number().integer().required(),
    conferenceName: Joi.string().required()
});

// Make Schema for validate schemaGetGroupMembersInfo

let schemaGetGroupMembersInfo = Joi.object().keys({
    indexName: Joi.string().required(),
    companyId: Joi.number().integer().required(),
    conferenceName: Joi.string().required(),
    scrollId: Joi.string().empty(""),
    size: Joi.number().integer().min(5),
    //sort: Joi.string().empty(""),
    //orderBy: Joi.string().empty("")
});

/********************************************** Starts: Validation function  ***************************************************/

// function for validate scheme validateSaveRoom
const validateSaveRoom = (ServiceTypeInput) => { // Validate validateSaveRoom API
    return Joi.validate(ServiceTypeInput, schemaSaveRoom);
}

// function for validate scheme validateUpdateRoom
const validateUpdateRoom = (ServiceTypeInput) => { // Validate validateUpdateRoom API
    return Joi.validate(ServiceTypeInput, schemaUpdateRoom);
}

// function for validate scheme validateGetRoom
const validateGetRoom = (ServiceTypeInput) => { // Validate validateGetRoom API
    return Joi.validate(ServiceTypeInput, schemaGetRoom);
}

// function for validate scheme validateLeaveRoom
const validateDeleteRoom = (ServiceTypeInput) => { // Validate validateLeaveRoom API
    return Joi.validate(ServiceTypeInput, schemaDeleteRoom);
}

// function for validate scheme validateGetTotalRoomMembersInfo
const validateTotalRoomMembersInfo = (ServiceTypeInput) => {
    return Joi.validate(ServiceTypeInput, schemaTotalRoomMembersInfo);
}

// function for validate scheme validateGetGroupMembersInfo
const validateGetGroupMembersInfo = (ServiceTypeInput) => {
    return Joi.validate(ServiceTypeInput, schemaGetGroupMembersInfo);
}

module.exports = {
    validateSaveRoom,
    validateUpdateRoom,
    validateGetRoom,
    validateTotalRoomMembersInfo,
    validateDeleteRoom,
    validateGetGroupMembersInfo
}
