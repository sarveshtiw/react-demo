const Joi = require('joi');

/********************************************** Starts: Validation schema  ***************************************************/
// Make Schema for validation for open graph
let schemaOpenGraph = Joi.object().keys({
    fileObject: Joi.array().items([
        Joi.object().keys({
            chatId: Joi.string().required(),
            url: Joi.string().required(),
        })
      ]).required()
});
/********************************************** Starts: Validation function  ***************************************************/

// function for validate scheme validateOpenGraph
const validateOpenGraph = (ServiceTypeInput) => { // Validate validateOpenGraph API
    return Joi.validate(ServiceTypeInput, schemaOpenGraph);
}


module.exports = {
    validateOpenGraph,
}