const Joi = require('joi');

/********************************************** Starts: Validation schema  ***************************************************/
// Make Schema for validation for open graph
let schemacreateSRG = Joi.object().keys({
    user: Joi.string().required(),
    host: Joi.string().required(),
    name: Joi.string().required(),
    description: Joi.string().required(),
    display: Joi.string().required(),
});

// Make Schema for validation for open graph
let schemadeleteSRG = Joi.object().keys({
    group: Joi.string().required(),
    host: Joi.string().required(),
});

// Make Schema for validation for open graph
let schemaaddUserToSGR = Joi.object().keys({
    user: Joi.string().required(),
    host: Joi.string().required(),
    group: Joi.string().required(),
    grouphost: Joi.string().required(),
});

// Make Schema for validation for open graph
let schemacreateChatRoom = Joi.object().keys({
    name: Joi.string().required(),
    service: Joi.string().required(),
    host: Joi.string().required(),
});

// Make Schema for validation for open graph
let schemaaddItemToUserRoster = Joi.object().keys({
    localuser: Joi.string().required(),
    localserver: Joi.string().required(),
    user: Joi.string().required(),
    server: Joi.string().required(),
});

// Make Schema for validation for open graph
let schemasendMessage = Joi.object().keys({
    text: Joi.string().required(),
    username: Joi.string().required(),
    channel: Joi.string().required(),
    link_names: Joi.string().required(),
    icon_emoji: Joi.string().required(),
});



/********************************************** Starts: Validation function  ***************************************************/

// function for validate scheme validatecreateSRG
const validatecreateSRG = (ServiceTypeInput) => { // Validate validatecreateSRG API
    return Joi.validate(ServiceTypeInput, schemacreateSRG);
}

// function for validate scheme validatedeleteSRG
const validatedeleteSRG = (ServiceTypeInput) => { // Validate validatedeleteSRG API
    return Joi.validate(ServiceTypeInput, schemadeleteSRG);
}

// function for validate scheme validateaddUserToSGR
const validateaddUserToSGR = (ServiceTypeInput) => { // Validate validateaddUserToSGR API
    return Joi.validate(ServiceTypeInput, schemaaddUserToSGR);
}

// function for validate scheme validateaddItemToUserRoster
const validateaddItemToUserRoster = (ServiceTypeInput) => { // Validate validateaddItemToUserRoster API
    return Joi.validate(ServiceTypeInput, schemaaddItemToUserRoster);
}

// function for validate scheme validatecreateChatRoom
const validatecreateChatRoom = (ServiceTypeInput) => { // Validate validatecreateChatRoom API
    return Joi.validate(ServiceTypeInput, schemacreateChatRoom);
}

// function for validate scheme validatesendMessage
const validatesendMessage = (ServiceTypeInput) => { // Validate validatesendMessage API
    return Joi.validate(ServiceTypeInput, schemasendMessage);
}

module.exports = {
    validatecreateSRG,
    validatedeleteSRG,
    validateaddUserToSGR,
    validateaddItemToUserRoster,
    validatecreateChatRoom,
    validatesendMessage
}