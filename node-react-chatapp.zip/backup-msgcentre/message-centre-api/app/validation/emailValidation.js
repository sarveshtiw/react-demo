const Joi = require('joi');
let ErrorArr = [];

// Make Schema for validate schemaUserSave
let schemaSendEmail = Joi.object().keys({
    to: Joi.array().min(1),
    from: Joi.object().required(),
    confName: Joi.string().empty(""),
});

// function for validate scheme validateUserSave
const validateEmail = (ServiceTypeInput) => {
    return Joi.validate(ServiceTypeInput, schemaSendEmail);
}

module.exports = {
    validateEmail,
}
