const Joi = require('joi');
let ErrorArr = [];

/******** Starts: Validation schema *********************/
// Make Schema for validate schemaUserSave
let schemaUserSave = Joi.object().keys({
    companyId: Joi.number().integer().required(),
    data: Joi.object().min(1),
});

// Make Schema for validate schemaGetUserInfo
let schemaUserInfo = Joi.object().keys({
    companyId: Joi.number().integer().required(),
    documentName: Joi.string().required(),
    queryString: Joi.object().min(1),
});

// Make Schema for validate schemaUserUpdate
let schemaUserProfileUpdate = Joi.object().keys({
    companyId: Joi.number().integer().required(),
    jid: Joi.string().required(),
    personalInfoFields: Joi.array().items([
        Joi.object().keys({
            key: Joi.string().required(),
            value: Joi.string().required(),
        })
      ]).required()
});

// Make Schema for validate schemaSaveContacts
let schemaSaveContacts = Joi.object().keys({
    companyId: Joi.number().integer().required(),
    from: Joi.string().required(),
    data: Joi.array().min(1),
});

// Make Schema for validate contact info
let schemaUpdateContact = Joi.object().keys({
    companyId: Joi.number().integer().required(),
    tojid: Joi.string().required(),
    fromjid: Joi.string().required(),
    type: Joi.string().required(),
    fields: Joi.array().items([
        Joi.object().keys({
            key: Joi.string().required(),
            value: Joi.string().required(),
        })
    ]).required(),
});

/********************** Starts: Validation function  **************************/

// function for validate scheme validateUserSave
const validateUserSave = (ServiceTypeInput) => {
    return Joi.validate(ServiceTypeInput, schemaUserSave);
}

const validateUserInfo = (ServiceTypeInput) => {
    return Joi.validate(ServiceTypeInput, schemaUserInfo);
}

const validateUserProfileUpdate = (ServiceTypeInput) => {
    return Joi.validate(ServiceTypeInput, schemaUserProfileUpdate);
}

const validateSaveContacts = (ServiceTypeInput) => {
    return Joi.validate(ServiceTypeInput, schemaSaveContacts);
}

const validateUpdateContact = (ServiceTypeInput) => {
    return Joi.validate(ServiceTypeInput, schemaUpdateContact);
}

module.exports = {
    validateUserSave,
    validateUserInfo,
    validateUserProfileUpdate,
    validateSaveContacts,
    validateUpdateContact
}
