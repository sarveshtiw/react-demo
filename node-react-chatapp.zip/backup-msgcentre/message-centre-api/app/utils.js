const { formatError } = require('graphql');

// Constant message 
const ErrorMessages = {
    dbError: "Database Error",
}

class CustomError extends Error {
    constructor(message, field) {
        super(message);
        this.field = field;
    }
}

const formatErr = error => {
    const data = formatError(error);
    const { originalError } = error;
    data.field = originalError && originalError.field
    return data;
};

module.exports = { ErrorMessages, formatErr, CustomError };
