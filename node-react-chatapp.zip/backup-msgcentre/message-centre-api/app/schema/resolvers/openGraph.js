/*
@Author : sanjay Verma
*/
const validation = require('../../validation/openGraphValidation');
const openGraph = require('open-graph-scraper');

module.exports = {
    Query: {
        getMessageScraperUrlInfo: async(obj, args, context, info) => { 
            // Query for url scraper
            // Prepare array to validate fields
            try {
                // validate Keys
                let ErrorArr = validation.validateOpenGraph({ fileObject: args.input.fileObject });
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                let status = false, message;
                let data = [];
                let resultArr = [];

                let fileObject = args.input.fileObject;
                let options = '';
                for(let i = 0; i < fileObject.length; i++) {
                    options = { 'url': fileObject[i].url, 'timeout': 3000 };

                    let response = await openGraph(options)
                        .then(result => {
                            if (result) {
                                return result.data;
                            }
                        })
                        .catch(error => {
                            return error;
                        });

                    response.chatId = fileObject[i].chatId;
                    response.url = fileObject[i].url;
                    resultArr.push(
                        response
                    );
                }
                return {message: message, data: resultArr };
            } catch (err) {
                return { errors: err };
            }
        },
        // Query END Here
    }

}