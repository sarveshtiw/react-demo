/*
@Author : sanjay Verma
@Date : 20/11/2017
@Rosters : This schema use to manage Rosters like create SRG, delete SRG, get SRG Members,
 add User To SGR, delete User To SGR, add Item To Use Roster, delete Item To Use Roster,
 create chat room and send message etc.
*/
const validation = require('../../validation/rosterValidation');
const constant = require('../../lib/constant');
const ejabberd = require('../../lib/ejabberd');

module.exports = {
    Query: {
	
    },
    Mutation: {
        createSRG: async(obj, args, context, info) => { 
            // Mutation for save chat
            // Prepare array to validate fields
            try {
                const insObj = {
                    'user': args.input.user || '',
                    'host': args.input.host || '',
                    'name': args.input.name || '',
                    'description': args.input.description || '',
                    'display': args.input.display || ''
                };
                // validate Keys
                let ErrorArr = validation.validatecreateSRG(insObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                let status = false,
                    message = null;

                await ejabberd.SRG.create(insObj.user, insObj.host, insObj.name, insObj.description, insObj.display)
                    .then(result => {
                        if (result === 0) {
                            status = true;
                            message = 'shared roster group created';
                        } else {

                            message = 'Error while creating SRG'
                        }
                    })
                    .catch(err => {
                        message = err;
                    });
                return { status: status, message: message };
            } catch (err) {
                return err;
            }
        },
        deleteSRG: async(obj, args, context, info) => { 
            // Mutation for save chat
            // Prepare array to validate fields
            try {
                const insObj = {
                    'group': args.input.group || '',
                    'host': args.input.host || ''
                };
                // validate Keys
                let ErrorArr = validation.validatedeleteSRG(insObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                let status = false,
                    message = null;

                await ejabberd.SRG.delete(insObj.group, insObj.host)
                    .then(result => {
                        if (result === 0) {
                            status = true;
                            message = 'shared roster group deleted';
                        } else {

                            message = 'Error while deleting SRG'
                        }
                    })
                    .catch(err => {
                        message = err;
                    });
                return { status: status, message: message };
            } catch (err) {
                return err;
            }
        },
        getSGRMembers: async(obj, args, context, info) => { 
            // Mutation for save chat
            // Prepare array to validate fields
            try {
                const insObj = {
                    'group': args.input.group || '',
                    'host': args.input.host || ''
                };
                // validate Keys
                let ErrorArr = validation.validatedeleteSRG(insObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                let status = false,
                    message = null;

                await ejabberd.SRG.memberList(insObj.group, insObj.host)
                    .then(result => {
                        if (result.length < 1) {
                            message = 'No member found';
                        } else {
                            status = true;
                            members = result;
                        }
                    })
                    .catch(err => {
                        message = err;
                    });
                return { status: status, message: message };
            } catch (err) {
                return err;
            }
        },
        addUserToSGR: async(obj, args, context, info) => { 
            // Mutation for save chat
            // Prepare array to validate fields
            try {
                const insObj = {
                    'user': args.input.user || '',
                    'host': args.input.host || '',
                    'group': args.input.group || '',
                    'grouphost': args.input.grouphost || '',
                };
                // validate Keys
                let ErrorArr = validation.validateaddUserToSGR(insObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                let status = false,
                    message = null;

                await ejabberd.SRG.addUser(insObj.user, insObj.host, insObj.group, insObj.grouphost)
                    .then(result => {
                        if (result === 0) {
                            status = true;
                            message = 'user added to SRG';
                        } else {

                            message = 'Error while adding user in SRG'
                        }
                    })
                    .catch(err => {
                        message = err;
                    });
                return { status: status, message: message };
            } catch (err) {
                return err;
            }
        },

        deleteUserFromSGR: async(obj, args, context, info) => { 
            // Mutation for save chat
            // Prepare array to validate fields
            try {
                const insObj = {
                    'user': args.input.user || '',
                    'host': args.input.host || '',
                    'group': args.input.group || '',
                    'grouphost': args.input.grouphost || '',
                };
                // validate Keys
                let ErrorArr = validation.validateaddUserToSGR(insObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                let status = false,
                    message = null;

                await ejabberd.SRG.deleteUser(insObj.user, insObj.host, insObj.group, insObj.grouphost)
                    .then(result => {
                        if (result === 0) {
                            status = true;
                            message = 'user deleted from SRG';
                        } else {

                            message = 'Error while deleting user from SRG'
                        }
                    })
                    .catch(err => {
                        message = err;
                    });
                return { status: status, message: message };
            } catch (err) {
                return err;
            }
        },

        addItemToUserRoster: async(obj, args, context, info) => {
            // Mutation for save chat
            // Prepare array to validate fields
            try {
                const insObj = {
                    'localuser': args.input.localuser || '',
                    'localserver': args.input.localserver || '',
                    'user': args.input.user || '',
                    'server': args.input.server || ''
                };
                // validate Keys
                let ErrorArr = validation.validateaddItemToUserRoster(insObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                let status = false,
                    message = null;

                await ejabberd.roster.UserRosterDeleteItem(insObj.localuser, insObj.localserver, insObj.user, insObj.server)
                    .then(result => {
                        if (result === 0) {
                            status = true;
                            message = 'Item added in user roster';
                        } else {
                            message = 'Item can not be added';
                        }
                    })
                    .catch(err => {
                        message = err;
                    });
                return { status: status, message: message };
            } catch (err) {
                return err;
            }
        },
        deleteItemFromUserRoster: async(obj, args, context, info) => { 
            // Mutation for save chat
            // Prepare array to validate fields
            try {
                const insObj = {
                    'localuser': args.input.localuser || '',
                    'localserver': args.input.localserver || '',
                    'user': args.input.user || '',
                    'server': args.input.server || ''
                };
                // validate Keys
                let ErrorArr = validation.validateaddItemToUserRoster(insObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                let status = false,
                    message = null;

                await ejabberd.roster.UserRosterDeleteItem(insObj.localuser, insObj.localserver, insObj.user, insObj.server)
                    .then(result => {
                        if (result === 0) {
                            status = true;
                            message = 'Item deleted from user roster';
                        } else {
                            message = 'Item can not be deleted';
                        }
                    })
                    .catch(err => {
                        message = err;
                    });
                return { status: status, message: message };
            } catch (err) {
                return err;
            }
        },
        createChatRoom: async(obj, args, context, info) => { 
            // Mutation for save chat
            // Prepare array to validate fields
            try {
                const insObj = {
                    'name': args.input.name || '',
                    'service': args.input.service || '',
                    'host': args.input.host || ''
                };
                // validate Keys
                let ErrorArr = validation.validatecreateChatRoom(insObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                let status = false,
                    message = null;

                await ejabberd.roster.MUCCreate(insObj.name, insObj.service, insObj.host)
                    .then(result => {
                        if (result === 0) {
                            status = true;
                            message = 'Multi user chatroom created';
                        } else {
                            message = 'Chat room can not be created';
                        }
                    })
                    .catch(err => {
                        message = err;
                    });
                return { status: status, message: message };
            } catch (err) {
                return err;
            }
        },
        sendMessage: async(obj, args, context, info) => { 
            // Mutation for save chat
            // Prepare array to validate fields
            try {
                const insObj = {
                    'text': args.input.text || '',
                    'username': args.input.username || '',
                    'channel': args.input.channel || '',
                    'link_names': args.input.link_names || '',
                    'icon_emoji': args.input.icon_emoji || ''
                };
                // validate Keys
                let ErrorArr = validation.validatesendMessage(insObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                let status = false,
                    message = null;

                await ejabberd.roster.SendMessage(insObj.text, insObj.username, insObj.channel, insObj.link_names, insObj.icon_emoji)
                    .then(result => {
                        //console.log('result', result)
                        if (result === 0) {
                            status = true;
                            message = 'Message send';
                        } else {
                            message = 'Message cannot be send';
                        }
                    })
                    .catch(err => {
                        message = err;
                    });
                return { status: status, message: message };
            } catch (err) {
                return err;
            }
        },

        // Mutation END Here
        // Mutation END Here
        // Mutation END Here
    }

}
