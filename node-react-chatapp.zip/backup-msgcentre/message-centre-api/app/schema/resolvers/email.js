/*
@Author : sarvesh Tiwari
@Date : 20/11/2017
@Invitation and Notifications : This schema use to manage Invitation like save room Invitation, save invitation, and Notifications Listing and update Notifications
*/
const validation = require('../../validation/emailValidation');
const email = require('../../lib/email');
const constant = require('../../lib/constant');

module.exports = {
    Query: {
        sendMentionEmail: async(obj, args, context, info) => {
            let emailResponse; let outputRes = {}; 
            try {                
                // Prepare array to validate fields,
                const validateObj = {
                    'to': args.input.to || '',
                    'from': args.input.from || '',
                    'confName': args.input.confName || ''
                };
                let ErrorArr = validation.validateEmail(validateObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }

                //send email to all users
                for(let i=0; i<args.input.to.length; i++){
                    let obj= { 
                        service: 'MCA',
                        template: "mentionUser",
                        templateData: { 
                            username: args.input.to[i].name,
                            fromUserName: args.input.from[0].name,
                            confName: args.input.confName,
                            dateTime: new Date().toJSON().slice(0,10)
                        },
                        subject : "Notification from Synthesis",
                        to: args.input.to[i].email
                    } 
                    
                    //console.log(obj);
                    emailResponse = await email.sendEmail(obj); 
                                                         
                    if (emailResponse.error){
                        outputRes.error = emailResponse.error;
                        outputRes.success = ''; 
                    }else{
                        outputRes.error = emailResponse.error;
                        outputRes.success = emailResponse.result.message;  
                    }
                }    
                return { message: constant.SUCCESS, data: outputRes };
            } catch (err) {
                let emailResponse; 
                console.log(err);
                return { message: "error", data: err.message };
            }
        },
        sendInvitationEmail: async(obj, args, context, info) => {
            let emailResponse; let outputRes = {}; 
            try {                
                // Prepare array to validate fields,
                const validateObj = {
                    'to': args.input.to || '',
                    'from': args.input.from || '',
                    'confName': args.input.confName || ''
                };
                let ErrorArr = validation.validateEmail(validateObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }

                //send email to all users
                let obj= { 
                    service: 'MCA',
                    template: 'invitation',
                    templateData: { 
                        fromUserName: args.input.from.name,
                        confName: args.input.confName,
                        dateTime: new Date().toJSON().slice(0,10)
                    },
                    subject: "Joined a new conference",
                    users: args.input.to
                }                        
                emailResponse = await email.sendEmail(obj); 
                                                
                if (emailResponse.error){
                    outputRes.error = emailResponse.error;
                    outputRes.success = ''; 
                }else{
                    outputRes.error = emailResponse.error;
                    outputRes.success = emailResponse.result.message;  
                }
                return { message: constant.SUCCESS, data: outputRes };
            } catch (err) {
                let emailResponse; 
                console.log(err);
                return { message: "error", data: err.message };
            }
        },
    },
    Mutation: {        
        // Mutation END Here
    }
}