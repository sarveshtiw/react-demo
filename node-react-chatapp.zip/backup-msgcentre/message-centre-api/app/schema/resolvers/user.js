/*
@Author : sanjay Verma
@Date : 20/11/2017
@Users : This schema use to manage Users like save User, get User Status, and update User profile
@modified by: Sarvesh Tiwari, 5/2/2018
*/

const validation = require('../../validation/userValidation');
const constant = require('../../lib/constant');
const elasticSearchLib = require('../../lib/elasticSearch');
const elasticQuery = require('../../lib/query');
const {
    USER_INFO,
    USER_CONTACTS,
    INDEX_USER,
    INDEX_CONTACT,
    INDEX_CONFERENCE
} = require('../../config/documentNames');

module.exports = {
    Query: {
        getMessageActiveUsers: async(obj, args, context, info) => {
            try{
                let currentTime = new Date().getTime();
                //get user contacts
                let queryContacts = elasticQuery.getUserContatcs(args.input);                
                let resultContacts = await elasticSearchLib.search(queryContacts);
                let arrContacts = []; let contacts = [];
                if (resultContacts.hits && resultContacts.hits.total > 0 && resultContacts.hits.hits) {                    
                    for (let i = 0; i < resultContacts.hits.total; i++) {
                        if(resultContacts.hits.hits[i]){
                            let name = resultContacts.hits.hits[i]._source.from.jid.split("@");
                            arrContacts.push(resultContacts.hits.hits[i]._source.from.jid);
                            contacts[resultContacts.hits.hits[i]._source.from.jid] = resultContacts.hits.hits[i]._source;
                        }
                    }
                }    
                
                //get users info
                //console.log('---------->>>>>>', arrContacts);
                let resultArr = [];
                for(let a = 0; a < arrContacts.length; a++){
                    let queryUsers = elasticQuery.getUsersInfo(args.input, arrContacts[a]);
                    let result = await elasticSearchLib.search(queryUsers);
                    //console.log('---------->>>>>>1', queryUsers.queryString.query,result.hits.hits);
                    
                    if (result.hits && result.hits.total > 0) {
                        for (let i = 0; i < result.hits.total; i++) {
                            let jid = result.hits.hits[i]._source.personalinfo.jid;
                            resultArr.push({
                                jid: jid || '',
                                status: result.hits.hits[i]._source.personalinfo.status || '',
                                showtypes: result.hits.hits[i]._source.personalinfo.showtypes || '',
                                fullName: result.hits.hits[i]._source.personalinfo.fullName || '',
                                displayName: result.hits.hits[i]._source.personalinfo.displayName || '',
                                userImage: result.hits.hits[i]._source.personalinfo.userImage || '',
                                email: result.hits.hits[i]._source.personalinfo.email || '',
                                is_starred: contacts.hasOwnProperty(jid) ? contacts[jid].from.is_starred : false,
                                fromDate: contacts.hasOwnProperty(jid) ? contacts[jid].from.fromDate : currentTime,
                                archiveDate: contacts.hasOwnProperty(jid) ? contacts[jid].from.archiveDate : currentTime
                            });
                        }
                    }
                }    
                
                return { message: constant.SUCCESS, data: resultArr };
            }catch(err){
                return err;
            }
        },
        getMessageUserProfile: async(obj, args, context, info) => {
            try{
                //get users info
                let queryUsers = elasticQuery.getUsersProfileInfo(args.input);                              
                let result = await elasticSearchLib.search(queryUsers);
                
                let resultArr = [];
                if (result.hits && result.hits.total > 0) {
                    for (let i = 0; i < result.hits.total; i++) {                        
                        resultArr.push({
                            jid: result.hits.hits[i]._source.personalinfo.jid || '',
                            status: result.hits.hits[i]._source.personalinfo.status || '',
                            showtypes: result.hits.hits[i]._source.personalinfo.showtypes || '',
                            fullName: result.hits.hits[i]._source.personalinfo.fullName || '',
                            displayName: result.hits.hits[i]._source.personalinfo.displayName || '',
                            userImage: result.hits.hits[i]._source.personalinfo.userImage || ''
                        });
                    }
                }
                
                return { message: constant.SUCCESS, data: resultArr };
            }catch(err){
                return err;
            }
        },
    },
    Mutation: {
        createMessageUser: async(obj, args, context, info) => {
            // Prepare array to validate fields,
            let status = '';
            try{
                let insObj = {
                    'companyId': args.input.companyId,
                    'personalinfo': args.input.data || {},
                };
                // validate Keys
                let ErrorArr = validation.validateUserSave(args.input);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                //cross check if user does not exist
                let queryUsers = elasticQuery.getUsersInfo(args.input, args.input.data.jid);
                let userData = await elasticSearchLib.search(queryUsers);
                console.log("userData =>>>>>>>>>",userData);
                let result = {};
                if(userData.hits.total === 0){
                    // Process the API
                    //result = await elasticSearchLib.save(insObj, INDEX_USER, USER_INFO);
                }
                result.status = true;
                return { data: result, message: constant.SUCCESS };
            } catch(err) {
                return err ;
            }            
        },
        updateMessageUserProfileInfo: async(obj, args, context, info) => {
            try {         
                // create a simple object to validate parameters with JOI
                let validateObj = {
                    //'indexName': INDEX_USER,
                    'companyId': args.input.companyId,
                    'jid': args.input.jid || '',
                    'personalInfoFields': args.input.personalInfoFields || {},
                }

                let ErrorArr = validation.validateUserProfileUpdate(validateObj);                
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                let queryUsers = elasticQuery.updateUserProfile(validateObj);
                let result = await elasticSearchLib.update(queryUsers.queryString, queryUsers.indexName, queryUsers.documentName);
                return { data: result, message: constant.SUCCESS };
            } catch(err) {
                return err;
            }
        },        
        addMessageContacts: async(obj, args, context, info) => {
            // Prepare array to validate fields,
            let result;
            try{
                let currentTime = new Date().getTime();
                // create a simple object to validate parameters with JOI
                let ErrorArr = validation.validateSaveContacts(args.input);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }

                let status = '';

                //get existing contacts
                let queryContacts = elasticQuery.getUserContatcs({"jid": args.input.from}); 
                let resultContacts = await elasticSearchLib.search(queryContacts);
                let arrContacts = [];
                let result = {};
                if (resultContacts.hits && resultContacts.hits.total > 0 && resultContacts.hits.hits) {                    
                    for (let i = 0; i < resultContacts.hits.total; i++) {
                        //let name = resultContacts.hits.hits[i]._source.from.jid.split("@");
                        arrContacts.push(resultContacts.hits.hits[i]._source.from.jid);
                    }
                }

                result.status = true; 
                result.fromDate = currentTime;

                //add in contacts
                for(let i=0; i<args.input.data.length; i++){
                    if(arrContacts.indexOf(args.input.data[i]) === -1){
                        let data = {
                            "to": {
                                "jid": args.input.from,
                                "companyId": args.input.companyId
                            },
                            "from": {
                                "jid": args.input.data[i],
                                "is_starred": false,
                                "fromDate": currentTime,
                                //"archiveDate": currentTime
                            }
                        }

                        result = await elasticSearchLib.save(data, INDEX_CONTACT, USER_CONTACTS); 
                        result.status = true; 
                        result.fromDate = currentTime;   
                    }
                }
                
                return { data: result, message: constant.SUCCESS };
            } catch(err) {
                return err;
            }            
        },
        updateMessageContactInfo: async(obj, args, context, info) => {            
            try{
                const currentTime = new Date().getTime();
                // create a simple object to validate parameters with JOI
                let ErrorArr = validation.validateUpdateContact(args.input);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }

                // Process the API
                let queryUsers;
                if(args.input.type === 'groupchat'){
                    let data = {
                        'indexName': INDEX_CONFERENCE,
                        'companyId': args.input.companyId,
                        'conferenceName': args.input.fromjid, 
                        'jid': args.input.tojid,
                        'conferenceFields': args.input.fields,
                        'currentTime': currentTime
                    }
                    queryUsers = elasticQuery.updateRoom(data);                    
                   
                }else{
                    let data = {
                        'indexName': INDEX_CONTACT,
                        'companyId': args.input.companyId,
                        'fromjid': args.input.fromjid, 
                        'tojid': args.input.tojid,
                        'fields': args.input.fields,
                        'currentTime': currentTime
                    }
                    queryUsers = elasticQuery.updateContact(data);
                }
                
                let result = {};
                if(Object.keys(queryUsers).length){                    
                    await elasticSearchLib.update(queryUsers.queryString, queryUsers.indexName, queryUsers.documentName);
                    result.currentTime = currentTime;
                }
                
                return { data: result, message: constant.SUCCESS };
            }catch(error){
                return error;
            }    
        },    
    }
}
