/*
@Author : sarvesh Tiwari
@Date : 20/11/2017
@Invitation and Notifications : This schema use to manage Invitation like save room Invitation, save invitation, and Notifications Listing and update Notifications
*/
const validation = require('../../validation/notificationValidation');
const constant = require('../../lib/constant');
const elasticSearchLib = require('../../lib/elasticSearch');
const elasticQuery = require('../../lib/query');
const {
    CHAT_DATA, 
    CONFERENCES, 
    NOTIFICATIONS, 
    USER_INFO,
    USER_CONTACTS,
    INDEX_NOTIFICATION
} = require('../../config/documentNames');

module.exports = {
    Query: {
        getMessageNotifications: async(obj, args, context, info) => {
            try {
                // Prepare array to validate fields,
                const validateObj = {
                    'indexName': INDEX_NOTIFICATION,
                    'companyId': args.input.companyId,
                    'jid': args.input.jid || '',
                    'from': args.input.from || 0,
                    'size': args.input.size || 25,
                    'sort': args.input.sort || 'createdOn',
                    'orderBy': args.input.orderBy || 'desc'
                };
                let ErrorArr = validation.validategetNotificationList(validateObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                // Process the API
                let queryUsers = elasticQuery.getNotifications(validateObj);
                let result = await elasticSearchLib.search(queryUsers);
                let resultArr = [];
                if (result.hits && result.hits.hits.length > 0) {
                    for (let i = 0; i < result.hits.hits.length; i++) {
                        resultArr.push({
                            id: result.hits.hits[i]._source.id || '',
                            type: result.hits.hits[i]._source.type || '',
                            body: result.hits.hits[i]._source.body || '',
                            from: { bare: result.hits.hits[i]._source.from.bare, full: result.hits.hits[i]._source.from.full, local: result.hits.hits[i]._source.from.local },
                            to: { bare: result.hits.hits[i]._source.to.bare, full: result.hits.hits[i]._source.to.full, local: result.hits.hits[i]._source.to.local },
                            status: result.hits.hits[i]._source.status || '',
                            time: result.hits.hits[i]._source.time || '',
                        });
                    }
                }
                return { message: constant.SUCCESS, data: resultArr };
            } catch (err) {
                return err;
            }
        },

    },
    Mutation: {
        createMessageNotification: async(obj, args, context, info) => { 
            try {
                // Mutation for add new notification
                // create a simple object to validate parameters with JOI
                let currentTime = new Date();
                let validateObj = {
                    'indexName': INDEX_NOTIFICATION,
                    'companyId': args.input.companyId,
                    'id': 'synthesis' + currentTime.getTime() || '',
                    'body': args.input.data['body'] || '',
                    'type': args.input.data['type'] || '',
                    'from': {
                        'bare': args.input.data.from['bare'] || '',
                        'full': args.input.data.from['full'] || '',
                        'local': args.input.data.from['local'] || ''
                    },
                    'to': {
                        'bare': args.input.data.to['bare'] || '',
                        'full': args.input.data.to['full'] || '',
                        'local': args.input.data.to['local'] || ''
                    },
                    'time': currentTime.getTime(),
                }

                let ErrorArr = validation.validateAddNotification(validateObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                // Process the API
                let queryUsers = elasticQuery.addNotifications(validateObj);
                let result = await elasticSearchLib.save(queryUsers.data, INDEX_NOTIFICATION, NOTIFICATIONS);
                result.id = 'synthesis' + currentTime.getTime();
                return { data: result, message: constant.SUCCESS };
            } catch (err) {
                return err;
            }
        },
        updateMessageNotification: async(obj, args, context, info) => { 
            try {
                // Mutation for update the notification Status
                // create a simple object to validate parameters with JOI
                let validateObj = {
                    'indexName': INDEX_NOTIFICATION,
                    'companyId': args.input.companyId,
                    'jid': args.input.jid || '',
                    'id': args.input.id || '',
                    'status': args.input.status || false
                }
                let ErrorArr = validation.validateupdateNotification(validateObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                // Process the API
                let queryUsers = elasticQuery.updateNotifications(validateObj);
                let result = await elasticSearchLib.update(queryUsers.queryString, INDEX_NOTIFICATION, NOTIFICATIONS);
                return { data: result, message: constant.SUCCESS };
            } catch (err) {
                return err;
            }
        },

        // Mutation END Here
        // Mutation END Here
        // Mutation END Here
    }

}