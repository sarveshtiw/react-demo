const { mergeResolvers } = require('merge-graphql-schemas');

const chat = require('./chat');
const room = require('./room');
const notification = require('./notification');
const user = require('./user');
const email = require('./email');
const openGraph = require('./openGraph');

const resolvers = [
    chat,
    room,
    notification,
    user,
    openGraph,
    email,
]

module.exports = mergeResolvers(resolvers);