/*
@Author : sanjay Verma
@Date : 20/11/2017
@Ejabberd : This schema use to ejabberd Users like register User, unregister User, change Passsword, check account exists, set user nikename and verify password.
*/
const validation = require('../../validation/ejbUserValidation');
const constant = require('../../lib/constant');
const ejabberd = require('../../lib/ejabberd');

module.exports = {
    Query: {

    },
    Mutation: {
        registerUser: async(obj, args, context, info) => { 
            // Mutation for save chat
            // Prepare array to validate fields
            try {
                const insObj = {
                    'user': args.input.user || '',
                    'host': args.input.host || '',
                    'password': args.input.password || ''
                };
                // validate Keys
                let ErrorArr = validation.validateregisterUser(insObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                let status = false,
                    message = null;

                await ejabberd.accounts.RegisterUser(insObj.user, insObj.host, insObj.password)
                    .then(result => {
                        if (result.statusCode) {
                            message = result.error.message;
                        } else {
                            status = true;
                            message = 'User registered successfully';
                        }
                    })
                    .catch(err => {
                        message = err;
                    });
                return { status: status, message: message };
            } catch (err) {
                return err;
            }
        },
        unRegister: async(obj, args, context, info) => {
            // Mutation for save chat
            // Prepare array to validate fields
            try {
                const insObj = {
                    'user': args.input.user || '',
                    'host': args.input.host || ''
                };
                // validate Keys
                let ErrorArr = validation.validateUnregisterUser(insObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                let status = false,
                    message = null;

                await ejabberd.accounts.UnregisterUser(insObj.user, insObj.host)
                    .then(result => {
                        if (result.statusCode) {
                            message = result.error.message;
                        } else {
                            status = true;
                            message = 'User unregistered successfully';
                        }
                    })
                    .catch(err => {
                        message = err;
                    });
                return { status: status, message: message };
            } catch (err) {
                return err;
            }
        },
        changePassword: async(obj, args, context, info) => { 
            // Mutation for save chat
            // Prepare array to validate fields
            try {
                const insObj = {
                    'user': args.input.user || '',
                    'host': args.input.host || '',
                    'newpassword': args.input.newpassword || ''
                };
                // validate Keys
                let ErrorArr = validation.validatechangePassword(insObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                let status = false,
                    message = null;

                await ejabberd.accounts.ChangePassword(insObj.user, insObj.host, insObj.newpassword)
                    .then(result => {
                        if (result.statusCode) {
                            message = result.error;
                        } else {
                            if (result == 0) {
                                status = true;
                                message = 'Password Changed successfully';
                            } else {
                                message = 'Error while changing password';
                            }
                        }
                    })
                    .catch(err => {
                        message = err;
                    });
                return { status: status, message: message };
            } catch (err) {
                return err;
            }
        },
        accountExists: async(obj, args, context, info) => { 
            // Mutation for save chat
            // Prepare array to validate fields
            try {
                const insObj = {
                    'user': args.input.user || '',
                    'host': args.input.host || ''
                };
                // validate Keys
                let ErrorArr = validation.validateaccountExists(insObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                let status = false,
                    message = null;
                    await ejabberd.accounts.AccountExists(insObj.user, insObj.host)
                        .then(result => {
                            if (result === 0) {
                                status = true;
                                message = 'Account already exists';
                            } else {
                                message = 'Account Not found';
                            }
                        })
                        .catch(err => {
                            message = err;
                        });
                return { status: status, message: message };
            } catch (err) {
                return err;
            }
        },

        verifyPassword: async(obj, args, context, info) => { 
            // Mutation for save chat
            // Prepare array to validate fields
            try {
                const insObj = {
                    'user': args.input.user || '',
                    'host': args.input.host || '',
                    'password': args.input.password || '',
                };
                // validate Keys
                let ErrorArr = validation.validateregisterUser(insObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                let status = false,
                    message = null;
                    await ejabberd.accounts.CheckPassword(insObj.user, insObj.host, insObj.password)
                        .then(result => {
                            if (result === 0) {
                                status = true;
                                message = 'Password matched';
                            } else {
                                message = 'Password not matched'
                            }
                        })
                        .catch(err => {
                            message = err;
                        });
                return { status: status, message: message };
            } catch (err) {
                return err;
            }
        },

        setNickname: async(obj, args, context, info) => { 
            // Mutation for save chat
            // Prepare array to validate fields
            try {
                const insObj = {
                    'user': args.input.user || '',
                    'host': args.input.host || '',
                    'nickname': args.input.nickname || '',
                };
                // validate Keys
                let ErrorArr = validation.validatesetNickname(insObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                let status = false,
                    message = null;
                    await ejabberd.accounts.SetNickname(insObj.user, insObj.host, insObj.nickname)
                        .then(result => {
                            if (result === 0) {
                                status = true;
                                message = 'nickname added successfully';
                            } else {
                                message = 'nickname not added';
                            }
                        })
                        .catch(err => {
                            message = err;
                        });
                return { status: status, message: message };
            } catch (err) {
                return err;
            }
        },
        // Mutation END Here
        // Mutation END Here
        // Mutation END Here
        // Mutation END Here
        // Mutation END Here
        // Mutation END Here
    }

}