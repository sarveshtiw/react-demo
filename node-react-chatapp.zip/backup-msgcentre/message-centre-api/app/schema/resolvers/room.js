/*
@Author : sanjay Verma
@Date : 20/11/2017
@Rooms : This schema use to manage Rooms like save Rooms, get Rooms Lists, get Room Members, leave Room and update Room data
@modified by: Sarvesh Tiwari, 5/2/2018
*/
const validation = require('../../validation/roomValidation');
const constant = require('../../lib/constant');
const elasticSearchLib = require('../../lib/elasticSearch');
const elasticQuery = require('../../lib/query');
const {
    CONFERENCES, 
    NOTIFICATIONS, 
    USER_INFO,
    USER_CONTACTS,
    INDEX_CONFERENCE
} = require('../../config/documentNames');

module.exports = {
    Query: {
        getMessageRooms: async(obj, args, context, info) => {
            try {
                let currentTime = new Date().getTime();
                // Prepare array to validate fields,
                const validateObj = {
                    //'indexName': INDEX_CONFERENCE,
                    'companyId': args.input.companyId,
                    'jid': args.input.jid || '',
                    'from': args.input.from || 0,
                    'size': args.input.size || 25,
                    'sort': args.input.sort || 'createdOn',
                    'orderBy': args.input.orderBy || 'desc'
                };
                let ErrorArr = validation.validateGetRoom(validateObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                // Process the API
                let queryUsers = elasticQuery.getRooms(validateObj);
                let result = await elasticSearchLib.search(queryUsers);
                let resultArr = [];
                //console.log("result =>>>>>>>>>>>>>",result);
                if (result.hits && result.hits.hits.length > 0) {
                    for (let i = 0; i < result.hits.hits.length; i++) {
                        resultArr.push({
                            name: result.hits.hits[i]._source.conference.name || '',
                            nick: result.hits.hits[i]._source.conference.nick || '',
                            autojoin: result.hits.hits[i]._source.conference.autojoin || false,
                            jid: {
                                bare: result.hits.hits[i]._source.conference.jid.bare || '',
                            },
                            local: result.hits.hits[i]._source.conference.jid.local || '',
                            unread: result.hits.hits[i]._source.conference.unread || false,
                            role: result.hits.hits[i]._source.conference.role || '',
                            affiliation: result.hits.hits[i]._source.conference.affiliation || '',
                            description: result.hits.hits[i]._source.conference.description || '',
                            type: result.hits.hits[i]._source.conference.type|| '',
                            is_starred: result.hits.hits[i]._source.conference.is_starred || false,
                            fromDate: result.hits.hits[i]._source.conference.fromDate,
                            archiveDate: result.hits.hits[i]._source.conference.archiveDate,
                        });
                    }
                }
                return { message: constant.SUCCESS, data: resultArr };
            } catch (err) {
                return err;
            }
        },
        getMessageRoomMembers: async(obj, args, context, info) => {
            try {
                let validateObj = {
                    'indexName': INDEX_CONFERENCE,
                    'companyId': args.input.companyId,
                    'conferenceName': args.input.conferenceName || ''
                }         
                // validate Keys
                let ErrorArr = validation.validateTotalRoomMembersInfo(validateObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                
                // Process the API
                let queryUsers = elasticQuery.getRoomMembers(validateObj);
                let result = await elasticSearchLib.search(queryUsers);
                
                let resultArr = [];
                if (result.hits && result.hits.hits.length > 0) {
                    for (let i = 0; i < result.hits.hits.length; i++) {
                        resultArr.push({
                            jid: result.hits.hits[i]._source.jid || ''
                        });
                    }
                }
                return { message: constant.SUCCESS, data: resultArr }; //{ countRoomMembers : countRoomMembers}
            }catch(err){
                return err;
            }
        },
        getGroupMembersData: async(obj, args, context, info) => {
            try {
                let validateObj = {
                    'indexName': INDEX_CONFERENCE,
                    'companyId': args.input.companyId,
                    'conferenceName': args.input.conferenceName || '',
                    'scrollId': args.input.scrollId || '',
                    'size': args.input.size || 5,
                    //'sort': args.input.sort || 'fullName',
                    //'orderBy': args.input.orderBy || 'asc'
                }         
                // validate Keys
                let ErrorArr = validation.validateGetGroupMembersInfo(validateObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                
                // Process the API
                let queryUsers = elasticQuery.getGroupMembersData(validateObj);
                let result = await elasticSearchLib.cursorSearch(queryUsers);
                let resultArr = [];
                let total = 0;
                if (result.hits && result.hits.hits.length > 0) {
                    total = result.hits.total;
                    let memberJIds = this.getRoomMembersJid(result.hits.hits);
                    const membersData = await this.getJIDUsersData(memberJIds);
                    for (let i = 0; i < result.hits.hits.length; i++) {
                        resultArr.push({
                            companyId: membersData[result.hits.hits[i]._source.jid].companyId || '',
                            jid: membersData[result.hits.hits[i]._source.jid].personalinfo.jid || '',
                            status: membersData[result.hits.hits[i]._source.jid].personalinfo.status || '',
                            showtypes: membersData[result.hits.hits[i]._source.jid].personalinfo.showtypes || '',
                            fullName: membersData[result.hits.hits[i]._source.jid].personalinfo.fullName || '',
                            displayName: membersData[result.hits.hits[i]._source.jid].personalinfo.displayName || '',
                            userImage: membersData[result.hits.hits[i]._source.jid].personalinfo.userImage || '',
                            email: membersData[result.hits.hits[i]._source.jid].personalinfo.email || ''
                        });
                    }
                }
                return { message: constant.SUCCESS, total: total, scrollId: result._scroll_id,  data: resultArr }; 
            }catch(err){
                return err;
            }
        }
    },
    Mutation: {
        createMessageRoom: async(obj, args, context, info) => { 
            // Mutation for save Room
            //Prepare array to validate fields
            let status = '';
            let currentTime = new Date().getTime();
            try {
                let validateObj = {
                    'indexName': INDEX_CONFERENCE,
                    'companyId': args.input.companyId,
                    'jid': args.input.data['jid'] || '',
                    'name': args.input.data['conference']['name'] || '',
                    'bare': args.input.data['conference']['jid']['bare'] || '',
                    'local': args.input.data['conference']['jid']['local'] || '',
                    'nick': args.input.data['conference']['nick'] || '',
                    'description': args.input.data['conference']['description'] || '',
                    'password': args.input.data['conference']['password'] || '',
                    "fromDate": currentTime,
                    "archiveDate": currentTime,
                };
                let ErrorArr = validation.validateSaveRoom(validateObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                // Process the API
                args.input.data['companyId'] = args.input.companyId;
                args.input.data.conference.type = args.input.data['conference']['type'];
                args.input.data.conference.createdOn = currentTime;
                let queryUsers = elasticQuery.saveRoom(validateObj.indexName, args.input.data);
                let result = await elasticSearchLib.save(queryUsers.data, queryUsers.indexName, queryUsers.documentName);
                
                result.status = true;
                return { data: result, message: constant.SUCCESS };
            } catch (err) {
                return err;
            }
        },
        updateMessageRoom: async(obj, args, context, info) => { 
            try {
                // Mutation for update the Room
                // create a simple object to validate parameters with JOI
                let validateObj = {
                    'indexName': INDEX_CONFERENCE,
                    'companyId': args.input.companyId,
                    'jid': args.input.jid || '',
                    'conferenceName': args.input.conferenceName || '',
                    'conferenceFields': args.input.conferenceFields || {},
                }
                let ErrorArr = validation.validateUpdateRoom(validateObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                // Process the API
                let queryUsers = elasticQuery.updateRoom(validateObj);
                let result = await elasticSearchLib.update(queryUsers.queryString, queryUsers.indexName, queryUsers.documentName);
                result.status = true;
                return { data: result, message: constant.SUCCESS };
            } catch (err) {
                return err;
            }
        },

        deleteMessageRoom: async(obj, args, context, info) => { 
            // Mutation for delete the Room
            try {
                // create a simple object to validate parameters with JOI
                let validateObj = {
                    'indexName': INDEX_CONFERENCE,
                    'companyId': args.input.companyId,
                    'conferenceName': args.input.conferenceName || ''
                }
                let ErrorArr = validation.validateDeleteRoom(validateObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }

                let queryUsers = elasticQuery.deleteGroup(validateObj);
                let result = await elasticSearchLib.delete(queryUsers.queryString, queryUsers.indexName, queryUsers.documentName);
                result.status = true;
                return { data: result, message: constant.SUCCESS };
            } catch (err) {
                return err;
            }
        }
        // Mutation END Here
    }

}

exports.getRoomMembersJid = (data) => { 
    let memberJIds = [];  
    for (let i = 0; i < data.length; i++) {
         memberJIds.push(data[i]._source.jid);
    }
    return memberJIds;
}

exports.getJIDUsersData = async(memberJIds) => { 
    let response = [];
    let memberJIdObjs = [];  
    if(memberJIds.length > 0) {
        for (let i = 0; i < memberJIds.length; i++) {
            let queryUsers = await elasticQuery.getUsersProfileInfo({jid: memberJIds[i]});
            response = await elasticSearchLib.search(queryUsers);
            let jid = response.hits.hits[0]._source.personalinfo.jid;
            let userdata = response.hits.hits[0]._source;
            memberJIdObjs[jid] = userdata;
        }
        response = memberJIdObjs;
    }
    return response;
}
