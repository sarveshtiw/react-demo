/*
@Author : sanjay Verma
@Date : 20/11/2017
@DeCampaignion : This schema use to manage Chat like save chat, search Chat lists, and update Chat
@modified by: Sarvesh Tiwari, 5/2/2018
*/
const validation = require('../../validation/chatValidation');
const constant = require('../../lib/constant');
const elasticSearchLib = require('../../lib/elasticSearch');
const fileStorage = require('../../lib/fileStorage');
const elasticQuery = require('../../lib/query');
const {
    CHAT_DATA, 
    CONFERENCES, 
    NOTIFICATIONS, 
    USER_INFO,
    USER_CONTACTS,
    INDEX_CHAT,
} = require('../../config/documentNames');
const EMAIL_URL = require("../../config").EMAIL_URL;

const request = require('request');
const fs = require('fs');

module.exports = {
    Query: {
        getChatMessages: async (obj, args, context, info) => {
            try {
                const validateObj = {
                    'indexName': INDEX_CHAT,
                    'companyId': args.input.companyId,
                    'fromJid': args.input.fromJid || '',
                    'toJid': args.input.toJid || '',
                    'scrollId': args.input.scrollId || '',
                    'size': args.input.size || 25,
                    'sort': args.input.sort || 'createdOn',
                    'orderBy': args.input.orderBy || 'desc',
                    'type': args.input.type || '',
                    'fromDate': args.input.fromDate || ''
                };
                let ErrorArr = validation.validateGetChatMessages(validateObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }

                // Process the API
                let queryUsers;
                if(args.input.type === 'groupchat'){
                    queryUsers = elasticQuery.getGroupChatMessages(validateObj);
                }else{
                    queryUsers = elasticQuery.getChatMessages(validateObj);
                }

                let result = await elasticSearchLib.cursorSearch(queryUsers);
                let resultArr = [];
                let total = 0;
                if (result.hits && result.hits.hits.length > 0) {
                    total = result.hits.total;
                    let fileIds = this.getChatAttachments(result.hits.hits);
                    const fileIdsUrls = await this.getChatAttachmentUrls(fileIds);
                    for (let i = 0; i < result.hits.hits.length; i++) {
                        let bodyData = result.hits.hits[i]._source.body;
                        let fileType = "";
                           
                        //check if msg is of attachement type
                        if(result.hits.hits[i]._source.isAttachment && 
                            (typeof fileIdsUrls === 'json' || typeof fileIdsUrls === 'object') 
                            && fileIdsUrls.hasOwnProperty(bodyData)) {
                            bodyData = fileIdsUrls[result.hits.hits[i]._source.body].url;
                            fileType = fileIdsUrls[result.hits.hits[i]._source.body].fileName;
                        }

                        resultArr.push({
                            id: result.hits.hits[i]._source.id || '',
                            type: result.hits.hits[i]._source.type || '',
                            body: bodyData || '',
                            attachmentType: fileType || "",
                            from: {
                                jid: result.hits.hits[i]._source.from.jid || '', 
                                name: result.hits.hits[i]._source.from.name || '' 
                            },
                            to: {
                                jid: result.hits.hits[i]._source.to.jid || '', 
                                name: result.hits.hits[i]._source.to.name || '' 
                            }, 
			                isAttachment: result.hits.hits[i]._source.isAttachment || false,
                            isEdited: result.hits.hits[i]._source.isEdited || false,
                            isFavourite: result.hits.hits[i]._source.isFavourite || false,
                            isDeleted: result.hits.hits[i]._source.isDeleted || false,
                            isLocation: result.hits.hits[i]._source.isLocation || false,
                            createdOn: result.hits.hits[i]._source.createdOn || '0000-00-00'
                        });
                    }
                }
                return { total: total, scrollId: result._scroll_id, data: resultArr, message: constant.SUCCESS };
            } catch (err) {
                return err;
            }
        },
        getFileUrlByFileId: async (obj, args, context, info) => {
            try {
                const validateObj = {
                    'files': args.input.files || '',
                };
                let ErrorArr = validation.validateGetFileUrl(validateObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                // Process the API
                const response = await this.getChatAttachmentUrls([args.input.files]);
                return { data: {fileIdURL: response[args.input.files].url }, message: constant.SUCCESS };
            } catch (err) {
                return err;
            }
        },
        getChatMessagesByCategory: async(obj, args, context, info) => {
            try {
                const validateObj = {
                    'indexName': INDEX_CHAT,
                    'companyId': args.input.companyId,
                    'fromJid': args.input.fromJid || '',
                    'toJid': args.input.toJid || '',
                    'scrollId': args.input.scrollId || '',
                    'size': args.input.size || 5,
                    'sort': args.input.sort || 'createdOn',
                    'orderBy': args.input.orderBy || 'desc',
                    'type': args.input.type || '',
                };
                let ErrorArr = validation.validateGetCategoryChatMessages(validateObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }

                // Process the API
                let queryUsers = elasticQuery.getCategoryChatMessages(validateObj);
                let result = await elasticSearchLib.cursorSearch(queryUsers);
                let total = 0;
		        let resultArr = [];
                if (result.hits && result.hits.hits.length > 0) {
                    total = result.hits.total;
                    let fileIds = this.getChatAttachments(result.hits.hits);
                    const fileIdsUrls = await this.getChatAttachmentUrls(fileIds);
                    for (let i = 0; i < result.hits.hits.length; i++) {
                        let bodyData = result.hits.hits[i]._source.body;
                        let fileType = "";

                        //check if msg is of attachement type
                        if(result.hits.hits[i]._source.isAttachment && 
                            (typeof fileIdsUrls === 'json' || typeof fileIdsUrls === 'object') 
                            && fileIdsUrls.hasOwnProperty(bodyData)) {
                            bodyData = fileIdsUrls[result.hits.hits[i]._source.body].url;
                            fileType = fileIdsUrls[result.hits.hits[i]._source.body].fileName;
                        }

                        resultArr.push({
                            id: result.hits.hits[i]._source.id || '',
                            type: result.hits.hits[i]._source.type || '',
                            body: bodyData || '',
                            attachmentType: fileType || "",
                            from: {
                                jid: result.hits.hits[i]._source.from.jid || '', 
                                name: result.hits.hits[i]._source.from.name || '' 
                            },
                            to: {
                                jid: result.hits.hits[i]._source.to.jid || '', 
                                name: result.hits.hits[i]._source.to.name || '' 
                            }, 
			                isAttachment: result.hits.hits[i]._source.isAttachment || false,
                            isEdited: result.hits.hits[i]._source.isEdited || false,
                            isFavourite: result.hits.hits[i]._source.isFavourite || false,
                            isDeleted: result.hits.hits[i]._source.isDeleted || false,
                            isLocation: result.hits.hits[i]._source.isLocation || false,
                            createdOn: result.hits.hits[i]._source.createdOn || '0000-00-00'
                        });
                    }
                }
                return { total: total, scrollId: result._scroll_id, data: resultArr, message: constant.SUCCESS };
            } catch (err) {
                return err;
            }
        },
        searchChatMessages: async (obj, args, context, info) => {
            try {
                const validateObj = {
                    'indexName': INDEX_CHAT,
                    'companyId': args.input.companyId,
                    'fromjid': args.input.fromjid,
                    'tojid': args.input.tojid,
                    'search': args.input.search,
                    'scrollId': args.input.scrollId || '',
                    'size': args.input.size || 25,
                    'sort': args.input.sort || 'createdOn',
                    'orderBy': args.input.orderBy || 'desc',
                    'type': args.input.type || 'chat',
                };
                //let ErrorArr = validation.validateGetFileUrl(validateObj);
                //if (ErrorArr.error) {
                    //throw new Error(ErrorArr.error.details[0].message);
                //}
                let queryUsers = elasticQuery.searchMessages(validateObj);
                let result = await elasticSearchLib.cursorSearch(queryUsers);
                let total = 0;
		        let resultArr = [];
                if (result.hits && result.hits.hits.length > 0) {
                    total = result.hits.total;
                    for (let i = 0; i < result.hits.hits.length; i++) {
                        let bodyData = result.hits.hits[i]._source.body;

                        resultArr.push({
                            id: result.hits.hits[i]._source.id || '',
                            type: result.hits.hits[i]._source.type || '',
                            body: bodyData || '',
                            attachmentType: "",
                            from: {
                                jid: result.hits.hits[i]._source.from.jid || '', 
                                name: result.hits.hits[i]._source.from.name || '' 
                            },
                            to: {
                                jid: result.hits.hits[i]._source.to.jid || '', 
                                name: result.hits.hits[i]._source.to.name || '' 
                            }, 
			                isAttachment: result.hits.hits[i]._source.isAttachment || false,
                            isEdited: result.hits.hits[i]._source.isEdited || false,
                            isFavourite: result.hits.hits[i]._source.isFavourite || false,
                            isDeleted: result.hits.hits[i]._source.isDeleted || false,
                            isLocation: result.hits.hits[i]._source.isLocation || false,
                            createdOn: result.hits.hits[i]._source.createdOn || '0000-00-00'
                        });
                    }
                }
                // Process the API
                return { total: total, scrollId: result._scroll_id, data: resultArr, message: constant.SUCCESS };
            } catch (err) {
                return err;
            }
        },
        getMCEnvDetails: async (obj, args, context, info) => {
            let esURL = process.env.ELASTICSEARCH_SERVICE_HOST + ':'+ process.env.ELASTICSEARCH_SERVICE_PORT;
            return { data: esURL };
        }
        
    },
    Mutation: {
        createChatMessage: async (obj, args, context, info) => { 
            // Mutation for save chat
            // Prepare array to validate fields
            let status = '';
            try {
                let currentTime = new Date().getTime();
                args.input.data['createdOn'] = currentTime;// assign searverside time
                args.input.data['id'] = 'synthesis' + currentTime;
                let insObj = {
                    'indexName': INDEX_CHAT,
                    'companyId': args.input.companyId,
                    'type': args.input.data['type'] || '',
                    'id': 'synthesis' + currentTime || '',
                    'body': args.input.data['body'] || '',
                    'fromName': args.input.data['from']['name'] || '',
                    'fromJID': args.input.data['from']['jid'] || '',
                    'toName': args.input.data['to']['name'] || '',
                    'toJID': args.input.data['to']['jid'] || '',
                    'isAttachment': args.input.data['isAttachment'] || false,
                    'isEdited': args.input.data['isEdited'] || false,
                    'isFavourite': args.input.data['isFavourite'] || false,
                    'isDeleted': args.input.data['isDeleted'] || false,
                    'createdOn': currentTime,
                    'isLocation': args.input.data['isLocation'] || false,
                };
                // validate Keys
                let ErrorArr = validation.validateSaveChat(insObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                delete insObj; // delete Object becuase we using args.input object to save chat
                // Assign value to new variable then remove existing keys    
                // Process the API
                args.input.data['companyId'] = args.input.companyId;

                let result = await elasticSearchLib.save(args.input.data, INDEX_CHAT, CHAT_DATA);
                result.status = true;
                result.createdOn = currentTime;
                return { data: result, message: constant.SUCCESS };
            } catch (err) {
                return { errors: err };
            }
        },
        updateChatMessage: async (obj, args, context, info) => { 
            try {
                // Mutation for update the chat
                // create a simple object to validate parameters with JOI
                let validateObj = {
                    'indexName': INDEX_CHAT,
                    'companyId': args.input.companyId,
                    'chatId': args.input.chatId || '',
                    'chatFields': args.input.chatFields || {},
                }
                let ErrorArr = validation.validateUpdateChat(validateObj);
                if (ErrorArr.error) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                // Process the API
                let queryUsers = elasticQuery.updateChat(validateObj);
                let result = await elasticSearchLib.update(queryUsers.queryString, queryUsers.indexName, queryUsers.documentName);
                return { data: result, message: constant.SUCCESS };
            } catch (err) {
                return { errors: err };
            }
        },
        emailChatMessages: async (obj, args, context, info) => { 
            try {     
                // Mutation for Email chat
                // create a simple object to validate parameters with JOI
                let validateObj = {
                    'indexName': INDEX_CHAT,
                    'companyId': args.input.companyId,
                    'fromJid': args.input.fromJid || '',
                    'fromName': args.input.fromName || '',
                    'chatIds': args.input.chatIds || ''
                }
                let ErrorArr = validation.validateEmailChat(validateObj);
                if (ErrorArr.error) {  
                    throw new Error(ErrorArr.error.details[0].message);
                }
                let status = false;
                // Process the API
                let queryUsers = elasticQuery.getEmailChatMessages(validateObj); 
                let result = await elasticSearchLib.search(queryUsers, queryUsers.indexName, queryUsers.documentName);
                let resultArr = [];
                if (result.hits && result.hits.hits.length > 0) {
                    status = true;
                    for (let i = 0; i < result.hits.hits.length; i++) {
                        let bodyData = result.hits.hits[i]._source.body;
                        resultArr.push({
                            id: result.hits.hits[i]._source.id || '',
                            type: result.hits.hits[i]._source.type || '',
                            body: bodyData || '',
                            from: {
                                jid: result.hits.hits[i]._source.from.jid || '', 
                                name: result.hits.hits[i]._source.from.name || '' 
                            },
                            to: {
                                jid: result.hits.hits[i]._source.to.jid || '', 
                                name: result.hits.hits[i]._source.to.name || '' 
                            }, 
                            createdOn: result.hits.hits[i]._source.createdOn || '0000-00-00'
                        });
                    }
                }
                let response = '';
                let currentTime = new Date().getTime();
                let fileName = "chat_"+currentTime+".txt";
                let writeStream = fs.createWriteStream("./upload/"+fileName); 
                let writeStreamData = "fromName, toName, Message, createdTime\n";
                for (let i = 0; i < resultArr.length; i++) {
                    let date = new Date(resultArr[i].createdOn);
                    let createdTime = date.getDate() + '/' + (date.getMonth()+1) + '/' + date.getFullYear() + ' ' + date.getHours() + ':' + date.getMinutes();
                    writeStreamData += resultArr[i].from.name+", "+ resultArr[i].to.name+", "+ resultArr[i].body+", "+ createdTime +"\n";
                }
                writeStream.write(writeStreamData);
                writeStream.on('finish', function () {
                    //console.log('file has been written');
                });

                let readStream = fs.createReadStream("./upload/"+fileName);
                readStream.on('finish', function () {
                    //console.log('file has been read');
                });
                readStream.pipe(process.stdout);

                fs.unlink("./upload/"+fileName,function(err){
                    if (err)  console.log("error", err)
                    //console.log(fileName+" has been deleted.")
                });
                let emailResponse = await this.sendEmail({name: args.input.fromName, attachmentName: fileName, attachments: readStream, email: args.input.fromJid});
                return { status: status, message: constant.SUCCESS };
            } catch (err) {
                return { errors: err };
            }
        },
        // Mutation END Here
    }
}

exports.getChatAttachments = (chats) => { 
    let chatFileIds = [];  
    for (let i = 0; i < chats.length; i++) {
        if(chats[i]._source.isAttachment === true) {
            chatFileIds.push(chats[i]._source.body);
        }
    }
    return chatFileIds;
}

exports.getChatAttachmentUrls = async(fileIds) => { 
    let response = [];
    let chatFileIdObjs = [];  
    if(fileIds.length > 0) {
        response = await fileStorage.getFileUrls(fileIds);
        for (let i = 0; i < response.length; i++) {
            let fileId = response[i].fileId;
            chatFileIdObjs[fileId] = response[i];
        }
        response = chatFileIdObjs;
    }
    return response;
}

exports.sendEmail = async(data) => {
    let formData = { 
        service: 'MCA',
        template: 'sendEmailChat',
        templateData: JSON.stringify({ 
            username: data.name
        }),
        subject : 'Email chat messages from Synthesis',
        users: JSON.stringify([{email: data.email}]),
        attachments: [data.attachments]
    };
    return request.post({ url: `${EMAIL_URL}send-mail`, formData: formData }, function optionalCallback(err, httpResponse, body) {
        if (err) {
            return {'error': err};
        } else {
            return {'success': true};
        }
    });    
}
