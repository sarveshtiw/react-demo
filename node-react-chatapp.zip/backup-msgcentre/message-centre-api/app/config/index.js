module.exports = {
    server: {
        host: process.env.HOST || '0.0.0.0',
        port: process.env.PORT || 3000
    },
    db: {
        username: process.env.APP_DB_USER,
        name: process.env.APP_DB_NAME,
        password: process.env.APP_DB_PASS,
        options: {
            host: process.env.MYSQL_SERVICE_HOST || "localhost",
            port: process.env.MYSQL_SERVICE_PORT || 3306,
            dialect: 'mysql',
            logging: true,
            freezeTableName: true,
            define: {
                timestamps: false
            },
            pool: {
                max: 9,
                min: 0,
                idle: 10000
            }
        }
    },
    elastic: {
        URL: `${process.env.ELASTICSEARCH_SERVICE_SCHEME || 'http'}://${process.env.ELASTICSEARCH_SERVICE_HOST || 'localhost'}:${process.env.ELASTICSEARCH_SERVICE_PORT_HTTP || 9200}`,
    },
    FILE_STORAGE_URL:`${process.env.FILE_STORAGE_API_SERVICE_SCHEME || 'http'}://${process.env.FILE_STORAGE_API_SERVICE_HOST}:${process.env.FILE_STORAGE_API_SERVICE_PORT}${process.env.FILE_STORAGE_API_SERVICE_PATH || '/'}`,
    EMAIL_URL:`${process.env.EMAIL_SERVICE_SERVICE_SCHEME || 'http'}://${process.env.EMAIL_SERVICE_SERVICE_HOST || 'localhost'}:${process.env.EMAIL_SERVICE_SERVICE_PORT}${process.env.EMAIL_SERVICE_SERVICE_PATH || '/'}`,
    ContactManager: `${process.env.CONTACT_MANAGER_SERVICE_SCHEME || 'http'}://${process.env.CONTACT_MANAGER_SERVICE_HOST}:${process.env.CONTACT_MANAGER_SERVICE_PORT}${process.env.CONTACT_MANAGER_SERVICE_PATH || '/'}`,
  };
