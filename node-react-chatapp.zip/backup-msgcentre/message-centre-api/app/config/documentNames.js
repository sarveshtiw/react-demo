const USER_INFO = 'userinfo'
const CHAT_DATA = 'chatdata'
const NOTIFICATIONS = 'usernotifications' 
const CONFERENCES = 'userconferences'
const USER_CONTACTS = 'usercontacts'
const INDEX_USER = 'user'
const INDEX_CHAT = 'chat'
const INDEX_NOTIFICATION = 'notification'
const INDEX_CONFERENCE = 'conference'
const INDEX_CONTACT = 'contact'
module.exports = {
    USER_INFO,
    CHAT_DATA,
    NOTIFICATIONS,
    CONFERENCES,
    USER_CONTACTS,
    INDEX_USER,
    INDEX_CHAT,
    INDEX_NOTIFICATION,
    INDEX_CONFERENCE,
    INDEX_CONTACT
}