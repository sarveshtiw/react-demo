Messaging API Application
=========================

## Introduction
This is a messaging API application required to make communication between APM and XMPP app. This is an backend API developed in Koa.

## How to run
This application requires node to be installed on your system. Please check [upstream documentation](https://nodejs.org/en/download/)
for how to install node on your system.

### Development build
In application root path run following commands
```bash
cd app
npm install
npm start
```
### Production build
Run following commands
```bash
cd app
npm install --only=production
npm start
```

## Dependencies
This application required following connections to run:
- MySQL
- ejabberd messaging engine
- auth-server
- elasticsearch

## Environment variables
Environment variables is the main mechanism of manipulating application settings. Currently application recognizes
following environment variables:

| Variable        | Default value        | Description              |
| --------------- | -------------------- | ------------------------ |
| NODE_ENV        | null                 | Sets current environment. Allows application to manipulate some settings automatically |
| HOST            | 0.0.0.0              | Sets an address to listen on |
| PORT            | 3000                 | Sets a port to listen on     |
| MYSQL_SERVICE_HOST | localhost         | Database engine address  |
| MYSQL_SERVICE_PORT | 3306              | Database engine port     |
| APP_DB_NAME     | null                 | Database name            |
| APP_DB_USER     | null                 | Database user            |
| APP_DB_PASS     | null                 | Database password        |
| ELASTICSEARCH_SERVICE_SCHEME | http    | Sets elasticsearch scheme http or https |
| ELASTICSEARCH_SERVICE_HOST   | null    | Sets elasticsearch endpoint address     |
| ELASTICSEARCH_SERVICE_PORT_HTTP | null | Sets elasticsearch endpoint port        |
| FILE_STORAGE_MANAGER_SERVICE_SCHEME | http     | Set file storage scheme |
| FILE_STORAGE_MANAGER_SERVICE_HOST   | null     | Set file storage host   |
| FILE_STORAGE_MANAGER_SERVICE_PORT   | null     | Set file storage port   |
| FILE_STORAGE_MANAGER_SERVICE_PATH   | /        | Set file storage path   |


## File System Access
Application does not require any kind of persistent or temporary volumes

## Testing with docker
To test application in docker you need first docker to be installed. Check [upstream documentation](https://docs.docker.com/install)
for how to install docker on your system.
To bring up all services run in repository root path
```bash
docker-compose -f docker/docker-compose.yml pull --ignore-pull-failures
docker-compose -f docker/docker-compose.yml up
```

## API Documentation
You can get API docs using /docs path
