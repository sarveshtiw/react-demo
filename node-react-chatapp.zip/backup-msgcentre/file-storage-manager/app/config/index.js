module.exports = {
    server: {
        host: process.env.HOST || '0.0.0.0',
        port: process.env.PORT || 3000
    },
    database: {
        username: process.env.APP_DB_USER,
        name: process.env.APP_DB_NAME,
        password: process.env.APP_DB_PASS,
        options: {
            host: process.env.MYSQL_SERVICE_HOST || 'localhost',
            port: process.env.MYSQL_SERVICE_PORT || 3306,
            dialect: 'mysql',
            freezeTableName: true,
            define: {
                timestamps: false
            },
            logging:console.log,
            pool: {
                max: 9,
                min: 0,
                idle: 10000
            }
        }
    },
    authAPI: `${process.env.AUTH_SERVER_SERVICE_SCHEME || 'http'}://${process.env.AUTH_SERVER_SERVICE_HOST}:${process.env.AUTH_SERVER_SERVICE_PORT}${process.env.AUTH_SERVER_SERVICE_PATH || '/'}`,
    etcd: process.env.ETCD_HOST || 'http://etcd01.asergis.net:2379',
    location: process.env.LOCATION || 'powergate',
    rabbitmq: {
        username: process.env.RABBITMQ_USER,
        password: process.env.RABBITMQ_PASS,
        host: process.env.RABBITMQ_SERVICE_HOST,
        port: process.env.RABBITMQ_SERVICE_PORT,
        prefix: process.env.RABBITMQ_PREFIX,
        exchange: process.env.RABBITMQ_EXCHANGE
    }
};