const file = require('./file');
const healthCheck = require('./healthCheck');

module.exports = {
    file,
    healthCheck
}
