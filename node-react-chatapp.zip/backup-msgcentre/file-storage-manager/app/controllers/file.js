const HTTPStatus = require('http-status')
const amqp = require('amqplib')
const minio = require('minio')
const { Etcd3 } = require('etcd3');

const lib = require('./../lib')
const { location, rabbitmq, etcd } = require('../config')
const validation = require('./../validation')
const model = require('../models');

const client = new Etcd3({
    hosts: etcd
});

//let minioClients = {}

const minioConfigs = async (req, res) => {
    try {
        let minioClients = {}
        let a = await client.getAll().prefix('/development/storage/')
        //console.log(a)
        //console.log(Object.keys(a).length)
        for (let i = 0; i < Object.keys(a).length; i=i+4) {
            minioClients[Object.keys(a)[i].split('/')[3]] = new minio.Client({
                secretKey: Object.values(a)[i],
                accessKey: Object.values(a)[i + 1],
                secure: Object.values(a)[i + 3] === 'http://' ? true : false,
                endPoint: Object.values(a)[i + 2]
            })            
        }
        //console.log('####',minioClients)
        return minioClients
    }
    catch(err) {
        return err
    }    
}

const locationId = async () => {
    try {
        let data = await model.StoragePop.findOne({
            where: {
                pop_name: location
            }
        })
        return data.id
    }
    catch (err) {
        return err
    }
}

const getFiles = async (req, res) => {
    try {
        let result = await lib.minioOperations.getFiles(req.body.files, req.minioClients, req.locationId)
        res.status(200).json(result)
    }
    catch (err) {
        res.status(200).send({
            status: false,
            message: 'Internal Server Error'
        })
    }
}

const uploadFiles = async (req, res) => {
    try {
        //console.log('13123131', req.amqpConnection)
        let conn = await req.amqpConnection
        let ch = await conn.createChannel()
        let ok = await ch.assertQueue('')
        ch.assertExchange(rabbitmq.exchange, 'fanout', { durable: true });
        let uploadedFiles = []
        for(let i=0; i<req.body.files.length; i++) {
            let insertFile = await model.StoredFile.create({
                uuid: req.body.files[i].fileId,
                date_stored: new Date(),
                application_name: req.body.appName,
                application_use: req.body.appUse,
                file_name: req.body.files[i].minioFileId,
                local_only: req.body.localOnly,
                cache: req.body.cache,
                SFL: [{
                    id_storage_pop: req.locationId,
                    date_stored: new Date()
                }]
            }, {
                include: [{
                    model: model.StoredFileLocation,
                    as: 'SFL'
                }]
            })
            let msg = JSON.stringify({ fileName: req.body.files[i].minioFileId, source: location, operation: 'PutObject', appName: req.body.appName, appUse: req.body.appUse, bucket: req.body.appName + '-' + req.body.appUse, local_only: req.body.localOnly || '0', cache: req.body.cache || '0' })
            ch.publish(rabbitmq.exchange, '', new Buffer(msg));
            uploadedFiles.push({
                fileId: req.body.files[i].fileId,
                fileName: req.body.files[i].fileName
            })                    
        } 
        //console.log('result', uploadedFiles)               
        res.status(HTTPStatus.OK).send(uploadedFiles)
    } catch (err) {
        res.status(200).send({
            status: false,
            message: 'Internal Server Error'
        })
    }
}

const deleteFiles = async (req, res) => {
    try {
        let result = await lib.minioOperations.delete(req.body.files, req.minioClients, req.locationId)
        if (result === 'DELETED') {
            res.status(HTTPStatus.OK).send({
                status: true,
                message: 'File deleted successfully'
            })
        }
    }
    catch (err) {
        res.status(200).send({
            status: false,
            message: 'Internal Server Error'
        })
    }
}

const insertRecord = async (req, res) => {
    try {
        let result = await lib.minioOperations.insertFileRecord(req.body)
        if(result) {
            res.status(HTTPStatus.OK).send({
                message: 'File location updated'
            })
        }
    }
    catch (err) {
        res.status(200).send({
            status: false,
            message: 'Internal Server Error'
        })
    }
}

const deleteRecord = async (req, res) => {
    try {
        let result = await lib.minioOperations.deleteFileRecord(req.body)
        if(result) {
            res.status(HTTPStatus.OK).send({
                message: 'File location deleted'
            })
        }
    }
    catch (err) {
        res.status(200).send({
            status: false,
            message: 'Internal Server Error'
        })
    }
}

module.exports = {
    minioConfigs,
    locationId,
    uploadFiles,
    getFiles,
    deleteFiles,
    insertRecord, 
    deleteRecord
}