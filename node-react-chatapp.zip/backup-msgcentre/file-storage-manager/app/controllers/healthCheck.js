const sequelize = require('../models').sequelize;
const { database } = require('../config');
const liveness = (req, res) => {
    res.json({ Status: 'Running' });
};
const readiness = async(req, res) => {
    const result = { Status: 'Red', Services: {} };
    const dbCheckResult = await checkMysqlConnection();
    result.Services = dbCheckResult;
    console.log(dbCheckResult)
    if (dbCheckResult.Mysql.Status === 'OK') {
        result.Status = 'Green'
        res.status(200).json(result);
    } else {
        res.status(200).json(result);
    }
};
const checkMysqlConnection = async() => {
    const result = { Mysql: { Status: 'Failed' } };
    try {

        if (database.name && database.username && database.password && database.options.host) {
            const response = await sequelize.authenticate();
            result.Mysql.Status = 'OK'
            return result;
        }
        result.Mysql.Message = 'Invalid Mysql config found';
        return result;
    } catch (err) {
        console.log(err);
        result.Mysql.Message = 'Error while connecting to Mysql database';
        return result;
    }
}
module.exports = {
    liveness,
    readiness
}