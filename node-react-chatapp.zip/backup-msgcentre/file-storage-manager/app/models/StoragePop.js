module.exports = function(sequelize, DataTypes) {
    var StoragePop = sequelize.define('StoragePop', {
      id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
      pop_name: { type: DataTypes.INTEGER, foreignKey: true, allowNull: false},
      active: {type: DataTypes.ENUM('1','0'), allowNull: false }
    }, {
      tableName: 'storage_pop'
    });

    return StoragePop;
  };
     