module.exports = function(sequelize, DataTypes) {
    var StoragePopDistance = sequelize.define('StoragePopDistance', {
      id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
      id_from_pop: { type: DataTypes.INTEGER, foreignKey: true, allowNull: false},
      id_to_pop: { type: DataTypes.INTEGER, foreignKey: true, allowNull: true},
      distance: {type: DataTypes.INTEGER, allowNull: true}
    }, {
      tableName: 'storage_pop_distance'
    });

    return StoragePopDistance;
  };
                          