"use strict";
var Sequelize = require('sequelize');
var config = require('../config').database;
var fs = require("fs");
var path = require("path");
var sequelize = new Sequelize(
    config.name,
    config.username,
    config.password,
    config.options
);
var db = {};

fs.readdirSync(__dirname)
    .filter(function(file) {
        return (file.indexOf(".") !== 0) && (file !== "index.js");
    })
    .forEach(function(file) {
        var model = sequelize["import"](path.join(__dirname, file));
        db[model.name] = model;
    });


Object.keys(db).forEach(function(modelName) {
    if(db[modelName].associate){
        db[modelName].associate(db);
    }
});

sequelize
    .authenticate()
    .then(function(err) {
        console.log('Connection has been established successfully with File Storage Database');
    })
    .catch(function(err) {
        console.log('Unable to connect to File Storage Database', err);
    });

db.sequelize = sequelize;
db.Sequelize = Sequelize;

module.exports = db;
