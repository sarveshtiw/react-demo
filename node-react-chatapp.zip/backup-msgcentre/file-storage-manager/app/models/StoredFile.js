module.exports = function (sequelize, DataTypes) {
    var StoredFile = sequelize.define('StoredFile', {
        id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true, allowNull: false },
        uuid: { type: DataTypes.STRING, allowNull: false },
        application_name: { type: DataTypes.STRING, allowNull: false },
        file_name: { type: DataTypes.STRING, allowNull: false },
        application_use: { type: DataTypes.STRING, allowNull: false },
        date_stored: { type: DataTypes.DATE, allowNull: false },
        local_only: { type: DataTypes.ENUM('1','0'),allowNull: true, defaultValue: '0'},
        cache: { type: DataTypes.ENUM('1','0'), allowNull: true, defaultValue: '0'},
    }, {
            tableName: 'stored_file'
        });

    StoredFile.associate = models => {
        models.StoredFile.hasMany(models.StoredFileLocation, { foreignKey: 'id_stored_file', constraints: true, as: 'SFL' });
    };

    return StoredFile;
};
