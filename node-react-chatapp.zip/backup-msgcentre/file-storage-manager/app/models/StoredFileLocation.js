module.exports = function(sequelize, DataTypes) {
    var StoredFileLocation = sequelize.define('StoredFileLocation', {
      id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
      id_stored_file: { type: DataTypes.INTEGER, foreignKey: true, allowNull: false},
      id_storage_pop: { type: DataTypes.INTEGER, foreignKey: true, allowNull: true},
      date_stored: {type: DataTypes.DATE, allowNull: true}
    }, {
      tableName: 'stored_file_location'
    });

    StoredFileLocation.associate = models => {
        models.StoredFileLocation.hasMany(models.StoragePopDistance, {sourceKey: 'id_storage_pop', foreignKey: 'id_from_pop', constraints: true, as: 'SPD' });
    };


    return StoredFileLocation;
  };
                          