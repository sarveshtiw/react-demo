DROP TABLE IF EXISTS `cm_file_history`;
DROP TABLE IF EXISTS `cm_file_storage`;

DROP TABLE IF EXISTS `stored_file`;
CREATE TABLE `stored_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(64) NOT NULL,
  `date_stored` datetime NOT NULL,
  `application_name` varchar(64) NOT NULL,
  `file_name` varchar(250) NOT NULL,
  `application_use` varchar(45) NOT NULL,
  `local_only` enum('1','0') DEFAULT '0',
  `restriction` enum('1','0') DEFAULT '0',
  `cache` enum('1','0') DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

DROP TABLE IF EXISTS `storage_pop`;
CREATE TABLE `storage_pop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pop_name` varchar(32) NOT NULL,
  `active` enum('0','1') DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

DROP TABLE IF EXISTS `storage_pop_distance`;
CREATE TABLE `storage_pop_distance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_from_pop` int(11) NOT NULL,
  `id_to_pop` int(11) NOT NULL,
  `distance` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_storage_pop_distance_1_idx` (`id_from_pop`),
  KEY `fk_storage_pop_distance_2_idx` (`id_to_pop`),
  CONSTRAINT `fk_storage_pop_distance_1` FOREIGN KEY (`id_from_pop`) REFERENCES `storage_pop` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_storage_pop_distance_2` FOREIGN KEY (`id_to_pop`) REFERENCES `storage_pop` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

DROP TABLE IF EXISTS `stored_file_location`;
CREATE TABLE `stored_file_location` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_stored_file` int(11) NOT NULL,
  `id_storage_pop` int(11) NOT NULL,
  `date_stored` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_stored_file_instance_1_idx` (`id_stored_file`),
  KEY `fk_stored_file_location_2_idx` (`id_storage_pop`),
  CONSTRAINT `fk_stored_file_instance_1` FOREIGN KEY (`id_stored_file`) REFERENCES `stored_file` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_stored_file_location_2` FOREIGN KEY (`id_storage_pop`) REFERENCES `storage_pop` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;