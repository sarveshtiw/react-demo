const Joi = require('joi')

const schema = Joi.object().keys({
  file: Joi.string().required()
})

const schema2 = Joi.object().keys({
  asergisPopId: Joi.string().required()
})

exports.fileInfo = file => {
  let errors = []
  const {error} = Joi.validate({file: file}, schema, {abortEarly: false})
  if(error) {
    error.details.forEach(error => {
      let obj = {}
      obj.key = error.message.match(/"([^"]+)"/)[1]
      obj.message = error.message.split(/ (.+)/)[1]
      errors.push(obj)
    })
  }
  return errors
}

exports.uploadFile = (file, asergisPopId) => {
  let errors = []
  if(!file) {
    errors.push({
      key: 'file',
      message: 'is required'
    })
  }
  const {error} = Joi.validate({asergisPopId: asergisPopId}, schema2, {abortEarly: false})
  if(error) {
    error.details.forEach(error => {
      let obj = {}
      obj.key = error.message.match(/"([^"]+)"/)[1]
      obj.message = error.message.split(/ (.+)/)[1]
      errors.push(obj)
    })
  }
  return errors
}
