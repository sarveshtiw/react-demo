if (process.env.NODE_ENV === 'local') {
    require('dotenv').config();
}
const express = require('express')
const app = express()
const cors = require('cors');
const bodyParser = require('body-parser')
const HTTPStatus = require('http-status')
const swaggerUi = require('swagger-ui-express');
const amqp = require('amqplib')

const controllers = require('./controllers');
const swaggerDocument = require('./swagger.json');
const lib = require('./lib');
const { server, rabbitmq } = require('./config');

!async function () {
    try {


        app.use(cors());
        app.use('/docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

        app.use(bodyParser.urlencoded({ extended: false }))
        app.use(bodyParser.json())

        app.get('/healthz/liveness', controllers.healthCheck.liveness);
        app.get('/healthz/readiness', controllers.healthCheck.readiness);

        app.post('/fw-insert', controllers.file.insertRecord)
        app.post('/fw-delete', controllers.file.deleteRecord)

        

        app.listen(server.port, () => {
            console.log(`Server listening on port: ${server.host}:${server.port}`);
        });

        let amqpConnection = await amqp.connect(`amqp://${rabbitmq.username}:${rabbitmq.password}@${rabbitmq.host}:${rabbitmq.port}/${rabbitmq.prefix}`)

        let minioClients = await controllers.file.minioConfigs()
        //console.log(minioClients)
        let locationId = await controllers.file.locationId()

        app.use((req, res, next) => {
            req.minioClients = minioClients
            req.locationId = locationId
            req.amqpConnection = amqpConnection
            next()
        })

        app.post('/files-upload', controllers.file.uploadFiles)
        app.post('/files-get', controllers.file.getFiles)
        app.delete('/files-delete', controllers.file.deleteFiles)
    }
    catch (err) {
        console.log('dadasda', err)
        return err
    }
}();