File Storage Microservice
=========================

## Introduction
This is a REST API and Websocket backend for storing files. This API is developed in Express.

## How to run
This application requires node to be installed on your system. Please check [upstream documentation](https://nodejs.org/en/download/)
for how to install node on your system.

### Development build
In application root path run following commands
```bash
cd app; npm install
npm start
```
### Production build
Run following commands
```bash
cd app; npm install --only=production
npm start
```

## DB Migrations
This application uses nodejs based db migration mechanism. You need node to be installed on your system first. Please
check [upstream documentation](https://nodejs.org/en/download/) for how to install node on your system. After that you
need to install libraries:
```bash
npm install -g db-migrate db-migrate-pg db-migrate-mysql
```
and finally run the command in application root path:
```bash
cd app; db-migrate up --env ${ENVIRONMENT:=local} --config ./config/database.json
```
Migration application reads database.json config file to obtain database engine connection parameters:
```json
{
  "sql-file": true,
  "local": {
    "driver": "mysql",
    "multipleStatements": true,
    "host": "localhost",
    "user": "plcae_db_user_here",
    "password": "plcae_db_password_here",
    "database": "place_db_name_here"
  }
}
```
It can work with environment variables as well:
```json
{
  "sql-file": true,
  "development": {
    "driver": "mysql",
    "multipleStatements": true,
    "host": {
      "ENV": "DEVELOPMENT_APP_DB_HOST"
    },
    "database": {
      "ENV": "DEVELOPMENT_APP_DB_NAME"
    },
    "user": {
      "ENV": "DEVELOPMENT_APP_DB_USER"
    },
    "password": {
      "ENV": "DEVELOPMENT_APP_DB_PASS"
    }
  }
}
```

## Dependencies
This application required following connections to run:
- MySQL
- RabbitMQ
- auth-server
- ETCD
- Minio

## Environment variables
Environment variables is the main mechanism of manipulating application settings. Currently application recognizes
following environment variables:

| Variable           | Default value | Description          |
| ------------------ | ------------- | -------------------- |
| NODE_ENV           | null          | Sets current environment. Allows application to manipulate some settings automatically |
| HOST               | 0.0.0.0       | Address to listen on |
| PORT               | 3000          | Port to listen on    |
| MYSQL_SERVICE_HOST | localhost     | Database engine address |
| MYSQL_SERVICE_PORT | 3306          | Database engine port |
| APP_DB_NAME        | null          | Database name        |
| APP_DB_USER        | null          | Database user        |
| APP_DB_PASS        | null          | Database password    |
| RABBITMQ_SERVICE_HOST | localhost  | RabbitMQ address     |
| RABBITMQ_SERVICE_PORT | 5672       | RabbitMQ port        |
| RABBITMQ_USER      | guest         | RabbitMQ user        |
| RABBITMQ_PASSWORD  | guest         | RabbitMQ password    |
| RABBITMQ_PREFIX    | /             | RabbitMQ prefix      |
| AUTH_SERVER_SERVICE_SCHEME | http  | auth-server connection scheme (http or https) |
| AUTH_SERVER_SERVICE_HOST   | null  | auth-server address  |
| AUTH_SERVER_SERVICE_PORT   | null  | auth-server port     |
| AUTH_SERVER_SERVICE_PATH   | /     | Path auth-server accepts requests on |


## File System Access
Application does not require any kind of persistent or temporary volumes

## Testing with docker
To test application in docker you need first docker to be installed. Check [upstream documentation](https://docs.docker.com/install)
for how to install docker on your system.
To bring up all services run in repository root path
```bash
docker-compose -f docker/docker-compose.yml pull --ignore-pull-failures
docker-compose -f docker/docker-compose.yml up
```

## API Documentation
You can get API docs using /docs path
