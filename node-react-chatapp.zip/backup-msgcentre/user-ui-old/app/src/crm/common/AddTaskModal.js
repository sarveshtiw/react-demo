import React from 'react'
import { Col, FormGroup, FormControl, ButtonGroup, Radio, ButtonToolbar, InputGroup, Row, Form, Button, Modal, ControlLabel } from 'react-bootstrap';
import Dropdown from 'react-dropdown';
import _ from 'lodash';
import { graphql, compose, withApollo } from 'react-apollo';
import { DatePicker, TimePicker } from 'antd';
import { bootstrapUtils } from 'react-bootstrap/lib/utils';
import moment from 'moment';
import { ADD_ACTIVITY_TASK } from '../Mutations';
import { GET_ACTIVITY_TASK_BY_ID, ADD_CALL_DEFAULT } from '../Queries';
const optionData = {
  optionStatus: [
    'Not Started', 'Deferred', 'In Progress', 'Completed', 'Waiting on Someone Else'
  ]
};
const weeks = [
  'first', 'second', 'third', 'fourth', 'last'
]
const days = [
  'day', 'weekday', 'weekend day', 'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'
]

const months = [
  'january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'
]
class AddTaskModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      switchTab: 'none',
      model_id: this.props.model_id,
      model_name: this.props.model_name,
      AddNewTask: this.props.AddNewTask,
      data: {
        ownerArr: [],
        owner: '',
        due_date: '',
        end_after_occurence: '',
        recurrence_end_date: '',
        recurrence_type: 'none',
        end_date_option: '1',
        subject: '',
        task_status: '',
        description: ''
      },
      date: new Date(),
      daily_recurrence: {
        daily: 'daily',
        daily_day_no: 1
      },
      weekly_recurrence: {
        recur_every_week: '1',
        weekly_monday: false,
        weekly_tuesday: false,
        weekly_wednesday: false,
        weekly_thursday: false,
        weekly_friday: false,
        weekly_saturday: false,
        weekly_sunday: false
      },
      monthly_recurrence: {
        monthly_option: "day",
        monthly_day: 1,
        monthly_every_month: 1,
        monthly_week: "first",
        monthly_day_of_week: "weekday",
        monthly_of_every_month: 1
      },
      yearly_recurrence: {
        yearly: 'monthly',
        recur_every_year: 1,
        yearly_on_month: 'january',
        yearly_on_month_day: 12,
        yearly_week: 'first',
        yearly_day_of_week: 'monday',
        yearly_of_every_month: 'january',
      },
    };
    this.onSubmit = this.onSubmit.bind(this);
    this.onChange = this.onChange.bind(this);
  }

  componentWillMount() {
    this.getCrmOwner();
    if (this.props.taskId) {
      this.getCrmActivityTaskById(this.props.taskId);
    }
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      AddNewTask: nextProps.AddNewTask
    })
  }

  changeTab(e) {
    this.setState({
      switchTab: e
    })
  }

  // Input Type
  onChange(e) {
    let data = this.state.data;
    let value = e.target.value;
    data[e.target.name] = value;
    this.setState({
      data
    })
    console.log('onChange')
  }

  // Status and Owner Drop down
  _onSelect = (option, type) => {
    console.log(option, type)
    this.setState({
      data: {
        ...this.state.data,
        [type]: option.value
      }
    });
  }

  // Date
  setDate = (date, due_date) => {
    let value = date
    if (date == null) {
      value = null
    }
    if (due_date === "due_date") {
      this.setState({
        data: {
          ...this.state.data,
          due_date: value
        }
      });
    } else {
      this.setState({
        data: {
          ...this.state.data,
          recurrence_end_date: value
        }
      });
    }
  }

  // Add Task End Date
  onRadio = (e) => {
    let value = e.target.value;
    this.setState({
      data: {
        ...this.state.data,
        end_date_option: value
      }
    })
  }

  // Daily
  changeDaily = (e) => {
    let { daily_recurrence } = this.state;
    daily_recurrence[e.target.name] = e.target.value;
    this.setState({
      daily_recurrence
    });
  }

  // Day Selection
  weeklyChange = (e) => {
    let { weekly_recurrence } = this.state;
    weekly_recurrence[e.target.name] = e.target.value;
    if (e.target.type == "checkbox") {
      weekly_recurrence[e.target.name] = weekly_recurrence[e.target.name] ? false : true;
    } else {
      weekly_recurrence[e.target.name] = e.target.value;
    }
    this.setState({
      weekly_recurrence
    });
  }

  // Monthly
  monthlyChange = (e) => {
    let { monthly_recurrence } = this.state;
    monthly_recurrence[e.target.name] = e.target.value;
    this.setState({
      monthly_recurrence
    });
  }

  // Yearly
  yearlyChange = (e) => {
    let { yearly_recurrence } = this.state;
    yearly_recurrence[e.target.name] = e.target.value;
    this.setState({
      yearly_recurrence
    });
  }

  // Select Week 
  selectMonthlyWeek = (option, type, subType) => {
    this.setState({
      [type]: {
        ...this.state[type],
        [subType]: option.value
      }
    });
  }

  async onSubmit(e) {
    e.preventDefault();
    let input = {
      "owner": 786,
      // "owner": this.state.owner,
      'id_crm_task_status_master': this.state.data.task_status,
      "subject": this.state.data.subject,
      "due_date": this.state.data.due_date,
      "recurrence_type": this.state.switchTab,
      "end_date_option": this.state.data.end_date_option,
      "recurrence_end_date": this.state.data.recurrence_end_date,
      "description": this.state.data.description,
      "ActivityTaskLinks": [
        {
          "model_id": this.state.model_id,
          "model_name": this.state.model_name
        }
      ]
    }
    // Recurrence Type
    switch (this.state.switchTab) {
      case 'daily':
        input['Daily'] = [
          {
            'daily_option': this.state.daily_recurrence.daily,
            'daily_day_no': this.state.daily_recurrence.daily_day_no
          }
        ];

        break;
      case 'weekly':
        input['Weekly'] = [{
          "recur_every_week": this.state.weekly_recurrence.recur_every_week,
          "weekly_monday": this.state.weekly_recurrence.weekly_monday,
          "weekly_tuesday": this.state.weekly_recurrence.weekly_tuesday,
          "weekly_wednesday": this.state.weekly_recurrence.weekly_wednesday,
          "weekly_thursday": this.state.weekly_recurrence.weekly_thursday,
          "weekly_friday": this.state.weekly_recurrence.weekly_friday,
          "weekly_saturday": this.state.weekly_recurrence.weekly_saturday,
          "weekly_sunday": this.state.weekly_recurrence.weekly_sunday
        }];
        break;
      case 'monthly':
        input['Monthly'] = [{
          "monthly_option": this.state.monthly_recurrence.monthly_option,
          "monthly_day": this.state.monthly_recurrence.monthly_day,
          "monthly_every_month": this.state.monthly_recurrence.monthly_every_month,
          "monthly_week": this.state.monthly_recurrence.monthly_week,
          "monthly_day_of_week": this.state.monthly_recurrence.monthly_day_of_week,
          "monthly_of_every_month": this.state.monthly_recurrence.monthly_of_every_month
        }];
        break;
      case 'yearly':
        input['Yearly'] = [{
          "yearly_option": this.state.yearly_recurrence.yearly,
          "recur_every_year": this.state.yearly_recurrence.recur_every_year,
          "yearly_on_month": this.state.yearly_recurrence.yearly_on_month,
          "yearly_on_month_day": this.state.yearly_recurrence.yearly_on_month_day,
          "yearly_week": this.state.yearly_recurrence.yearly_week,
          "yearly_of_every_month": this.state.yearly_recurrence.yearly_of_every_month
        }]
        break;
      default:
        break;
      case 'none':
        break;
    }
    // Recurrence Type
    switch (this.state.data.end_date_option) {
      case 'no':
        break;
      case 'endafter':
        input['end_after_occurence'] = this.state.data.end_after_occurence;
        break;
      case 'endby':
        input['end_date'] = this.state.data.end_date;
        break;
      default:
        break;
    }
    try {
      let response = await this.props.addActivityTask({
        variables: {
          input: input
        }
      })
      if (response.data.createCrmActivityTask.message === 'Success') {
        console.log(input)
        this.setState({
          AddNewTask: false
        })
      }

    } catch (err) {
      console.log(err)
    }
  }
  getCrmOwner = async () => {
    console.log(this.props)
    try {
      let response = await this.props.client.query({
        query: ADD_CALL_DEFAULT
      })
      this.setState({
        data: {
          ...this.state.data,
          ownerArr: response.data.getCrmOwner,
        }
      })
    } catch (err) {

    }
  }

  getCrmActivityTaskById = async (id) => {
    try {
      let response = await this.props.client.query({
        query: GET_ACTIVITY_TASK_BY_ID,
        variables: {
          input: Number(id)
        }
      })
      let res = response.data.getCrmActivityTaskById.result;
      this.setState({
        switchTab: res.recurrence_type,
        data: {
          ...this.state.data,
          owner: res.owner,
          due_date: moment(res.due_date),
          end_after_occurence: res.end_after_occurence,
          recurrence_end_date: res.recurrence_end_date ? moment(res.recurrence_end_date) : '',
          recurrence_type: res.type,
          end_date_option: res.end_date_option.toString(),
          subject: res.subject,
          task_status: res.id_crm_task_status_master,
          description: res.description
        }
      })
      switch (res.recurrence_type) {
        case 'daily':
          this.setState({
            daily_recurrence: {
              daily: res.Daily[0].daily_option,
              daily_day_no: res.Daily[0].daily_day_no
            }
          })

          break;
        case 'weekly':
          this.setState({
            weekly_recurrence: {
              recur_every_week: res.Weekly[0].monthly_option,
              weekly_monday: res.Weekly[0].weekly_monday,
              weekly_tuesday: res.Weekly[0].weekly_tuesday,
              weekly_wednesday: res.Weekly[0].weekly_wednesday,
              weekly_thursday: res.Weekly[0].weekly_thursday,
              weekly_friday: res.Weekly[0].weekly_friday,
              weekly_saturday: res.Weekly[0].weekly_saturday,
              weekly_sunday: res.Weekly[0].weekly_sunday
            }
          })
          break;
        case 'monthly':
          this.setState({
            monthly_recurrence: {
              monthly_option: res.Monthly[0].monthly_option,
              monthly_day: res.Monthly[0].monthly_day,
              monthly_every_month: res.Monthly[0].monthly_every_month,
              monthly_week: res.Monthly[0].monthly_week,
              monthly_day_of_week: res.Monthly[0].monthly_day_of_week,
              monthly_of_every_month: res.Monthly[0].monthly_of_every_month
            }
          })
          break;
        case 'yearly':
          this.setState({
            yearly_recurrence: {
              yearly: res.Yearly[0].recur_every_year,
              recur_every_year: res.Yearly[0].monthly_option,
              yearly_on_month: res.Yearly[0].yearly_on_month,
              yearly_on_month_day: res.Yearly[0].yearly_on_month_day,
              yearly_week: res.Yearly[0].yearly_week,
              yearly_day_of_week: res.Yearly[0].yearly_day_of_week,
              yearly_of_every_month: res.Yearly[0].yearly_of_every_month,
            }
          })
          break;
        default:
          break;
        case 'none':
          break;
      }
    } catch (err) {
      console.log(err)
    }
  }

  render() {
    bootstrapUtils.addStyle(Button, 'conBtn');
    return (
      <Modal
        show={true}
        onHide={() => this.props.taskClose()}
        dialogClassName="modal-md audioView bg-white">
        <Modal.Body>
          <div className="ibox">
            <div className="ibox-title pt-5 pl-5 pr-5 pb-0 clearfix">
              <h5 className="h-modal">Add New Task</h5>
            </div>
            <div className="ibox-content ml-5 mr-5 pl-0 pr-0 no-border">
              <Form className="row" onSubmit={this.onSubmit}>
                <Col className="clearfix">
                  <Col sm={6} xs={12}>
                    <FormGroup>
                      <ControlLabel>Subject</ControlLabel>
                      <FormControl
                        type="text"
                        onChange={this.onChange}
                        value={this.state.data.subject}
                        placeholder="subject"
                        name="subject" />
                    </FormGroup>
                    <FormGroup>
                      <ControlLabel>Status</ControlLabel>
                      <FormControl
                        componentClass="select"
                        name="owner"
                        placeholder="select owner"
                        value={this.state.data.status}
                        onChange={this.onChange}>
                        {
                          optionData.optionStatus.map((item, key) => {
                            return <option value={item} key={key}>{item}</option>
                          })
                        }
                      </FormControl>
                    </FormGroup>
                  </Col>

                  <Col sm={6} xs={12}>
                    <FormGroup>
                      <ControlLabel>Due Date</ControlLabel>
                      <DatePicker
                        style={{ width: '100%' }}
                        format="ddd, DD MMM YYYY"
                        onChange={(date) => this.setDate(date, "due_date")}
                        value={this.state.data.due_date} />
                    </FormGroup>
                    <FormGroup>
                      <ControlLabel>Owner</ControlLabel>
                      <FormControl
                        componentClass="select"
                        name="owner"
                        placeholder="select owner"
                        value={this.state.data.owner}
                        onChange={this.onChange}>
                        {
                          this.state.data.ownerArr.map((item, key) => {
                            return <option value={item.id} key={key}>{item.name}</option>
                          })
                        }
                      </FormControl>
                    </FormGroup>
                  </Col>
                </Col>
                <hr className="bdr mt-4" />
                <div className="clearfix">
                  <div className="col-md-12 mt-4 mb-4 inner-heading">Task Recurrence</div>
                  <FormGroup className="clearfix">
                    <Col md={12}>
                      <ButtonToolbar>
                        <Button
                          onClick={() => this.changeTab('none')}
                          bsStyle="conBtn"
                          className={this.state.switchTab === 'none' ? 'active' : ''}>None</Button>
                        <Button
                          onClick={() => this.changeTab('daily')}
                          bsStyle="conBtn"
                          className={this.state.switchTab === 'daily' ? 'active' : ''}>Daily </Button>
                        <Button
                          onClick={() => this.changeTab('weekly')}
                          bsStyle="conBtn"
                          className={this.state.switchTab === 'weekly' ? 'active' : ''}>Weekly</Button>
                        <Button
                          onClick={() => this.changeTab('monthly')}
                          bsStyle="conBtn"
                          className={this.state.switchTab === 'monthly' ? 'active' : ''}>Monthly</Button>
                        <Button
                          onClick={() => this.changeTab('yearly')}
                          bsStyle="conBtn"
                          className={this.state.switchTab === 'yearly' ? 'active' : ''}>Yearly</Button>
                      </ButtonToolbar>
                    </Col>
                  </FormGroup>
                  {(() => {
                    switch (this.state.switchTab) {
                      case 'none':
                        return;
                        break;
                      case 'daily':
                        return (
                          <div>
                            <Col md={12}>
                              <FormGroup>
                                <Row>
                                  <Col md={4}>
                                    <div className="radio radio-info radio-inline" onChange={this.changeDaily}>
                                      <input
                                        id="daily"
                                        type="radio"
                                        value="daily"
                                        name="daily"
                                        checked={this.state.daily_recurrence.daily === 'daily'}
                                        style={{ marginTop: '10px', marginLeft: ' -19px' }} />
                                      <label htmlFor="daily"> Every &nbsp;</label>
                                      <FormControl
                                        type="text"
                                        placeholder={1}
                                        name="daily_day_no"
                                        className="sm-input occur d-inline-block"
                                        value={this.state.daily_recurrence.daily_day_no}
                                        onChange={this.changeDaily}
                                        disabled={this.state.daily_recurrence.daily === 'daily' ? false : true}
                                      /> &nbsp;&nbsp;<b> Day</b> &nbsp;&nbsp;&nbsp;
                                    </div>
                                  </Col>
                                  <Col md={4} className="addconf">
                                    <div className="radio radio-info radio-inline"
                                      onChange={this.changeDaily}>
                                      <input
                                        id="weekday"
                                        type="radio"
                                        value="weekday"
                                        name="daily"
                                        checked={this.state.daily_recurrence.daily === 'weekday'} />
                                      <label htmlFor="weekday"> Every Weekday </label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                  	</div>
                                  </Col>
                                </Row>
                              </FormGroup>
                            </Col>
                            <div className="clearfix"></div>
                            <hr />
                          </div>
                        );
                        break;
                      case 'weekly':
                        return (
                          <div>
                            <Col md={12} className="recur">
                              <span>Recur every</span>
                              <span className="weeks">
                                <input
                                  className="form-control"
                                  type="text"
                                  value={this.state.recur_every_week}
                                  placeholder="1"
                                  name="recur_every_week"
                                  onChange={this.weeklyChange}
                                />
                              </span>
                              <span>week(s) on:</span>
                            </Col>
                            <Col md={12} className="mt-3" >
                              <div className="checkbox checkbox-week checkbox-inline">
                                <input
                                  id="weekly_monday"
                                  type="checkbox"
                                  name="weekly_monday"
                                  value={this.state.weekly_recurrence.weekly_monday}
                                  onChange={this.weeklyChange}
                                  checked={this.state.weekly_recurrence.weekly_monday === true} />
                                <label className="mr-3" htmlFor="weekly_monday"> Monday </label>
                              </div>
                              <div className="checkbox checkbox-week checkbox-inline">
                                <input
                                  type="checkbox"
                                  name="weekly_tuesday"
                                  id="weekly_tuesday"
                                  value={this.state.weekly_tuesday}
                                  onChange={this.weeklyChange}
                                  checked={this.state.weekly_recurrence.weekly_tuesday === true} />
                                <label className="mr-3" htmlFor="weekly_tuesday"> Tuesday </label>
                              </div>
                              <div className="checkbox checkbox-week checkbox-inline">
                                <input
                                  type="checkbox"
                                  name="weekly_wednesday"
                                  id="weekly_wednesday"
                                  value={this.state.weekly_wednesday}
                                  onChange={this.weeklyChange}
                                  checked={this.state.weekly_recurrence.weekly_wednesday === true} />
                                <label className="mr-3" htmlFor="weekly_wednesday"> Wednesday </label>
                              </div>
                              <div className="checkbox checkbox-week checkbox-inline">
                                <input
                                  type="checkbox"
                                  name="weekly_thursday"
                                  id="weekly_thursday"
                                  value={this.state.weekly_thursday}
                                  onChange={this.weeklyChange}
                                  checked={this.state.weekly_recurrence.weekly_thursday === true} />
                                <label className="mr-3" htmlFor="weekly_thursday"> Thursday </label>
                              </div>
                              <div className="checkbox checkbox-week checkbox-inline">
                                <input
                                  type="checkbox"
                                  name="weekly_friday"
                                  id="weekly_friday"
                                  value={this.state.weekly_friday}
                                  onChange={this.weeklyChange}
                                  checked={this.state.weekly_recurrence.weekly_friday === true} />
                                <label className="mr-3" htmlFor="weekly_friday"> Friday </label>
                              </div>
                              <div className="checkbox checkbox-week checkbox-inline">
                                <input
                                  type="checkbox"
                                  name="weekly_saturday"
                                  id="weekly_saturday"
                                  value={this.state.weekly_saturday}
                                  onChange={this.weeklyChange}
                                  checked={this.state.weekly_recurrence.weekly_saturday === true} />
                                <label className="mr-3" htmlFor="weekly_saturday"> Saturday </label>
                              </div>
                              <div className="checkbox checkbox-week checkbox-inline">
                                <input
                                  type="checkbox"
                                  name="weekly_sunday"
                                  id="weekly_sunday"
                                  value={this.state.weekly_sunday}
                                  onChange={this.weeklyChange}
                                  checked={this.state.weekly_recurrence.weekly_sunday === true} />
                                <label className="mr-3" htmlFor="weekly_sunday"> Sunday </label>
                              </div>
                            </Col>
                            <div className="clearfix"></div>
                            <hr />
                          </div>
                        );
                        break;
                      case 'monthly':
                        return (
                          <div>
                            <Col md={12}>
                              <FormGroup>
                                <Row>
                                  <Col md={12}>
                                    <div className="radio radio-info radio-inline">
                                      <input
                                        type="radio"
                                        value="day"
                                        defaultChecked
                                        name="monthly_option"
                                        id="monthly_option_1"
                                        onClick={this.monthlyChange}
                                        style={{ marginTop: '9px', marginLeft: ' -19px' }}
                                      />
                                      <label htmlFor="monthly_option_1"> Day &nbsp;&nbsp;</label>
                                      <FormControl
                                        type="text"
                                        placeholder={1}
                                        name="monthly_day"
                                        className="sm-input occur d-inline-block"
                                        value={this.state.monthly_day}
                                        onChange={this.monthlyChange}
                                        disabled={this.state.monthly_recurrence.monthly_option === 'day' ? false : true}
                                      />&nbsp;&nbsp;<b>Of every</b>&nbsp;&nbsp;
                                      <FormControl
                                        type="text"
                                        placeholder={1}
                                        name="monthly_every_month"
                                        className="sm-input occur d-inline-block"
                                        value={this.state.monthly_every_month}
                                        onChange={this.monthlyChange}
                                        disabled={this.state.monthly_recurrence.monthly_option === 'day' ? false : true}
                                      />&nbsp;&nbsp;<b>month</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    </div>
                                  </Col>
                                </Row>
                              </FormGroup>
                            </Col>
                            <Col md={12}>
                              <FormGroup>
                                <Row>
                                  <Col md={12} className="linedrop">
                                    <div className="radio radio-info radio-inline">
                                      <div className="one">
                                        <input
                                          type="radio"
                                          value="weekly"
                                          name="monthly_option"
                                          id="monthly_option"
                                          onClick={this.monthlyChange}
                                          style={{ marginTop: '3px', marginLeft: ' -19px' }} />
                                        <label htmlFor="monthly_option"> The &nbsp;&nbsp;</label>
                                      </div>
                                      <Dropdown
                                        options={weeks}
                                        placeholder="Select"
                                        value={this.state.monthly_recurrence.monthly_week}
                                        onChange={(option) => this.selectMonthlyWeek(option, 'monthly_recurrence', 'monthly_week')}
                                        disabled={this.state.monthly_recurrence.monthly_option === 'weekly' ? false : true} />
                                      <Dropdown
                                        options={days}
                                        placeholder="Select"
                                        value={this.state.monthly_recurrence.monthly_day_of_week}
                                        onChange={(option) => this.selectMonthlyWeek(option, 'monthly_recurrence', 'monthly_day_of_week')}
                                        disabled={this.state.monthly_recurrence.monthly_option === 'weekly' ? false : true} />
                                      <div className="two">
                                        <b>of every</b>&nbsp;&nbsp;
                                        <FormControl
                                          type="text"
                                          placeholder={1}
                                          name="monthly_of_every_month"
                                          className="sm-input occur d-inline-block"
                                          value={this.state.monthly_of_every_month}
                                          onChange={this.monthlyChange}
                                          disabled={this.state.monthly_recurrence.monthly_option === 'weekly' ? false : true}
                                        />
                                        &nbsp;&nbsp;<b>month</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                      </div>
                                    </div>
                                  </Col>
                                </Row>
                              </FormGroup>
                            </Col>
                            <div className="clearfix"></div>
                            <hr />
                          </div>
                        );
                        break;
                      case 'yearly':
                        return (
                          <div>
                            <Col md={12} className="recur">
                              <span>Recur every</span>
                              <span className="weeks">
                                <input
                                  className="form-control"
                                  type="text"
                                  placeholder="1"
                                  name="recur_every_year"
                                  onChange={this.yearlyChange} />
                              </span>
                              <span>year</span>
                            </Col>
                            <Col md={12}>
                              <FormGroup>
                                <Row>
                                  <Col md={12} className="linedrop">
                                    <div className="radio radio-info radio-inline">
                                      <div className="one">
                                        <input
                                          type="radio"
                                          value="monthly"
                                          name="yearly"
                                          id="yearly_1"
                                          defaultChecked
                                          onChange={this.yearlyChange} />
                                        <label htmlFor="yearly_1"> On &nbsp;&nbsp;</label>
                                      </div>
                                      <Dropdown
                                        placeholder="Select"
                                        options={months}
                                        value={this.state.yearly_recurrence.yearly_on_month}
                                        disabled={this.state.yearly_recurrence.yearly === 'monthly' ? false : true}
                                        onChange={(option) => this.selectMonthlyWeek(option, 'yearly_recurrence', 'yearly_on_month')} />
                                      <div className="two">
                                        <FormControl
                                          type="text"
                                          placeholder={1}
                                          name="yearly_on_month_day"
                                          className="sm-input occur d-inline-block"
                                          value={this.state.yearly_recurrence.yearly_on_month_day}
                                          onChange={this.yearlyChange}
                                          disabled={this.state.yearly_recurrence.yearly === 'monthly' ? false : true}
                                        />
                                      </div>
                                    </div>
                                  </Col>
                                </Row>
                              </FormGroup>
                            </Col>
                            <Col md={12}>
                              <FormGroup>
                                <Row>
                                  <Col md={12} className="linedrop">
                                    <div className="radio radio-info radio-inline">
                                      <div className="one">
                                        <input
                                          type="radio"
                                          value="weekly"
                                          name="yearly"
                                          id="yearly_2"
                                          onChange={this.yearlyChange} />
                                        <label htmlFor="yearly_2"> On The &nbsp;&nbsp;</label>
                                      </div>
                                      <Dropdown
                                        options={weeks}
                                        placeholder="Select"
                                        value={this.state.yearly_recurrence.yearly_week}
                                        disabled={this.state.yearly_recurrence.yearly === 'weekly' ? false : true}
                                        onChange={(option) => this.selectMonthlyWeek(option, 'yearly_recurrence', 'yearly_week')} />
                                      <Dropdown
                                        options={days}
                                        placeholder="Select"
                                        value={this.state.yearly_recurrence.changeYearlyDay}
                                        disabled={this.state.yearly_recurrence.yearly === 'weekly' ? false : true}
                                        onChange={(option) => this.selectMonthlyWeek(option, 'yearly_recurrence', 'changeYearlyDay')} />
                                      <div className="two yeSpace">
                                        <b>of</b>&nbsp;&nbsp;
																		</div>
                                      <Dropdown
                                        options={months}
                                        placeholder="Select"
                                        value={this.state.yearly_of_every_month}
                                        disabled={this.state.yearly_recurrence.yearly === 'weekly' ? false : true}
                                        onChange={(option) => this.selectMonthlyWeek(option, 'yearly_recurrence', 'changeYearlyDay')} />
                                    </div>
                                  </Col>
                                </Row>
                              </FormGroup>
                            </Col>
                            <div className="clearfix"></div>
                            <hr />
                          </div>
                        );
                        break;
                      default:
                        return;
                    }
                  })()}
                  <div className="col-md-12 mt-4 mb-4 inner-heading">Add Task End Date</div>
                  <FormGroup className="clearfix">
                    <Col md={2} className="rwithfiled">
                      <div className="radio radio-info radio-inline" onChange={this.onRadio}>
                        <input
                          id="no"
                          type="radio"
                          value="1"
                          name="end_date_option"
                          checked={this.state.data.end_date_option === '1'} />
                        <label htmlFor="no"> No </label>
                      </div>
                    </Col>
                    <Col md={4} className="rwithfiled">
                      <div className="radio radio-info radio-inline" onChange={this.onRadio}>
                        <input
                          id="endafter"
                          type="radio"
                          value="2"
                          name="end_date_option"
                          checked={this.state.data.end_date_option === '2'} />
                        <label htmlFor="endafter"> End After </label>
                      </div>
                      <FormControl
                        type="text"
                        placeholder="1"
                        name="end_after_occurence"
                        className="sm-input"
                        value={this.state.data.end_after_occurence}
                        onChange={this.onChange}
                        disabled={this.state.data.end_date_option !== '2' ? true : false}
                      />
                      <ControlLabel className="day">Day</ControlLabel>
                    </Col>
                    <Col md={4} className="rwithfiled">
                      <div className="radio radio-info radio-inline" onChange={this.onRadio}>
                        <input
                          id="endby"
                          type="radio"
                          value="3"
                          name="end_date_option"
                          checked={this.state.data.end_date_option === '3'} />
                        <label htmlFor="endby"> End By </label>
                      </div>
                      <div className="end-date">
                        <DatePicker
                          style={{ width: '100%' }}
                          format="ddd, DD MMM YYYY"
                          onChange={(date) => this.setDate(date)}
                          value={this.state.data.recurrence_end_date}
                          allowClear={true}
                          placeholder="select date"
                          disabled={this.state.data.end_date_option !== '3' ? true : false}
                        />
                      </div>
                    </Col>
                  </FormGroup>
                  <hr className="bdr mt-3 mb-4" />
                  <div className="col-md-12 mt-4 mb-4 inner-heading">Description</div>
                  <FormGroup className="clearfix">
                    <Col md={12}>
                      <textarea
                        className="form-control"
                        rows="4"
                        placeholder="description"
                        name="description"
                        value={this.state.data.description}
                        onChange={this.onChange}
                      />
                    </Col>
                  </FormGroup>
                </div>
                <Col sm={12} className="text-left mt-4">
                  <Button className="btn-submit" type="submit">Submit</Button>
                  <Button className="btn-cancel" onClick={() => this.props.taskClose()}>Cancel</Button>
                </Col>
              </Form>
            </div>
          </div>
        </Modal.Body>
      </Modal>
    )
  }
}
export default compose(
  withApollo,
  graphql(ADD_ACTIVITY_TASK, {
    name: 'addActivityTask'
  })
)(AddTaskModal);