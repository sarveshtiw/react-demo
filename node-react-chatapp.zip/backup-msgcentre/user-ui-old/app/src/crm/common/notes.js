import React from 'react'
import { Col, Table, FormGroup, FormControl, Form, Button, OverlayTrigger, Tooltip, ProgressBar, HelpBlock } from 'react-bootstrap';
import { graphql, compose, withApollo } from 'react-apollo';
import _ from 'lodash';
import moment from 'moment';
import axios from 'axios';
import { isArray } from 'util'
import SuccessErrorModal from '../../common/containers/successErrorModal';
import { GET_NOTES } from '../Queries';
import { CREATE_NOTE, UPDATE_NOTE, DELETE_NOTE } from '../Mutations';

class Notes extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            notes: [],
            uploadImage: [],
            uploadInput: '',
            uploadImgClose: '',
            fileSize: '',
            fileName: '',
            fileInfo: [],
            error: '',
            model_id: this.props.id,
            model_name: this.props.type,
            noteId: null,
            note_title: null,
            note_description: null,
            ModelNoteAttachments: [],
            companyList: [],
            attachedFile: [],
        }
    }

    handleChange = (e) => {
        let { name, value } = e.target
        if (this.state.note_title != '') {
            this.setState({
                error: ''
            })
        } else {
            this.setState({
                error: 'Please enter the note_title'
            })
        }
        this.setState({
            [name]: value
        })
    }

    bytesToSize = (bytes) => {
        var sizes = ['Bytes', 'Kb', 'Mb', 'Gb', 'Tb'];
        if (bytes == 0) return 'n/a';
        var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
        if (i == 0) return bytes + ' ' + sizes[i];
        return (bytes / Math.pow(1024, i)).toFixed(1) + ' ' + sizes[i];
    }

    uploadImgClose = (id) => {
        let filterFileArr = this.state.fileInfo.filter(item => {
            return item.id !== id
        })
        console.log(filterFileArr)
        this.setState({
            percentage: 0,
            fileInfo: filterFileArr
        });
    }

    uploadImage = (e) => {
        let { name, files } = e.target
        console.log(files);
        let fileInfoArr = Object.keys(files).map(function (key) { return files[key]; })
        fileInfoArr.map((item, index) =>
            item['id'] = index
        )
        this.setState({
            uploadInput: !this.state.uploadInput,
            fileInfo: fileInfoArr,
        })
        let fileArr = e.target.files, i = 0;
        const formData = new FormData();
        while (i < fileArr.length) {
            formData.append('files', fileArr[i])
            i++
        }
        formData.append('appName', 'synthesis');
        formData.append('locationId', '3');
        formData.append('replication', '0');
        formData.append('bucketName', 'app');
        formData.append('restriction', '0');

        let myUploadProgress = (myFileId) => (progress) => {
            this.setState({
                ['percentage' + myFileId]: Math.round((progress.loaded * 100) / progress.total)
            })
        }
        for (let j = 0; j < files.length; j++) {
            let config = {
                headers: {
                    'content-type': 'multipart/form-data',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                },
                onUploadProgress: myUploadProgress(j).bind(this)
            };

            axios.post(`http://192.168.1.171:3020/file-upload`, formData, config)
                .then(({ data }) => {
                    console.log(data)
                    if (data.uploadedfiles) {
                        this.setState({
                            attachedFile: data.uploadedfiles,
                        })
                    }
                }).catch(err => {
                    console.log(err);
                });
        }
    }

    componentWillMount = async () => {
        if (this.state.model_id) {
            this.getAllCrmNotesByModel(this.state.model_id);
        }
    }

    getAllCrmNotesByModel = async (id) => {
        let input = {
            model_id: id,
            model_name: this.state.model_name
        }
        try {
            let response = await this.props.client.query({
                query: GET_NOTES,
                variables: {
                    input
                }
            })
            this.setState({
                notes: response.data.getAllCrmNotesByModel.ModelNotes
            })
        } catch (err) {
            console.log(err)
        }
    }

    onsubmit = async (e) => {
        e.preventDefault();
        if (this.state.note_title) {
            this.CreateCrmNote(this.state.noteId)
        } else {
            this.setState({
                error: 'Please enter the Note Title'
            })
        }
    }

    CreateCrmNote = async (noteId) => {
        const { note_title, note_description, ModelNoteAttachments, error, model_id, model_name } = this.state
        let inputData = {
            "model_id": model_id,
            "model_name": model_name,
            "note_title": note_title,
            "note_description": note_description,
            "ModelNoteAttachments": []
        }
        console.log(inputData);
        this.state.attachedFile.map((item) =>
            inputData['ModelNoteAttachments'].push({
                minio_file_id: item.fileId
            })
        )


        if (noteId) {
            // inputData['id'] = noteId
            try {
                let response = await this.props.updateNoteById({
                    variables: {
                        id: noteId,
                        input: inputData
                    }
                })
                if (response.data.updateCrmModelNote !== null) {
                    this.clearState()
                    this.getAllCrmNotesByModel(model_id)
                }

            } catch (err) {
                console.log(err)
            }

        }
        else {
            try {
                let response = await this.props.createNote({
                    variables: {
                        input: inputData
                    }
                })
                if (response.data.createNote !== null) {
                    this.clearState()
                    this.getAllCrmNotesByModel(model_id)
                }
            } catch (err) {

            }
        }

    }

    deleteCrmNoteById = async (id) => {
        const { model_id, model_name } = this.state;
        try {
            let response = await this.props.deleteNoteById({
                variables: {
                    input: {
                        "id": Number(id)
                    }
                }
            })
            if (response.data.deleteCrmModelNote) {
                this.getAllCrmNotesByModel(this.props.id)
            }

        } catch (err) {
            console.log(err)
        }
    }
    clearState() {
        this.setState({
            success: true,
            note_title: '',
            note_description: '',
            error: '',
            ModelNoteAttachments: '',
            uploadInput: false,
            percentage: 0
            // ['percentage' + myFileId]: 0
        })
    }
    updatedNotesByID(item) {
        let fileInfoArr = _.cloneDeep(item.ModelNoteAttachments);
        fileInfoArr = Object.keys(fileInfoArr).map(function (key) { return fileInfoArr[key]; })
        fileInfoArr.map((item, index) => {
            item['id'] = index
        })
        for (let m = 0; m < item.ModelNoteAttachments.length; m++) {
            this.setState({
                ['percentage' + m]: 100
            })
        }
        this.setState({
            noteId: item.id,
            note_title: item.note_title,
            note_description: item.note_description,
            fileInfo: fileInfoArr,
            uploadInput: true,
        })
    }
    render() {
        const { fileInfo, note_title, note_description, ModelNoteAttachments, error, notes, noteId, success } = this.state;
        return (
            <div className="ibox notes">
                <div className="ibox-title clearfix">
                    <div className="col-sm-12">
                        <h5>Notes</h5>
                    </div>
                </div>
                <div className="ibox-content clearfix p-4">
                    <Form className="col-sm-12" onSubmit={this.onsubmit}>
                        <div className="attach-box">
                            <div className="form-group row">
                                <div className="col-sm-8">
                                    <FormGroup className={error != '' ? 'has-error' : ''}>
                                        <FormControl
                                            type="text"
                                            name="note_title"
                                            value={note_title}
                                            placeholder="add a title"
                                            onChange={this.handleChange}
                                        />
                                        {error != '' ? <HelpBlock>{error}</HelpBlock> : ''}
                                    </FormGroup>
                                </div>
                            </div>
                            <div className="form-group">
                                <FormControl
                                    componentClass="textarea"
                                    placeholder="add notes"
                                    name='note_description'
                                    value={note_description}
                                    rows='5'
                                    onChange={this.handleChange}
                                />
                            </div>
                            <div className="form-group row mt-5 mb-0 d-flex justify-content-start">
                                <div className="col-sm-6  d-flex align-items-center">
                                    <div className="pos-r attachLinkWrap d-flex pointer">
                                        <button className="btn btn-attach pointer"><i className="icon-clip"></i> Attach File</button>
                                        <FormControl
                                            type="file"
                                            multiple
                                            name="uploadImage"
                                            placeholder="add a title"
                                            className="pos-a attachLink pointer"
                                            onChange={(e) => this.uploadImage(e)}
                                        />
                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <Button className="btn-submit pull-right mr-0" type="submit">Save</Button>
                                    <Button className="btn-cancel pull-right mr-4">Cancel</Button>
                                </div>
                            </div>
                            {this.state.uploadInput &&
                                <div className="form-group row notesProgressBar">
                                    {
                                        fileInfo.map((item, index) =>
                                            <div key={index} className="col-sm-9 d-flex align-items-center">
                                                <span className="col-sm-4">{item.name} ({this.bytesToSize(item.size)})</span>
                                                <div className="col-sm-6">
                                                    <ProgressBar bsStyle="success" now={this.state['percentage' + index]} />
                                                </div>
                                                <i className="material-icons" onClick={() => this.uploadImgClose(item.id)}>close</i>
                                            </div>
                                        )
                                    }
                                </div>
                            }
                        </div>
                    </Form>
                    <div className="col-sm-12">
                        {notes.map((item, index) =>
                            <div className="attach-box-2  mt-4 clearfix" key={index}>
                                <div className="row">
                                    <div className="col-sm-12">
                                        <div className="d-flex justify-content-end">
                                            <i className="material-icons" onClick={() => this.updatedNotesByID(item)}>border_color</i>
                                            <i className="material-icons" onClick={() => this.deleteCrmNoteById(item.id)}>close</i>
                                        </div>
                                    </div>
                                    {item.ModelNoteAttachments.length ?
                                        <div className="col-sm-6 d-flex">
                                            <div className="pull-left mr-4">
                                                <img src="/images/added.png" alt="Avatar" className="imgNew pull-left" />
                                            </div>
                                            <div className="d-flex justify-content-center flex-column p-5">
                                                <h3>print_screen.jpg</h3>
                                                <h4>(212Kb)</h4>
                                                <div>
                                                    <i className="material-icons ml-0">remove_red_eye</i>
                                                    <i className="icon-download"></i>
                                                </div>
                                            </div>
                                        </div>
                                        : ''
                                    }
                                    <div className={item.ModelNoteAttachments.length ? "col-sm-6" : 'col-sm-12 '} id={item.ModelNoteAttachments.length} >
                                        <div className="d-flex align-content-start">
                                            <div className="pull-left mr-4">
                                                <img src="/images/user.png" alt="Avatar" className="img" />
                                            </div>
                                            <div>
                                                <h3 className="text-capitalize">{item.note_title}</h3>
                                                <h4>{item.updated_by != null ? item.updated_by : item.created_by} <strong>{
                                                    moment(moment(item.created_at).format("YYYYMMDD"), "YYYYMMDD").fromNow()
                                                }</strong></h4>
                                                <p>{item.note_description}</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
                {
                    success &&
                    <SuccessErrorModal icon='/images/tick.png'
                        content={
                            <div className="text-center">
                                <p>Your Notes has been {noteId ? 'updated' : 'created'} successfully</p>
                            </div>
                        }
                        upperClose={true}
                        closeModal={() => this.setState({ success: false })}
                    />
                }
            </div>
        )
    }
}
export default compose(
    withApollo,
    graphql(CREATE_NOTE, {
        name: 'createNote'
    }),
    graphql(DELETE_NOTE, {
        name: 'deleteNoteById'
    }),
    graphql(UPDATE_NOTE, {
        name: 'updateNoteById'
    })
)(Notes)