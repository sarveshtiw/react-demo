import React from 'react';
import { Col, Table, FormGroup, FormControl, ButtonGroup, Radio, ButtonToolbar, InputGroup, Row, Form, Button, OverlayTrigger, Tooltip, Modal, ControlLabel } from 'react-bootstrap';
import { DatePicker, TimePicker } from 'antd';
import { graphql, compose, withApollo } from 'react-apollo';
import { Scrollbars } from 'react-custom-scrollbars';
import Dropdown from 'react-dropdown';
import LinkWithTooltip from '../../common/containers/tooltip';
import { TooltipNew, TooltipNew2 } from './tooltip-new';
import moment from 'moment';
import AddTaskModal from './AddTaskModal';
import AddEventModal from './AddEventModal';
import AddCallModal from './AddCallModal';
import '../style/leads.scss';
import { GET_ACTIVITY_BY_MODEL } from '../Queries'

class Activities extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: '',
      model_id: this.props.id,
      model_name: this.props.type,
      taskId: '',
      callId: '',
      eventId: ''
    }
  }

  componentWillMount = async () => {

    if (this.state.model_id) {
      this.getCrmActivityListByModel(this.state.model_id);
    }
  }
  getCrmActivityListByModel = async (id) => {
    let input = {
      model_id: id,
      model_name: this.state.model_name
    }
    try {
      let response = await this.props.client.query({
        query: GET_ACTIVITY_BY_MODEL,
        variables: {
          input
        }
      })
      this.setState({
        data: response.data.getCrmActivityListByModel.result
      })
    } catch (err) {
      console.log(err);
    }
  }
  AddNewTaskModal() {
    this.setState({
      AddNewTask: true
    })
  }
  taskClose() {
    this.setState({
      AddNewTask: false
    })
  }
  AddEventModal() {
    this.setState({
      AddNewEvent: true
    })
  }
  eventClose() {
    this.setState({
      AddNewEvent: false
    })
  }
  AddCallModal() {
    this.setState({
      AddNewCall: true
    })
  }
  callClose() {
    this.setState({
      AddNewCall: false
    })
  }
  editActivity(id, type) {
    console.log(id, type)
    switch (type) {
      case 'Task':
        this.setState({
          AddNewTask: true,
          taskId: id
        })
        break;
      case 'Call':
        this.setState({
          AddNewCall: true,
          callId: id
        })
        break;
      case 'Event':
        break;
        this.setState({
          AddNewEvent: true,
          eventId: id
        })
    }
  }

  deleteActivity(id, type) {
    console.log(id, type)
  }
  render() {
    const { data, AddNewTask, AddNewEvent, AddNewCall, showModal, deleteRequest } = this.state
    return (
      <div className="ibox">
        <div className="ibox-title mng-title clearfix">
          <div className="col-sm-6"><h5 className="mt-3">Activities</h5></div>
          <div className="col-sm-6 d-flex justify-content-end actionWrap">
            <TooltipNew2
              tooltip="New Task"
              classN="icon-task box-icon"
              styleN={{ fontSize: 20 }}
              customTp={() => this.AddNewTaskModal()}
              id="newTask" />

            <TooltipNew2
              tooltip="Add New Event"
              classN="icon-calender box-icon"
              styleN={{ fontSize: 18 }}
              customTp={() => this.AddEventModal()}
              id="addNewEvent" />

            <TooltipNew2
              tooltip="Add Call"
              classN="icon-telephone box-icon"
              styleN={{ fontSize: 18 }}
              customTp={() => this.AddCallModal()}
              id="addCall" />
          </div>
        </div>
        <div className="ibox-content clearfix no-topborder">
          <div className="gt-viewlead gTable-new row mt-2">
            <div className="table-responsive">
              <Table className="table-bordered">
                <thead>
                  <tr>
                    <th>Subject</th>
                    <th width="22%">Activity Owner </th>
                    <th width="22%">Scheduled Date/Time </th>
                    <th width="12%" className="text-center">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {
                    data &&
                    data.map((item, index) => {
                      return (
                        <tr key={item.id}>
                          <td className={item.activity_type}>
                            {item.activity_type === 'Task' &&
                              <i className="icon-task box-icon mr-2" style={{ fontSize: '20px', color: '#b2b3b9' }}></i>
                            }
                            {item.activity_type === 'Event' &&
                              <i className="icon-calender box-icon mr-2" style={{ fontSize: '18px', color: '#b2b3b9' }}></i>
                            }
                            {item.activity_type === 'Call' &&
                              <i className="icon-telephone box-icon mr-2" style={{ fontSize: '18px', color: '#7b7b7b' }}></i>
                            }
                            {item.subject}</td>
                          <td>{item.owner}</td>
                          <td>{item.schedule_date}</td>
                          <td className="text-center">
                            <TooltipNew2
                              tooltip="Edit"
                              icon="border_color"
                              id="tooltip-1"
                              classN="myicon material-icons pointer mr-4"
                              customTp={() => this.editActivity(item.id, item.activity_type)}
                            />
                            <TooltipNew2
                              tooltip="Delete"
                              icon="delete"
                              id={"tooltip-1" + item.id}
                              classN="myicon material-icons pointer"
                              customTp={() => this.deleteActivity(item.id, item.activity_type)}
                            />
                          </td>
                        </tr>
                      );
                    })
                  }
                </tbody>
              </Table>
            </div>
          </div>
        </div>
        {
          AddNewTask &&
          <AddTaskModal
            taskClose={() => this.taskClose()}
            model_id={this.state.model_id}
            model_name={this.state.model_name}
            taskId={this.state.taskId}
          />
        }
        <AddEventModal
          AddNewEvent={AddNewEvent}
          eventClose={() => this.eventClose()}
          model_id={this.state.model_id}
          model_name={this.state.model_name}
          eventId={this.state.eventId}
        />

        <AddCallModal
          AddNewCall={AddNewCall}
          callClose={() => this.callClose()}
          id={this.state.model_id}
          type={this.state.model_name}
          callId={this.state.callId}
        />
      </div>
    )
  }
}
export default compose(
  withApollo
)(Activities);
