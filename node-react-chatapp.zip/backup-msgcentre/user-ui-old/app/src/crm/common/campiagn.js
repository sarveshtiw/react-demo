import React from 'react'
import { Col, Table, FormGroup, FormControl, Form, Button, OverlayTrigger, Tooltip } from 'react-bootstrap';
import LinkWithTooltip from '../../common/containers/tooltip'
import { TooltipNew, TooltipNew2 } from '../components/leads/view-lead/tooltip-new';


import moment from 'moment';
import {
  compose,
  withApollo
} from 'react-apollo'



const Campaigns = ({ data }) => {

  return (
    <div className="ibox mb-0">
      <div className="ibox-title mng-title clearfix">
        <div className="col-sm-6"> <h5 className="mt-3">Campaigns</h5></div>
        <div className="col-sm-6 d-flex justify-content-end actionWrap">
          <i className="icon-announce" style={{ fontSize: 18 }}></i>
        </div>
      </div>

      <div className="ibox-content clearfix no-topborder">
        <div className="gTable-new gt-viewlead row mt-2">
          <div className="table-responsive">
            <Table className="table-bordered">
              <thead>
                <tr>
                  <th>Campaign Name</th>
                  <th>Status</th>
                  <th>Type</th>
                  <th>Expected Revenue</th>
                  <th>Budgeted Cost</th>
                  <th>Start Date</th>
                  <th>End Date</th>
                  <th className="text-center">Action</th>
                </tr>
              </thead>
              <tbody>
                {data &&
                  data.map((item, index) =>
                    <tr>
                      <td>{item.campaign_name}</td>
                      <td>{item.campaign_status}</td>
                      <td>{item.CampaignTypeMaster.campaign_type}</td>
                      <td>{item.expected_revenue}</td>
                      <td>{item.budgeted_cost}</td>
                      <td>{moment(item.start_date).format("DD-MM-YYYY")}</td>
                      <td>{moment(item.end_date).format("DD-MM-YYYY")}</td>
                      <td className="text-center">


                        <TooltipNew tooltip="Edit" icon="border_color" id="tooltip-1" classN="myicon material-icons pointer mr-4" customTp={() => this.show()} />

                        <TooltipNew tooltip="Delete" icon="delete" id="tooltip-1" classN="myicon material-icons pointer" customTp={() => this.handleShow()} />
                      </td>
                    </tr>
                  )}
              </tbody>
            </Table>
          </div>
        </div>
      </div>
    </div>
  )
}
export default compose(
  withApollo
)(Campaigns)