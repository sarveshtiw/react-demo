import React from 'react';
import { Col, Table, FormGroup, FormControl, ButtonGroup, Radio, ButtonToolbar, InputGroup, Row, Form, Button, OverlayTrigger, Tooltip, Modal, ControlLabel } from 'react-bootstrap';
import Dropdown from 'react-dropdown';
import { DatePicker, TimePicker } from 'antd';
import { Scrollbars } from 'react-custom-scrollbars';
const optionData = {
  optionStatus: [
    'Not Started', 'Deferred', 'In Progress', 'Completed', 'Waiting on Someone Else'
  ],
  optionOwner: [
    'Ashwani Kumar', 'Hassan Raza', 'Pradeep Kaushal', 'Manish Badola'
  ]

};
class AddEventModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: '',
      model_id: this.props.id,
      model_name: this.props.type,
    }
  }
  render() {
    return (
      <Modal
        show={this.props.AddNewEvent}
        onHide={() => this.props.eventClose()}
        dialogClassName="modal-md audioView addEvent bg-white">
        <Modal.Body>
          <Modal.Header closeButton>
          </Modal.Header>
          <div className="ibox">
            <div className="ibox-title pb-0 clearfix">
              <h5 className="h-modal">Add Event</h5>
            </div>
            <div className="ibox-content ml-5 mr-5 pl-0 pr-0 no-border">
              <Form className="row">
                <Col className="clearfix">
                  <Row>
                    <Col sm={4} xs={12}>
                      <FormGroup>
                        <ControlLabel>Status</ControlLabel>
                        <Dropdown options={optionData.optionStatus} onChange={this._onSelect} placeholder="select status" />
                      </FormGroup>
                    </Col>
                    <Col sm={4} xs={12}>
                      <FormGroup>
                        <ControlLabel>Location</ControlLabel>
                        <FormControl type="text" placeholder="location" />
                      </FormGroup>
                    </Col>
                    <Col sm={4} xs={12}>
                      <FormGroup>
                        <ControlLabel>Owner</ControlLabel>
                        <Dropdown options={optionData.optionOwner} onChange={this._onSelect} placeholder="select owner" />
                      </FormGroup>
                    </Col>
                  </Row>
                  <Row>
                    <Col sm={2} xs={12}>
                      <FormGroup>
                        <ControlLabel>Start Date/Time</ControlLabel>
                        <DatePicker
                          style={{ width: '100%' }}
                          format="ddd, DD MMM YYYY" />
                      </FormGroup>

                    </Col>
                    <Col sm={2} xs={12}>
                      <FormGroup>
                        <ControlLabel>&nbsp;</ControlLabel>
                        <TimePicker
                          use12Hours
                          style={{ 'width': "100%" }}
                          format="h:mm A"
                          placeholder="Select Start Time" />
                      </FormGroup>
                    </Col>
                    <Col sm={2} xs={12}>
                      <FormGroup>
                        <ControlLabel>End Date/Time</ControlLabel>
                        <DatePicker
                          style={{ width: '100%' }}
                          format="ddd, DD MMM YYYY" />
                      </FormGroup>
                    </Col>
                    <Col sm={2} xs={12}>
                      <FormGroup>
                        <ControlLabel>&nbsp;</ControlLabel>
                        <TimePicker
                          use12Hours
                          style={{ 'width': "100%" }}
                          format="h:mm A"
                          placeholder="Select Start Time" />
                      </FormGroup>
                    </Col>
                  </Row>
                  <Row>
                    <Col sm={12} className="add_event">
                      <FormGroup controlId="formControlsTextarea ">
                        <ControlLabel className="">Description</ControlLabel>
                        <FormControl componentClass="textarea" placeholder="description" />
                      </FormGroup>
                    </Col>
                  </Row>
                </Col>
                <hr className="bdr mt-4 border_line" />
                <div className="ibox contactAndGroup mb-0">
                  <div className="ibox-content p-0 clearfix d-flex mng-height">
                    <div className="col-md-6 leftPanel no-border">
                      <h4 className="participant">Add Participant
                            <div className="pull-right btnGroup btn-group">
                          <button type="button" className="active  btn btn-default">Participant</button>
                          <button type="button" className="btn btn-default">Groups</button>
                        </div>
                      </h4>
                      <div className="form-group">
                        <span className="fShadow1 input-group search_txt">
                          <input type="text" placeholder="Search" id="searchContact" className="form-control" />
                          <span className="input-group-addon"><i className="fa fa-search"></i></span>
                        </span>
                      </div>
                      <Scrollbars className="overlayScroll"
                        autoHeight
                        autoHeightMin={500}>
                        <ul className="partList">
                          <li>
                            <div className="listing_user">
                              <div className="box_list">
                                <span className="dropped-elem">Ankit Lakher</span>
                                <p>ankitkumar@gmail.com<span><img src="/images/drag.png" /></span></p>
                              </div>
                              <div className="box_list">
                                <span className="dropped-elem">Ankit Lakher</span>
                                <p>ankitkumar@gmail.com<span><img src="/images/drag.png" /></span></p>
                              </div>
                              <div className="box_list">
                                <span className="dropped-elem">Ankit Lakher</span>
                                <p>ankitkumar@gmail.com<span><img src="/images/drag.png" /></span></p>
                              </div>
                              <div className="box_list">
                                <span className="dropped-elem">Ankit Lakher</span>
                                <p>ankitkumar@gmail.com<span><img src="/images/drag.png" /></span></p>
                              </div>
                              <div className="box_list">
                                <span className="dropped-elem">Ankit Lakher</span>
                                <p>ankitkumar@gmail.com<span><img src="/images/drag.png" /></span></p>
                              </div>
                              <div className="box_list">
                                <span className="dropped-elem">Ankit Lakher</span>
                                <p>ankitkumar@gmail.com<span><img src="/images/drag.png" /></span></p>
                              </div>
                              <div className="box_list">
                                <span className="dropped-elem">Ankit Lakher</span>
                                <p>ankitkumar@gmail.com<span><img src="/images/drag.png" /></span></p>
                              </div>
                            </div>
                          </li>
                        </ul>
                      </Scrollbars>
                    </div>
                    <div className="col-md-6 drag_box_custom">
                      <div className="droppable">
                        <div className="preDrop">
                          <img src="/images/dragParticipant.png" alt="Drag Participants here to add them" />
                          <p>Drag Participants here to add them</p>
                        </div>
                      </div>
                    </div>
                    <Row>
                      <Col sm={6}>
                      </Col>
                    </Row>
                  </div>
                </div>
                <hr className="bdr mt-3 mb-4" />
                <Col sm={12} className="text-left mt-4">
                  <Button className="btn-submit">Submit</Button>
                  <Button className="btn-cancel" onClick={() => this.props.eventClose()}>Cancel</Button>
                </Col>
              </Form>
            </div>
          </div>
        </Modal.Body>
      </Modal>
    )
  }
}
export default AddEventModal;