import React from 'react';
import { OverlayTrigger, Tooltip } from 'react-bootstrap';

export class TooltipNew extends React.Component {
  render() {
    return (
      <OverlayTrigger
        overlay={<Tooltip id={this.props.id}>{this.props.tooltip}</Tooltip>}
        placement="top"
        delayShow={300}
        delayHide={150}
      >
        <i className={this.props.classN} onClick={this.props.customTp}>{this.props.icon}</i>
      </OverlayTrigger>
    );
  }
}

export class TooltipNew2 extends React.Component {
  render() {
    return (
      <OverlayTrigger
        overlay={<Tooltip id={this.props.id}>{this.props.tooltip}</Tooltip>}
        placement="bottom"
        delayShow={300}
        delayHide={150}
      >
        <i className={this.props.classN} style={this.props.styleN} onClick={this.props.customTp}>{this.props.icon}</i>
      </OverlayTrigger>
    );
  }
}

