import React from 'react'
import { Col, FormGroup, FormControl, ButtonGroup, Radio, ButtonToolbar, InputGroup, Row, Form, Button, Modal, ControlLabel } from 'react-bootstrap';
import Dropdown from 'react-dropdown';
import { ADD_CALL_DEFAULT } from '../Queries'
import { compose, withApollo, graphql } from 'react-apollo'
import { ADD_CALL } from '../Mutations'

class AddCallModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      model_id: this.props.id,
      model_name: this.props.type,
      owner: '',
      subject: null,
      call_type: 'inbound',
      call_details: 'current',
      result: null,
      description: null,
      ownerList: [],
      AddNewCall: this.props.AddNewCall
    }

  }
  componentWillReceiveProps(nextProps) {
    this.setState({
      AddNewCall: nextProps.AddNewCall
    })
  }
  componentWillMount() {
    this.getDefaultListingData();
  }

  getDefaultListingData = async () => {

    try {
      let response = await this.props.client.query({
        query: ADD_CALL_DEFAULT
      })
      this.setState({
        ownerList: response.data.getCrmOwner
      })
    }

    catch (err) {
      console.log("Found Error: ", err)
    }
  }

  handleChange = (e) => {
    let { name, value } = e.target
    this.setState({
      [name]: value ? value : null,
    })
  }

  onChecked = (e) => {
    let value = e.target.value;
    this.setState({
      call_type: value,

    })
  }


  onChecked1 = (e) => {
    let value = e.target.value;
    this.setState({

      call_details: value

    })
  }

  onSubmit = async (e) => {
    e.preventDefault();
    const { owner, subject, call_type, call_details, result, description, model_id, model_name } = this.state

    console.log("Hello!:!:!:", this.state)

    let inputData = {
      ActivityCallLinks: [{
        "model_id": model_id,
        "model_name": model_name,
      }],
      call_details: call_details,
      owner: Number(owner),
      subject: subject,
      result: result,
      description: description,
      call_type: call_type
    }
    try {
      let response = await this.props.addCall({

        variables: {
          input: inputData
        }
      })
      if (response.data.createCrmActivityCall.message === 'Success') {
        this.setState({
          AddNewCall: false
        })
      }
      console.log("Hurreyyyyy!!!", response, this.state.AddNewCall)
    } catch (err) {
      console.log("Error is here:", err)
    }

  }

  render() {
    const { AddNewCall, owner, subject, call_type, call_details, result, description, ownerList } = this.state
    return (
      <Modal
        show={AddNewCall}
        onHide={() => this.props.callClose()}
        dialogClassName="modal-md audioView addEvent bg-white">
        <Modal.Body>

          <div className="ibox">
            <div className="ibox-title pb-0 clearfix">
              <h5 className="h-modal">Add Call</h5>
            </div>
            <div className="ibox-content ml-5 mr-5 pl-0 pr-0 no-border">
              <Form className="row" onSubmit={this.onSubmit}>
                <Col className="clearfix">
                  <Row>
                    <Col sm={4} xs={12}>
                      <FormGroup>
                        <ControlLabel>Subject</ControlLabel>
                        <FormControl
                          type="text"
                          placeholder="subject"
                          value={subject}
                          name="subject"
                          onChange={this.handleChange}
                        />
                      </FormGroup>

                    </Col>
                    <Col sm={4} xs={12}>
                      <FormGroup>
                        <ControlLabel>Owner</ControlLabel>
                        <FormControl
                          componentClass="select"
                          name="owner"
                          placeholder="select owner"
                          value={owner}
                          onChange={this.handleChange}
                        >
                          {
                            ownerList.map((item, key) => {
                              return <option value={item.id} key={key}>{item.name}</option>
                            })
                          }
                        </FormControl>
                      </FormGroup>
                    </Col>
                    <Col sm={4} xs={12}>
                      <FormGroup onChange={this.onChecked}>
                        <ControlLabel className="call_sec">Call Type</ControlLabel>
                        <div className="radio radio-info radio-inline">
                          <input
                            type="radio"
                            id="inbound_call"
                            value="inbound"
                            defaultChecked
                            name="call_type"
                            checked={this.state.call_type === "inbound"}
                          />
                          <label htmlFor="inbound_call"> Inbound Call</label>
                        </div>
                        <div className="radio radio-info radio-inline">
                          <input
                            type="radio"
                            id="outbound_call"
                            value="outbound"
                            name="call_type"
                            checked={this.state.call_type === "outbound"}
                          />
                          <label htmlFor="outbound_call"> Outbond Call</label>
                        </div>
                      </FormGroup>
                    </Col>
                  </Row>
                  <Row>
                    <Col sm={6} xs={12}>
                      <FormGroup className="details_call" onChange={this.onChecked1}>
                        <ControlLabel className="call_sec">Call Details</ControlLabel>
                        <div className="radio radio-info radio-inline">
                          <input
                            type="radio"
                            id="current_call"
                            value="current"
                            name="call_details"
                            defaultChecked
                            checked={this.state.call_details === "current"}
                          />
                          <label htmlFor="current_call"> Current Call</label>
                        </div>
                        <div className="radio radio-info radio-inline">
                          <input
                            type="radio"
                            id="completed_call"
                            value="completed"
                            name="call_details"
                            checked={this.state.call_details === "completed"}
                          />
                          <label htmlFor="completed_call"> Completed call</label>
                        </div>
                        <div className="radio radio-info radio-inline">
                          <input
                            type="radio"
                            id="scheduled_call"
                            value="schedule"
                            name="call_details"
                            checked={this.state.call_details === "schedule"}
                          />
                          <label htmlFor="scheduled_call"> Schedule Call </label>
                        </div>
                      </FormGroup>
                    </Col>
                  </Row>
                </Col>
                <div className="clearfix add_event sp_top">
                  <FormGroup controlId="formControlsTextarea">
                    <ControlLabel>Call Result</ControlLabel>
                    <FormControl
                      componentClass="textarea"
                      placeholder="call result"
                      value={result}
                      name="result"
                      onChange={this.handleChange}
                    />
                  </FormGroup>
                  <FormGroup controlId="formControlsTextarea">
                    <ControlLabel>Description</ControlLabel>
                    <FormControl
                      componentClass="textarea"
                      placeholder="description"
                      value={description}
                      name="description"
                      onChange={this.handleChange}
                    />
                  </FormGroup>



                </div>

                <Col sm={12} className="text-left mt-4">
                  <Button className="btn-submit" type="submit">Submit</Button>
                  <Button className="btn-cancel" onClick={() => this.props.callClose()}>Cancel</Button>
                </Col>
              </Form>
            </div>
          </div>


        </Modal.Body>
      </Modal>
    )
  }
}
export default compose(
  withApollo, graphql(ADD_CALL, {
    name: "addCall"
  })
)(AddCallModal);