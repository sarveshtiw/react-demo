import React from 'react';
import axios from 'axios'
class FileUpload extends React.Component {


    handleChange(e) {
        console.log(e.target.files)
        let fileArr = e.target.files, i = 0;
        const formData = new FormData();
        while (i < fileArr.length) {
            formData.append('files', fileArr[i])
            i++
        }
        formData.append('appName', 'synthesis');
        formData.append('locationId', '3');
        formData.append('replication', '0');
        formData.append('bucketName', 'app');
        formData.append('restriction', '0');
        console.log(formData)
        axios.post(`http://192.168.1.171:3020/file-upload`, formData, {
            headers: {
                'content-type': 'multipart/form-data',
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        }).then(({ data }) => {
            console.log(data);
            // if (data.uploadedfiles) {
            //     this.setState({ audio_file_id: data.uploadedfiles[0].fileId })
            // }
        }).catch(err => {
            console.log(err);
        });
    }

    render() {
        return (
            <div className="main">
                <input type="file" multiple onChange={this.handleChange} />
            </div>
        );
    }
}

export default FileUpload;