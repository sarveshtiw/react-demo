import { isArray } from 'util'
import { customJoiNumber, customJoiString } from '../../common/customJoiRules'
const BaseJoi = require('joi-browser');
//const Extension = require('joi-date-extensions');
const Extension = '';
const Joi = BaseJoi;//.extend(Extension);

const schemaCreateLead = Joi.object().keys({
    title: Joi.any().allow('').valid(['Mr', 'Mrs', 'Ms', 'Dr', 'Prof']).optional(),
    fname: Joi.string().required().optional(),
    lname: Joi.string().required().optional(),
    designation: Joi.string().allow(null).optional(),
    primaryPhone: customJoiString.string().isNumber().min(6).max(30).required().optional(),
    mobile: customJoiString.string().isNumber().min(6).max(30).allow(null).optional(),
    fax: customJoiString.string().isNumber().allow(null).optional(),
    primaryEmail: customJoiString.string().email().emailValidation().required().optional(),
    secondaryEmail: customJoiString.string().email().emailValidation().allow(null).optional(),
    mailZip: customJoiString.string().isNumber().min(6).max(9).allow('').optional(),
    otherZip: customJoiString.string().isNumber().min(6).max(9).allow('').optional(),
    company_name: customJoiString.string().required().optional(),
    employees: customJoiString.string().isNumber().allow(null).optional(),
    annualRevenue: customJoiString.string().isNumber().allow(null).optional(),
    //website: joi.string().websiteValidation().allow(null).optional(),
})

const schemaCreateContact = Joi.object().keys({
    title: Joi.any().allow('').valid(['Mr', 'Mrs', 'Ms', 'Dr', 'Prof']).optional(),
    firstName: Joi.string().required().optional(),
    lastName: Joi.string().allow(null).optional(),
    companyName: Joi.string().required().optional(),
    designation: Joi.string().allow(null).optional(),
    leadSource: Joi.string().allow(null).optional(),
    phone: customJoiString.string().isNumber().min(6).max(30).allow(null).optional(),
    mobile: customJoiString.string().isNumber().min(6).max(30).allow(null).optional(),
    primaryEmail: customJoiString.string().email().emailValidation().allow(null).optional(),
    cnfPrimaryEmail: customJoiString.string().email().emailValidation().allow(null).optional(),
    secondaryEmail: customJoiString.string().email().emailValidation().allow(null).optional(),
    cnfSecondaryEmail: customJoiString.string().email().emailValidation().allow(null).optional(),
    description: Joi.string().allow(null).optional(),
})

export const clearEmpties = (o) => {
    for (var k in o) {
        if (!o[k] || typeof o[k] !== "object") {
            (o[k] === undefined || o[k] === null || o[k] == '') && delete o[k]
            continue
        }
        clearEmpties(o[k]);
        if (Object.keys(o[k]).length === 0) {
            delete o[k];
        }
    }
    for (var k in o) {
        if (isArray(o[k])) {
            o[k] = o[k].filter(function (x) {
                return (x !== (undefined || null || ''));
            });
        }
    }
}


export const validateCreateLead = (inputCreateLead) => {
    return Joi.validate(inputCreateLead, schemaCreateLead, { abortEarly: false });
}


const schemaCreateCompany = Joi.object().keys({
    company_name: Joi.string().required().optional(),
    employees_number: customJoiString.string().isNumber().allow(null).optional(),
    annual_revenue: customJoiString.string().isNumber().allow(null).optional(),
    phone: customJoiString.string().isNumber().min(6).max(30).allow(null).optional(),
    fax: customJoiString.string().isNumber().allow(null).optional(),
    website: customJoiString.string().websiteValidation().allow(null).optional(),
    email_id: customJoiString.string().email().emailValidation().allow(null).optional(),
    cnf_email_id: customJoiString.string().email().emailValidation().allow(null).optional(),
    zipcode: customJoiString.string().isNumber().min(6).max(9).allow(null).optional()
})

export const validateCreateCompany = (inputCreateCompany) => {
    return Joi.validate(inputCreateCompany, schemaCreateCompany, { abortEarly: false });
}


const schemaCreateCampaign = Joi.object().keys({
    campaign_name: Joi.string().required().optional(),
    expected_revenue: customJoiString.string().isNumber().allow(null).optional(),
    budgeted_cost: customJoiString.string().isNumber().allow(null).optional(),
    actual_cost: customJoiString.string().isNumber().allow(null).optional(),
})
export const validateCreateCampaign = (inputCreateCampaign) => {
    return Joi.validate(inputCreateCampaign, schemaCreateCampaign, { abortEarly: false });
}

export const validateCreateContact = (inputCreateContact) => {
    return Joi.validate(inputCreateContact, schemaCreateContact, { abortEarly: false });
}




const schemaCreateDeal = Joi.object().keys({
    dealName: Joi.string().required().optional(),
    closingDate: Joi.date().required(),
    amount: Joi.string().optional().allow(''),

})


export const validateCreateDeal = (inputCreateDeal) => {
    return Joi.validate(inputCreateDeal, schemaCreateDeal, { abortEarly: false });
}
