import gql from 'graphql-tag';

export const CREATE_COMPANY = gql`
    mutation createCrmCompany($input:CreateCrmCompanyInput!){
        createCrmCompany(input:$input){
            message
        }
    }`

export const UPDATE_COMPANY = gql`
    mutation updateCrmCompany($input:EditCrmCompanyInput!){
        updateCrmCompany(input:$input){
            message
        }
    }`

export const CREATE_CRM_LEAD = gql`

mutation createCrmLead($input:CrmLeadInput!){
  createCrmLead(input:$input){
    message
  }
}
`;
export const DELETE_LEAD = gql`
mutation delete_row($id: [Int!]!){
  deleteCrmLeadById(id: $id){
   message
  }
}
`;



export const UPDATE_CRM_LEAD = gql`

mutation updateCrmLead($id:Int!,$input:CrmLeadInput!){
  updateCrmLead(id:$id,input:$input){
       message
  }
}
`;


export const CREATE_CRM_DEAL = gql`

mutation createCrmDeal($input:CrmDealInput!){
  createCrmDeal(input:$input){
    message
    Deal{
     id
      owner
      id_crm_contact
      expected_revenue
      id_crm_company
      deal_name
      deal_type
      deal_closing_date
      deal_amount
      id_crm_lead_source_master
      id_crm_campaign
      id_crm_pipeline_stage
      next_step
      description
    }    
  }
}
`;



export const UPDATE_CRM_DEAL = gql`

mutation updateCrmDeal($id:Int!,$input:CrmDealInput!){
  updateCrmDeal(id:$id, input:$input){
    message
  }
}`;


// Contacts
export const DELETE_CONTACTS = gql`
mutation deleteCrmContactById($id:[Int!]!){
  deleteCrmContactById(id:$id){
    message
  }
}
`;


export const DELETE_COMPANY = gql`
  mutation deleteCrmCompanyById($id:[Int!]!){
    deleteCrmCompanyById(id:$id){
      message
    }
  }
  `;


//Campaign

export const DELETE_CAMPAIGN = gql`
  mutation deleteCrmCampaignById($id:[Int!]!){
    deleteCrmCampaignById(id:$id){
      message
    }
  }
  `;

//create contact
export const CREATE_CRM_CONTACT = gql`  
mutation createCrmContact($input: CrmContactInput!){
  createCrmContact(input: $input){
    Contact{
      	id,
        owner,
        id_crm_company,
        date_of_birth,
        LeadContactParent{
          first_name,
          last_name,
          title,
          designation,
          phone,
          mobile,
          email,
          secondary_email,  
          description,
      }
    }
  }
}
`;

//update contact
export const UPDATE_CRM_CONTACT = gql`  
mutation updateCrmContact($id:Int!,$input:CrmContactInput!){
updateCrmContact(id:$id,input:$input){
  message
  }
}`;


export const DELETE_DEAL = gql`
  mutation deleteCrmDealById($id: [Int!]!){
    deleteCrmDealById(id: $id){
      message
    }
  }`;

// Leads Notes
export const CREATE_NOTE = gql`
mutation createCrmModelNote($input: CrmModelNoteInput!) {
  createCrmModelNote(input: $input) {
    message
  }
}`;

export const UPDATE_NOTE = gql`
mutation updateCrmModelNote($id:Int!, $input: CrmModelNoteInput!) {
  updateCrmModelNote(id: $id, input:$input){
    message
  }
}`;

export const DELETE_NOTE = gql`
mutation deleteCrmModelNote($id:Int!) {
  deleteCrmModelNote(id: $id) {
    message
  }
}`;

// Activity Task
export const ADD_ACTIVITY_TASK = gql`
mutation addActivityTask($input: CrmActivityTaskInput!) {
  createCrmActivityTask(input: $input) {
    message
  }
}`;

//Create Campaign

export const CREATE_CAMPAIGN = gql`
 mutation createCrmCampaign($input: CrmCampaignInput!){
  createCrmCampaign(input: $input){
   message
 }
}
 `;


//Delete Activities
/* export const DELETE_ACTIVITY_CALL = gql`
mutation deleteCrmActivityCallById($id:[Int!]!){
  deleteCrmActivityCallById(id:$id){
    message
   }
}`;

export const DELETE_ACTIVITY_EVENT = gql`
mutation deleteCrmActivityEventById($id:[Int!]!){
  deleteCrmActivityEventById(id:$id){
    message
   }
}`;

export const DELETE_ACTIVITY_TASK = gql`
mutation deleteCrmActivityTaskById($id:[Int!]!){
  deleteCrmActivityTaskById(id:$id){
    message
   }
}`; */

export const DELETE_ACTIVITY = gql`
  mutation deleteCrmActivity($task:[Int!]!, $event:[Int!]!, $call:[Int!]!){
    deleteCrmActivityTaskById(id:$task){
    message
   }
   deleteCrmActivityEventById(id:$event){
    message
   }
  deleteCrmActivityCallById(id:$call){
    message
   }
}
`;


export const UPDATE_CAMPAIGN = gql`
mutation updateCrmCampaign($id:Int!,$input:CrmCampaignInput!){
  updateCrmCampaign(id:$id,input:$input){
    message
    
  }
}`;


//Add Call

export const ADD_CALL = gql`
 mutation createCrmActivityCall($input: CrmActivityCallInput!){
  createCrmActivityCall(input: $input){
    message
  }
}`;

export const DELETE_CALL_ON_ACTIVITY = gql`
mutation deleteCrmActivityCallById($id: [Int!]!){
  deleteCrmActivityCallById(id: $id){
    message
  }
}
`;
