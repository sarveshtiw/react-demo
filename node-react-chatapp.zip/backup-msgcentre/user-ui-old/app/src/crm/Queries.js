import gql from 'graphql-tag';

export const GET_LEAD_LIST = gql`
{
  getCrmLeadSourceMasterList{
    id,
    source
  },
  getCrmPipelineStageList{
    id,
    stage_name
  },
  getCrmRatingMasterList{
    id,
    rating
  },
  getCrmIndustryMasterList{
    id,
    industry_name
  },
  getCrmOwner{
    id,
    name 
  }
}
`;

export const LEAD_LIST = gql`
query getCrmLeadListByPage($input: PageInfoInput){
  getCrmLeadListByPage(input: $input){
    pageInfo{
      totalCounts,
      totalPages
    }
    Leads {
      id
      LeadContactParent{
        first_name,
        last_name,
        phone,
        email,
        id_crm_lead_source_master
      }
      company_name,
      IndustryMaster{
        industry_name
      }
    }
  }
}`;

export const VIEW_LEAD = gql`
query getCrmLeadById($id: Int!) {
  getCrmLeadById(id: $id) {
    Lead {
      id
      owner
      company_name
      id_crm_rating_master
      annual_revenue
      no_of_employees
        fax
        website
        skype_url
        twitter_url
        linkedin_url
        facebook_url
      RatingMaster {
        id,
        rating
      }
      id_crm_pipeline_stage,
      PipelineStage {
        id
        stage_name
        win_probabality
      }
      LeadContactParent {
      LeadSourceMaster {
          id
          source
        }
        designation
        email
        secondary_email
        first_name
        
        last_name
        title
        phone
        mobile
     
        description
        is_lead
        id_crm_lead_source_master       
      }
      Addresses {
        address_type,
        id,
        street,
        city,
        state_province,
        zip_code,
        country
      },
      IndustryMaster{
        id,
        industry_name
      }
    }
  }
}`;

// Contacts
export const CONTACT_LIST = gql`
query getCrmContactListByPage($input: PageInfoInput){
  getCrmContactListByPage(input: $input){
    pageInfo{
      totalCounts,
      totalPages
    }
    Contacts{
      id
      owner
      Company{
        company_name
      }
      LeadContactParent{
        designation
        first_name
        last_name
      }
    }
  }
}`;


export const VIEW_CONTACT = gql`
query getCrmContactById($id: Int!) {
  getCrmContactById(id:$id){
  Contact{
        owner,
        id_crm_company,
        date_of_birth,
        LeadContactParent{       
        first_name,
        last_name,
        title,
        designation,
        phone,
        mobile,
        email,
        secondary_email, 
        description,
        id_crm_lead_source_master,
        },
       Company{
        company_name
      }
    }
  }  
  }
`;


export const GET_CONTACT_LISTING = gql`
{
  getCrmLeadSourceMasterList{
    id,
    source
  },
  getCrmOwner{
    id,
    name 
  },
  getCrmCompanyList{
    result{
      id
      name
    }
  }
}`;


export const COMPANY_DEFAULT_LISTING = gql`
    {
        getCrmOwner{
            id
            name
        }
        getCrmIndustryMasterList{
            id
            industry_name
        }
        getCrmCompanyOwnershipMasterList{
            id
            company_ownership
        }
        getCrmCompanyStatusMasterList{
            id
            company_status
        }         
    }`;





export const VIEW_DEAL = gql`
 query getCrmDealById($id:Int!){
  getCrmDealById(id:$id){
    Deal{
      id
      owner
      expected_revenue
      id_crm_contact
      id_crm_company
      deal_name
      deal_type
      deal_closing_date
      deal_amount
      id_crm_lead_source_master
      id_crm_campaign
      id_crm_pipeline_stage
      next_step
      description
      Contact{
        id
        LeadContactParent{
          first_name
          last_name
        }
      }
    }
  }
}`;

export const GET_COMPANYDETAILS_BY_ID = gql`
    query getCrmCompanyById($id:Int!){
        getCrmCompanyById(id:$id){
            Company{
                id
                owner
                company_name
                registration_number
                company_email
                phone
                fax
                website
                no_of_employees
                annual_revenue
                description
                twitter_url
                skype_url
                linkedin_url
                facebook_url
                id_crm_industry_master
                id_crm_company_ownership_master
                id_crm_company_status_master
                Addresses{
                    id
                    street
                    zip_code
                    city
                    city_name
                    state_province
                    state_province_name
                    country
                    country_name
                }
            }
        }
    }`


export const GET_COMPANYLIST = gql`
    query getCrmCompanyListByPage($input:PageInfoInput){
      getCrmCompanyListByPage(input:$input){
        pageInfo{
          totalPages
        }
        Companies{
          id
          company_name
          Addresses{
            city_name
            country_name
          }
          CompanyOwnershipMaster{
            id
            company_ownership
          }
          IndustryMaster{
            id
            industry_name
          }
        }
      }
    }`;

// Deal
export const DEAL_LIST = gql`
query getCrmDealListByPage($input:PageInfoInput){
  getCrmDealListByPage(input:$input){
    pageInfo{
      totalCounts
      totalPages
    }
    Deals{
      id
      owner
      id_crm_contact
      id_crm_company
      deal_name
      deal_type
      deal_closing_date
      deal_amount
      expected_revenue
      id_crm_lead_source_master
      id_crm_campaign
      id_crm_pipeline_stage
      next_step
      description
      Company{
        company_name
      }

 }
  }
}`;



export const DEAL_DEFAULT_LISTING_START = gql`
{
  getCrmLeadSourceMasterList{
      id,
      source
    },
    getCrmPipelineStageList{
      id,
      stage_name
    },
    getCrmIndustryMasterList{
      id,
      industry_name
    },
    getCrmOwner{
      id,
      name 
    }
}
`;


//Contact
export const GET_CONTACT_DEAL = gql`
{
 getCrmContactList{
 result{
      id
      name
    }
}
}
`;



export const LEADS_NOTES = gql`
query getAllCrmNotesByLead($id: Int!) {
 getAllCrmNotesByLead(id: $id) {
   LeadNotes {
      id
      id_crm_lead
     note_title
      note_description
      created_by
      updated_by
      created_at
      updated_at
      LeadNoteAttachements
     {
       id
      id_crm_lead_note
       minio_file_id
       minio_file_url
     }
   }
 }
}`;

export const GET_COMPANY_DEAL = gql`
{
  getCrmCompanyList{
    result {
      id
      name
    }
  }
}`;


export const GET_NOTES = gql`
query getAllCrmNotesByModel($input: CrmModelNotesInput!) {
  getAllCrmNotesByModel(input: $input) {
    message
    ModelNotes {
      id
      model_id
      model_name
      note_title
      note_description
      created_at
      created_by
      updated_at
      updated_by
      ModelNoteAttachments {
        id_crm_model_note
        minio_file_id
        minio_file_url
      }
    }
  }
}`;


//Campaign
export const CAMPAIGN = gql`
{
 getCrmCampaignList{
    result{
      id
      name
    }
  },
}
`;

export const PRE_DATA = gql`
{
  getCrmOwner{
      id  
      name
  }
  getCrmCampaignTypeMasterList{
    id
    campaign_type
  }
}
`;

export const CAMPAIGN_LIST = gql`
query getCrmCampaignListByPage($input: PageInfoInput){
  getCrmCampaignListByPage(input: $input){
    pageInfo{
      totalPages,
      totalCounts
    }
    Campaigns{
      id
      owner
      campaign_name
      start_date
      end_date
      CampaignTypeMaster{
        id
        campaign_type
      }
      campaign_status
    }
  }
}
`;

export const GET_ACTIVITY_LIST = gql`
query getCrmActivityListByPage($input: PageInfoInput) {
  getCrmActivityListByPage(input: $input) {
    pageInfo{
      totalPages
    },
    result{
        id,
        subject,
        company_name,
        contact_name,
        activity_type,
        due_date,
        status,
        owner
    }
  }
}
`;
export const GET_CAMPAIGN_BY_ID = gql`
query getCrmCampaignById($id:  Int!){
  getCrmCampaignById(id: $id){
    Campaign{
      id
      owner
      campaign_name
      campaign_status
      start_date
      end_date
      expected_revenue
      actual_cost
      budgeted_cost
      id_crm_campaign_type_master
      description
    }
  }
}`;

// GET_ACTIVITY_BY_MODEL
export const GET_ACTIVITY_BY_MODEL = gql`
query getCrmActivityListByModel($input: ModelInput) {
  getCrmActivityListByModel(input: $input) {
    result {
      id
      owner
      activity_type
      subject
      schedule_date
    }
    totalCounts
    message
  }
}`;

export const GET_CRM_CAMPAIGN_LEAD = gql`
query getCrmLeadCampaigns($id: Int!) {
  getCrmLeadCampaigns(id: $id) {
    Lead {
      Campaigns {
        campaign_name
        id
        owner
        campaign_status
        budgeted_cost
        CampaignTypeMaster {
          campaign_type
        }
        expected_revenue
        actual_cost
        start_date
        end_date
      }
    }
  }
}`;

export const GET_CRM_CAMPAIGN_CONTACT = gql`
query getCrmContactCampaigns($id: Int!) {
  getCrmContactCampaigns(id: $id) {
    Contact {
      Campaigns {
        campaign_name
        campaign_status
        CampaignTypeMaster {
          campaign_type
        }
        expected_revenue
        budgeted_cost
        start_date
        end_date
      }
      id
      owner
      id_crm_lead_contact_parent
      id_crm_company
      home_phone
    }
  }
}
`;

export const ADD_CALL_DEFAULT = gql`
query{
  getCrmOwner{
      id
      name
  }
}`;

export const GET_ACTIVITY_TASK_BY_ID = gql`
query getCrmActivityTaskById($input: Int!){
  getCrmActivityTaskById(id: $input){
    result{
      id
      owner
      subject
      due_date
      id_crm_task_status_master
      recurrence_type
      end_date_option
      end_after_occurence
      recurrence_end_date
      description
      created_at
      updated_by
      ActivityTaskLinks{
        model_id
        model_name
      }
      Daily{
        daily_option
        daily_day_no
      }
      Monthly{
        monthly_option
        monthly_day
        monthly_every_month
        monthly_week
        monthly_day_of_week
        monthly_of_every_month
      }
      Weekly{
        recur_every_week
        weekly_monday
        weekly_tuesday
        weekly_wednesday
        weekly_thursday
        weekly_friday
        weekly_saturday
        weekly_sunday
      }
      Yearly{
        recur_every_year
        yearly_option
        yearly_on_month
        yearly_on_month_day
        yearly_week
        yearly_week
        yearly_day_of_week
        yearly_of_every_month
      }
    }
  }
}`;
