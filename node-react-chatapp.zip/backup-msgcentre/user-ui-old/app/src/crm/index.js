import React from 'react';
import { compose, withApollo } from 'react-apollo';
import TopMenu from '../common/containers/MainTopMenu'
import Dashboard from './containers/dashboard/Content'

const menu = {
    title: "CRM",
    menuItem: [

        {
            title: "Leads",
            route: "/crm/leads",
            subNav: []
        },
        {
            title: "Company",
            route: "/crm/company/company-list",
            subNav: []
        },
        {
            title: "Contacts",
            route: "/crm/contacts",
            subNav: []
        },
        {
            title: "Opportunity",
            route: "/crm/deals",
            subNav: []
        },
        {
            title: "Products",
            route: "/crm/products",
            subNav: []
        },
        {
            title: "Activity",
            route: "/crm/activity",
            subNav: []
        },
        {
            title: "Campaign",
            route: "/crm/campaign/campaign-list",
            subNav: []
        }

    ]
}


class CRM extends React.Component {
    render() {
        return (
            <div className="main">
                <TopMenu {...this.props} menu={menu} />
                <Dashboard {...this.props} />
            </div>
        );
    }
}

export default compose(withApollo)(CRM);