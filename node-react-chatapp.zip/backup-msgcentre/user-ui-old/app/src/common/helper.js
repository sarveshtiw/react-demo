export const ClearEmpties = function clearEmpties(o) {
    for (var k in o) {
        if (!o[k] || typeof o[k] !== "object") {
            (o[k] === undefined || o[k] === null || o[k] == '') && delete o[k]
            continue
        }

        clearEmpties(o[k]);
        if (Object.keys(o[k]).length === 0) {
            delete o[k];
        }
    }
}