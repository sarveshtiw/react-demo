import React from 'react';


const getDesign = (val) => {
    switch (val) {
        case "delete":
            return { bgColor: "red", icon: "delete" }

        case "success":
            return { bgColor: "green", icon: "block" }

        case "info":
            return { bgColor: "blue", icon: "info" }

        case "notification":
            return { bgColor: "yellow", icon: "save" }
        case "error":
             return{bgColor: "red", icon: "error"}
        default:
            return { bgColor: "blue", icon: "info" }
    }

}


class Toaster extends React.Component {

    state = {
        designData: {}
    }

    componentWillMount = () => {
        const { notifyType } = this.props
        let data = getDesign(notifyType)
        this.setState({
            designData: data
        })
    }

    render() {
        const { designData } = this.state;
        return (
            <div className="notifyWrapper">
                <span className="icon" style={{ backgroundColor: designData.bgColor }}><i className="material-icons">{designData.icon}</i></span>
                <span className="msg">{this.props.msg}</span>
            </div>
        );
    }
}

export default Toaster; 