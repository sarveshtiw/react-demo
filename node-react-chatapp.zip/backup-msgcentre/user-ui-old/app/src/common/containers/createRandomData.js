import React from "react";

const range = len => {
    const arr = [];
    for (let i = 0; i < len; i++) {
        arr.push(i);
    }
    return arr;
};

export const country_list = ["Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Anguilla", "Antigua &amp; Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia &amp; Herzegovina", "Botswana", "Brazil", "British Virgin Islands", "Brunei", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Cape Verde", "Cayman Islands", "Chad", "Chile", "China", "Colombia", "Congo", "Cook Islands", "Costa Rica", "Cote D Ivoire", "Croatia", "Cruise Ship", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Estonia", "Ethiopia", "Falkland Islands", "Faroe Islands", "Fiji", "Finland", "France", "French Polynesia", "French West Indies", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guam", "Guatemala", "Guernsey", "Guinea", "Guinea Bissau", "Guyana", "Haiti", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran", "Iraq", "Ireland", "Isle of Man", "Israel", "Italy", "Jamaica", "Japan", "Jersey", "Jordan", "Kazakhstan", "Kenya", "Kuwait", "Kyrgyz Republic", "Laos", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Mauritania", "Mauritius", "Mexico", "Moldova", "Monaco", "Mongolia", "Montenegro", "Montserrat", "Morocco", "Mozambique", "Namibia", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Norway", "Oman", "Pakistan", "Palestine", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russia", "Rwanda", "Saint Pierre &amp; Miquelon", "Samoa", "San Marino", "Satellite", "Saudi Arabia", "Senegal", "Serbia", "Seychelles", "Sierra Leone", "Singapore", "Slovakia", "Slovenia", "South Africa", "South Korea", "Spain", "Sri Lanka", "St Kitts &amp; Nevis", "St Lucia", "St Vincent", "St. Lucia", "Sudan", "Suriname", "Swaziland", "Sweden", "Switzerland", "Syria", "Taiwan", "Tajikistan", "Tanzania", "Thailand", "Timor L'Este", "Togo", "Tonga", "Trinidad &amp; Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks &amp; Caicos", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "Uruguay", "Uzbekistan", "Venezuela", "Vietnam", "Virgin Islands (US)", "Yemen", "Zambia", "Zimbabwe"];

export const city_names = ["Aberdeen", "Abilene", "Akron", "Albany", "Albuquerque", "Alexandria", "Allentown", "Amarillo", "Anaheim", "Anchorage", "Ann Arbor", "Antioch", "Apple Valley", "Appleton", "Arlington", "Arvada", "Asheville", "Athens", "Atlanta", "Atlantic City", "Augusta", "Aurora", "Austin", "Bakersfield", "Baltimore", "Barnstable", "Baton Rouge", "Beaumont", "Bel Air", "Bellevue", "Berkeley", "Bethlehem", "Billings", "Birmingham", "Bloomington", "Boise", "Boise City", "Bonita Springs", "Boston", "Boulder", "Bradenton", "Bremerton", "Bridgeport", "Brighton", "Brownsville", "Bryan", "Buffalo", "Burbank", "Burlington", "Cambridge", "Canton", "Cape Coral", "Carrollton", "Cary", "Cathedral City", "Cedar Rapids", "Champaign", "Chandler", "Charleston", "Charlotte", "Chattanooga", "Chesapeake", "Chicago", "Chula Vista", "Cincinnati", "Clarke County", "Clarksville", "Clearwater", "Cleveland", "College Station", "Colorado Springs", "Columbia", "Columbus", "Concord", "Coral Springs", "Corona", "Corpus Christi", "Costa Mesa", "Dallas", "Daly City", "Danbury", "Davenport", "Davidson County", "Dayton", "Daytona Beach", "Deltona", "Denton", "Denver", "Des Moines", "Detroit", "Downey", "Duluth", "Durham", "El Monte", "El Paso", "Elizabeth", "Elk Grove", "Elkhart", "Erie", "Escondido", "Eugene", "Evansville", "Fairfield", "Fargo", "Fayetteville", "Fitchburg", "Flint", "Fontana", "Fort Collins", "Fort Lauderdale", "Fort Smith", "Fort Walton Beach", "Fort Wayne", "Fort Worth", "Frederick", "Fremont", "Fresno", "Fullerton", "Gainesville", "Garden Grove", "Garland", "Gastonia", "Gilbert", "Glendale", "Grand Prairie", "Grand Rapids", "Grayslake", "Green Bay", "GreenBay", "Greensboro", "Greenville", "Gulfport-Biloxi", "Hagerstown", "Hampton", "Harlingen", "Harrisburg", "Hartford", "Havre de Grace", "Hayward", "Hemet", "Henderson", "Hesperia", "Hialeah", "Hickory", "High Point", "Hollywood", "Honolulu", "Houma", "Houston", "Howell", "Huntington", "Huntington Beach", "Huntsville", "Independence", "Indianapolis", "Inglewood", "Irvine", "Irving", "Jackson", "Jacksonville", "Jefferson", "Jersey City", "Johnson City", "Joliet", "Kailua", "Kalamazoo", "Kaneohe", "Kansas City", "Kennewick", "Kenosha", "Killeen", "Kissimmee", "Knoxville", "Lacey", "Lafayette", "Lake Charles", "Lakeland", "Lakewood", "Lancaster", "Lansing", "Laredo", "Las Cruces", "Las Vegas", "Layton", "Leominster", "Lewisville", "Lexington", "Lincoln", "Little Rock", "Long Beach", "Lorain", "Los Angeles", "Louisville", "Lowell", "Lubbock", "Macon", "Madison", "Manchester", "Marina", "Marysville", "McAllen", "McHenry", "Medford", "Melbourne", "Memphis", "Merced", "Mesa", "Mesquite", "Miami", "Milwaukee", "Minneapolis", "Miramar", "Mission Viejo", "Mobile", "Modesto", "Monroe", "Monterey", "Montgomery", "Moreno Valley", "Murfreesboro", "Murrieta", "Muskegon", "Myrtle Beach", "Naperville", "Naples", "Nashua", "Nashville", "New Bedford", "New Haven", "New London", "New Orleans", "New York", "New York City", "Newark", "Newburgh", "Newport News", "Norfolk", "Normal", "Norman", "North Charleston", "North Las Vegas", "North Port", "Norwalk", "Norwich", "Oakland", "Ocala", "Oceanside", "Odessa", "Ogden", "Oklahoma City", "Olathe", "Olympia", "Omaha", "Ontario", "Orange", "Orem", "Orlando", "Overland Park", "Oxnard", "Palm Bay", "Palm Springs", "Palmdale", "Panama City", "Pasadena", "Paterson", "Pembroke Pines", "Pensacola", "Peoria", "Philadelphia", "Phoenix", "Pittsburgh", "Plano", "Pomona", "Pompano Beach", "Port Arthur", "Port Orange", "Port Saint Lucie", "Port St. Lucie", "Portland", "Portsmouth", "Poughkeepsie", "Providence", "Provo", "Pueblo", "Punta Gorda", "Racine", "Raleigh", "Rancho Cucamonga", "Reading", "Redding", "Reno", "Richland", "Richmond", "Richmond County", "Riverside", "Roanoke", "Rochester", "Rockford", "Roseville", "Round Lake Beach", "Sacramento", "Saginaw", "Saint Louis", "Saint Paul", "Saint Petersburg", "Salem", "Salinas", "Salt Lake City", "San Antonio", "San Bernardino", "San Buenaventura", "San Diego", "San Francisco", "San Jose", "Santa Ana", "Santa Barbara", "Santa Clara", "Santa Clarita", "Santa Cruz", "Santa Maria", "Santa Rosa", "Sarasota", "Savannah", "Scottsdale", "Scranton", "Seaside", "Seattle", "Sebastian", "Shreveport", "Simi Valley", "Sioux City", "Sioux Falls", "South Bend", "South Lyon", "Spartanburg", "Spokane", "Springdale", "Springfield", "St. Louis", "St. Paul", "St. Petersburg", "Stamford", "Sterling Heights", "Stockton", "Sunnyvale", "Syracuse", "Tacoma", "Tallahassee", "Tampa", "Temecula", "Tempe", "Thornton", "Thousand Oaks", "Toledo", "Topeka", "Torrance", "Trenton", "Tucson", "Tulsa", "Tuscaloosa", "Tyler", "Utica", "Vallejo", "Vancouver", "Vero Beach", "Victorville", "Virginia Beach", "Visalia", "Waco", "Warren", "Washington", "Waterbury", "Waterloo", "West Covina", "West Valley City", "Westminster", "Wichita", "Wilmington", "Winston", "Winter Haven", "Worcester", "Yakima", "Yonkers", "York", "Youngstown"];

const newPerson = () => {
    const bridgeCharge = Math.floor(Math.random() * 100) + '.00';
    const inboundCharge = Math.floor(Math.random() * 100) + '.00';
    const miscCharge = Math.floor(Math.random() * 100) + '.00';
    const totalCost = calCost(bridgeCharge, inboundCharge, miscCharge)
    const servicesArr = ['AC', 'VC', 'VOIP', 'IVR']
    return {
        id: Math.floor(Math.random() * 100000000),
        Date: '14/12/2017',
        sTime: '03:30 PM',
        eTime: '04:30 PM',
        Duration: '01h 25m 06s',
        dialIn: Math.floor(Math.random() * 1000) + '-' + Math.floor(Math.random() * 1000) + '-' + Math.floor(Math.random() * 10000),
        bridgeCharge: bridgeCharge,
        inboundCharge: inboundCharge,
        miscCharge: miscCharge,
        totalCost: totalCost,
        services: servicesArr[Math.floor(Math.random() * servicesArr.length)]
    };
};


function calCost(a, b, c) {
    // console.log(a, b, c)
    return parseFloat(a) + parseFloat(b) + parseFloat(c) + '.00';
}
export function makeData(len = 65) {
    return range(len).map(d => {
        return {
            ...newPerson()
        };
    });
}



const purchaseDid = () => {
    const servicesArr = ['AC', 'VC', 'VOIP', 'IVR']
    return {
        id: Math.floor(Math.random() * 100000000),
        did: Math.floor(Math.random() * 1000) + '-' + Math.floor(Math.random() * 1000) + '-' + Math.floor(Math.random() * 10000),
        country: country_list[Math.floor(Math.random() * country_list.length)],
        city: city_names[Math.floor(Math.random() * city_names.length)],
        type: Math.random() > 0.5 ? 'Global' : 'Dedicated',
        date: '23/01/2018',
        cdr: 'View',
        services: servicesArr[Math.floor(Math.random() * servicesArr.length)],
        status: Math.random() > 0.5 ? 'Enabled' : 'Disabled'
    };
};


export function makePurchasedData(len = 65) {
    return range(len).map(d => {
        return {
            ...purchaseDid()
        };
    });
}


const trackDidData = () => {

    var statusVal = Math.random();
    return {
        id: Math.floor(Math.random() * 100000000),
        request: Math.floor(Math.random() * 100000),
        country: country_list[Math.floor(Math.random() * country_list.length)],
        city: city_names[Math.floor(Math.random() * city_names.length)],
        didReq: Math.floor(Math.random() * 20),
        type: Math.random() > 0.5 ? 'Global' : 'Dedicated',
        date: '23/01/2018',
        price: Math.floor(Math.random() * 100),
        status: statusVal < 0.35 ? 'Request Declined' : statusVal < 0.65 ? 'Request Confirmed' : 'Request Fullfilled'
    };
};

export function makeDidRequestData(len = 65) {
    return range(len).map(d => {
        return {
            ...trackDidData()
        };
    });
}


const viewDid = () => {
    const servicesArr = ['AC', 'VC', 'VOIP', 'IVR']
    return {
        id: Math.floor(Math.random() * 100000000),
        did: Math.floor(Math.random() * 1000) + '-' + Math.floor(Math.random() * 1000) + '-' + Math.floor(Math.random() * 10000),
        allocatedDate: '23/01/2018',
        services: servicesArr[Math.floor(Math.random() * servicesArr.length)],
        status: Math.random() > 0.5 ? 'Active' : 'Disabled',
        totalTime: '15h 4m 33s'
    };
};

export function makeViewDidData(len = 65) {
    return range(len).map(d => {
        return {
            ...viewDid()
        };
    });
}

const manageDidReseller = () => {
    const servicesArr = ['AC', 'VC', 'VOIP', 'IVR']
    return {
        id: Math.floor(Math.random() * 100000000),
        did: Math.floor(Math.random() * 1000) + '-' + Math.floor(Math.random() * 1000) + '-' + Math.floor(Math.random() * 10000),
        type: Math.random() > 0.5 ? 'Global' : 'Dedicated',
        country: country_list[Math.floor(Math.random() * country_list.length)],
        city: city_names[Math.floor(Math.random() * city_names.length)],
        date: '23/01/2018',
        cdr: 'View',
        services: servicesArr[Math.floor(Math.random() * servicesArr.length)],
        status: Math.random() > 0.5 ? 'Enable' : 'Disable'
    };
};


export function makeDidResellerData(len = 65) {
    return range(len).map(d => {
        return {
            ...manageDidReseller()
        };
    });
}

const viewCustomer = () => {
    const servicesArr = ['AC', 'VC', 'VOIP', 'IVR']
    const randomCompany = ['Abc Technologies', 'Efg Technologies', 'Ghi Technologies', 'Jkl Technologies', 'Mno Technologies']
    return {
        id: Math.floor(Math.random() * 100000000),
        customerName: randomCompany[Math.floor(Math.random() * randomCompany.length)],
        did: Math.floor(Math.random() * 1000) + '-' + Math.floor(Math.random() * 1000) + '-' + Math.floor(Math.random() * 10000),
        type: Math.random() > 0.5 ? 'Global' : 'Dedicated',
        country: country_list[Math.floor(Math.random() * country_list.length)],
        city: city_names[Math.floor(Math.random() * city_names.length)],
        date: '23/01/2018',
        address: 'D-2,sector-2',
        contact: Math.floor(Math.random() * 1000000000),
        numberOfDid: Math.floor(Math.random() * 100),
        services: servicesArr[Math.floor(Math.random() * servicesArr.length)],
    };
};


export function viewCustomerData(len = 65) {
    return range(len).map(d => {
        return {
            ...viewCustomer()
        };
    });
}


// const leadList = () => {
//     const statusChance = Math.random();
//     const randomCompany = ['Abc Technologies', 'Efg Technologies', 'Ghi Technologies', 'Jkl Technologies', 'Mno Technologies']
//     return {
//         firstName: namor.generate({ words: 1, numbers: 0 }),
//         lastName: namor.generate({ words: 1, numbers: 0 }),
//         company: randomCompany[Math.floor(Math.random() * randomCompany.length)],
//         contact: Math.floor(Math.random() * 1000000000),
//         age: Math.floor(Math.random() * 30),
//         visits: Math.floor(Math.random() * 100),
//         progress: Math.floor(Math.random() * 100),

//     };
// };

// export function makeLeadData(len = 5553) {
//     return range(len).map(d => {
//         return {
//             ...leadList(),
//             children: range(10).map(leadList)
//         };
//     });
// }
