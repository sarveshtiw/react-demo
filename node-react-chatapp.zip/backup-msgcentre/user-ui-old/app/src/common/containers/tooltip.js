import React from 'react';
import { OverlayTrigger, Tooltip } from 'react-bootstrap';

class LinkWithTooltip extends React.Component {
    render() {
        const { type, onClic, iconName } = this.props
        let tooltip = <Tooltip id={this.props.id}>{this.props.tooltip}</Tooltip>;
        return (
            <div onClick={() => { type !== 'link' ? this.props.onClic() : '' }}>
                <OverlayTrigger
                    overlay={tooltip}
                    placement="top"
                    delayShow={300}
                    delayHide={150}
                >
                    <i className={`${this.props.class} icon-in-list`}>{this.props.iconName}</i>
                </OverlayTrigger>
            </div>
        );
    }
}

export default LinkWithTooltip; 