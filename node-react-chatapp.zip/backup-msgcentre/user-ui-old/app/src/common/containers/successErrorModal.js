import React from 'react';
import { Link } from 'react-router-dom'

class SuccessErrorModal extends React.Component {

    render() {
        const { icon, content, upperClose, link, closeModal, heading, customClass } = this.props
        let upCloseReference;
        if (link) {
            upCloseReference = <Link className="close new-close" to={link}><i className="material-icons">clear</i></Link>
        } else {
            upCloseReference = <button type="button" className="close new-close" onClick={() => this.props.closeModal()}><i className="material-icons">clear</i></button>
        }
        return (
            <div className='myModal show'>
                <div className={`myModal-content modal-sm ${customClass}`}>
                    <div className="myModal-header mng-mymodal-head">
                        {upperClose && upCloseReference}
                        {heading}
                    </div>
                    <div className="myModal-body">
                        {icon && <img src={icon} alt="Synthesis" />}
                        {content}
                    </div>
                    <div className="myModal-footer">
                        {this.props.children}
                    </div>
                </div>
                <div className='myModal-overlay show' />
            </div>
        );
    }
}

export default SuccessErrorModal; 