import React from 'react'
import Header from '../components/MainHeader'
import { Nav, Navbar } from 'react-bootstrap'
import FirstMenu from '../components/FirstLevelMenu'
import SecondMenu from '../components/SecondLevelMenu'
import '../../style/top.scss'

class TopMenu extends React.Component {

    state = {
        subBar: true,
        subBarDrop: false,
        subBarDropMenu: {},
        clickedMenu: '',
        popOver: false
    }

    toggleSubBar = () => {
        // console.log(`i clickeed`)
        let subBarStatus = !this.state.subBar;
        this.setState({
            subBar: subBarStatus,
            subBarDrop: false,
            subBarDropMenu: {},
            clickedMenu: ''
        })
    }

    toggleSubBarDrop = (data) => {
        const { menu } = this.props
        const { clickedMenu, subBarDrop } = this.state
        let clickedMenuTitle = clickedMenu
        let subBarDropStatus = subBarDrop
        if (clickedMenuTitle != data) {
            var filterSubMenu = menu.menuItem.filter((item) => {
                return item.title == data
            })
            subBarDropStatus = true
            clickedMenuTitle = data
        } else {
            subBarDropStatus = !subBarDropStatus
            var filterSubMenu = [{}]
            clickedMenuTitle = ''
        }
        this.setState({
            subBarDrop: subBarDropStatus,
            clickedMenu: clickedMenuTitle,
            subBarDropMenu: filterSubMenu[0],

        })
    }

    closeSubBar = () => {
        this.setState({
            subBarDrop: false,
            subBarDropMenu: {},
            clickedMenu: ''
        })
    }

    searchInput = () => {
        let popOver = !this.state.popOver;
        this.setState({
            popOver: popOver
        })
    }

    render() {
        const { menu } = this.props
        const { subBar, subBarDrop, subBarDropMenu, popOver } = this.state
        return (
            <div className="navigation">
                <Header
                    menu={menu}
                    toggleSubBar={() => this.toggleSubBar()}
                    searchInput={() => this.searchInput()}
                    popOver={popOver}
                />
                {subBar == true && menu.menuItem !== undefined ?

                    <FirstMenu
                        menu={menu.menuItem}
                        toggleSubBarDrop={(data) => this.toggleSubBarDrop(data)}
                        closeSubBar={() => this.closeSubBar()}
                    />

                    : ''}

                {
                    subBar == true && subBarDrop == true ?
                        <SecondMenu
                            menu={subBarDropMenu}
                        />
                        : ''
                }
            </div>
        )
    }
}



export default TopMenu
