import React from 'react';
import { Row, Col, FormGroup, FormControl, HelpBlock, ControlLabel, Form, Button } from 'react-bootstrap';
import { Typeahead } from 'react-bootstrap-typeahead';

class AddressData extends React.Component {

    state = {
        street: null,
        city: null,
        state: null,
        country: null,
        zipcode: null
    }

    handleChange(e) {
        this.setState({
            [e.target.name]: e.target.value
        })
    }

    render() {
        return (
            <div>
                <Row>
                    <Col sm={4}>
                        <FormGroup>
                            <ControlLabel>Street Address</ControlLabel>
                            <FormControl
                                type="text"
                                value={this.state.street}
                                name="street"
                                placeholder="Street"
                                onChange={(e) => this.handleChange(e)}
                            />
                        </FormGroup>
                    </Col>
                    <Col sm={4}>
                        <FormGroup>
                            <ControlLabel>City</ControlLabel>
                            {/* <Typeahead
                                labelKey="name"
                                onChange={(e) => {
                                    this.changeCity(e);
                                }}
                                placeholder="city"
                                options={cityArr}
                                clearButton={true}
                                disabled={cityArr.length > 0 ? false : true}
                                selected={this.state.city}
                            /> */}
                        </FormGroup>
                    </Col>
                    <Col sm={4}>
                        <FormGroup>
                            <ControlLabel>State/Province</ControlLabel>
                            {/* <Typeahead
                                labelKey="name"
                                onChange={(e) => {
                                    this.getCityByStateId(e);
                                }}
                                placeholder="state"
                                options={stateArr}
                                clearButton={true}
                                selected={this.state.stateVal}
                                disabled={stateArr.length > 0 ? false : true}
                            /> */}

                        </FormGroup>
                    </Col>
                </Row>
                <Row>
                    <Col sm={4}>
                        <FormGroup >
                            <ControlLabel>Zip/Postal Code</ControlLabel>
                            <FormControl
                                type="text"
                                value={this.state.zipcode}
                                name="zipcode"
                                placeholder="Zip/Postal Code"
                                onChange={(e) => this.handleChange(e)}
                            />
                        </FormGroup>
                    </Col>
                    <Col sm={4}>
                        <FormGroup>
                            <ControlLabel>Country</ControlLabel>
                            {/* <Typeahead
                                className="auto-suggest"
                                labelKey="country_name"
                                onChange={(e) => {
                                    this.getState(e, 'other');
                                }}
                                selected={this.state.country}
                                placeholder="country"
                                options={countryArr}
                                clearButton={true}
                            /> */}

                        </FormGroup>
                    </Col>
                </Row>
            </div>
        )
    }
}

export default AddressData; 