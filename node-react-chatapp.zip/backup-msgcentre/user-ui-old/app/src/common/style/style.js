import styled from 'styled-components';

export const SubHeading = styled.h6`
  color: #06bed2;
  font-size: 16px;
  font-weight: 600;
  margin-top: 5px;
`;

export const DropdownWrap = styled.ul`
  position: absolute;
  left: 0;
  top: 100%;
  right: 0;
  background-color: #fff;
  overflow: auto;
  max-height: 200px;
  list-style: none;
  padding-left: 0;
  box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.14);
  z-index: 1;
`;

export const DropdownItem = styled.li`
  padding: 5px 10px;
  background-color: ${props => props.highlighted && '#05bed2'} !important;
  color: ${props => (props.highlighted ? '#fff' : '#333')};
  border-top: 1px solid #ccc;
  &:nth-child(odd) {
    background-color: #f9f9f9;
  }
`;

export const Parent = styled.div`
  position: relative;
`;

export const Icon = styled.button`
  position: absolute;
  background: #fff;
  color: #354052;
  border-radius: 50%;
  right: 25px;
  top: 7px;
  width: 20px;
  height: 20px;
  line-height: 20px;
  text-align: center;
  font-size: 12px;
  cursor: pointer;
  border: 0;
  outline: 0;
  box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.14);
`;
