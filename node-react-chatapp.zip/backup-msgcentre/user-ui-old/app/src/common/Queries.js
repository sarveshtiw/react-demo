import gql from 'graphql-tag';

export const GETCOUNTRIES_LIST = gql`
{ 
    getCountries{
        details{
            id
            country_name
        }
    }
}
`;

export const owners = gql`

{
  owners{
    id
    name
  }
}

`;


export const GETCITIESBYCOUNTRIESID_LIST = gql`
query getCitiesByCountryID($input:listCitiesByIdIn){
         getCitiesByCountryID(input:$input){
            details{
            id
            name
            }
        }
    }
`;

export const GETSTATESBYCOUNTRIESID_LIST = gql`
query getStatesByCountryID($input:getStatesByCountryIn){
         getStatesByCountryID(input:$input){
            fetch
            details{
            id
            name
            }
        }
    }
`;

export const GETCITIESBYSTATEID_LIST = gql`
query getCitiesByStateID($input:getCitiesByStateIDIn){
         getCitiesByStateID(input:$input){
            details{
            id
            name
            }
        }
    }
`;

export const PROFILE_DATA = gql`
{
       profile{
            id
            uuid
            last_access
            email
            Profile{
                id
                title
                fname
                lname
                gender
                phone
                Country{
                    country_name
                }
                Company{
                    id
                    company_name
                }
                Role{
                    name
                    type
                }
                Designation{
                    designation_name
                }

            }
        }
    }
`;


export const GET_APPLICATIONS = gql`
{
  getApplications{
    details{
      id
      name
    }
  }
}
`;

export const GETDID_TYPES = gql`
{ 
    getDidTypes(input:{ }) 
    { 
        details{ 
            id 
            did_type 
        } 
    } 
}
`;