import gql from 'graphql-tag';

export const GETCOUNTRIES_LIST = gql`
  {
    getCountryData {
      id
      name_country
    }
  }
`;

export const GETCITIESBYCOUNTRIESID_LIST = gql`
  query getCityDataByCountryId($id: Int!) {
    getCityDataByCountryId(id: $id) {
      id
      name_city
    }
  }
`;

export const GETSTATESBYCOUNTRIESID_LIST = gql`
  query getStatesDataByCountryId($id: Int!) {
    getStatesDataByCountryId(id: $id) {
      id
      name_state
    }
  }
`;

export const GETCITIESBYSTATEID_LIST = gql`
  query getCityDataByStateId($id: Int!) {
    getCityDataByStateId(id: $id) {
      id
      name_city
    }
  }
`;

export const PROFILE_DATA = gql`
  {
    profile {
      id
      uuid
      last_access
      email
      Profile {
        id
        title
        fname
        lname
        gender
        phone
        Country {
          country_name
        }
        Company {
          id
          company_name
        }
        Role {
          name
          type
        }
        Designation {
          designation_name
        }
        Company {
          id
        }
      }
    }
  }
`;

export const GET_APPLICATIONS = gql`
  {
    getApplications {
      details {
        id
        name
      }
    }
  }
`;

export const GETDID_TYPES = gql`
  {
    getDidTypes(input: {}) {
      details {
        id
        did_type
      }
    }
  }
`;
