const Joi = require('joi-browser');
var emailRegex = /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
var websiteRegex = /^(http: \/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/i

export const customJoiString = Joi.extend((joi) => ({
    base: joi.string(),
    name: 'string',
    language: {
        emailValidation: 'should be a valid email',
        isNumber: 'should be a number',
        websiteValidation: 'should be a valid website url'
    },
    rules: [
        {
            name: 'emailValidation',
            validate(params, value, state, options) {

                if (emailRegex.test(value) == false) {
                    // Generate an error, state and options need to be passed, q is used in the language
                    return this.createError('string.emailValidation', { v: value }, state, options);
                }

                return value; // Everything is OK
            }
        },
        {
            name: 'isNumber',
            validate(params, value, state, options) {

                if (isNaN(value)) {
                    // Generate an error, state and options need to be passed, q is used in the language
                    return this.createError('string.isNumber', { v: value }, state, options);
                }

                return value; // Everything is OK
            }
        },
        {
            name: 'websiteValidation',
            validate(params, value, state, options) {

                if (websiteRegex.test(value) == false) {
                    // Generate an error, state and options need to be passed, q is used in the language
                    return this.createError('string.websiteValidation', { v: value }, state, options);
                }

                return value; // Everything is OK
            }
        },
    ]
}));