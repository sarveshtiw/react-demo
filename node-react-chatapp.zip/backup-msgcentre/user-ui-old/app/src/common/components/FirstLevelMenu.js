import React from 'react'
import { Link } from 'react-router-dom';
import { Nav, NavItem, Navbar } from 'react-bootstrap'
import { IndexLinkContainer } from 'react-router-bootstrap'

const FirstMenu = ({
    menu,
    toggleSubBarDrop,
    closeSubBar
}) => (
        <Navbar collapseOnSelect className="nav-audioConf bottom">
            <Navbar.Collapse>
                <Nav>
                    {
                        menu.map((item, i) => {
                            if (item.subNav.length > 0) {
                                return (
                                    <NavItem key={i} eventKey={item.title} href="javascript:void('0')" onClick={() => toggleSubBarDrop(item.title)}>
                                        <i className="material-icons">add_circle_outline</i> {item.title}
                                    </NavItem>
                                )
                            } else {
                                return (
                                    <IndexLinkContainer key={i} to={item.route} onClick={() => closeSubBar()}>
                                        <NavItem eventKey={item.title}>
                                            {item.title}
                                        </NavItem>
                                    </IndexLinkContainer>
                                )
                            }
                        })
                    }
                </Nav>
            </Navbar.Collapse >
        </Navbar >
    )




export default FirstMenu
