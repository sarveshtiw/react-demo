import React from 'react'
import { Navbar, Nav, NavItem, NavDropdown, FormGroup, MenuItem, FormControl } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import NavDrop from './NavDrop';
import '../../style/top.scss'

const Header = ({
    menu,
    toggleSubBar,
    searchInput,
    popOver
}) => (
        <Navbar collapseOnSelect className="nav-audioConf">
            <Navbar.Collapse>
                <Nav>
                    <Navbar.Brand>
                        <Link to="/"><img src="/images/logo.png" alt="Synthesis Dashboard" /></Link>
                        <a href="javascript:void('0')" onClick={toggleSubBar}><i className="icon-app"></i></a>
                    </Navbar.Brand>
                    <Navbar.Toggle />
                </Nav>
                <Navbar.Header>
                    <h1>{menu.title}</h1>
                </Navbar.Header>

                <div className="nav navbar-nav navbar-right">
                    <FormGroup controlId="formBasicText" className={popOver ? "btnGroup focus" : "btnGroup"}>
                        <form name="search-message" autoComplete="off" >
                            <FormControl type="text" name="searchInput" placeholder="Search" onBlur={searchInput} onFocus={searchInput} ></FormControl>
                            <span className="form-control-feedback material-icons">search</span>
                        </form>
                    </FormGroup>
                    <NavDrop />
                </div>

            </Navbar.Collapse>
        </Navbar>
    )




export default Header
