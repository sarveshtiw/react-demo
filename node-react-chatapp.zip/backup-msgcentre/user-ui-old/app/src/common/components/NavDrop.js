import React from 'react';
import { Nav, NavDropdown, MenuItem, NavItem } from 'react-bootstrap';

const logoutUser = () => {
    localStorage.clear();
    window.location.replace('/');
}

const NavDrop = () => {
    return (
        <Nav>
            <NavDropdown eventKey={1}
                title={
                    <img src='/images/avatar.png' />
                } id="user-dropdown">
                <MenuItem eventKey={1.1}>Action</MenuItem>
                <MenuItem eventKey={1.2}>Another action</MenuItem>
                <MenuItem eventKey={1.3}>Something else here</MenuItem>
                <MenuItem divider />
                <MenuItem eventKey={1.4} onClick={() => logoutUser()}>Log Out</MenuItem>
            </NavDropdown>
            <NavItem eventKey={2} href="#"><i className="icon-notifications"></i></NavItem>
            <NavItem eventKey={3} href="#"><i className="icon-settings"></i></NavItem>
        </Nav>
    );
}

export default NavDrop;