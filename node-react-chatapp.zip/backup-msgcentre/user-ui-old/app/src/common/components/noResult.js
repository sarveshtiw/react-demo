import React from 'react';
import '../style/noResult.scss';

const NoResult = ({
    clickRef,
    data
}) =>
    (
        <div className="ibox mb-0">
            <div className="ibox-content text-center oops-box">
                <img src="/images/question-search.png" className="pic" alt="Oops! There's Nothing" />
                <h1 className="mt-0">Oops! There's Nothing</h1>
                <p>seems like there is no data for now, but you can start creating it.</p>
                <button className="btn btn-submit pl-5 pr-5 mr-0" onClick={clickRef}>{data}</button>
            </div>
        </div>
    );

export default NoResult;