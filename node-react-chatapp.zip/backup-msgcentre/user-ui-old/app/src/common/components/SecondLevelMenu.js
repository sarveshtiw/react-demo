import React from 'react'
import { Link } from 'react-router-dom';
import { NavItem, Nav, Navbar } from 'react-bootstrap'
import { IndexLinkContainer } from 'react-router-bootstrap'

const SecondMenu = ({
    menu
}) => (
        <Navbar collapseOnSelect className="nav-audioConf bottom">
            <Navbar.Collapse className="thirdlevelMenu">
                <Nav>
                    {
                        menu.subNav.map((item, i) => {
                            return (
                                <IndexLinkContainer key={i} to={item.route}>
                                    <NavItem eventKey={item.title}>
                                        {item.title}
                                    </NavItem>
                                </IndexLinkContainer>
                            )
                        })
                    }
                </Nav>
            </Navbar.Collapse>
        </Navbar>
    )




export default SecondMenu
