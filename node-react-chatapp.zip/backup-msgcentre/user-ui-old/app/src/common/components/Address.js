import React, { Component } from 'react';
import PropTypes from 'prop-types';
import {
  Row,
  Col,
  FormGroup,
  FormControl,
  ControlLabel,
  HelpBlock,
} from 'react-bootstrap';
import { Query, withApollo, compose } from 'react-apollo';
import AutoComplete from './AutoComplete';
import { SubHeading } from '../style/style';

import {
  GETCOUNTRIES_LIST,
  GETSTATESBYCOUNTRIESID_LIST,
  GETCITIESBYCOUNTRIESID_LIST,
  GETCITIESBYSTATEID_LIST,
} from '../Queries_new';

class Address extends Component {
  state = {
    address_line1: '',
    address_line2: '',
    address_line3: '',
    id_country: '',
    id_city: '',
    id_state: '',
    pincode: '',
    state: [],
    city: [],
  };

  // handle change of all input
  handleChange = e => {
    const target = e.target;
    this.setState({
      [target.dataset.name]: target.value,
    });
    if (
      !(
        target.dataset.name === 'id_country' ||
        target.dataset.name === 'id_state' ||
        target.dataset.name === 'id_city'
      )
    ) {
      this.props.onChange(this.props.index, target.dataset.name, target.value);
    }
  };

  autoCompleteReset = name => {
    if (name === 'id_country') {
      this.setState({
        id_country: '',
        id_state: '',
        id_city: '',
        state: [],
        city: [],
      });
      this.props.onChange(this.props.index, name, 0);
      this.props.onChange(this.props.index, 'id_state', 0);
      this.props.onChange(this.props.index, 'id_city', 0);
    } else if (name === 'id_state') {
      this.setState({ id_state: '', id_city: '', city: [] });
      this.props.onChange(this.props.index, 'id_state', 0);
      this.props.onChange(this.props.index, 'id_city', 0);
    } else {
      this.setState({ id_city: '' });
      this.props.onChange(this.props.index, 'id_city', 0);
    }
  };

  // auto complete select function
  autoComplete = (name, selected, select) => {
    let id = selected ? selected.id : 0;
    let text = selected ? selected[select] : '';
    this.setState({ [name]: text });
    // this.props.onChange(this.props.index, name, id);
    if (name === 'id_country') {
      this.getStateByCountryIDList(id);
    }

    if (name === 'id_state') {
      this.getCityByStateList(id);
    }
  };

  autoCompleteBlur = (name, items, select, value) => {
    let selected = items.find(d => {
      return d[select].toLowerCase() === value.toLowerCase();
    });
    if (selected) {
      this.setState({ [name]: selected[select] });
      this.props.onChange(this.props.index, name, selected.id);
    } else {
      this.setState({ [name]: '' });
    }
  };

  // get state by country id
  async getStateByCountryIDList(id) {
    // set default value when country change
    this.setState({ state: [], city: [], id_state: '', id_city: '' });
    try {
      let response = await this.props.client.query({
        query: GETSTATESBYCOUNTRIESID_LIST,
        variables: {
          id: Number(id),
        },
      });
      console.log(response);

      let {
        data: { getStatesDataByCountryId },
      } = response;

      if (getStatesDataByCountryId.length) {
        this.setState({ state: getStatesDataByCountryId });
      } else {
        // if state not found get city
        this.getCityByCountryList(id);
      }
    } catch (err) {
      console.log(err);
    }
  }

  async getCityByCountryList(id) {
    // set default value of city and hide when country change
    this.setState({ city: [], id_city: '' });
    try {
      let response = await this.props.client.query({
        query: GETCITIESBYCOUNTRIESID_LIST,
        variables: {
          id: Number(id),
        },
      });

      let {
        data: { getCityDataByCountryId },
      } = response;

      this.setState({ city: getCityDataByCountryId });
    } catch (err) {
      console.log(err);
    }
  }

  async getCityByStateList(id) {
    this.setState({ city: [], id_city: '' });

    try {
      let response = await this.props.client.query({
        query: GETCITIESBYSTATEID_LIST,
        variables: {
          id: Number(id),
        },
      });

      let {
        data: { getCityDataByStateId },
      } = response;

      this.setState({ city: getCityDataByStateId });
    } catch (err) {
      console.log(err);
    }
  }

  countryList = ({ error, loading, data }) => {
    if (error) return <div>Some Server Error, Please try again!</div>;
    if (loading) return <div>loading...</div>;

    return (
      <AutoComplete
        placeholder="Select Country"
        items={data.getCountryData}
        select="name_country"
        onSelect={this.autoComplete}
        onChange={this.handleChange}
        onBlur={this.autoCompleteBlur}
        onReset={this.autoCompleteReset}
        value={this.state.id_country}
        name="id_country"
      />
    );
  };

  render() {
    let {
      address_line1,
      address_line2,
      address_line3,
      pincode,
      state,
      city,
    } = this.state;
    let { index, errors } = this.props;
    return (
      <Row>
        <Col xs={12}>
          <SubHeading>
            {index === 0 ? 'Primary Address' : `Address ${index + 1}`}
          </SubHeading>
          <hr className="mt-3" />
        </Col>
        <Col sm={4} xs={12}>
          <FormGroup
            controlId={'address_line1' + index}
            validationState={errors.address_line1 && 'error'}
          >
            <ControlLabel>
              Address Line 1<span className="star">*</span>
            </ControlLabel>
            <FormControl
              type="text"
              value={address_line1}
              data-name="address_line1"
              placeholder="address line 1"
              onChange={this.handleChange}
            />
            {errors.address_line1 && (
              <HelpBlock>
                {errors.address_line1.replace(
                  'address_line1',
                  'address line 1',
                )}
              </HelpBlock>
            )}
          </FormGroup>
        </Col>
        <Col sm={4} xs={12}>
          <FormGroup
            controlId={'address_line2' + index}
            validationState={errors.address_line2 && 'error'}
          >
            <ControlLabel>Address Line 2</ControlLabel>
            <FormControl
              type="text"
              value={address_line2}
              data-name="address_line2"
              placeholder="address line 2"
              onChange={this.handleChange}
            />
            {errors.address_line2 && (
              <HelpBlock>
                {errors.address_line2.replace(
                  'address_line2',
                  'address line 2',
                )}
              </HelpBlock>
            )}
          </FormGroup>
        </Col>
        <Col sm={4} xs={12}>
          <FormGroup
            controlId={'address_line3' + index}
            validationState={errors.address_line3 && 'error'}
          >
            <ControlLabel>Address Line 3</ControlLabel>
            <FormControl
              type="text"
              value={address_line3}
              data-name="address_line3"
              placeholder="address line 3"
              onChange={this.handleChange}
            />
            {errors.address_line3 && (
              <HelpBlock>
                {errors.address_line3.replace(
                  'address_line3',
                  'address line 3',
                )}
              </HelpBlock>
            )}
          </FormGroup>
        </Col>
        <Col sm={4} xs={12}>
          <FormGroup
            controlId={'id_country' + index}
            validationState={errors.id_country && 'error'}
          >
            <ControlLabel>
              Country<span className="star">*</span>
            </ControlLabel>
            <Query query={GETCOUNTRIES_LIST}>{this.countryList}</Query>
            {errors.id_country && (
              <HelpBlock>
                {errors.id_country.replace('id_country', 'country')}
              </HelpBlock>
            )}
          </FormGroup>
        </Col>
        <Col sm={4} xs={12}>
          <FormGroup
            controlId={'id_state' + index}
            validationState={errors.id_state && 'error'}
          >
            <ControlLabel>
              State/ Province<span className="star">*</span>
            </ControlLabel>
            <AutoComplete
              placeholder="State/ Province"
              items={state}
              select="name_state"
              onSelect={this.autoComplete}
              name="id_state"
              onChange={this.handleChange}
              onBlur={this.autoCompleteBlur}
              onReset={this.autoCompleteReset}
              value={this.state.id_state}
            />
            {errors.id_state && (
              <HelpBlock>
                {errors.id_state.replace('id_state', 'state')}
              </HelpBlock>
            )}
          </FormGroup>
        </Col>
        <Col sm={4} xs={12}>
          <FormGroup
            controlId={'id_city' + index}
            validationState={errors.id_city && 'error'}
          >
            <ControlLabel>
              City<span className="star">*</span>
            </ControlLabel>
            <AutoComplete
              items={city}
              placeholder="City"
              select="name_city"
              onSelect={this.autoComplete}
              name="id_city"
              onChange={this.handleChange}
              onBlur={this.autoCompleteBlur}
              onReset={this.autoCompleteReset}
              value={this.state.id_city}
            />
            {errors.id_city && (
              <HelpBlock>{errors.id_city.replace('id_city', 'city')}</HelpBlock>
            )}
          </FormGroup>
        </Col>
        <Col sm={4} xs={12}>
          <FormGroup
            controlId={'pincode' + index}
            validationState={errors.pincode && 'error'}
          >
            <ControlLabel>
              Zip/ Postal Code<span className="star">*</span>
            </ControlLabel>
            <FormControl
              type="text"
              value={pincode}
              placeholder="pincode"
              data-name="pincode"
              onChange={this.handleChange}
            />
            {errors.pincode && <HelpBlock>{errors.pincode}</HelpBlock>}
          </FormGroup>
        </Col>
      </Row>
    );
  }
}

Address.propTypes = {
  index: PropTypes.number.isRequired,
  onChange: PropTypes.func.isRequired,
};

export default compose(withApollo)(Address);
