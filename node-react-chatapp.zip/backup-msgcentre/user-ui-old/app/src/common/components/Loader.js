import React from "react";
import "../style/loader.scss";

export default () => {
  return (
    <div className="loader-wrap">
      <div className="loader-col" />
    </div>
  );
};
