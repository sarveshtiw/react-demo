import React from 'react';
import PropTypes from 'prop-types';
import ReactAutoComplete from 'react-autocomplete';

import { DropdownItem, DropdownWrap, Parent, Icon } from '../style/style';

const validateComplete = (value, items, select, onSelect, name) => {
  let selected = items.find(d => {
    return d[select] === value;
  });
  onSelect(name, selected, select);
};

const AutoComplete = ({
  select,
  items,
  onChange,
  name,
  onBlur,
  value,
  onReset,
  onSelect,
  placeholder,
}) => (
  <Parent>
    <ReactAutoComplete
      items={items}
      getItemValue={item => item[select]}
      shouldItemRender={(item, value) =>
        item[select].toLowerCase().indexOf(value.toLowerCase()) === 0
      }
      renderItem={(item, highlighted) => (
        <DropdownItem key={item.id} highlighted={highlighted}>
          {item[select]}
        </DropdownItem>
      )}
      renderMenu={(items, value, style) => <DropdownWrap children={items} />}
      value={value}
      onChange={onChange}
      onSelect={val => validateComplete(val, items, select, onSelect, name)}
      inputProps={{
        className: 'form-control',
        disabled: !items.length,
        placeholder: placeholder,
        onBlur: () => onBlur(name, items, select, value),
      }}
      renderInput={props => (
        <div>
          <input data-name={name} {...props} />
          {value && (
            <Icon type="button" onClick={e => onReset(name)}>
              X
            </Icon>
          )}
        </div>
      )}
      wrapperStyle={{
        display: 'block',
      }}
    />
  </Parent>
);
const propTypes = {
  items: PropTypes.array.isRequired,
  select: PropTypes.string.isRequired,
  onSelect: PropTypes.func.isRequired,
  onBlur: PropTypes.func.isRequired,
  onReset: PropTypes.func.isRequired,
  onChange: PropTypes.func.isRequired,
  name: PropTypes.string.isRequired,
  value: PropTypes.string.isRequired,
  placeholder: PropTypes.string,
};

AutoComplete.propTypes = propTypes;

export default AutoComplete;
