import React, { Component } from 'react';
import '../style/error.scss';

class ServerError extends Component {
    render() {
        return (
            <div className="error-bg">
                <img src="/images/error500.png" alt="Error 500" />
            </div>
        );
    }
}

export default ServerError;