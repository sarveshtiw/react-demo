import React from 'react';
import { Link } from 'react-router-dom'
import { Button } from 'react-bootstrap'
import '../style/error.scss';
import { from } from 'zen-observable';

class NotFound extends React.Component {
    render() {
        const { dashBoard } = this.props
        return (
            <div className="error-bg" style={{ minHeight: dashBoard == true ? 589 + 'px' : 100 + "%" }} >
                <div>
                    <img src="/images/error404.png" alt="Error 404" /><br />
                    {dashBoard == true ? '' : <Link className="btn btn-submit" to="/">Home</Link>}
                </div>
            </ div>
        )
    }
}

export default NotFound;