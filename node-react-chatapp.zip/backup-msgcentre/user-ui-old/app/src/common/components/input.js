import React from 'react';
import PropTypes from 'prop-types';
import {
  FormGroup,
  ControlLabel,
  FormControl,
  HelpBlock,
} from 'react-bootstrap';

const Input = ({
  type,
  label,
  value,
  name,
  onChange,
  placeholder,
  required,
  children,
  error,
}) => {
  return (
    <FormGroup validationState={error && 'error'}>
      {label && (
        <ControlLabel>
          {label}
          {required && <span className="star">*</span>}
        </ControlLabel>
      )}
      {type === 'select' ? (
        <FormControl
          componentClass={type}
          data-name={name}
          value={value}
          onChange={onChange}
        >
          {children}
        </FormControl>
      ) : (
        <FormControl
          type={type}
          data-name={name}
          value={value}
          onChange={onChange}
          placeholder={placeholder}
        />
      )}
      {error && (
        <HelpBlock>{error.replace(name, label.toLowerCase())}</HelpBlock>
      )}
    </FormGroup>
  );
};

Input.defaultProps = {
  type: 'text',
};

Input.propTypes = {
  type: PropTypes.string.isRequired,
  label: PropTypes.string,
  value: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
  placeholder: PropTypes.string,
  required: PropTypes.bool,
  onChange: PropTypes.func.isRequired,
  children: PropTypes.node,
};

export default Input;
