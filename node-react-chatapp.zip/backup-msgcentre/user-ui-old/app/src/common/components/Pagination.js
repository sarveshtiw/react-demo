import React, { Component } from 'react';

class MyPagination extends Component {
    constructor (props) {
        super()

        this.getSafePage = this.getSafePage.bind(this)
        this.changePage = this.changePage.bind(this)
        this.applyPage = this.applyPage.bind(this)
        this.state = {
            page: props.page,
            classname:''
        }
    }

    componentWillReceiveProps (nextProps) {
        this.setState({ page: nextProps.page })
    }
    getSafePage (page) {
        if (isNaN(page)) {
            page = this.props.page
        }
        return Math.min(Math.max(page, 0), this.props.pages - 1)
    }

    changePage (page) {
        page = this.getSafePage(page)
        this.setState({ page })
        if (this.props.page !== page) {
            this.props.onPageChange(page)
        }
    }

    applyPage (e) {
        if (e) { e.preventDefault() }
        const page = this.state.page
        this.changePage(page === '' ? this.props.page : page)
    }

    render () {
        const {
            pages,
            page,
            pageSizeOptions,
            pageSize,
            canPrevious,
            canNext,
            onPageSizeChange
        } = this.props

        const paginationItems= [];

        for(var pi=0; pi<pages; pi++) {
            paginationItems.push (pi);
        }
        return (
            <div className="row">
                <div className="col-md-12">
                    <select
                        onChange={e => onPageSizeChange(Number(e.target.value))}
                        value={pageSize}
                    >
                        {pageSizeOptions.map((option, i) => (
                            <option key={i} value={option}>
                                {option} {this.props.rowsText}
                            </option>
                        ))}
                    </select>
                    <div className="table-pag">
                        <ul className="pagination">
                            <li className="disabled"><a role="button"  tabindex="-1"><span aria-label="First">fast_rewind</span></a></li>
                            <li className={canPrevious?"":"disabled"}
                                onClick={() => {
                                    if (!canPrevious) return
                                    this.changePage(page - 1)
                                }}
                                disabled={!canPrevious}
                            ><a role="button"  tabindex="-1"><span aria-label="Previous">play_arrow</span></a></li>
                            { paginationItems.map((paginationItems, index) => (
                                <li className= {this.state.page == paginationItems ? "active" : ""} onClick={() => { this.changePage(paginationItems)}}><a role="button" >{paginationItems + 1}</a></li>
                            ))}
                            <li className={canNext?"":"disabled"}
                                onClick={() => {
                                    if (!canNext) return
                                    this.changePage(page + 1)
                                }}
                            ><a role="button"><span aria-label="Next">play_arrow</span></a></li>
                            <li className=""><a role="button"><span aria-label="Last">fast_forward</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        )
    }
}

export default MyPagination;