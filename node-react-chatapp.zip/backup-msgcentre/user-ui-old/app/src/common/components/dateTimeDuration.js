import { Row, Col, Table, Pagination, OverlayTrigger, Tooltip, SplitButton, MenuItem, FormGroup, FormControl, InputGroup } from 'react-bootstrap';

import DatePicker from 'react-date-picker';

class DateTimeDuration extends React.Component {
    render() {
        return (
            <div className="timebox-reseller">
                <div className="form-area">
                    <Row>
                        <Col md={4} sm={12}>
                            <FormGroup>
                                <DatePicker
                                    calendarIcon={<i className="fa fa-calendar"></i>}
                                    nextLabel={<i className="fa fa-caret-right" aria-hidden="true"></i>}
                                    prevLabel={<i className="fa fa-caret-left" aria-hidden="true"></i>}
                                />
                            </FormGroup>
                        </Col>
                        <Col md={4} sm={12}>
                            <FormGroup>
                                <InputGroup>
                                    <FormControl type="text" placeholder="Select Time" className="fShadow" />
                                    <InputGroup.Addon>
                                        <i className="fa fa-clock-o"></i>
                                    </InputGroup.Addon>
                                </InputGroup>
                            </FormGroup>
                        </Col>
                        <Col md={4} sm={12}>
                            <FormGroup>
                                <InputGroup>
                                    <FormControl type="text" placeholder="Select Duration" className="fShadow" />
                                    <InputGroup.Addon>
                                        <i className="fa fa-hourglass"></i>
                                    </InputGroup.Addon>
                                </InputGroup>
                            </FormGroup>
                        </Col>
                    </Row>
                </div>
            </div>
        );
    }
}

export default DateTimeDuration;