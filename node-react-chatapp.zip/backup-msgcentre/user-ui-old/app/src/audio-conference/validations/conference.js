const Joi = require('joi-browser');

/********************************************** Starts: Validation schema  ***************************************************/
// Make Schema for validate create conference
let schemaCreateConference = Joi.object().keys({
    conf_name: Joi.string().min(5).max(100).required().trim().regex(/^[\w\-\s]+$/),
    participant_limit: Joi.number().integer().min(2).max(500).required(),
    conf_leaderpin: Joi.number().required(),
    conf_participant_pin: Joi.number().required(),
    id_ac_pop: Joi.number().required(),
    auto_dial: Joi.boolean().required(),
    generate_new_pin: Joi.boolean().optional(),
    send_invites: Joi.boolean().required(),
    record_conf: Joi.boolean().required(),
    participiant_on_mute: Joi.boolean().required(),
    participiant_on_hold: Joi.boolean().required(),
    end_conf_leader_hangs_up: Joi.boolean().required(),
    play_sound: Joi.boolean().required(),
    participiant_name_announced: Joi.boolean().required(),
    enable_touch_tone: Joi.boolean().required(),
    play_music_on_hold: Joi.boolean().required(),
    conf_recurrence_type: Joi.string().required().valid('none', 'daily', 'weekly', 'monthly', 'yearly'),
    daily_recurrence_option: Joi.when('conf_recurrence_type', {
        is: 'daily',
        then: Joi.object({
            daily_option: Joi.string().required().valid('daily', 'weekly'),
            daily_day_no: Joi.number().required().min(1).max(99)
        }).required(),
        otherwise: Joi.optional()
    }),
    weekly_recurrence_option: Joi.when('conf_recurrence_type', {
        is: 'weekly',
        then: Joi.object({
            recur_every_week: Joi.number().required().min(1).max(99),
            weekly_monday: Joi.boolean().required(),
            weekly_tuesday: Joi.boolean().required(),
            weekly_wednesday: Joi.boolean().required(),
            weekly_thursday: Joi.boolean().required(),
            weekly_friday: Joi.boolean().required(),
            weekly_saturday: Joi.boolean().required(),
            weekly_sunday: Joi.boolean().required()
        }).required(),
        otherwise: Joi.optional()
    }),
    monthly_recurrence_option: Joi.when('conf_recurrence_type', {
        is: 'monthly',
        then: Joi.object({
            monthly_option: Joi.string().required().valid('day', 'weekly'),
            monthly_day: Joi.number().optional().min(1).max(31),
            monthly_every_month: Joi.number().optional().min(1).max(99),
            monthly_week: Joi.string().optional().valid('first', 'second', 'third', 'fourth', 'last'),
            monthly_day_of_week: Joi.string().optional().valid('day', 'weekday', 'weekend day', 'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'),
            monthly_of_every_month: Joi.number().optional().min(1).max(99),
        }).required(),
        otherwise: Joi.optional()
    }),
    yearly_recurrence_option: Joi.when('conf_recurrence_type', {
        is: 'yearly',
        then: Joi.object({
            recur_every_year: Joi.number().required().min(1).max(99),
            yearly_option: Joi.string().required().valid('monthly', 'weekly'),
            yearly_on_month: Joi.string().optional().valid('january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'),
            yearly_on_month_day: Joi.number().optional().min(1).max(31),
            yearly_week: Joi.string().optional().valid('first', 'second', 'third', 'fourth', 'last'),
            yearly_day_of_week: Joi.string().optional().valid('day', 'weekday', 'weekend day', 'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'),
            yearly_of_every_month: Joi.string().optional().valid('january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december')
        }).required(),
        otherwise: Joi.optional()
    }),
    conf_start_time: Joi.optional(),
    conf_end_time: Joi.optional(),
    //conf_start_time: Joi.date().min(dateFormat(new Date(), "yyyy-mm-dd")).optional(),
    //conf_end_time: Joi.string().regex(/^([0-1]?[0-9]|2[0-3])(:[0-5][0-9]) ([AaPp][Mm])?$/).allow(''),
    //conf_duration: Joi.string().regex(/^([0-1]?[0-9]|2[0-3])(:[0-5][0-9]) ([AaPp][Mm])?$/).allow(''),
    participiants: Joi.array().items(Joi.number()).optional(),
    dids: Joi.array().items(Joi.number()).optional(),
    conf_end_date_option: Joi.number().required().valid(1, 2, 3),
    conf_end_after_occurence: Joi.number().optional().min(2).max(999),
    conf_end_date: Joi.date().optional()
});

let schemaUpdateConference = Joi.object().keys({
    id: Joi.number().required(),
    conf_name: Joi.string().min(3).max(150).required().trim(),
    participant_limit: Joi.number().integer().min(2).max(500).required(),
    conf_leaderpin: Joi.number().required(),
    conf_participant_pin: Joi.number().required(),
    id_ac_pop: Joi.number().required(),
    auto_dial: Joi.boolean().required(),
    generate_new_pin: Joi.boolean().optional(),
    send_invites: Joi.boolean().required(),
    record_conf: Joi.boolean().required(),
    participiant_on_mute: Joi.boolean().required(),
    participiant_on_hold: Joi.boolean().required(),
    end_conf_leader_hangs_up: Joi.boolean().required(),
    play_sound: Joi.boolean().required(),
    participiant_name_announced: Joi.boolean().required(),
    enable_touch_tone: Joi.boolean().required(),
    play_music_on_hold: Joi.boolean().required(),
    conf_recurrence_type: Joi.string().required().valid('none', 'daily', 'weekly', 'monthly', 'yearly'),
    daily_recurrence_option: Joi.when('conf_recurrence_type', {
        is: 'daily',
        then: Joi.object({
            daily_option: Joi.string().required().valid('daily', 'weekly'),
            daily_day_no: Joi.number().required()
        }).required(),
        otherwise: Joi.optional()
    }),
    weekly_recurrence_option: Joi.when('conf_recurrence_type', {
        is: 'weekly',
        then: Joi.object({
            recur_every_week: Joi.number().required(),
            weekly_monday: Joi.boolean().required(),
            weekly_tuesday: Joi.boolean().required(),
            weekly_wednesday: Joi.boolean().required(),
            weekly_thursday: Joi.boolean().required(),
            weekly_friday: Joi.boolean().required(),
            weekly_saturday: Joi.boolean().required(),
            weekly_sunday: Joi.boolean().required()
        }).required(),
        otherwise: Joi.optional()
    }),
    monthly_recurrence_option: Joi.when('conf_recurrence_type', {
        is: 'monthly',
        then: Joi.object({
            monthly_option: Joi.string().required().valid('day', 'weekly'),
            monthly_day: Joi.number().optional(),
            monthly_every_month: Joi.number().optional(),
            monthly_week: Joi.string().optional().valid('first', 'second', 'third', 'fourth', 'last'),
            monthly_day_of_week: Joi.string().optional().valid('day', 'weekday', 'weekend day', 'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'),
            monthly_of_every_month: Joi.number().optional(),
        }).required(),
        otherwise: Joi.optional()
    }),
    yearly_recurrence_option: Joi.when('conf_recurrence_type', {
        is: 'yearly',
        then: Joi.object({
            recur_every_year: Joi.number().required(),
            yearly_option: Joi.string().required().valid('monthly', 'weekly'),
            yearly_on_month: Joi.string().optional().valid('january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'),
            yearly_on_month_day: Joi.number().optional(),
            yearly_week: Joi.string().optional().valid('first', 'second', 'third', 'fourth', 'last'),
            yearly_day_of_week: Joi.string().optional().valid('day', 'weekday', 'weekend day', 'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'),
            yearly_of_every_month: Joi.string().optional().valid('january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december')
        }).required(),
        otherwise: Joi.optional()
    }),
    conf_start_time: Joi.optional(),
    conf_end_time: Joi.optional(),
    participiants: Joi.array().items(Joi.number()).optional(),
    dids: Joi.array().items(Joi.number()).optional(),
    delParticipiants: Joi.array().items(Joi.number()).optional(),
    delDids: Joi.array().items(Joi.number()).optional(),
    conf_end_date_option: Joi.number().required().valid(1, 2, 3),
    conf_end_after_occurence: Joi.number().optional(),
    conf_end_date: Joi.date().optional()
});

let schemaListConference = Joi.object().keys({
    page: Joi.number().required(),
    pageSize: Joi.number().required(),
    sorted: Joi.optional(),
    filtered: Joi.optional()
});

let schemaDetailConference = Joi.object().keys({
    id: Joi.number().required()
});

let schemaDeleteConference = Joi.object().keys({
    id: Joi.number().required()
});

// function for validate schema schemaCreateConference
const validateCreateConference = (inputCreateConference) => {
    return Joi.validate(inputCreateConference, schemaCreateConference);
}

// function for validate schema schemaUpdateConference
const validateUpdateConference = (inputUpdateConference) => {
    return Joi.validate(inputUpdateConference, schemaUpdateConference);
}

// function for validate schema schemaListConference
const validateListConference = (inputListConference) => {
    return Joi.validate(inputListConference, schemaListConference);
}

// function for validate schema schemaDetailConference
const validateDetailConference = (inputDetailConference) => {
    return Joi.validate(inputDetailConference, schemaDetailConference);
}

// function for validate schema schemaDeleteConference
const validateDeleteConference = (inputDeleteConference) => {
    return Joi.validate(inputDeleteConference, schemaDeleteConference);
}

module.exports = {
    validateCreateConference,
    validateUpdateConference,
    validateListConference,
    validateDetailConference,
    validateDeleteConference
}