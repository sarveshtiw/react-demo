import React from 'react';
import { Switch, Route } from 'react-router-dom';
import { compose, withApollo } from 'react-apollo';
import { ToastContainer } from 'react-toastify';
import TopMenu from './topMenu/TopMenu';
import DashBoard from './dashboard';
import LiveConfDashboard from './containers/Live';

class AudioConference extends React.Component {
    render() {
        return (
            <Switch>
                <Route path="/audio-conference/live/:id" component={LiveConfDashboard} />
                <Route path="/audio-conference" render={(props) => (<div className="main">
                    <ToastContainer />
                    <TopMenu {...this.props} />
                    <DashBoard {...this.props} />
                </div>)} />
            </Switch>

        );
    }
}

export default compose(withApollo)(AudioConference);