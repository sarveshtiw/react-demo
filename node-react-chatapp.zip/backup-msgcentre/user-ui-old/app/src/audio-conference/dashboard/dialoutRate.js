import React from 'react';
import { Table, Col } from 'react-bootstrap';

class DialoutRate extends React.Component {
  render() {
    return (
      <div className="ibox">
        <div className="ibox-title">
          <h5>Dialout Rate</h5>
        </div>
        <div className="ibox-content pt-0 pb-0">
          <div className="my-service clearfix">
            <Table responsive>
              <thead>
                <tr>
                  <th width="80%">Country</th>
                  <th>Sell Rate</th>
                </tr>
              </thead>
              <tbody>
                {[...Array(3)].map((x, i) =>
                  <tr key={i}>
                    <td>Armenia</td>
                    <td>0.80 $/min</td>
                  </tr>
                )}
              </tbody>
            </Table>
            <Col md={12} className="text-right pt-3 pb-3">
              <span className="text-muted">view all</span>
            </Col>
          </div>
        </div>
      </div>
    );
  }
}

export default DialoutRate;