import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';

import DashLeftMenu from '../../dashboard/components/DashLeft';
import DashRightMenu from '../../dashboard/components/DashRight';
import DashBord from './DashBoard';
import CreateNewConference from '../containers/CreateConference';
import EditConference from '../containers/EditConference';
import AudioConferenceList from '../containers/AudioConferenceList';
import CdrList from '../containers/CdrList';
import RecordingList from '../containers/RecordingList';
import AssociatedNumbers from '../containers/AssociatedNumbers';
import AddAudio from '../containers/AddAudio';
import AudioList from '../containers/AudioList';
import InCallList from '../audioManagement/inCallList';
import './styles/dashboard.scss'

class DashBoard extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            list: []
        }
    }
    createConf(name) {
        const list = this.state.list;
        list.push({ id: list.length + 100, name, hidden: true });
        this.setState({ list });
    }
    render() {
        return (
            <div className="container-flud">
                <div className="mainArea">
                    <DashLeftMenu />
                    <div className="middleArea">
                        <Switch >
                            <Route exact path="/audio-conference" component={DashBord} />
                            <Route path="/audio-conference/ac-management/create-new-conference" component={CreateNewConference} />
                            <Route path="/audio-conference/ac-management/conference-list" component={AudioConferenceList} />
                            <Route path="/audio-conference/ac-management/edit/:id" component={EditConference} />
                            <Route path="/audio-conference/ac-management/cdr-list/:id" component={CdrList} />
                            <Route path="/audio-conference/ac-management/recording-list/:id" component={RecordingList} />
                            <Route path="/audio-conference/ac-management/associated-numbers" component={AssociatedNumbers} />
                            <Route path="/audio-conference/audio-management/add-audio" component={AddAudio} />
                            <Route path="/audio-conference/audio-management/audio-list" component={AudioList} />
                            <Route path="/audio-conference/audio-management/in-call-list" component={InCallList} />
                        </Switch>
                        <div className="clearfix"></div>
                    </div>
                    <DashRightMenu />
                </div>
            </div>
        );
    }
}

export default DashBoard;
