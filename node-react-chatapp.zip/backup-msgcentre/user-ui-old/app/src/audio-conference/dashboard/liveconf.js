import React from 'react';
import { Table, Col } from 'react-bootstrap';

class LiveConf extends React.Component {
  render() {
    return (
      <div className="ibox">
        <div className="ibox-title">
          <h5>Live Conference</h5>
        </div>
        <div className="ibox-content pt-0 pb-0">
          <div className="my-service clearfix">
            <Table responsive>
              <thead>
                <tr>
                  <th>Conference Name</th>
                  <th>Time</th>
                  <th>Type</th>
                </tr>
              </thead>
              <tbody>
                {[...Array(3)].map((x, i) =>
                  <tr key={i}>
                    <td className="text-info">Sales Conf.</td>
                    <td>10:00 AM</td>
                    <td className="d-flex align-items-center justify-content-between">Reserved <i className="material-icons text-muted h6">keyboard_arrow_right</i></td>
                  </tr>
                )}
              </tbody>
            </Table>
            <Col md={12} className="text-right pt-3 pb-3">
              <span className="text-muted">view all</span>
            </Col>
          </div>
        </div>
      </div>
    );
  }
}

export default LiveConf;