import React from 'react';
import { Table, Col } from 'react-bootstrap';

class OutstandingInvoice extends React.Component {
  render() {
    return (
      <div className="ibox">
        <div className="ibox-title">
          <h5>Outstanding Invoice</h5>
        </div>
        <div className="ibox-content pt-0 pb-0">
          <div className="my-service clearfix">
            <Table responsive>
              <thead>
                <tr>
                  <th>Invoice Number</th>
                  <th>Company</th>
                  <th>Period</th>
                  <th>Invoice Amount Incl. Tax</th>
                  <th>Outstanding Amount Incl. Tax</th>
                </tr>
              </thead>
              <tbody>
                {[...Array(6)].map((x, i) =>
                  <tr key={i}>
                    <td>201700000416</td>
                    <td>Carlson Limited</td>
                    <td>Dec 2017</td>
                    <td>$880</td>
                    <td>$887</td>
                    <td className="d-flex align-items-center justify-content-between">
                      <i className="material-icons text-info h6">file_download</i>
                    </td>
                  </tr>
                )}
              </tbody>
            </Table>
            <Col md={12} className="text-right pt-3 pb-3">
              <span className="text-muted">view all</span>
            </Col>
          </div>
        </div>
      </div>
    );
  }
}

export default OutstandingInvoice;