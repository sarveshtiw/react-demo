import React from 'react';
import './styles/upcomingConferences.scss'

class UpcomingConferences extends React.Component {
  render() {
    return (
      <div className="ibox">
        <div className="ibox-title">
          <h5>Upcoming Conferences</h5>
        </div>
        <div className="ibox-content clearfix">
          <div className="my-service">
            <ul>
              {[...Array(3)].map((x, i) => [
                <li key={i + '1'}>
                  <b>Delhi Conference</b><small className="active pull-right">Active</small>
                  <p><span className="mr-5">15-02-2018</span>|<span className="ml-5">12:15 PM - 12:45 PM</span> </p>
                </li>,
                <li key={i + "2"}>
                  <b>London Conference</b><small className="pending pull-right">RECURRING</small>
                  <p><span className="mr-5">15-02-2018</span>|<span className="ml-5">12:15 PM - 12:45 PM</span> </p>
                </li>,
                <li key={i + "3"}>
                  <b>Pune Conference</b><small className="delay pull-right">RESERVED</small>
                  <p><span className="mr-5">15-02-2018</span>|<span className="ml-5">12:15 PM - 12:45 PM</span> </p>
                </li>
              ])}
            </ul>
          </div>
          <div className="text-right pt-3">
            <span className="text-muted">view all</span>
          </div>
        </div>
      </div>
    );
  }
}

export default UpcomingConferences;