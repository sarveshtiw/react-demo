import React from 'react';
import { ButtonToolbar} from 'react-bootstrap';
import BigCalendar from 'react-big-calendar';
import events from './event';
import moment from 'moment';

import './styles/fullCalendar.scss';

BigCalendar.momentLocalizer(moment);
// let allViews = Object.keys(BigCalendar.Views).map(k => BigCalendar.Views[k]);

class FullCalendar extends React.Component {
	render() {
		return (
			<div className="ibox">
				<div className="ibox-title d-flex justify-content-between">
					<h5>Calendar</h5>
					<ButtonToolbar>
						<button className="btn btn-default btn-sub pl-3 pr-3">+ Add New Conference</button>
					</ButtonToolbar>
				</div>
				<div className="ibox-content">
					<div className="toplegend2">
						<div>
							<span><b className="color1"></b></span> Reserved Conference
						</div>
						<div>
							<span><b className="color3"></b></span> Recurring Conference
						</div>
					</div>
					<div className="calenderHeight">
						<BigCalendar
							{...this.props}
							events={events}
							views={['month', 'week', 'day']}
							step={60}
							defaultDate={new Date(2017, 11, 1)}
						/>
					</div>
				</div>
			</div>
		);
	}
}

export default FullCalendar;