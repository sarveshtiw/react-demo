import React from 'react';
import { Row, Col, Grid } from 'react-bootstrap';

import FullCalendar from './fullCalendar';
import AccountManager from './accountManager';

import LiveConf from './liveconf';
import ActiveDedicatedDID from './activeDedicatedDID';
import DialoutRate from './dialoutRate';
import OutstandingInvoice from './outstandingInvoice';
import CallUsage from './callUsage';
import UpcomingConferences from './upcomingConferences';

class Dashboard extends React.Component {
  
  componentDidMount() {
    document.body.classList.toggle('audioDashboard', true)
  }
  componentWillUnmount() {
    document.body.classList.remove('audioDashboard')
  }
  render() {
    return (
      <Grid fluid className="audioDashboard">
        <Row className="d-flex flex-row">
          <Col md={12}>
            <CallUsage />
          </Col>
        </Row>
        <Row className="d-flex flex-row">
          <Col md={4}>
            <LiveConf />
          </Col>
          <Col md={4}>
            <ActiveDedicatedDID />
          </Col>
          <Col md={4}>
            <DialoutRate />
          </Col>
        </Row>
        <Row className="d-flex flex-row">
          <Col md={8}>
            <OutstandingInvoice />
          </Col>
          <Col md={4}>
            <AccountManager />
          </Col>
        </Row>
        <Row className="d-flex flex-row">
          <Col md={8}>
            <FullCalendar />
          </Col>
          <Col md={4}>
            <UpcomingConferences />
          </Col>
        </Row>
      </Grid>
    );
  }
}

export default Dashboard;