import React from 'react';
import { Table, Col } from 'react-bootstrap';

class ActiveDedicatedDID extends React.Component {
  render() {
    return (
      <div className="ibox">
        <div className="ibox-title">
          <h5>Active Dedicated DID</h5>
        </div>
        <div className="ibox-content pt-0 pb-0">
          <div className="my-service clearfix">
            <Table responsive>
              <thead>
                <tr>
                  <th width="70%">Location</th>
                  <th>Number</th>
                </tr>
              </thead>
              <tbody>
                {[...Array(3)].map((x, i) =>
                  <tr key={i}>
                    <td>India - Bangalore</td>
                    <td>+91 (0) 9811649017</td>
                  </tr>
                )}
              </tbody>
            </Table>
            <Col md={12} className="text-right pt-3 pb-3">
              <span className="text-muted">view all</span>
            </Col>
          </div>
        </div>
      </div>
    );
  }
}

export default ActiveDedicatedDID;