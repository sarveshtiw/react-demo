import React from 'react';
import { Button, Navbar, Nav, NavItem, NavDropdown, DropdownButton, FormGroup, MenuItem, FormControl, Col } from 'react-bootstrap';
import { IndexLinkContainer } from 'react-router-bootstrap';
import {
    Link
} from 'react-router-dom'
//import './topMenu.css';
import NavDrop from '../../common/components/NavDrop';

class AcTopMenu extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            popoverMenu: false,
            subNavbar: true,
            subSubNavbar: false,
            audioBar: false
        };
        this.popoverShow = this.popoverShow.bind(this);
        this.popoverHide = this.popoverHide.bind(this);
        this.subNavbar = this.subNavbar.bind(this);
        this.subSubNavbar = this.subSubNavbar.bind(this);
        this.audioNavbar = this.audioNavbar.bind(this);
    }
    popoverShow() {
        this.setState({
            popoverMenu: true
        });
    }
    popoverHide() {
        this.setState({
            popoverMenu: false
        });
    }

    subNavbar() {
        if (!this.state.subNavbar) {
            this.setState({
                subNavbar: true
            })
        } else {
            this.setState({
                subNavbar: false
            })
        }
    }

    subSubNavbar() {
        if (!this.state.subSubNavbar) {
            this.setState({
                subSubNavbar: true
            })
        } else {
            this.setState({
                subSubNavbar: false
            })
        }
    }

    audioNavbar() {
        if (!this.state.audioBar) {
            this.setState({
                audioBar: true
            })
        } else {
            this.setState({
                audioBar: false
            })
        }
    }

    render() {
        return (
            <div className="navigation">
                <Navbar collapseOnSelect className="nav-audioConf">
                    <Navbar.Collapse>
                        <Nav>
                            <Navbar.Brand>
                                <a href="/"><img src="./images/logo.png" alt="Synthesis Dashboard" /></a>
                                <a href="javascript:void('0')" onClick={this.subNavbar}><i className="icon-app"></i></a>
                            </Navbar.Brand>
                            <Navbar.Toggle />
                        </Nav>
                        <Navbar.Header>
                            <h1>Audio Conference</h1>
                        </Navbar.Header>
                        <div className="nav navbar-nav navbar-right">
                            <FormGroup controlId="formBasicText" className={!this.state.popoverMenu ? "btnGroup" : "btnGroup focus"}>
                                <form name="search-message" onSubmit={this.props.handleSearch} autoComplete="off">
                                    <FormControl type="text" name="searchInput" placeholder="Search" onBlur={this.popoverHide} value={this.state.search} onFocus={this.popoverShow}></FormControl>
                                    <span className="form-control-feedback material-icons">search</span>
                                </form>
                            </FormGroup>
                            <NavDrop />
                        </div>
                    </Navbar.Collapse>
                </Navbar>
                {this.state.subNavbar &&
                    <Navbar collapseOnSelect className="nav-audioConf bottom">
                        <Navbar.Collapse>
                            <Nav>
                                <IndexLinkContainer to="/audio-conference">
                                    <NavItem eventKey={2} href="javascript:void('0')">Dashboard</NavItem>
                                </IndexLinkContainer>
                                <IndexLinkContainer to="/audio-conference/ac-management/conference-list">
                                    <NavItem eventKey={2} href="javascript:void('0')">Conference List</NavItem>
                                </IndexLinkContainer>
                                <IndexLinkContainer to="/audio-conference/audio-management/audio-list">
                                    <NavItem eventKey={2} href="javascript:void('0')">Audio List</NavItem>
                                </IndexLinkContainer>
                                <IndexLinkContainer to="/audio-conference/ac-management/associated-numbers">
                                    <NavItem eventKey={2} href="javascript:void('0')">Associated Numbers</NavItem>
                                </IndexLinkContainer>
                            </Nav>
                        </Navbar.Collapse>
                        {this.state.subSubNavbar &&
                            <Navbar.Collapse className="thirdlevelMenu">
                                <Nav>
                                    <IndexLinkContainer to="/audio-conference/ac-management/create-new-conference">
                                        <NavItem eventKey={3}>
                                            Create New Conference
                    </NavItem>
                                    </IndexLinkContainer>
                                    <IndexLinkContainer to="/audio-conference/ac-management/conference-list">
                                        <NavItem eventKey={3}>
                                            Conference list
                    </NavItem>
                                    </IndexLinkContainer>

                                    <IndexLinkContainer to="/audio-conference/ac-management/associated-numbers">
                                        <NavItem eventKey={3}>
                                            Associated Numbers
                  </NavItem>
                                    </IndexLinkContainer>
                                    <IndexLinkContainer to="/audio-conference/ac-management/dialout-rates">
                                        <NavItem eventKey={3}>
                                            dialout rates
                  </NavItem>
                                    </IndexLinkContainer>
                                    <IndexLinkContainer to="/audio-conference/ac-management/outbound-simulator">
                                        <NavItem eventKey={3}>
                                            Outbound Simulator
                  </NavItem>
                                    </IndexLinkContainer>
                                </Nav>
                            </Navbar.Collapse>
                        }
                        {this.state.audioBar &&
                            <Navbar.Collapse className="thirdlevelMenu">
                                <Nav>
                                    <IndexLinkContainer to="/audio-conference/audio-management/add-audio">
                                        <NavItem eventKey={3}>
                                            Add New Audio
                    </NavItem>
                                    </IndexLinkContainer>
                                    <IndexLinkContainer to="/audio-conference/audio-management/welcome-list">
                                        <NavItem eventKey={3}>
                                            Welcome Audio list
                    </NavItem>
                                    </IndexLinkContainer>

                                    <IndexLinkContainer to="/audio-conference/audio-management/in-call-list">
                                        <NavItem eventKey={3}>
                                            In Call Audio List
                  </NavItem>
                                    </IndexLinkContainer>
                                </Nav>
                            </Navbar.Collapse>
                        }
                    </Navbar>
                }
            </div>
        )
    }
}

export default AcTopMenu;