export const generateNumbers = () => {
    var limit = 5,
        amount = 3,
        lower_bound = 1,
        upper_bound = 9999999,
        unique_random_numbers = [];

    if (amount > limit)
        limit = amount; //Infinite loop if you want more unique
    //Natural numbers than existemt in a given range
    while (unique_random_numbers.length < limit) {
        var random_number = Math.round(Math.random() * (upper_bound - lower_bound) + lower_bound);
        if (unique_random_numbers.indexOf(random_number) == -1) {
            // Yay! new random number
            unique_random_numbers.push(random_number);
        }
    }
    return unique_random_numbers;
};