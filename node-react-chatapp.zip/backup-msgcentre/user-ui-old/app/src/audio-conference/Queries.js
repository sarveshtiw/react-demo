import gql from 'graphql-tag';

export const CONFERENCE_LIST = gql`
query ($input: aconfListInput){
  getAudioConferences(input: $input){
    error
    result{
      id
        conf_name
        participant_limit
        conf_leaderpin
        conf_participant_pin
        id_ac_pop
        conf_date
        conf_start_time
        conf_end_time
        conf_duration
        auto_dial
        generate_new_pin
        send_invites
        record_conf
        participiant_on_mute
        participiant_on_hold
        end_conf_leader_hangs_up
        play_sound
        participiant_name_announced
        enable_touch_tone
        play_music_on_hold
        conf_recurrence_type
        hidden
        participiants
        dids
    }
    pages
  }
}
`;

export const PINS_QUERY = gql`
    query pinsquery($pins: [Int])
    {
      checkPin(pin: $pins ){
        pins
      }
    }
`;

export const CONTACT_LIST = gql`
query{
  getContacts{
    contact{
      id_contact
      uid_ua_user
      fname
      lname
      intl_code
      designation
      department
      organisation
      contactEmails{
        id_contact_email
        id_contact
        email
        primary
        status
      }
      contactNumbers{
        id_contact_phone
        id_contact
        phone
        primary
        status
      }
    }
  }
}`;

export const PARTICIPANTS_QUERY = gql`
  query usersQuery($input: [Int]) {
    getContact(id_contact: $input){
      contact{
        id_contact
        fname
        lname
      }
    }
  }     
`

export const DIDS_QUERY = gql`
    query didQuery($dids: [Int] ) {
      listDidsByDidIDS(input: { dids: $dids })
      {
        details {
          id
          did
          country_id
          carrier_name
          type_name
          country_name
          city_name
          status
          selected
        }
      }
    }
`;


export const GET_CONFERENCE_DETAILS = gql`
query($input: conferenceDetail){
  getAudioConferenceDetailById(input: $input){
    details{
    id
    conf_name
    participant_limit
    conf_leaderpin
    conf_participant_pin
    id_ac_pop
    conf_date
    auto_dial
    generate_new_pin
    send_invites
    record_conf
    participiant_on_mute
    participiant_on_hold
    end_conf_leader_hangs_up
    play_sound
    participiant_name_announced
    enable_touch_tone
    play_music_on_hold
    conf_recurrence_type    
   conf_end_date_option
    conf_end_date_option
    conf_end_after_occurence
    conf_end_date  
   weekly_recurrence_option {
        recur_every_week
        weekly_monday
        weekly_tuesday
        weekly_wednesday
        weekly_thursday
        weekly_friday
        weekly_saturday
        weekly_sunday
      }
      yearly_recurrence_option {
        recur_every_year
        yearly_option
        yearly_on_month
        yearly_on_month_day
        yearly_week
        yearly_day_of_week
        yearly_of_every_month
      }
      monthly_recurrence_option {
        monthly_option
        monthly_day
        monthly_every_month
        monthly_week
        monthly_day_of_week
        monthly_of_every_month
      }
      daily_recurrence_option {
        daily_option
        daily_day_no
      }
    }
  }
 }
`;
export const SEARCH_CONTACT = gql`
    query searchContact($input:searchContact!){
      searchContact(input:$input){
        contact{
          id_contact
          uid_ua_user
          fname
          lname
          intl_code
          designation
          department
          organisation
          contactEmails{
            id_contact_email
            id_contact
            email
            primary
            status
          }
          contactNumbers{
            id_contact_phone
            id_contact
            phone
            primary
            status
          }
        }
      }  
    }
  `
export const SEARCH_CONTACT_GROUP = gql`
query searchContactGroup($name: String){
  searchContactGroup(name:$name){
    groups{
      id_group
      group_name
      GroupMembers{
        Contact{
          id_contact
          fname
          lname
          contactEmails{
            id_contact_email
            email
          }
        }
      }
    }    
  }
}
`
export const CHECK_EMAIL_EXISTS = gql`
query isEmailExist($input:isEmailExistIn){
  isEmailExist(input:$input){
    isExist
  }
}
`
export const CHECK_PHONE_EXISTS = gql`
query isNumberExist($input:isNumberExistIn){
  isNumberExist(input:$input){
    isExist
  }
}
`
export const GROUP_LIST = gql`
query getContactGroups{
  getContactGroups{
    groups{
      id_group
      group_name
      GroupMembers{
        Contact{
          id_contact
          fname
          lname
          contactEmails{
            id_contact_email
            email
          }
        }
      }
    }
  }
}
`

export const DEDICATED_DIDS = gql`
  query ($input: getCustomerDidsIn){
    getCustomerDids(input: $input) {
      details{
        id
        did
        status
        country_name
        city_name
        type_name
      }
      pages
    }
  } 
`;

export const GLOBAL_DIDS = gql`
  query ($input: sharedDidList){
    getSharedDids(input: $input){
      result{
        id
        did
        country_name
        city_name
        toll_free
        active
      }
      pages
    }
  } 
`;

export const RECORDING_LIST = gql`
  query($input: confRecordingList, $id: Int!){
    getAudioConferenceDetailById(input:{
      id: $id
    }){
      details{
        conf_name
        conf_start_time
      }
    }
    getConferenceRecordingById(input: $input){
      result{
        id
        id_ac_conf      
       starttime
        endtime
        conf_report_sent
        recording_file_url
      }
      pages
    }
  }
`;

export const CDR_LIST = gql`
  query($input: cdrList, $id: Int!){
    getAudioConferenceDetailById(input:{
      id: $id
    }){
      details{
        conf_name
        conf_start_time
      }
    }
    getCdr(input: $input) {
      result{
        id
        fs_call_id
        callerid
        callername
        starttime
        endtime
        dialled_no
        inbound_charge
        bridge_charge
        misc_charge
        total_cost      
     }
     pages
    }
  }
`;
/* 
   profile{
			id
      id_amp_user_profile
      Profile{
        fname
        lname
        Company{
          id_company_parent
          id
        }
        Designation{
          designation_name
        }
        Country{
          country_name
        }
      }
    }
*/
export const LIVE_DATA = gql`
  query($id: Int!){
    profile{
			id
      id_amp_user_profile
      Profile{
        fname
        lname
        Company{
          id_company_parent
          id
        }
        Designation{
          designation_name
        }
        Country{
          country_name
        }
      }
    }
    getAudioConferenceDetailById(input:{
      id: $id
    }){
      details{
        conf_name
        conf_start_time
        conf_leaderpin
        conf_participant_pin
        participiants
      }
    }
    getLiveParticipantsById(input: {
      id_ac_conf: $id
    }){
      result{
        id
        fs_call_id
        callerid
        called_number
        starttime
      }
    }
  }
`;

export const GET_AUDIO_LIST = gql`
  query($input:audioMessageList){
    getAudioMessages(input:$input){
      result{
        id
        audio_file_url
        audio_description
        is_default_audio
        audio_type
      }
    pages
    }
  }
`;

export const GET_LIVE_PARTICIPANTS = gql`
  query($input:liveParticipantData){
    getLiveParticipantsById(input: $input) {
      result{
        id
        fs_call_id
        callerid
        called_number
        starttime
      }
    }
  }
`;