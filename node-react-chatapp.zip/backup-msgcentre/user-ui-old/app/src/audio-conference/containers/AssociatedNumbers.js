import React from 'react';
import { compose, withApollo } from 'react-apollo';
import { withRouter } from 'react-router-dom';

import AssociatedNumber from '../acManagement/components/associatedNumbers';
import { GLOBAL_DIDS, DEDICATED_DIDS } from '../Queries';

class AssociatedNumbers extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            dedicatedData: [],
            globalData: [],
            loading: false,
            dLoading: false,
            pages: null,
            selected: {},
            selectAll: 0,
            dateValue: null,
            pageSize: 5,
            which: "global"

        }
    }

    fetchData(values) {
        this.setState({ loading: true });
        const { page, pageSize, sorted, filtered } = values;
        this.props.client.query({
            query: GLOBAL_DIDS,
            variables: {
                input: { page, pageSize, sorted, filtered }
            }
        }).then(({ data }) => {
            console.log(data);
            this.setState({
                globalData: data.getSharedDids.result,
                pages: data.getSharedDids.pages,
                loading: false
            })
        }).catch((err) => {
            console.log(err);
            this.setState({ loading: false})
        })
    }

    fetchDedicatedData(values) {
        this.setState({ dLoading: true });
        const { page, pageSize, sorted, filtered } = values;
        this.props.client.query({
            query: DEDICATED_DIDS,
            variables: {
                input: { page, pageSize, sorted, filtered }
            }
        }).then(({ data }) => {
            console.log(data);
            this.setState({
                dedicatedData: data.getCustomerDids.details,
                pages: data.getCustomerDids.pages,
                dLoading: false
            })
        }).catch((err) => {
            this.setState({ dLoading: false})
            console.log(err);
        })
    }

    changeWhich = (type) => {
        this.setState({ which: type })
    }

    render() {

        return(<AssociatedNumber
                which={this.state.which}
                changeWhich={this.changeWhich}
                dedicatedData={this.state.dedicatedData}
                globalData={this.state.globalData}
                loading={this.state.loading}
                dLoading={this.state.dLoading}
                fetchData={this.fetchData.bind(this)}
                fetchDedicatedData={this.fetchDedicatedData.bind(this)}
                history={this.props.history}
                pages={this.state.pages}
                pageSize={this.state.pageSize}
            />)
    }
}

export default compose(
    withApollo,
    withRouter
)(AssociatedNumbers);