import React, { Component } from 'react';
import asyncLoop from 'node-async-loop';
import moment from 'moment';
import { compose, withApollo, graphql } from 'react-apollo';
import { withRouter } from 'react-router-dom';
import { EDIT_CONFERENCE, CREATE_CONTACT } from '../Mutations';
import { PINS_QUERY, CONTACT_LIST, GROUP_LIST, SEARCH_CONTACT, SEARCH_CONTACT_GROUP, CHECK_EMAIL_EXISTS, CHECK_PHONE_EXISTS, GET_CONFERENCE_DETAILS } from '../Queries';
import { toast } from 'react-toastify';
import Toaster from '../../common/containers/toaster';
import CreateNewConference from '../acManagement/components/createNewConference';
import { generateNumbers } from '../CommonUtils';
import helper from '../../video-conference/lib/common';
import { validateCreateContact } from '../../video-conference/validation/contact';
import { validateCreateConference } from '../validations/conference';
import _ from 'lodash';

let helperObj = new helper;
let userId = 6

class EditConference extends Component {

    constructor(props, context) {
        super(props);
        this.state = {
            data: {
                id: 0,
                conf_name: '',
                conf_end_time: moment(),
                conf_start_time: moment(),
                participant_limit: 10,
                record_conf: false,
                participiant_on_mute: false,
                participiant_on_hold: false,
                end_conf_leader_hangs_up: false,
                participiant_name_announced: false,
                enable_touch_tone: false,
                play_music_on_hold: false,
                play_sound: false,
                dids: [],
                id_ac_pop: 1,
                auto_dial: false,
                conf_recurrence_type: 'none',
                conf_end_date_option: 1,
                send_invites: true,
                generate_new_pin: false,
                selectedParticipant: []
            },
            timepickerDialog: false,
            endtimepickerDialog: false,
            error: {
                name: ''
            },
            date: new Date(),
            dids: [],
            openDialogStatus: {
                selectParticipant: {
                    status: false
                },
                addParticipant: {
                    status: false
                }
            },
            contactList: [],
            droppedOption: {
                dropped: []
            },
            daily_recurrence_option: {
                daily_option: 'daily',
                daily_day_no: 1
            },
            weekly_recurrence_option: {
                recur_every_week: 1,
                weekly_monday: false,
                weekly_tuesday: false,
                weekly_wednesday: false,
                weekly_thursday: false,
                weekly_friday: false,
                weekly_saturday: false,
                weekly_sunday: false
            },
            monthly_recurrence_option: {
                monthly_option: "day",
                monthly_day: 1,
                monthly_every_month: 1,
                monthly_week: "First",
                monthly_day_of_week: 0,
                monthly_of_every_month: 1
            },
            yearly_recurrence_option: {
                yearly_option: 'monthly',
                recur_every_year: 1,
                yearly_on_month: 'January',
                yearly_on_month_day: 12,
                yearly_week: 'Monday',
                yearly_day_of_week: 'First',
                yearly_of_every_month: 'January',
            },
            addParticipantForm: {
                fname: '',
                lname: '',
                email: [{ value: '', primary: true, errorMsg: '' }],
                phone: [{ value: '', primary: true, errorMsg: '' }],
                designation: '',
                department: '',
                organisation: '',
                errorMsg: '',
                intl_code: 'IND'
            },
            errorParticipant: {
                fname: '',
                lname: '',
                email: new Array(2).fill(''),
                phone: new Array(5).fill(''),
                designation: '',
                department: '',
                organisation: ''
            },
            errorMsg: "",
            groups: {
                selectedTab: "participant",
                list: []
            },
            errorConference: {}
        }
        console.log(this.props);
        this.participantFormData = Object.assign({}, this.state.addParticipantForm);
        this.errorParticipantClearData = Object.assign({}, this.state.errorParticipant);
        this.getDids = this.getDids.bind(this);
        this.getContactList = this.getContactList.bind(this)
        this.onChange = this.onChange.bind(this)
        this.onSubmit = this.onSubmit.bind(this)
        this.onSelectSubmitParticipant = this.onSelectSubmitParticipant.bind(this)
        this.onAddSubmitParticipant = this.onAddSubmitParticipant.bind(this)
        this.onChangeAddParticipant = this.onChangeAddParticipant.bind(this)
        this.onChangeAddMore = this.onChangeAddMore.bind(this)
        this.addMore = this.addMore.bind(this)
        this.removeAddMore = this.removeAddMore.bind(this)
        this.onDrop = this.onDrop.bind(this)
        this.removeContact = this.removeContact.bind(this)
        this.openDialog = this.openDialog.bind(this)
        this.addMoreValidate = this.addMoreValidate.bind(this)
    }

    componentDidMount() {
        console.log(this.props.match.params.id);
        // this.generatePins();
        // this.getContactList();
        // this.getGroups();
        // this.getDids();
        this.getData();
    }

    getData() {
        this.props.client.query({
            query: GET_CONFERENCE_DETAILS,
            variables: { input: { id: this.props.match.params.id } }
        }).then(({ data }) => {
            if (data.getAudioConferenceDetailById.details) {
                //console.log(data);
                this.setState({ data: { ...data.getAudioConferenceDetailById.details } })
            } else {
                console.log('error occured', data)
            }
        }).catch(err => {
            console.log(err);
        });
    }

    generatePin(type) {
        const numbers = generateNumbers();
        this.props.client.query({
            query: PINS_QUERY,
            variables: {
                pins: numbers
            }
        })
            .then(({ data }) => {
                console.log(data);
                if (type === 0) {
                    this.setState({ data: { ...this.state.data, conf_leaderpin: data.checkPin.pins[0] } })
                } else {
                    this.setState({ data: { ...this.state.data, conf_participant_pin: data.checkPin.pins[0] } })
                }
            });
    }

    getDids() {
        // this.props.client.query({
        //     query: LIST_DIDS
        // })
        //     .then(({ data }) => {
        //         console.log(data);
        //         this.setState({ dids: data.getDids.details });
        //     }).catch((err) => {
        //         console.log(err);
        //     })
    }

    async getGroups() {
        let response = await this.props.client.query({
            query: GROUP_LIST
        });
        if (!response.hasOwnProperty('errors')) {
            let list = await helperObj.traverseGroupData(response.data.getContactGroups.groups);

            this.setState(prevState => ({
                groups: {
                    ...prevState.groups,
                    list: list
                }
            }))
        } else {
            this.setState(prevState => ({
                groups: {
                    ...prevState.groups,
                    list: []
                }
            }))
        }
    }

    generatePins() {
        const numbers = generateNumbers();
        this.props.client.query({
            query: PINS_QUERY,
            variables: {
                pins: numbers
            }
        })
            .then(({ data }) => {
                this.setState({ data: { ...this.state.data, conf_leaderpin: data.checkPin.pins[0], conf_participant_pin: data.checkPin.pins[1] } })
            });
    }

    onChange(event) {
        let data = this.state.data;
        let errorConference = this.state.errorConference;
        let value = event.target.value;
        data[event.target.name] = value;
        this.setState({
            data
        })
        let errorData = validateCreateConference({ [event.target.name]: event.target.value });
        if (errorData.error != null) {
            let err = errorData.error.details[0];
            if (err.context['key'] === event.target.name) {
                errorConference[event.target.name] = err.message;
                this.setState({
                    errorConference
                })
            } else {
                errorConference[event.target.name] = '';
                this.setState({
                    errorConference
                })
            }
        } else {
            errorConference[event.target.name] = '';
            this.setState({
                errorConference
            })
        }
        console.log(this.state.errorConference);
    }

    setDate = (date, dateString) => {
        let data = this.state.data;
        data["conf_date"] = date;
        this.setState({
            data
        });
        console.log(this.state.data);
    }

    onSlide(value) {
        let data = this.state.data;
        data["participant_limit"] = value;
        this.setState({ data });
        console.log(this.state.data);
    }

    async getContactList() {
        this.props.client.query({
            query: CONTACT_LIST
        }).then(({ data }) => {
            console.log('data is ', data);
            this.setState({
                contactList: data.getContacts.contact
            })
        }).catch((err) => {
            console.log(err);
        })
    }

    /**
   ** onSubmit add participant form
   * @param event
   */
    async onAddSubmitParticipant(event) {
        event.preventDefault()
        let formData = this.state.addParticipantForm;
        let errorParticipant = this.state.errorParticipant;
        let obj = {
            fname: formData.fname,
            lname: formData.lname,
            email: formData.email.map((row, index) => {
                return row.value;
            }),
            phone: formData.phone.map((row, index) => {
                return row.value;
            }),
            designation: formData.designation,
            department: formData.department,
            organisation: formData.organisation
        };
        let errorData = validateCreateContact(obj);
        if (errorData.error != null) {
            let err = errorData.error.details[0];
            if (err.path[0] === Object.keys(errorParticipant).find(k => k == err.path[0])) {
                if (err.path[0] == 'email' || err.path[0] == 'phone') {
                    `"${err.context.key}"`
                    errorParticipant[err.path[0]][err.context.key] = err.message.replace(`"${err.context.key}"`, `"${err.path[0]}"`);
                } else {
                    errorParticipant[err.path[0]] = err.message;
                }
                this.setState({
                    errorParticipant
                })
            } else {
                errorParticipant[err.path[0]] = '';
                this.setState({
                    errorParticipant
                })
            }

        } else {
            let obj = {
                fname: formData.fname,
                lname: formData.lname,
                designation: formData.designation,
                department: formData.department,
                organisation: formData.organisation,
                id_service: [1],
                email_ids: formData.email,
                numbers: formData.phone,
                intl_code: "IND"
            }
            let response = await this.props.createContact({ variables: { input: obj } })
            if (response.hasOwnProperty('errors')) {
                formData.errorMsg = JSON.stringify(response.errors)
                this.setState({
                    addParticipantForm: formData
                })
            } else {
                let contactList = this.state.contactList
                contactList = contactList.concat([response.data.createContact])
                this.setState({
                    contactList: contactList
                })
                this.openDialog('addParticipant')
            }
        }
    }

    /**
  ** onChange add participant field
  * @param event
  */
    onChangeAddParticipant = (event) => {
        let addParticipantForm = this.state.addParticipantForm;
        addParticipantForm[event.target.name] = event.target.value;
        let errorParticipant = this.state.errorParticipant;
        this.setState({
            addParticipantForm
        });
        let errorData = validateCreateContact({ [event.target.name]: event.target.value });
        if (errorData.error != null) {
            let err = errorData.error.details[0];
            if (err.context['key'] === event.target.name) {
                errorParticipant[event.target.name] = err.message;
                this.setState({
                    errorParticipant
                })
            } else {
                errorParticipant[event.target.name] = '';
                this.setState({
                    errorParticipant
                })
            }

        } else {
            errorParticipant[event.target.name] = '';
            this.setState({
                errorParticipant
            })
        }
    }

    /**
     ** onChange add more field
     * @param event
     */
    onChangeAddMore(event) {
        let addParticipantForm = this.state.addParticipantForm[event.target.name].map((item, index) => {
            if (parseInt(event.target.id) !== index) return item
            return { ...item, value: event.target.value }
        })
        let updated = this.state.addParticipantForm
        updated[event.target.name] = addParticipantForm
        this.setState({ updated })
        let errorParticipant = this.state.errorParticipant;
        let errorData = validateCreateContact({ [event.target.name]: [event.target.value] });
        if (errorData.error != null) {
            let err = errorData.error.details[0];
            if (err.path[0] === event.target.name) {
                errorParticipant[event.target.name][event.target.id] = err.message.replace(`"${err.context.key}"`, `"${err.path[0]}"`);
                this.setState({
                    errorParticipant
                })
            } else {
                errorParticipant[event.target.name][event.target.id] = '';
                this.setState({
                    errorParticipant
                })
            }

        } else {
            errorParticipant[event.target.name][event.target.id] = '';
            this.setState({
                errorParticipant
            })
        }
    }
    /**
   ** add more option
   * @param key
   */
    addMore(key, max) {
        let addParticipantForm = this.state.addParticipantForm
        if (addParticipantForm[key].length < max) {
            addParticipantForm[key] = addParticipantForm[key].concat([{ value: '', primary: false, errorMsg: '' }])
            this.setState({
                addParticipantForm
            })
        } else {
            toast(<Toaster notifyType="info" msg={`only ${max - 1} alternative ${key} can be used`} />, {
                position: toast.POSITION.BOTTOM_RIGHT,
                hideProgressBar: true
            });
        }
    }
    /**
     ** remove option
     * @param key
     * @param index
     */
    removeAddMore(key, index) {
        let addParticipantForm = this.state.addParticipantForm
        addParticipantForm[key] = addParticipantForm[key].filter((s, sidx) => parseInt(index) !== sidx)
        this.setState({
            addParticipantForm
        });
    }

    onDrop(event) {
        event.contacts ? this.onDropContacts(event) : (event.groups) ? this.onDropGroups(event) : this.onDropGroupsParticipants(event);
    }


    onDropContacts = (event) => {
        let arrStr = event.contacts.split('?'),
            index = parseInt(arrStr[1]),
            stringToJson = JSON.parse(arrStr[0]),
            droppedOption = this.state.droppedOption;

        let obj = droppedOption.dropped.find(item => { return item.id_contact == stringToJson.id_contact });
        if (!obj) {
            droppedOption.dropped = droppedOption.dropped.concat([stringToJson]);
            let contactList = this.state.contactList;
            contactList = contactList.filter((s, sidx) => index !== sidx)
            this.setState({ droppedOption, contactList })
        } else {
            toast(<Toaster notifyType="info" msg="Participant is already exist" />, {
                position: toast.POSITION.BOTTOM_RIGHT,
                hideProgressBar: true
            });
        }
    }

    onDropGroups = (event) => {
        let stringToJson = JSON.parse(event.groups),
            filteredContact = stringToJson.contacts,
            droppedOption = this.state.droppedOption;
        if (droppedOption.dropped.length > 0) {
            asyncLoop(droppedOption.dropped, async (item, callback) => {
                let index = await helperObj.findObjectByKeyValue(stringToJson.contacts, 'id_contact', item.id_contact, true)
                if (index || index == 0) {
                    filteredContact.splice(index, 1);
                }
                callback();
            }, err => {
                if (filteredContact.length > 0) {
                    droppedOption.dropped = droppedOption.dropped.concat(filteredContact);
                    this.setState({ droppedOption })
                }
            })
        } else {
            droppedOption.dropped = droppedOption.dropped.concat(stringToJson.contacts);
            this.setState({ droppedOption })
        }
    }

    onDropGroupsParticipants = (event) => {
        let stringToJson = JSON.parse(event.participants),
            droppedOption = this.state.droppedOption;

        let checkDuplicate = droppedOption.dropped.find(item => { return item.id_contact == stringToJson.id_contact });
        if (checkDuplicate) {
            toast(<Toaster notifyType="info" msg="Participant is already exist" />, {
                position: toast.POSITION.BOTTOM_RIGHT,
                hideProgressBar: true
            });
            console.log("Duplicate Item")
        } else {
            droppedOption.dropped = droppedOption.dropped.concat([stringToJson]);
            this.setState({ droppedOption })
        }
    }

    removeContact(row, index) {
        if (row.hasOwnProperty('type') && row.type == 'group') {
            let droppedOption = this.state.droppedOption;
            droppedOption.dropped = droppedOption.dropped.filter((s, sidx) => parseInt(index) !== sidx)
            this.setState({ droppedOption });
        } else if (row.hasOwnProperty('type') && row.type === 'participants') {
            let droppedOption = this.state.droppedOption;
            droppedOption.dropped = droppedOption.dropped.filter((s, sidx) => parseInt(index) !== sidx)
            this.setState({ droppedOption });
        } else {
            let contactList = this.state.contactList,
                droppedOption = this.state.droppedOption;
            droppedOption.dropped = droppedOption.dropped.filter((s, sidx) => parseInt(index) !== sidx)

            let findDuplicate = contactList.find(item => { return item.id_contact == row.id_contact });
            if (!findDuplicate) {
                contactList = contactList.concat([row])
                this.setState({ droppedOption, contactList })
            } else {
                this.setState({ droppedOption })
            }

        }
    }

    /**
     ** onSubmit select participant form
     * @param event
     */
    onSelectSubmitParticipant(event) {
        event.preventDefault()
        let data = this.state.data
        data.selectedParticipant = this.state.droppedOption.dropped.map((item) =>
            ({
                id: item.id_contact,
                name: item.fname + ' ' + item.lname,
                email: item.contactEmails[0].email
            }));
        this.setState({ data })
        this.openDialog('selectParticipant')
    }


    updateContactList() {

        let selectedParticipant = this.state.data.selectedParticipant;
        let droppedOption = this.state.droppedOption;
        let contactList = this.state.contactList;
        let meargeUnique = _.uniq(droppedOption.dropped.concat(selectedParticipant), 'id_contact');

        let arrTemp = [];
        asyncLoop(meargeUnique, async (items, callback) => {
            if (items) {
                let obj = await helperObj.findObjectByKeyValue(selectedParticipant, 'id_contact', items.id_contact)
                if (!obj) {
                    arrTemp.push(items)
                }
            }
            callback()
        }, err => {

            let updatedContactList = _.uniq(contactList.concat(arrTemp), 'id_contact');
            asyncLoop(selectedParticipant, async (item, callbackInner) => {
                if (item) {
                    let key = await helperObj.findObjectByKeyValue(updatedContactList, 'id_contact', item.id_contact, true)
                    if (key || key == 0) {
                        updatedContactList.splice(key, 1)
                    }
                }
                callbackInner()
            }, error => {
                droppedOption.dropped = selectedParticipant
                this.setState({
                    contactList: updatedContactList,
                    droppedOption
                })
            })
        })
    }

    openDialog(type, cancel = false) {
        let openDialogStatus = this.state.openDialogStatus;
        if (type === 'selectParticipant' && openDialogStatus[type].status && cancel) {
            this.updateContactList();
        }
        if (type === 'addParticipant' && cancel) {
            this.setState((prevState) => ({
                addParticipantForm: {
                    ...this.participantFormData
                },
                errorParticipant: {
                    ...this.errorParticipantClearData,
                    email: new Array(2).fill(''),
                    phone: new Array(5).fill('')
                }
            }));
        }
        openDialogStatus[type].status = openDialogStatus[type].status ? false : true
        this.setState({
            openDialogStatus
        })
    }

    addMoreValidate(arrData, type) {
        return new Promise(resolve => {
            let error = false
            return asyncLoop(arrData, (item, callback) => {
                if (!item.value.trim() && item.primary) {
                    item.errorMsg = `${type} cannot be blank.`
                    error = true
                } else if (item.value.trim() && !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(item.value) && type == 'email') {
                    item.errorMsg = 'Invalid email format'
                    error = true
                } else if (item.value.trim() && type == 'phone' && !item.value.match(/^[0-9]+$/)) {
                    item.errorMsg = 'Invalid phone number'
                    error = true
                } else {
                    item.errorMsg = ''
                }
                callback()
            }, err => {
                let addParticipantForm = this.state.addParticipantForm
                addParticipantForm[type] = arrData
                this.setState({
                    addParticipantForm
                })
                return resolve({ error: error })
            })
        })
    }

    updateTimepicker(time, timeString) {
        if (time !== null) {
            console.log(time);
            this.setState((prevState) => ({
                data: {
                    ...prevState.data,
                    conf_start_time: time
                }
            }))
        }
    }

    updateEndTimepicker(time, timeString) {
        if (time !== null) {
            console.log(time);
            this.setState((prevState) => ({
                data: {
                    ...prevState.data,
                    conf_end_time: time
                }
            }));
        }
    }

    async onSubmit(event) {
        event.preventDefault();
        console.log('calling the submit');
        let dids = [];
        this.state.dids.forEach((did) => {
            if (did.selected) {
                dids.push(did.did);
            }
        });
        const input = {
            ...this.state.data,
            dids,
            conf_start_time: moment(this.state.data.conf_start_time).format('YYYY-MM-DD HH:mm:ss'),
            conf_end_time: moment(this.state.data.conf_end_time).format('YYYY-MM-DD HH:mm:ss')
        };
        console.log(input);

        // delete input["selectedParticipant"];
        delete input["__typename"];
        console.log('input type is', input.conf_recurrence_type);
        switch (input.conf_recurrence_type) {

            case 'daily':
                input['daily_recurrence_option'] = this.state.daily_recurrence_option;
                if (this.state.daily_recurrence_option.hasOwnProperty('__typename')) {
                    delete input.daily_recurrence_option['__typename']
                }
                break;
            case 'weekly':
                input['weekly_recurrence_option'] = this.state.weekly_recurrence_option;
                if (this.state.weekly_recurrence_option.hasOwnProperty('__typename')) {
                    delete input.weekly_recurrence_option['__typename']
                }
                break;
            case 'monthly':
                input['monthly_recurrence_option'] = this.state.monthly_recurrence_option;
                if (this.state.monthly_recurrence_option.hasOwnProperty('__typename')) {
                    delete input.monthly_recurrence_option['__typename']
                }
                break;
            case 'yearly':
                input['yearly_recurrence_option'] = this.state.yearly_recurrence_option;
                if (this.state.yearly_recurrence_option.hasOwnProperty('__typename')) {
                    delete input.yearly_recurrence_option['__typename']
                }
                break;
            default:
                break;
            case 'none':
                break;
        }
        this.props.createAudioConference({ variables: { input } })
            .then(({ data }) => {
                if (data.updateAudioConference.message === 'Success') {
                    toast(<Toaster notifyType="success" msg="Conference Has been updated successfully." />, {
                        position: toast.POSITION.TOP_CENTER,
                        hideProgressBar: true
                    });
                    this.props.history.push('/audio-conference/ac-management/conference-list');
                } else {
                    console.log(data);
                }
                //console.log(response);
            }).catch((err) => {
                console.log(err);
            });
    }

    onChangeCheckBox(event) {
        let data = this.state.data;
        let value = data[event.target.name] ? false : true;
        data[event.target.name] = value;
        this.setState({
            data
        });
        console.log(this.state.data);
    }

    weeklyChange(event) {
        let { weekly_recurrence_option } = this.state;
        if (event.target.type === 'number') {
            weekly_recurrence_option[event.target.name] = event.target.value;
        } else {
            weekly_recurrence_option[event.target.name] = weekly_recurrence_option[event.target.name] ? false : true;
        }
        this.setState({
            weekly_recurrence_option
        });
        console.log(this.state.weekly_recurrence_option);
    }

    monthlyChange(event) {
        let { monthly_recurrence_option } = this.state;
        monthly_recurrence_option[event.target.name] = event.target.value;
        this.setState({
            monthly_recurrence_option
        });
        console.log(this.state.monthly_recurrence_option);
    }

    yearlyChange(event) {
        let { yearly_recurrence_option } = this.state;
        yearly_recurrence_option[event.target.name] = event.target.value;
        this.setState({
            yearly_recurrence_option
        });
        console.log(this.state.yearly_recurrence_option);
    }

    onChangeDid(event) {
        let dids = this.state.dids.map((did) => {
            if (did.id === event.target.value) {
                // if(did.selected) {
                //     let data = this.state.data;   
                //     data.dids.push(did.id);
                //     this.setState({ data });
                // } else {
                //     let data = this.state.data;   
                //      data.dids[did.id];
                //     this.setState({ data });
                //     //delete this.state.data.dids[did.id];
                // }
                return ({ ...did, selected: !did.selected });
            }
            return did;
        });
        this.setState({ dids });
        console.log(this.state.data.dids);
    }

    timepickerOption(type) {
        console.log('changing the state', this.state);
        if (type === 1) {
            this.setState(prevState => {
                return {
                    timepickerDialog: !prevState.timepickerDialog
                }
            })
        } else {
            this.setState(prevState => {
                return {
                    endtimepickerDialog: !prevState.endtimepickerDialog
                }
            })
        }
    }

    changeTab(type) {
        this.setState((prevState) => {
            let prevRec = prevState.data.conf_recurrence_type;
            let newStateData = {
                ...prevState.data,
                conf_recurrence_type: type
            };
            switch (prevRec) {
                case 'daily':
                    delete newStateData['daily_recurrence_option'];
                    break;
                case 'weekly':
                    delete newStateData['weekly_recurrence_option'];
                    break;
                case 'monthly':
                    delete newStateData['monthly_recurrence_option'];
                    break;
                case 'yearly':
                    delete newStateData['yearly_recurrence_option'];
                    break;
                default: 
                    break;
            }
            delete newStateData[prevRec];
            return ({
                data: newStateData
            });
        })
    }

    changeRadioButton(e) {
        let data = this.state.data;
        data[e.target.name] = e.target.value;
        this.setState({
            data
        })
        console.log(this.state.data);
    }

    selectMonthlyWeek(option) {
        console.log(option);
        this.setState((prevState) => ({
            monthly_recurrence_option: {
                ...prevState.monthly_recurrence_option,
                monthly_day_of_week: option.value
            }
        }))
    }

    selectMonthlyDay(option) {
        console.log(option);
        this.setState((prevState) => ({
            monthly_recurrence_option: {
                ...prevState.monthly_recurrence_option,
                monthly_week: option.value
            }
        }))
    }

    selectYearlyMonth(option) {
        console.log(option);
        this.setState((prevState) => ({
            yearly_recurrence_option: {
                ...prevState.yearly_recurrence_option,
                yearly_on_month: option.value
            }
        }))
    }

    changeYearlyWeek(option) {
        console.log(option);
        this.setState((prevState) => ({
            yearly_recurrence_option: {
                ...prevState.yearly_recurrence_option,
                yearly_week: option.value
            }
        }))
    }

    changeYearlyDay(option) {
        console.log(option);
        this.setState((prevState) => ({
            yearly_recurrence_option: {
                ...prevState.yearly_recurrence_option,
                yearly_day_of_week: option.value
            }
        }))
    }
    changeYearlyMonth(option) {
        console.log(option);
        this.setState((prevState) => ({
            yearly_recurrence_option: {
                ...prevState.yearly_recurrence_option,
                yearly_of_every_month: option.value
            }
        }))
    }
    changeDaily(event) {
        let { daily_recurrence_option } = this.state;
        daily_recurrence_option[event.target.name] = event.target.value;
        this.setState({
            daily_recurrence_option
        });
        console.log(this.state.daily_recurrence_option);
    }
    tabOption(type) {
        this.setState(prevState => ({
            groups: {
                ...prevState.groups,
                selectedTab: type
            }
        }))
    }
    participantExpands(id, event) {
        let circleType = event.target.id === 'add_circle' ? 'remove_circle' : 'add_circle';
        document.getElementById(`group_participant_${id}`).style.display = circleType == 'remove_circle' ? 'block' : 'none';
        event.target.innerHTML = circleType;
        event.target.id = circleType;
    }

    // Search on Select page
    // Search on Select page
    async searchContact(e) {
        e.preventDefault()
        //if (e.target.value.trim().length > 3 || e.target.value.trim() == 0) {
        if (this.state.groups.selectedTab == 'participant') {
            let response = await this.props.client.query({
                query: SEARCH_CONTACT,
                variables: { input: { keyword: e.target.value } }
            });
            this.setState({
                contactList: response.data.hasOwnProperty('searchContact') ? response.data.searchContact.contact : []
            })
        } else {
            let response = await this.props.client.query({
                query: SEARCH_CONTACT_GROUP,
                variables: { name: e.target.value }
            });
            let list = [];
            if (response.data.hasOwnProperty('searchContactGroup')) {
                list = await helperObj.traverseGroupData(response.data.searchContactGroup.groups);
            }
            this.setState(prevState => ({
                groups: {
                    ...prevState.groups,
                    list: list
                }
            }))
        }

        //}
    }


    checkExistEmail = async (event, rowData) => {
        event.preventDefault();
        let errorParticipant = this.state.errorParticipant;
        let name = event.target.name, id = event.target.id;
        try {
            let response = await this.props.client.query({
                query: CHECK_EMAIL_EXISTS,
                variables: { input: { email: rowData.value } }
            });
            errorParticipant[name][id] = response.data.isEmailExist.isExist == 1 ? 'email is already exists' : '';
            this.setState({
                errorParticipant
            })
        } catch (ex) {
            errorParticipant[name][id] = ex.graphQLErrors[0].message;
            this.setState({
                errorParticipant
            })
        }
    }

    checkExistPhone = async (event, rowData) => {
        event.preventDefault();
        let errorParticipant = this.state.errorParticipant;
        let name = event.target.name, id = event.target.id;
        let errorData = validateCreateContact({ [event.target.name]: [event.target.value] });
        try {
            if (errorData.error != null) {
                let err = errorData.error.details[0];
                if (err.path[0] === event.target.name) {
                    errorParticipant[name][id] = err.message.replace(`"${err.context.key}"`, `"${err.path[0]}"`);
                    this.setState({
                        errorParticipant
                    })
                } else {
                    errorParticipant[name][id] = '';
                    this.setState({
                        errorParticipant
                    })
                }

            } else {
                errorParticipant[name][id] = '';
                this.setState({
                    errorParticipant
                })
                let response = await this.props.client.query({
                    query: CHECK_PHONE_EXISTS,
                    variables: { input: { number: rowData.value } }
                });
                errorParticipant[name][id] = response.data.isNumberExist.isExist === 1 ? 'phone number is already exists' : '';
                this.setState({
                    errorParticipant
                })
            }

        } catch (ex) {
            errorParticipant[name][id] = ex.graphQLErrors[0].message;
            this.setState({
                errorParticipant
            })
        }
    }

    render() {

        return (<CreateNewConference
            errorConference={this.state.errorConference}
            data={this.state.data}
            date={this.state.date}
            onChange={this.onChange}
            onChangeCheckBox={this.onChangeCheckBox.bind(this)}
            onDidChange={this.onChangeDid.bind(this)}
            generatePin={this.generatePin.bind(this)}
            onSlide={this.onSlide.bind(this)}
            onSubmit={this.onSubmit}
            error={this.state.error}
            openDialog={this.openDialog}
            dialogStatus={this.state.openDialogStatus}
            dids={this.state.dids}
            contactList={this.state.contactList}
            onSelectSubmitParticipant={this.onSelectSubmitParticipant}
            onAddSubmitParticipant={this.onAddSubmitParticipant}
            onChangeAddParticipant={this.onChangeAddParticipant}
            onChangeAddMore={this.onChangeAddMore}
            addParticipantForm={this.state.addParticipantForm}
            errorParticipant={this.state.errorParticipant}
            addMore={this.addMore}
            removeAddMore={this.removeAddMore}
            onDrop={this.onDrop}
            droppedOption={this.state.droppedOption}
            removeContact={this.removeContact}
            errorMsg={this.state.errorMsg}
            setDate={this.setDate}
            updateTimepicker={this.updateTimepicker.bind(this)}
            timepickerOption={this.timepickerOption.bind(this)}
            timepickerDialog={this.state.timepickerDialog}
            endtimepickerDialog={this.state.endtimepickerDialog}
            updateEndTimepicker={this.updateEndTimepicker.bind(this)}
            changeTab={this.changeTab.bind(this)}
            changeRadioButton={this.changeRadioButton.bind(this)}
            weeklyChange={this.weeklyChange.bind(this)}
            weekOptions={this.state.weekly_recurrence_option}
            monthOptions={this.state.monthly_recurrence_option}
            monthlyChange={this.monthlyChange.bind(this)}
            selectMonthlyWeek={this.selectMonthlyWeek.bind(this)}
            selectMonthlyDay={this.selectMonthlyDay.bind(this)}
            selectYearlyMonth={this.selectYearlyMonth.bind(this)}
            yearlyChange={this.yearlyChange.bind(this)}
            yearlyOptions={this.state.yearly_recurrence_option}
            changeYearlyWeek={this.changeYearlyWeek.bind(this)}
            changeYearlyDay={this.changeYearlyDay.bind(this)}
            changeYearlyMonth={this.changeYearlyMonth.bind(this)}
            changeDaily={this.changeDaily.bind(this)}
            dailyOptions={this.state.daily_recurrence_option}
            tabOption={this.tabOption.bind(this)}
            groups={this.state.groups}
            participantExpands={this.participantExpands.bind(this)}
            searchContact={this.searchContact.bind(this)}
            checkExistEmail={this.checkExistEmail}
            checkExistPhone={this.checkExistPhone}
        />
        );
    }
}

export default compose(
    withApollo,
    withRouter,
    graphql(EDIT_CONFERENCE, {
        name: 'createAudioConference'
    }),
    graphql(CREATE_CONTACT, {
        name: 'createContact'
    })
)(EditConference);