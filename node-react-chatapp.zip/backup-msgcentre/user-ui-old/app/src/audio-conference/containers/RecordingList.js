import React from 'react';
import { compose, withApollo } from 'react-apollo';
import { withRouter } from 'react-router-dom';

import RecordingList from '../acManagement/components/recordingList';
import { RECORDING_LIST } from '../Queries';

class RecordingsList extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            conferenceDetails: {
                name: '',
                conf_start_time: null
            },
            data: [],
            loading: false,
            pages: null,
            selected: {},
            selectAll: 0,
            dateValue: null,
            pageSize: 5
        }
    }

    componentDidMount() {
        console.log('accesing the data');
        this.fetchData({ page: 0, pageSize: 10, sorted: [], filtered: [] });
    }

    fetchData(values) {
        this.setState({ loading: true });
        const { page, pageSize, sorted, filtered } = values;
        this.props.client.query({
            query: RECORDING_LIST,
            variables: {
                id: this.props.match.params.id,
                input: { page, pageSize, sorted, filtered, id_ac_conf: this.props.match.params.id  }
            }
        }).then(({ data }) => {
            console.log(data);
            this.setState({
                conferenceDetails: {
                    name: data.getAudioConferenceDetailById.details.conf_name,
                    conf_start_time: data.getAudioConferenceDetailById.details.conf_start_time
                },
                data: data.getConferenceRecordingById.result,
                pages: data.getConferenceRecordingById.pages,
                loading: false
            })
        }).catch((err) => {
            console.log(err);
        })

    }

    render() {
        return(<RecordingList
                {...this.state}
                loading={this.state.loading}
                fetchData={this.fetchData.bind(this)}
                history={this.props.history}
                pages={this.state.pages}
                pageSize={this.state.pageSize}
            />)
    }
}

export default compose(
    withApollo,
    withRouter
)(RecordingsList);