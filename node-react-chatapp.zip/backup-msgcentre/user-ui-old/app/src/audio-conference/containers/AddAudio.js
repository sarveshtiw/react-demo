import React, { Component } from 'react';
import { compose, withApollo, graphql } from 'react-apollo';
import { withRouter } from 'react-router-dom';
import AddNewAudio from '../audioManagement/addAudio';

import { ADD_AUDIO } from '../Mutations';

class AddAudio extends Component {

    addAudio(input) {
        this.props.addAudio({ variables: { input } })
    }

    render() {
        return(
            <AddNewAudio 
                addAudio={this.addAudio.bind(this)}
            />
        );
    }
};

export default compose(
    withApollo,
    withRouter,
    graphql(ADD_AUDIO, {
        name: 'addAudio'
    })
)(AddAudio);
