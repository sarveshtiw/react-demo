import React, { Component } from 'react';
import { compose, withApollo, graphql } from 'react-apollo';
import { withRouter } from 'react-router-dom';
import ConferenceList from '../acManagement/components/conferenceList';

import { CONFERENCE_LIST, DIDS_QUERY, PARTICIPANTS_QUERY } from '../Queries';
import { DELETE_CONFERENCE } from '../Mutations';

class AudioConferenceList extends Component {

    constructor(props) {
        super(props);
        this.state = {
            data: [],
            participiants: [],
            dids: [],
            loading: false,
            loadingView: false,
            pages: null,
            selected: {},
            selectAll: 0,
            dateValue: null,
            pageSize: 10
        }
    }

    componentWillMount() {
        this.fetchData({ page: 0, pageSize: 10, sorted: [], filtered: [] });
    }

    fetchData(state) {
        this.setState({ loading: true });
        const { page, pageSize, sorted, filtered } = state;
        this.props.client.query({
            query: CONFERENCE_LIST,
            variables: {
                input: { page, pageSize, sorted, filtered }
            }
        }).then(({ data }) => {
            this.setState({
                data: data.getAudioConferences.result,
                pages: data.getAudioConferences.pages,
                loading: false
            })
        });
    }

    fetchViewConfData(input, dids) {
        this.setState({ loadingView: true, participiants: [] });
        console.log(input);
        if (input.length > 0) {
            this.props.client.query({
                query: PARTICIPANTS_QUERY,
                variables: { input }
            }).then(({ data }) => {
                console.log(data);
                this.setState({
                    participiants: data.getContact.contact,
                    loadingView: false
                })
            });
        }
        if (dids.length > 0) {
            this.props.client.query({
                query: DIDS_QUERY,
                variables: { dids }
            }).then(({ data }) => {
                console.log(data);
                this.setState({
                    dids: data.listDidsByDidIDS.details,
                    loadingView: false
                })
            });
        }
    }

    showHide(item) {
        let updatedList = this.state.data.map((obj) => {
            console.log('checking');
            if (obj.id === item.id) {
                console.log('matchedid', obj.id, item.id);
                return { ...obj, hidden: !item.hidden };
            }
            return obj;
        });
        this.setState({
            data: updatedList,
        });
    }

    deleteConf(id) {
        let updatedList = this.state.data.filter((obj) => {
            if (obj.id === id) {
                return false;
            }
            return true;
        });
        this.setState({
            data: updatedList,
        });
        this.props.deleteConf({ variables: { input: { id } } });
    }

    toggleRow(id) {
        const newSelected = Object.assign({}, this.state.selected);
        newSelected[id] = !this.state.selected[id];
        this.setState({
            selected: newSelected,
            selectAll: 2
        });
    }

    toggleSelectAll() {
        let newSelected = {};
        if (this.state.selectAll === 0) {
            this.state.data.forEach(x => {
                newSelected[x.id] = true;
            });
        }

        this.setState({
            selected: newSelected,
            selectAll: this.state.selectAll === 0 ? 1 : 0
        });
    }

    render() {
        return (
            <ConferenceList
                list={this.state.data}
                data={this.state.data}
                participiants={this.state.participiants}
                dids={this.state.dids}
                fetchData={this.fetchData.bind(this)}
                showHide={this.showHide.bind(this)}
                deleteConf={this.deleteConf.bind(this)}
                loading={this.state.loading}
                fetch={this.fetchViewConfData.bind(this)}
                selected={this.state.selected}
                selectAll={this.state.selectAll}
                toggleRow={this.toggleRow.bind(this)}
                toggleSelectAll={this.toggleSelectAll.bind(this)}
                history={this.props.history}
                pages={this.state.pages}
                pageSize={this.state.pageSize}
            />
        );
    }
};

export default compose(
    withApollo,
    withRouter,
    graphql(DELETE_CONFERENCE, {
        name: 'deleteConf'
    })
)(AudioConferenceList);