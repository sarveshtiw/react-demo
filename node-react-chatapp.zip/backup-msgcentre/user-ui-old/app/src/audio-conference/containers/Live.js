import React from 'react';
import { compose, withApollo } from 'react-apollo';
import { withRouter } from 'react-router-dom';
import asyncLoop from 'node-async-loop'
import { toast } from 'react-toastify';
import Toaster from '../../common/containers/toaster';

import LIve from '../live';
import { LIVE_DATA, GET_LIVE_PARTICIPANTS } from '../Queries';
import {
    CONTACT_LIST_BY_CONF,
    VALIDATE_USER,
    CONTACT_LIST,
    SEARCH_CONTACT,
    GROUP_LIST,
    SEARCH_CONTACT_GROUP,

} from '../../video-conference/constants/query';
import {
    CREATE_CONTACT,
    SEND_EMAIL_TO_PARTICIPANT,
    PARTICIPANT_ADDTO_CONFERENCE
} from '../../video-conference/constants/mutation';

let socket = new WebSocket('wss://192.168.100.207:8111/');

class LIVE extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            tabOption: 'groups',
            conferenceDetails: {
                conf_name: "",
                conf_start_time: null,
                conf_leaderpin: null,
                conf_participant_pin: null,
                participiants: []
            },
            profile: {
                id: null,
                id_amp_user_profile: null,
                Profile: {
                    fname: "",
                    lname: "",
                    Designation: {
                        designation_name: ""
                    },
                    Country: {
                        country_name: ""
                    }
                }
            },
            data: [],
            loading: false,
            pages: null,
            selected: {},
            selectAll: 0,
            dateValue: null,
            pageSize: 10,
            participantInfo: {},
            contactList: [],
            groupList: [],
            dialogStatus: false,
            groupDetail: false,
            groupDetailShow: ''
        }
    }

    componentDidMount() {
        console.log(this.props.match.params.id);
        //this.fetchNewMember();
        this.fetchData({ page: 0, pageSize: 10, sorted: [], filtered: [] });
        this.getContactList();
        this.getGroupList();
        //this.connectWebsocket()
        socket.onopen = (conncetion) => {
            console.log('connected to teh scoket', conncetion)
            socket.send(unescape(encodeURIComponent(`{"acid":${this.props.match.params.id}}`)));
        };
        socket.onmessage = ({ data }) => {
            console.log(data)
            let myData = JSON.parse(data);
            console.log(myData.Action)
            switch (myData.Action) {

                case 'add-member':
                    console.log('switchadd');
                    this.fetchNewMember();
                    toast(<Toaster notifyType="success" msg="A New Member Joined the confernece." />, {
                        position: toast.POSITION.BOTTOM_RIGHT,
                        hideProgressBar: true
                    });
                    break;
                case 'del-member':
                    this.fetchNewMember();
                    toast(<Toaster notifyType="error" msg={`${myData["Caller-Username"]} has left the confernece.`} />, {
                        position: toast.POSITION.BOTTOM_RIGHT,
                        hideProgressBar: true
                    });
                    break;

                default:
                    break;
            }
        };
    }

    // connectWebsocket() {
    //     client.connect('ws://192.168.100.207:8111/', null, null, null, null);
    //     client.on('connect', function (connection) {
    //         connection.sendUTF(`{"acid":${this.props.match.params.id}}`);
    //         console.log('WebSocket Client Connected');
    //         connection.on("message", function (message) {
    //             if (message.type === 'utf8') {
    //                 let data = JSON.parse(message.utf8Data);
    //                 switch (data.Action) {
    //                     case 'add-member':
    //                         this.fetchNewMember();
    //                         break;
    //                     case 'del-member':
    //                         this.fetchNewMember();
    //                         break;
    //                     default:
    //                         break;
    //                 }
    //             }
    //         })
    //     });
    // }

    fetchNewMember = () => {
        console.log('fetching members');
        this.props.client.query({
            query: GET_LIVE_PARTICIPANTS,
            variables: { input: { id_ac_conf: this.props.match.params.id } }
        }).then(({ data }) => {
            this.setState({
                data: data.getLiveParticipantsById.result,
                pages: data.getLiveParticipantsById.pages,
                loading: false
            })
        })
    }

    changeTab = (type) => {
        this.setState({
            tabOption: type
        })
    }

    fetchData = (values) => {
        this.setState({ loading: true });
        //const { page, pageSize, sorted, filtered } = values;
        this.props.client.query({
            query: LIVE_DATA,
            variables: {
                id: this.props.match.params.id,
                //  input: { page, pageSize, sorted, filtered, id_ac_conf: this.props.match.params.id }
            }
        }).then(({ data }) => {
            console.log(data);
            this.setState({
                conferenceDetails: { ...data.getAudioConferenceDetailById.details },
                profile: { ...data.profile },
                data: data.getLiveParticipantsById.result,
                pages: data.getLiveParticipantsById.pages,
                loading: false
            })
        }).catch((err) => {
            console.log(err);
        })

    }


    // function to get all contact list
    getContactList = async () => {
        let response = await this.props.client.query({
            query: CONTACT_LIST
        });
        this.setState({
            contactList: (response.hasOwnProperty('errors') && response.errors.length > 0) ? [] : response.data.getContacts.contact
        })
    }

    getGroupList = async () => {
        let response = await this.props.client.query({
            query: GROUP_LIST
        });
        this.setState({
            groupList: response.data.getContactGroups.groups
        })
    }

    searchContact = async (e) => {
        e.preventDefault()
        if (e.target.value.trim().length > 3 || e.target.value.trim() == 0) {
            let response = await this.props.client.query({
                query: SEARCH_CONTACT,
                variables: { input: { keyword: e.target.value } }
            });
            this.setState({
                contactList: response.data.hasOwnProperty('searchContact') ? response.data.searchContact.contact : []
            })
        }
    }

    searchGroup = async (e) => {
        e.preventDefault();
        if (e.target.value.trim().length > 3 || e.target.value.trim() == 0) {
            let response = await this.props.client.query({
                query: SEARCH_CONTACT_GROUP,
                variables: { name: e.target.value }
            });
            this.setState({
                groupList: response.data.hasOwnProperty('searchContactGroup') ? response.data.searchContactGroup.groups : []
            })
        }
    }

    groupDetail = (item) => {
        console.log(item)
        this.setState({
            groupDetail: !this.state.groupDetail,
            groupDetailShow: item
        })
    }
    /********************/
    openDialog = () => {
        this.setState(prevState => ({
            dialogStatus: prevState.dialogStatus ? false : true
        }));
    }
    updateParticipantList = (detail) => {
        this.addParticipantToLiveConference(detail)
        let contactList = this.state.contactList;
        contactList = contactList.concat([detail])
        this.setState({ contactList })
    }

    sendInvitation = async (id, name, email) => {
        let obj = {
            id: id,
            confId: this.state.confDetail.id,
            name: name,
            email: email
        }
        let response = await this.props.inviteParticipant({ variables: { input: obj } })
        if (!response.data.inviteParticipantVideoConference.error) {
            toast(<Toaster notifyType="success" msg={response.data.inviteParticipantVideoConference.success} />, {
                position: toast.POSITION.BOTTOM_RIGHT,
                hideProgressBar: true
            });
        } else {
            toast(<Toaster notifyType="error" msg={response.data.inviteParticipantVideoConference.error} />, {
                position: toast.POSITION.BOTTOM_RIGHT,
                hideProgressBar: true
            });
        }
    }

    async addGroupParticipantToConference(event, row) {
        console.log("dfsdfds")
        let obj = {
            id: row.id_contact,
            confId: this.state.confDetail.id,
            name: row.name,
            email: row.email
        }
        let personId = document.getElementById(row.id + '-' + row.id_contact + '-person');
        let loaderId = document.getElementById(row.id + '-' + row.id_contact + '-loader');
        personId.style.display = 'none';
        loaderId.style.display = 'inline-block';
        let response = await this.props.participantAddToConference({ variables: { input: obj } });
        personId.style.display = 'inline-block';
        loaderId.style.display = 'none';
        if (!response.data.addParticipantToVideoConference.error) {
            let participantList = this.state.participantList
            participantList = participantList.concat([row])
            this.setState({
                participantList
            })
            toast(<Toaster notifyType="success" msg={response.data.addParticipantToVideoConference.success} />, {
                position: toast.POSITION.BOTTOM_RIGHT,
                hideProgressBar: true
            });
        } else {
            toast(<Toaster notifyType="error" msg={response.data.addParticipantToVideoConference.error} />, {
                position: toast.POSITION.BOTTOM_RIGHT,
                hideProgressBar: true
            });
        }
    }

    async addParticipantToLiveConference(row) {
        let obj = {
            id: row.id_contact,
            confId: this.state.confDetail.id,
            name: row.fname + ' ' + row.lname,
            email: row.contactEmails[0].email
        }
        let response = await this.props.participantAddToConference({ variables: { input: obj } });
        if (!response.data.addParticipantToVideoConference.error) {
            let participantList = this.state.participantList
            participantList = participantList.concat([row])
            this.setState({
                participantList
            })
            toast(<Toaster notifyType="success" msg={response.data.addParticipantToVideoConference.success} />, {
                position: toast.POSITION.BOTTOM_RIGHT,
                hideProgressBar: true
            });
        } else {
            toast(<Toaster notifyType="error" msg={response.data.addParticipantToVideoConference.error} />, {
                position: toast.POSITION.BOTTOM_RIGHT,
                hideProgressBar: true
            });
        }
    }

    async addParticipantToConference(row) {
        let obj = {
            id: row.id_contact,
            confId: this.state.confDetail.id,
            name: row.fname + ' ' + row.lname,
            email: row.contactEmails[0].email
        }
        let personId = document.getElementById(row.id_contact + '-person');
        let loaderId = document.getElementById(row.id_contact + '-loader');
        personId.style.display = 'none';
        loaderId.style.display = 'inline-block';
        let response = await this.props.participantAddToConference({ variables: { input: obj } });
        personId.style.display = 'inline-block';
        loaderId.style.display = 'none';
        if (!response.data.addParticipantToVideoConference.error) {
            let participantList = this.state.participantList
            participantList = participantList.concat([row])
            this.setState({
                participantList
            })
            toast(<Toaster notifyType="success" msg={response.data.addParticipantToVideoConference.success} />, {
                position: toast.POSITION.BOTTOM_RIGHT,
                hideProgressBar: true
            });
        } else {
            toast(<Toaster notifyType="error" msg={response.data.addParticipantToVideoConference.error} />, {
                position: toast.POSITION.BOTTOM_RIGHT,
                hideProgressBar: true
            });
        }
    }

    contactListTravers(arrData) {
        let result = [];
        return new Promise(resolve => {
            return asyncLoop(arrData, (item, callback) => {
                if (item) {
                    result.push(parseInt(item.cms_contact_id));
                    callback();
                } else {
                    callback();
                }
            }, err => {
                return resolve(result);
            });
        })
    }

    render() {
        return (<LIve
            {...this.state}
            changeTab={this.changeTab}
            tabOption={this.state.tabOption}
            conferenceDetails={this.state.conferenceDetails}
            profile={this.state.profile.Profile}
            loading={this.state.loading}
            fetchData={this.fetchData.bind(this)}
            history={this.props.history}
            pages={this.state.pages}
            pageSize={this.state.pageSize}
            searchContact={this.searchContact}
            openDialog={this.openDialog}
            sendInvitation={this.sendInvitation}
            addParticipantToConference={this.addParticipantToConference}
            updateParticipantList={this.updateParticipantList}
            groupDetail={this.groupDetail}
            addGroupParticipantToConference={this.addGroupParticipantToConference}
            searchGroup={this.searchGroup}
        />)
    }
}

export default compose(
    withApollo,
    withRouter
)(LIVE);