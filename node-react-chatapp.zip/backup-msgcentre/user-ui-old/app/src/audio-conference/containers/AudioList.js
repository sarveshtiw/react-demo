import React from 'react';
import { compose, withApollo } from 'react-apollo';
import { withRouter } from 'react-router-dom';

import AdioList from '../audioManagement/welcomeList';
import { GET_AUDIO_LIST } from '../Queries';

class AudioList extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            data: [],
            loading: false,
            pages: null,
            selected: {},
            selectAll: 0,
            dateValue: null,
            pageSize: 5,
            which: 1
        }
    }

    componentDidMount() {
        console.log('accesing the data');
        this.fetchData({ page: 0, pageSize: 10, sorted: [], filtered: [{ id: 'audio_type', value: 1 }] });
    }

    fetchData(values) {
        this.setState({ loading: true });
        const { page, pageSize, sorted, filtered } = values;
        filtered.push({ id: 'audio_type', value: this.state.which });
        this.props.client.query({
            query: GET_AUDIO_LIST,
            variables: {
                input: { page, pageSize, sorted, filtered  }
            },
            fetchPolicy: 'network-only'
        }).then(({ data }) => {
            console.log(data);
            this.setState({
                data: data.getAudioMessages.result,
                pages: data.getAudioMessages.pages,
                loading: false
            })
        }).catch((err) => {
            console.log(err);
        })

    }

    changeWhich = (which) => {
        this.setState({ which, data: [] });
        this.fetchData({ page: 0, pageSize: this.state.pageSize, sorted: [], filtered: [{ id: 'audio_type', value: this.state.which }]});
    }

    render() {
        return(<AdioList
                {...this.state}
                loading={this.state.loading}
                fetchData={this.fetchData.bind(this)}
                history={this.props.history}
                pages={this.state.pages}
                pageSize={this.state.pageSize}
                changeWhich={this.changeWhich}
            />)
    }
}

export default compose(
    withApollo,
    withRouter
)(AudioList);