import gql from 'graphql-tag';

export const CREATE_CONFERENCE = gql`
  mutation createAudioConference($input: createAudioConference) {
       createAudioConference(input: $input) {
          message
       }
   }
`;


export const EDIT_CONFERENCE = gql`
  mutation updateAudioConference($input: updateAudioConference) {
    updateAudioConference(input: $input) {
          message
       }
   }
`;

export const DELETE_CONFERENCE = gql`
  mutation deleteAudioConf($input: deleteAudioConference ){
    deleteAudioConference(input: $input){
      message
    }
  }
`;

export const CREATE_CONTACT = gql`
   mutation createContact($input: createContact!) {
       createContact(input:$input) {
              id_contact
              uid_ua_user
              fname
              lname
              designation
              department
              organisation
              contactEmails{
                email
              }
           }
   }
`;



export const ADD_AUDIO = gql`
  mutation($input: inputAddAudioMessage){
    addAudioMessage(input: $input) {
      message
    }
  }
`;