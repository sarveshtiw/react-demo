import React from 'react';
import { Row, Col, OverlayTrigger, Tooltip, ButtonGroup, Button, MenuItem, ButtonToolbar, DropdownButton } from 'react-bootstrap';
import { Link } from 'react-router-dom';
// Other file call
import moment from 'moment';
import './styles/welcomeList.scss';
import ReactTable from "react-table";
import Pagination from '../../common/components/Pagination';

var createReactClass = require('create-react-class');

const LinkWithTooltip = createReactClass({
  render() {
    let tooltip = <Tooltip id={this.props.id}>{this.props.tooltip}</Tooltip>;
    return (
      <OverlayTrigger
        overlay={tooltip}
        placement="top"
        delayShow={300}
        delayHide={150}
      >
        <a href={this.props.href}>{this.props.children}</a>
      </OverlayTrigger>
    );
  }
});
const list = [
  {
    id: 1,
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '04:30 PM',
    Duration: '01h 25m 06s',
    duration: '01:25:06',
    Dialledno: '202-555-0101',
    audio: 'a.mp3'
  },
  {
    id: 2,
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '04:30 PM',
    Duration: '01h 25m 06s',
    duration: '15:20',
    Dialledno: '202-555-0101',
    audio: 'b.mp3'
  },
  {
    id: 3,
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '04:30 PM',
    Duration: '01h 25m 06s',
    duration: '10:55',
    Dialledno: '202-555-0101',
    audio: 'c.mp3'
  },
  {
    id: 4,
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '04:30 PM',
    Duration: '01h 25m 06s',
    duration: '05:10',
    Dialledno: '202-555-0101',
    audio: 'a.mp3'
  },
  {
    id: 5,
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '04:30 PM',
    Duration: '01h 25m 06s',
    duration: '45:20',
    Dialledno: '202-555-0101',
    audio: 'b.mp3'
  },
  {
    id: 6,
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '04:30 PM',
    Duration: '01h 25m 06s',
    duration: '25:06',
    Dialledno: '202-555-0101',
    audio: 'c.mp3'
  },
];

class AudioList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      list: list,
      audioPlay: false,
      audioPause: false,
      audioDownload: false,
      audioDelete: false
    };
    this.handleClick = this.handleClick.bind(this);
    this.audioPlay = this.audioPlay.bind(this);
    this.audioPause = this.audioPause.bind(this);
    this.audioDownload = this.audioDownload.bind(this);
    this.audioDelete = this.audioDelete.bind(this);
  }

  handleClick(item) {
    let updatedList = this.state.list.map(obj => {
      if (obj.id === item.id) {
        return Object.assign({}, obj, {
          hidden: !item.hidden
        });
      }
      return obj;
    });
    this.setState({
      list: updatedList,
    });
  }
  audioPlay(e) {
    this.setState(
      function (prevState) {
        var audioElement = document.getElementById('beep-' + 1);
        audioElement.setAttribute("preload", "auto");
        audioElement.autobuffer = true;
        audioElement.load();
        audioElement.play();
        return {
          audioPlay: true
        };
      });
  }

  audioPause(e) {
    if (this.state.audioPlay) {
      this.setState({
        audioPlay: false,
      }, function () {
        var audioElement = document.getElementById('beep-' + 1);
        audioElement.pause();
      });
    }
  }

  audioDownload(e) {
    if (this.state.audioDownload) {
      this.setState({
        audioDownload: false,
      }, function () {
        var audioElement = document.getElementById('beep');
        audioElement.download();
      });
    }
  }
  audioDelete(e) {
    alert('Delete');
    if (this.state.audioDelete) {
      this.setState({
        audioDelete: false,
      }, function () {
        var audioElement = document.getElementById('beep');
        audioElement.pause();
      });
    }
  }

  playLine(e) {

  }

  render() {
    return (
      <div className="ibox">
      <div className="ibox-title clearfix mng-toparea">
          <h5>Welcome/ In-Call/ Audio List</h5>
          <div className="topBarbtn">
            <ButtonToolbar>
              <Link className="btn btn-default" to="./add-audio">
                <i className="material-icons">add</i>
              </Link>
            </ButtonToolbar>

            <ButtonToolbar>
              <DropdownButton title={<i className="material-icons">file_download</i>} pullRight noCaret>
                <MenuItem eventKey="1">Download Excel</MenuItem>
                <MenuItem divider />
                <MenuItem eventKey="2">Download</MenuItem>
              </DropdownButton>
            </ButtonToolbar>
          </div>
        </div>
        <div className="ibox-title">
        <Row className="m-b-15">
          <Col md={4} className="m-b-15 showD">
          </Col>
          <Col md={4}>
            <div className="centerBtn">
              <ButtonGroup>
                <Button
                defaultChecked={true}
                onClick={() => this.props.changeWhich(1)}
                >Welcome Audio List</Button>
                <Button
                onClick={() => this.props.changeWhich(2)}
                >In Call Audio List</Button>
                <Button
                  onClick={() => this.props.changeWhich(3)}
                >On Hold Audio List</Button>
              </ButtonGroup>
            </div>
          </Col>
          <Col md={4} className="m-b-15">
          </Col>
        </Row>
        </div>
        <div className="ibox-content">
          <Row className="mainTable">
            <ReactTable
              columns={
                [
                  {
                    Header: "Audio Description",
                    accessor: "audio_description",
                    filterable: false,
                    headerClassName: 'test',
                    sortable: false
                  },
                  {
                    Header: "Play",
                    accessor: "audio_file_url",
                    sortable: false,
                    filterable: false,
                    className: 'text-center',
                    Cell: ({ value }) => {
                      return (
                        <audio controls>
                          <source src={value} type="audio/mpeg" />
                          Your browser does not support the audio element.
                      </audio>)
                    },
                  },
                  {
                    Header: "Action",
                    sortable: false,
                    filterable: false,
                    className: 'text-center',
                    Cell: ({ original }) => {
                      return (<div className="action-wrap text-center">
                        <LinkWithTooltip tooltip="Delete">
                          <i onClick={this.audioDelete} className="material-icons recList">delete</i>
                        </LinkWithTooltip>
                      </div>)
                    }
                  },
                ]
              }
              onFetchData={this.props.fetchData}
              data={this.props.data}
              loading={this.props.loading}
              defaultPageSize={10}
              pages={this.props.pages}
              pageSize={this.props.pageSize}
              PaginationComponent={Pagination}
              manual
              loadingText={'Loading...'}
              noDataText="Sorry, No data found"
            />
          </Row>
        </div>
      </div>
    );
  }
}

export default AudioList;
