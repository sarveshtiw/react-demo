import React from 'react';
import { Row, Col, ButtonToolbar, SplitButton, MenuItem, Tooltip, FormGroup, InputGroup, ControlLabel, HelpBlock, Radio, Checkbox, Button } from 'react-bootstrap';
import axios from 'axios';
import { ReactMic, } from 'react-mic';
// import Speech from 'react-speech';
import './styles/addAudio.scss';

function FieldGroupNew({ id, label, name, checked, props, onClick }) {
  return (
    <div className="radio radio-info radio-inline mr-5">
      <input type="radio" id={id} name={name} onClick={onClick} checked={checked} />
      <label htmlFor={id}>{label}</label>
    </div>
  );
}

class welcomeAudioMessage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      temp_id: false,
      selectedContent: 1,
      audio_type: 1,
      audio_description: '',
      audio_file_id: '',
      is_default_audio: false,
      record: false,
      text: 'helo helo helo',
      blobUrl: ''
    };
    this.onChangeText = this.onChangeText.bind(this);
    this.uploadFile = this.uploadFile.bind(this);
    this.onChangeFile = this.onChangeFile.bind(this);
    this.onChangeValue = this.onChangeValue.bind(this);
  }

  onChangeValue(e) {
    let data = this.setState;
    data[e.target.name] = e.target.value;
    this.setState(data);
    console.log(this.state);
  }

  renderContent() {
    switch (this.state.selectedContent) {
      case 1:
        return (<div><Row>
          <Col md={12} className="DropBoxArea d-flex flex-column justify-content-center align-items-center mt-3">
            <img src="/images/audio-icon.png" alt="" />
            <h3 className="mt-3 mb-3">Drop Your File Here</h3>
            or
            <label className="control-label">Let Me Browse for File</label>
            <input type="file" onChange={this.onChangeFile} className="btn-sub  mit pr-5 pl-5 mt-3 mb-3 mr-0" />
            <h5>(Only .wav extension allowed & file size should be less than 5MB)</h5>

            <button type="button" class="btn-submit btn btn-default pr-5 pl-5" onClick={this.uploadFile}>Upload Audio</button>
          </Col>
        </Row>
        </div>);
      case 2:
        return (<Row>

          <Col md={12} className="recordingArea d-flex flex-column align-items-center justify-content-between mt-3 p-5">

            <div className="d-flex flex-row align-items-center justify-content-between align-self-stretch">
              <div className="mr-auto p-2">
                <h2 className="m-0">
                  <small>Wednesday, Feb 14</small>
                  00:00:10:06</h2>
              </div>
              <div className="mr-auto p-2 d-flex flex-row align-items-center justify-content-between">
                <i className="material-icons" onClick={this.startRecording}>play_arrow</i>
                <i className="material-icons" onClick={this.stopRecording}>stop</i>
                <i className="material-icons">content_cut</i>
              </div>
            </div>
            <Col md={12}>
              <Row>
                <ReactMic
                  record={this.state.record}
                  className="sound-wave"
                  onStop={this.onStop}
                  strokeColor="#d3d9ff"
                  backgroundColor="#FFFFFF"
                />
              </Row>
              <Row>
              {
                this.state.blobUrl ?
                <audio ref="audioSource" controls="controls" src={this.state.blobUrl}></audio>
                : ""
              }
              </Row>
            </Col>
            <Button type="submit" className="btn-submit pr-5 pl-5 mt-3 mb-3 mr-0">Save Recording</Button>
          </Col>
        </Row>);
      case 3:
        return (<Row className="textToSpeech">
          <Col md={12} className="mt-5 p-0">
            <FormGroup controlId="formControlsTextarea">
              <input type="text" class="textarea form-control" name="text" rows='12' cols="12" placeholder="type text here ..." value={this.state.text} onChange={this.onChangeText} />
            </FormGroup>
          </Col>
          <Col md={12} >
            {/* <Speech
              autostart={false}
              text={this.state.text}
              pitch="1"
              rate="1"
              volume="1"
              lang="en-GB"
              stop={true}
              pause={true}
              resume={true}
              voice="Google UK English Male" /> */}
          </Col>
          <Col md={12} className="d-flex flex-row justify-content-between align-items-center p-0">
            <button type="button" class="btn-submit btn btn-default pr-5 pl-5">Create Audio File</button>
            <ButtonToolbar>
              <SplitButton title="Select language" pullRight id="split-button-pull-right">
                <MenuItem eventKey="3">Download CSV</MenuItem>
                <MenuItem divider />
                <MenuItem eventKey="4">Download Excel</MenuItem>
              </SplitButton>
              <SplitButton title="Select voice type" pullRight id="split-button-pull-right">
                <MenuItem eventKey="3">Download CSV</MenuItem>
                <MenuItem divider />
                <MenuItem eventKey="4">Download Excel</MenuItem>
              </SplitButton>
              <SplitButton title="Select playing speed" pullRight id="split-button-pull-right">
                <MenuItem eventKey="3">Download CSV</MenuItem>
                <MenuItem divider />
                <MenuItem eventKey="4">Download Excel</MenuItem>
              </SplitButton>
            </ButtonToolbar>
          </Col>
        </Row>);
      default:
        break;
    }
  }

  onChangeText(e) {
    let data = this.state;
    data[e.target.name] = e.target.value;
    this.setState(data);
    console.log(this.state);
  }

  addAudio() {
    const { audio_type, audio_description, audio_file_id, is_default_audio } = this.state;
    this.props.addAudio({ audio_type, audio_description, audio_file_id, is_default_audio }).then(result => console.log(result));
  }
  onChangeFile(e) {
    this.setState({ file: e.target.files[0] })
  }
  startRecording = () => {
    this.setState({
      record: true
    });
  }

  stopRecording = () => {
    this.setState({
      record: false
    });
  }

  onStop = (recordedBlob) => {
    this.setState({ blobUrl: recordedBlob.blobURL })
    console.log('recordedBlob is: ', recordedBlob);
  }

  uploadFile = () => {
    console.log('uploading a file');
    let file = this.state.file;
    const formData = new FormData();
    formData.append('file', file);
    formData.append('appName', 'Audio Conference');
    formData.append('locationId', '2');
    formData.append('replication', 'local');
    //axios.post(`${process.env.REACT_APP_GATEWAY}/file-upload`, formData, {
    axios.post(`http://192.168.1.171:3004/file-upload`, formData, {
      headers: {
        'content-type': 'multipart/form-data',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    }).then(({ data }) => {
      console.log(data);
      if (data.data.message === "File uploaded successfully") {
        this.setState({ audio_file_id: data.data.fileId.fileId })
      }
    }).catch(err => {
      console.log(err);
    });

  }
  render() {
    return (
      <Col md={12}>
        <div className="ibox">
          <div className="ibox-title">
            <h5>Welcome / In Call / On Hold  Audio</h5>
          </div>
          <div className="ibox-content clearfix">
            <h4>Add Audio Details</h4>
            <form className="col-md-12">
              <Row>
                <Col md={2}>
                  <div class="form-group">
                    <label className="control-label">Audio Name</label>
                    <input type="text" className="form-control" placeholder="Enter Audio Name" name="audio_description" onChange={this.onChangeText} />
                  </div>
                </Col>
                <Col md={6} className='col-md-push-1'>
                  <FormGroup>
                    <ControlLabel className="col-md-12 p-0">Set Audio As</ControlLabel>
                    <div className="radio radio-info radio-inline mr-5">
                      <input type="radio" id="welcome_audio" name="audio_type" value={1} onClick={this.onChangeText} defaultChecked />
                      <label htmlFor="welcome_audio">Welcome Audio</label>
                    </div>
                    <div className="radio radio-info radio-inline mr-5">
                      <input type="radio" id="in_audio" name="audio_type" value={2} onClick={this.onChangeText} />
                      <label htmlFor="in_audio">In Call Audio</label>
                    </div>
                    <div className="radio radio-info radio-inline mr-5">
                      <input type="radio" id="hold_audio" name="audio_type" value={3} onClick={this.onChangeText} />
                      <label htmlFor="hold_audio">On Hold Audio</label>
                    </div>
                  </FormGroup>
                </Col>
              </Row>
              <hr className="row" />
              <Row>
                <Col md={12}>
                  <FormGroup>
                    <ControlLabel className="col-md-12 p-0">Add Audio Files</ControlLabel>
                    <FieldGroupNew
                      id="Upload"
                      label="Upload File"
                      placeholder="Enter text"
                      name="upload"
                      checked={this.state.selectedContent === 1}
                      onClick={() => this.setState({ selectedContent: 1 })}
                    />
                    <FieldGroupNew
                      id="Record"
                      label="Record Media"
                      placeholder="Enter text"
                      name="upload"
                      checked={this.state.selectedContent === 2}
                      onClick={() => this.setState({ selectedContent: 2 })}
                    />
                    <FieldGroupNew
                      id="Speech"
                      label="Text to Speech"
                      placeholder="Enter text"
                      name="upload"
                      checked={this.state.selectedContent === 3}
                      onClick={() => this.setState({ selectedContent: 3 })}
                    />
                  </FormGroup>
                </Col>
              </Row>
              {this.state.audio_file_id ?
                <Row>
                  1 File Selected
                </Row> :
                this.renderContent()
              }
              <Row>
                <Col md={12} className="p-5 d-flex flex-column justify-content-center align-items-center">
                  <button type="button" class="btn-submit btn btn-default pr-5 pl-5" onClick={() => this.addAudio()}>Submit</button>
                </Col>
              </Row>
            </form>
          </div>
        </div>

      </Col>
    )
  }
}

export default welcomeAudioMessage;