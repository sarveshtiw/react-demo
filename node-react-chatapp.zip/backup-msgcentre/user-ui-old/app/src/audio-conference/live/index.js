import React from 'react';
import Switch from 'react-switch_case'
import { Row, Col, FormGroup, InputGroup, FormControl, Tooltip, OverlayTrigger } from 'react-bootstrap';
import { Scrollbars } from 'react-custom-scrollbars';
import { Link } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
// Other file call
import './styles/audioLiveConference.scss';

import ContactList from '../../video-conference/components/vcManagement/conference/ContactList';
import ContactGroup from '../../video-conference/components/vcManagement/conference/ContactGroup';
import List from './components/list';


import { LinkWithTooltip } from './components/profile';
let Case = Switch.Case;

const list = [
    {
        id: 1,
        name: 'Ashwani Singh',
        profPic: '/images/videoConf-img1.jpg',
    },
    {
        id: 2,
        name: 'Manish Badola',
        profPic: '/images/videoConf-img2.jpg',
    },
    {
        id: 3,
        name: 'Bharat Singh',
        profPic: '/images/videoConf-img3.jpg',
    },
    {
        id: 4,
        name: 'Shamim Saifi',
        profPic: '/images/videoConf-img4.jpg',
    },
    {
        id: 5,
        name: 'Pradeep Kaushal',
        profPic: '/images/videoConf-img5.jpg',
    },
    {
        id: 6,
        name: 'Vaishali Srivastava',
        profPic: '/images/videoConf-img6.jpg',
    },
    {
        id: 7,
        name: 'Ganga Singh Thakur',
        profPic: '/images/videoConf-img7.jpg',
    },
    {
        id: 8,
        name: 'Mellisa Simpson',
        profPic: '/images/videoConf-img8.jpg',
    },
    {
        id: 9,
        name: 'Ankit Lakhera',
        profPic: '/images/videoConf-img9.jpg',
    },
    {
        id: 10,
        name: 'Lazar Seid',
        profPic: '/images/videoConf-img10.jpg',
    },
    {
        id: 11,
        name: 'Abdur Siddiqui',
        profPic: '/images/videoConf-img11.jpg',
    },
    {
        id: 12,
        name: 'Anlella White',
        profPic: '/images/videoConf-img12.jpg',
    },
    {
        id: 13,
        name: 'Ashwani Singh',
        profPic: '/images/videoConf-img1.jpg',
    },
    {
        id: 14,
        name: 'Manish Badola',
        profPic: '/images/videoConf-img2.jpg',
    },
    {
        id: 15,
        name: 'Bharat Singh',
        profPic: '/images/videoConf-img3.jpg',
    },
    {
        id: 16,
        name: 'Shamim Saifi',
        profPic: '/images/videoConf-img4.jpg',
    },
    {
        id: 17,
        name: 'Pradeep Kaushal',
        profPic: '/images/videoConf-img5.jpg',
    },
    {
        id: 18,
        name: 'Vaishali Srivastava',
        profPic: '/images/videoConf-img6.jpg',
    },
    {
        id: 19,
        name: 'Ganga Singh Thakur',
        profPic: '/images/videoConf-img7.jpg',
    },
    {
        id: 20,
        name: 'Mellisa Simpson',
        profPic: '/images/videoConf-img8.jpg',
    },
    {
        id: 21,
        name: 'Ankit Lakhera',
        profPic: '/images/videoConf-img9.jpg',
    },
    {
        id: 22,
        name: 'Lazar Seid',
        profPic: '/images/videoConf-img10.jpg',
    },
    {
        id: 23,
        name: 'Abdur Siddiqui',
        profPic: '/images/videoConf-img11.jpg',
    },
    {
        id: 24,
        name: 'Anlella White',
        profPic: '/images/videoConf-img12.jpg',
    },
    {
        id: 25,
        name: 'Pradeep White',
        profPic: '/images/videoConf-img2.jpg',
    },
];
const listGroup = [
    {
        id: 1,
        name: 'Pardeeep UI/UX Group',
        users: [
            {
                id: 1,
                name: 'Ashwani Singh',
                profPic: '/images/videoConf-img1.jpg',
            },
            {
                id: 2,
                name: 'Manish Badola',
                profPic: '/images/videoConf-img2.jpg',
            },
            {
                id: 3,
                name: 'Bharat Singh',
                profPic: '/images/videoConf-img3.jpg',
            },
            {
                id: 4,
                name: 'Shamim Saifi',
                profPic: '/images/videoConf-img4.jpg',
            },
            {
                id: 5,
                name: 'Pradeep Kaushal',
                profPic: '/images/videoConf-img5.jpg',
            },
            {
                id: 6,
                name: 'Vaishali Srivastava',
                profPic: '/images/videoConf-img6.jpg',
            },
            {
                id: 7,
                name: 'Ganga Singh Thakur',
                profPic: '/images/videoConf-img7.jpg',
            },
            {
                id: 8,
                name: 'Mellisa Simpson',
                profPic: '/images/videoConf-img8.jpg',
            }
        ]
    },
    {
        id: 2,
        name: 'Emigrant UI/UX Group',
        users: [
            {
                id: 1,
                name: 'Ashwani Singh',
                profPic: '/images/videoConf-img1.jpg',
            },
            {
                id: 2,
                name: 'Manish Badola',
                profPic: '/images/videoConf-img2.jpg',
            },
            {
                id: 3,
                name: 'Bharat Singh',
                profPic: '/images/videoConf-img3.jpg',
            },
            {
                id: 4,
                name: 'Shamim Saifi',
                profPic: '/images/videoConf-img4.jpg',
            },
            {
                id: 5,
                name: 'Pradeep Kaushal',
                profPic: '/images/videoConf-img5.jpg',
            },
            {
                id: 6,
                name: 'Vaishali Srivastava',
                profPic: '/images/videoConf-img6.jpg',
            },
            {
                id: 7,
                name: 'Ganga Singh Thakur',
                profPic: '/images/videoConf-img7.jpg',
            },
            {
                id: 8,
                name: 'Mellisa Simpson',
                profPic: '/images/videoConf-img8.jpg',
            }
        ]
    },
    {
        id: 3,
        name: 'Emigrant UI/UX Group',
        users: [
            {
                id: 1,
                name: 'Ashwani Singh',
                profPic: '/images/videoConf-img1.jpg',
            },
            {
                id: 2,
                name: 'Manish Badola',
                profPic: '/images/videoConf-img2.jpg',
            },
            {
                id: 3,
                name: 'Bharat Singh',
                profPic: '/images/videoConf-img3.jpg',
            },
            {
                id: 4,
                name: 'Shamim Saifi',
                profPic: '/images/videoConf-img4.jpg',
            },
            {
                id: 5,
                name: 'Pradeep Kaushal',
                profPic: '/images/videoConf-img5.jpg',
            },
            {
                id: 6,
                name: 'Vaishali Srivastava',
                profPic: '/images/videoConf-img6.jpg',
            },
            {
                id: 7,
                name: 'Ganga Singh Thakur',
                profPic: '/images/videoConf-img7.jpg',
            },
            {
                id: 8,
                name: 'Mellisa Simpson',
                profPic: '/images/videoConf-img8.jpg',
            }
        ]
    },
    {
        id: 4,
        name: 'Emigrant UI/UX Group',
        users: [
            {
                id: 1,
                name: 'Ashwani Singh',
                profPic: '/images/videoConf-img1.jpg',
            },
            {
                id: 2,
                name: 'Manish Badola',
                profPic: '/images/videoConf-img2.jpg',
            },
            {
                id: 3,
                name: 'Bharat Singh',
                profPic: '/images/videoConf-img3.jpg',
            },
            {
                id: 4,
                name: 'Shamim Saifi',
                profPic: '/images/videoConf-img4.jpg',
            },
            {
                id: 5,
                name: 'Pradeep Kaushal',
                profPic: '/images/videoConf-img5.jpg',
            },
            {
                id: 6,
                name: 'Vaishali Srivastava',
                profPic: '/images/videoConf-img6.jpg',
            },
            {
                id: 7,
                name: 'Ganga Singh Thakur',
                profPic: '/images/videoConf-img7.jpg',
            },
            {
                id: 8,
                name: 'Mellisa Simpson',
                profPic: '/images/videoConf-img8.jpg',
            }
        ]
    }
]

const tableData = [
    {
        id: 1,
        partiName: '+91-9210740008',
        accessNo: '2512 2522 1412',
        joinedTime: '21:42 PM',
        duration: '00:42:06',
    },
    {
        id: 2,
        partiName: 'Ankit Lakhera',
        accessNo: '2512 2522 1412',
        joinedTime: '21:42 PM',
        duration: '00:42:06',
    },
    {
        id: 3,
        partiName: '+91-9210740008',
        accessNo: '2512 2522 1412',
        joinedTime: '21:42 PM',
        duration: '00:42:06',
    },
    {
        id: 4,
        partiName: 'Ankit Lakhera',
        accessNo: '2512 2522 1412',
        joinedTime: '21:42 PM',
        duration: '00:42:06',
    },
    {
        id: 5,
        partiName: '+91-9210740008',
        accessNo: '2512 2522 1412',
        joinedTime: '21:42 PM',
        duration: '00:42:06',
    },
    {
        id: 6,
        partiName: 'Ankit Lakhera',
        accessNo: '2512 2522 1412',
        joinedTime: '21:42 PM',
        duration: '00:42:06',
    },
    {
        id: 7,
        partiName: '+91-9210740008',
        accessNo: '2512 2522 1412',
        joinedTime: '21:42 PM',
        duration: '00:42:06',
    },
    {
        id: 8,
        partiName: 'Ankit Lakhera',
        accessNo: '2512 2522 1412',
        joinedTime: '21:42 PM',
        duration: '00:42:06',
    },
    {
        id: 9,
        partiName: '+91-9210740008',
        accessNo: '2512 2522 1412',
        joinedTime: '21:42 PM',
        duration: '00:42:06',
    },
    {
        id: 10,
        partiName: 'Ankit Lakhera',
        accessNo: '2512 2522 1412',
        joinedTime: '21:42 PM',
        duration: '00:42:06',
    },
    {
        id: 11,
        partiName: '+91-9210740008',
        accessNo: '2512 2522 1412',
        joinedTime: '21:42 PM',
        duration: '00:42:06',
    },
    {
        id: 12,
        partiName: 'Ankit Lakhera',
        accessNo: '2512 2522 1412',
        joinedTime: '21:42 PM',
        duration: '00:42:06',
    },
    {
        id: 13,
        partiName: '+91-9210740008',
        accessNo: '2512 2522 1412',
        joinedTime: '21:42 PM',
        duration: '00:42:06',
    },
    {
        id: 14,
        partiName: 'Ankit Lakhera',
        accessNo: '2512 2522 1412',
        joinedTime: '21:42 PM',
        duration: '00:42:06',
    },
];
const options = [
    'Paid', 'Toll Free'
]
const options2 = [
    'Active', 'Deactivated', 'Expired'
]

class TooltipNew extends React.Component {
    render() {
        return (
            <OverlayTrigger
                overlay={<Tooltip id={this.props.id}>{this.props.tooltip}</Tooltip>}
                placement="top"
                delayShow={300}
                delayHide={150}
            >
                <i className={this.props.classN} onClick={this.props.customTp}>{this.props.icon}</i>
            </OverlayTrigger>
        );
    }
}
class LiveConfDashboard extends React.Component {
    constructor(props, contex) {
        super(props, contex)
        this.state = {
            list: list,
            showParticipants: false,
            listGroup: listGroup,
            tab: 'contacts',
            tableData: this.props.data,
        }
    }
    showParticipants() {
        this.setState({
            showParticipants: !this.state.showParticipants
        })
    }
    changeTab = (type) => {
        this.setState({
            tab: type
        })
    }
    render() {
        console.log(this.props);
        let conf = this.props.conferenceDetails;
        let { profile } = this.props;
        return (
            <div className="audio-section">
                <header className="online-head">
                    <Col md={4} className="col-md-4 d-flex">
                        <Link to="/dashboard"><img src="/images/logo.png" alt="Synthesis Dashboard" /></Link>
                        { /*<div className="v-time">
                    <span className="pointer">Duration</span>
                    <b className="text-info">08:48</b>
                 </div> */}
                    </Col>
                    <Col md={4} className="text-center">
                        <p>{conf.conf_name}</p>
                    </Col>
                    <Col md={4} className="text-right">
                        <div className="end-conf">
                            <button className="btn btn-default mr-4"><i className="material-icons">person_add</i> Add New Participant</button>
                            <button className="btn btn-danger">
                                <i className="material-icons">power_settings_new</i>
                                End Conference</button>
                        </div>
                    </Col>
                </header>
                <div className="online-body d-flex flex-Row structure">
                    <div id="mainConfWarp" className="member-video mt-0 flex-column pt-4">
                        <div className="col-sm-12">
                            <div className="d-flex align-items-center">
                                <img src="/images/account-icon.jpg" className="img-circle" />
                                <div className="col-sm-12 profileLive">
                                    <Row>
                                        <div className="col-sm-4 ml-5 mr-5 d-flex align-items-center">
                                            <h3 className="m-0 status online">{profile.fname}</h3>
                                        </div>

                                    </Row>
                                    <Row>
                                        <div className="col-sm-4 ml-5 mr-5 d-flex align-items-center">
                                            <p className="m-0"><strong>Designation</strong>: {profile.Designation.designation_name}</p>
                                        </div>
                                        <div className="col-sm-4 ml-5 mr-5 d-flex align-items-center">
                                            <p className="m-0"><strong>Participant Pin</strong>: {conf.conf_participant_pin}</p>
                                        </div>
                                    </Row>
                                    <Row>
                                        <div className="col-sm-4 ml-5 mr-5 d-flex align-items-center">
                                            <p className="m-0"><strong>Location</strong>: {profile.Country.country_name}</p>
                                        </div>
                                        <div className="col-sm-4 ml-5 mr-5 d-flex align-items-center">
                                            <p className="m-0"><strong>Leader Pin</strong>: {conf.conf_leaderpin}</p>
                                        </div>
                                    </Row>
                                </div>
                            </div>
                           
                            <div className="ibox mt-4 mb-4">
                                <div className="ibox-title d-flex align-items-center p-0">
                                    <h5>Active Participants in Conference ({this.props.data.length})</h5>
                                    <div className="ml-auto actionWrap d-flex align-items-center justify-content-end">
                                        <LinkWithTooltip tooltip="Edit" href="" id="mic">
                                            <i className="material-icons">call_merge</i>
                                        </LinkWithTooltip>
                                        <LinkWithTooltip tooltip="Edit" href="" id="">
                                            <i className="material-icons">mic_off</i>
                                        </LinkWithTooltip>
                                        <FormGroup>
                                            <InputGroup>
                                                <FormControl type="text" placeholder="Search Caller" className="fShadow"/>
                                                <InputGroup.Addon>
                                                    <i className="fa fa-search"></i>
                                                </InputGroup.Addon>
                                            </InputGroup>
                                        </FormGroup>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <List tableData={this.props.data} />
                        
                    </div>
                    
                    <div className="video-chat">
                    <div className="chat-menu">
                        <ul>
                            <li onClick={() => { this.props.changeTab('contacts') }}
                                className={
                                    this.props.tab === 'contacts' ? 'active' : ''
                                }><span><i className="material-icons">portrait</i></span></li>
                            <li onClick={() => { this.props.changeTab('groups') }}
                                className={
                                    this.props.tab === 'groups' ? 'active' : ''
                                }><span><i className="material-icons">people</i></span></li>
                            <li onClick={() => { this.props.changeTab('chat') }}
                                className={
                                    this.props.tab === 'chat' ? 'active' : ''
                                }><span><i className="material-icons">question_answer</i></span></li>
                            <li onClick={() => { this.props.changeTab('drop') }}
                                className={
                                    this.props.tab === 'drop' ? 'active' : ''
                                }><span><i className="material-icons">airplay</i></span></li>
                        </ul>
                    </div>
                        
                            <Switch value={this.props.tabOption}>
                                <Case value="contacts">
                                    <ContactList
                                        contactList={this.props.contactList}
                                        searchContact={this.props.searchContact}
                                        addParticipantToConference={this.props.addParticipantToConference}
                                        participantList={this.props.participantList}
                                    />
                                </Case>
                                <Case value="groups">
                                    <ContactGroup
                                        groupList={this.props.groupList}
                                        groupDetail={this.props.groupDetail}
                                        groupDetailShow={this.props.groupDetailShow}
                                        participantList={this.props.participantList}
                                        addGroupParticipantToConference={this.props.addGroupParticipantToConference}
                                        searchGroup={this.props.searchGroup}
                                    />
                                </Case>
                            </Switch>
                        
                    </div>
                </div>

            </div>
        );
    }
}

export default LiveConfDashboard;