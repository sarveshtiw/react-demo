const configData = {
    'api_url': process.env.API_URL,
    'api_minio': process.env.API_MINIO,
    'amp_api': process.env.AMP_API,
    'elasticSearch': {
        'index': 'asergis',
        'document': {
            'user': 'userinfo',
            'chat': 'chatdata',
            'notifications': 'notifications'
        }
    },
    'GROUP_DOMAIN': '@conference.192.168.1.170',
    'DOMAIN':'@192.168.1.170',
    'email':{
        'from': 'support@asergis.com',
    },
    'email_host': 'http://localhost:3002',
    'cm_graphql_endpoint' : 'http://localhost:5000/contact_manager'
}

export default configData;