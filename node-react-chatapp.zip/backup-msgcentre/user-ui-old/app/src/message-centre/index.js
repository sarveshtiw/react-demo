import React from 'react';
import App from './containers/App';
import Header from './containers/menu/TopMenu'
import LeftSidebar from './components/menu/LeftSidebar'
import RightSidebar from './components/menu/RightSidebar'
import { compose, withApollo } from 'react-apollo';
import XmppEventHandlers from './lib/XmppEventHandlers';

let self;
class MessageCentre extends React.Component {

    constructor(props) {
        super(props)
        self = this;
        let wsUrl =  process.env.REACT_APP_EJABBERD_URL;
        this.state = {
            sObject: new XmppEventHandlers(localStorage.uuid, localStorage.token, wsUrl, this.props),
            sPresence: {},
            sMessages: {},
            sNotifications: {},
            sMucInvitation: {},
            sDiscoCaps: [],
            sCurrentCap: {},
            sAvatar: {},
            message: {
                type: "",
                body: ""
            }
        }
    }

    componentWillMount() {
        //this.state.sObject.eventListners();
    }

    componentDidMount() {
        //listners
        this.state.sObject.sClient.on('auth:failed', this.handleFailedAuth)
        this.state.sObject.sClient.on('disconnected', this.handleDisconnected)
        this.state.sObject.sClient.on('session:end', this.handleDisconnected)
        this.state.sObject.sClient.on('disco:caps', this.handleDiscoCaps)
        this.state.sObject.sClient.on('muc:invite', this.handleNewMucInvitation)
        this.state.sObject.sClient.on('attention', this.handleNotifications)
        this.state.sObject.sClient.on('chat', this.handleMessages)
        this.state.sObject.sClient.on('groupchat', this.handleGroupMessages)
        //this.state.sObject.sClient.on('pubsub:event', this.handlePubSub)
        this.state.sObject.sClient.on('avatar', this.handleAvtar)
        this.state.sObject.sClient.on('subscribe', this.subscribeUser);
        this.state.sObject.sClient.on('subscribed', this.subscribedUser);

        /*
        //jingle listners
        this.state.sObject.sClient.on('jingle:incoming', (session)=>{
            console.log('jingle:incoming', session)
        })
        this.state.sObject.sClient.on('jingle:outgoing', (session)=>{
            console.log('jingle:outgoing', session)
        })
        this.state.sObject.sClient.on('jingle:terminated', (session)=>{
            console.log('jingle:terminated', session)
        })
        this.state.sObject.sClient.on('jingle:accepted', (session)=>{
            console.log('jingle:accepted', session)
        })
        this.state.sObject.sClient.on('jingle:localstream:added', (session)=>{
            console.log('jingle:localstream:added', session)
        })
        this.state.sObject.sClient.on('jingle:localstream:removed', (session)=>{
            console.log('jingle:localstream:removed', session)
        })
        this.state.sObject.sClient.on('jingle:remotestream:added', (session, stream)=>{
            console.log('jingle:remotestream:added', session, stream)
        })
        this.state.sObject.sClient.on('jingle:remotestream:removed', (session)=>{
            console.log('jingle:remotestream:removed', session)
        })
        this.state.sObject.sClient.on('jingle:ringing', (session)=>{
            console.log('jingle:ringing', session)
        })
        */
    }

    //handle failed authentications
    handleFailedAuth = (data) => {
        console.log("falied");
        //window.location = '/auth';
    }

    handleDisconnected = (data) => {
        console.log("Disconnected");
        //window.location = '/auth';
        //self.state.sObject.sClient.connect();
    }

    //handle user notifications
    handleNotifications = async (data) => {
        //add new notification into elastic
        let response = await this.state.sObject.addNotifications(data);
        data.id = response.data.id;
        data.body = response.data.body;
        data.time = response.data.time;
        //update state value
        let notifications = {
            ...self.state,
            sNotifications: {
                ...self.state.sNotifications,
                    all: {...self.state.sNotifications.all,
                    [data.id]: data
                },
                recentNotifation: data
            },
            status: 1,
            active: {}
        };
        self.setState(notifications);
    }

    //handle muc invitations
    handleNewMucInvitation = (data) => {
        console.log('invitation', data);
        self.setState({
            sMucInvitation: data
        })
    }

    //handle incoming discocaps
    handleDiscoCaps = (data) => {
        console.log('disco', data);
        if(data.from.bare !== self.state.sObject.sClient.config.jid.bare){
            var caps =  {
                ...self.state,
                sDiscoCaps : {
                    ...self.state.sDiscoCaps,
                    [data.from.bare] : data
                },
                sCurrentCap: data
            }
            self.setState(caps)
        }
    }

    //handle incoming messages
    handleMessages = async (data) => {
        let mid;
        if(data.id.indexOf('synthesis') >= 0){
            mid = Number(data.id.replace("synthesis", ""));
            data.createdOn = Number(mid); //change with server value

        }else{
            //check if message is coming from a different source like pidgin
            data.createdOn = new Date().getTime(); //assign a random value
            let response = await self.state.sObject.saveChat(data);
            mid = Number(response.data.createdOn);
            data.createdOn = Number(response.data.createdOn); //change with server value
        }

        let messages = {
            ...self.state,
            sMessages: [...self.state.sMessages, data]
        }
        self.setState(messages);
    }

    //handle group messages
    handleGroupMessages = async (data) => {
        if(data.from.resource !== self.state.sObject.displayName){
            let mid;
            if(data.id.indexOf('synthesis') >= 0){
                mid = Number(data.id.replace("synthesis", ""));
                data.createdOn = Number(mid); //change with server value

            }else{
                data.createdOn = new Date().getTime(); //assign a random value
                let response = await self.state.sObject.saveChat(data);
                mid = Number(response.data.createdOn);
                data.createdOn = Number(response.data.createdOn); //change with server value
            }

            let messages = {
                ...self.state,
                sMessages: [...self.state.sMessages, data]
            }
            self.setState(messages)
        }
    }

    handlePubSub = (data) => {
        //console.log('handlepubsub', data);
    }

    //handle avtars
    handleAvtar = (data) => {
        var avt =  {
            ...self.state,
            sAvatar : {
                ...self.state.sAvatar,
                [data.jid.bare] : data
            }
        }
        self.setState(avt)
    }

    showMessage = (props) => {
        this.setState({
            message: {
                type: props.type,
                body: props.body
            }
        }, () => {
            setTimeout(function() { 
                this.setState({ 
                    message: {
                    type: props.type,
                    body: props.body
                }});
            }.bind(this), 10000);
        })
    }

    subscribeUser = (data) => {
        console.log('subscribe' ,data);
        self.state.sObject.sClient.acceptSubscription(data.from.bare);
        self.state.sObject.sClient.subscribe(data.from.bare);
    }

    subscribedUser = (data) => {
        console.log('subscribed' ,data);
    }

    render() {
        return (
            <div className="main">
                <Header />
                <div className="container-flud">
                    <div className="mainArea">
                        {this.state.message.type ? <div className={this.state.message.type}> {this.state.message.body} </div> : ''}
                        <LeftSidebar />
                            <App {...this.state} {...this.props} showMessage={this.showMessage}  />
                        <RightSidebar />
                    </div>
                </div>
            </div>
        )
    }
}

export default compose(
    withApollo,
)(MessageCentre)
