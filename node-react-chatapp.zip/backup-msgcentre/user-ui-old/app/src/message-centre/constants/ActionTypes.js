// login
export const LOGIN = 'LOGIN';
export const LOGOUT = 'LOGOUT';

// action chat
export const CHAT_HISTORY = 'CHAT_HISTORY';
export const CHAT_OUTGOING = 'CHAT_OUTGOING';
export const CHAT_INCOMING = 'CHAT_INCOMING';
export const CHAT_REMOVE = 'CHAT_REMOVE';
export const CHAT_UPDATE = 'CHAT_UPDATE';
export const CHAT_SEND_ATTACHMENT = 'CHAT_SEND_ATTACHMENT';
export const CHAT_ATTACHMENTS = 'CHAT_ATTACHMENTS';
export const CHAT_FAVOURITES = 'CHAT_FAVOURITES';
export const CHAT_SEARCH = 'CHAT_SEARCH';
export const CHAT_MSG_UPDATE = 'CHAT_MSG_UPDATE'; //single chat message forss update

// action muc
export const LIST_MUC = 'LIST_MUC';
export const ADD_MUC = 'ADD_MUC';
export const REMOVE_MUC = 'REMOVE_MUC';
export const UPDATE_MUC = 'UPDATE_MUC';
export const ACTIVE_MUC = 'ACTIVE_MUC';
export const GET_INVITATION_MUC = 'GET_INVITATION_MUC';
export const SEND_INVITATION_MUC = 'GET_INVITATION_MUC';
export const LEAVE_ROOM = 'LEAVE_ROOM';

// action roster
export const LIST_CONTACT = 'LIST_CONTACT';
export const ADD_CONTACT = 'ADD_CONTACT';
export const REMOVE_CONTACT = 'REMOVE_CONTACT';
export const UPDATE_CONTACT = 'UPDATE_CONTACT';
export const ACTIVE_CONTACT = 'ACTIVE_CONTACT';

//notification
export const NOTIFICATION_ADD = 'NOTIFICATION_ADD';
export const NOTIFICATION_STATUS = 'NOTIFICATION_STATUS';
export const NOTIFICATION_HISTORY = 'NOTIFICATION_HISTORY';

//user status
export const USER_STATUS_UPDATE = 'USER_STATUS_UPDATE';



