import gql from 'graphql-tag';

export const GET_CHAT_MESSAGES = gql`
    query getChatMessages($input:getChatsInput) {
        getChatMessages(input:$input) {
            message
            total
            scrollId
            data {
                type
                id
                body
                attachmentType
                from {
                    name
                    jid
                }
                to {
                    name
                    jid
                }
                isAttachment
                isEdited
                isFavourite
                isDeleted
                createdOn
                isLocation
            }
        }
    }
`
export const GET_ROOM_LISTS = gql`
    query getMessageRooms($input:getRoomListIn){
        getMessageRooms(input:$input){
            message
            data {
                name
                nick
                jid {
                    bare
                }
                autojoin
                unread
                description
                role
                affiliation
                local
                type
                is_starred
                fromDate
            }
        }
    }
`
export const GET_ROOM_MEMBERS = gql`
    query getMessageRoomMembers($input:getRoomMembersIn) {
        getMessageRoomMembers(input:$input) {
            message
            data {
                jid
            }
        }
    }
`

export const GET_GROUP_USERS_DATA = gql`
    query getGroupMembersData($input:getGroupMembersIn) {
        getGroupMembersData(input:$input) {
            message
            total
            scrollId
            data {
                jid
                companyId
                fullName
                displayName
                status
                fullName
                showtypes
                userImage
                email
            }
        }
    }
`

export const GET_NOTIFICATION_LIST = gql`
    query getMessageNotifications($input:getNotificationListIn) {
        getMessageNotifications(input:$input) {
            message
            data {
                id
                type
                status
                body
                from {
                  bare
                  full
                  local
                }
                to {
                  bare
                  full
                  local
                }
                time
            }
        }
    }
`

export const GET_USER_STATUS = gql`
    query getMessageUserStatus($input:getUserStatusInput) {
        getMessageUserStatus(input:$input) {
            message
            data {
                jid
                status
                showtypes
                fullName
                displayName
                cap {
                    node
                    hash
                    ver
                }
            }
        }
    }
`

export const GET_ACTIVE_USERS = gql`
    query getMessageActiveUsers($input:getActiveUsersInput) {
        getMessageActiveUsers(input:$input){
            message
            data {
                jid
                displayName
                fullName
                showtypes
                status
                is_starred
                email
                fromDate
                archiveDate
            }
        }
    }    
`

export const GET_LOGGEDIN_USER_INFO = gql`
    query getMessageUserProfile($input:getUserProfileInput) {
        getMessageUserProfile(input:$input){
            message
            data {
                jid
                displayName
                fullName,
                showtypes,
                status,
                userImage
            }
        }
    }    
`

export const GET_COMPANY_USERS = gql`
    query getMessageUserProfile($input:getUserProfileInput) {
        getMessageUserProfile(input:$input){
            message,
            data {
                jid
                displayName
                fullName,
                showtypes,
                status,
                userImage
            }
        }
    }    
`

export const SEND_MENTION_EMAIL = gql`
    query sendMentionEmail($input:mentionEmailInput) {
        sendMentionEmail(input:$input){
            message
            data {
                error
                success
            }
        }
    }    
`

export const SEND_INVITATION_EMAIL = gql`
    query sendInvitationEmail($input:invitationEmailInput) {
        sendInvitationEmail(input:$input){
            message
            data {
                error
                success
            }
        }
    }    
`

export const GET_FILE_URL_BY_FILE_ID = gql`
    query getFileUrlByFileId($input:getFileUrlIn) {
        getFileUrlByFileId(input:$input){
            message,
            data {
                fileIdURL
            }
        }
    }    
`
export const GET_URL_INFO = gql`
    query getMessageScraperUrlInfo($input:getUrlInfoInput) {
        getMessageScraperUrlInfo(input:$input) {
            message
            data {
                chatId
                url
                ogTitle
                ogDescription
                ogImage {
                    url
                }
                ogSiteName
                ogUrl
                ogLocale
            }
        }
    }
`

export const GET_CHAT_MESSAGES_BY_CATEGORY = gql`
    query getChatMessagesByCategory($input:getCategoryChatIn) {
        getChatMessagesByCategory(input:$input) {
            message
            total
            scrollId
            data {
                type
                id
                body
                attachmentType
                from {
                    name
                    jid
                }
                to {
                    name
                    jid
                }
                isAttachment
                isEdited
                isFavourite
                isDeleted
                createdOn
            }
        }
    }
`
export const SEARCH_CHAT_MESSAGES = gql`
    query searchChatMessages($input:searchChatMessagesIn) {
        searchChatMessages(input:$input) {
            message
            total
            scrollId
            data {
                type
                id
                body
                attachmentType
                from {
                    name
                    jid
                }
                to {
                    name
                    jid
                }
                isAttachment
                isEdited
                isFavourite
                isDeleted
                createdOn
            }
        }
    }
`