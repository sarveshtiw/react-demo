import gql from 'graphql-tag';

export const AUTH_TOKEN_VERIFY = gql`
    mutation tokenVerify($input:TokenVerifyInput!) {
        tokenVerify(input:$input) {
            user_type
            result
        }
    }
`
export const SAVE_CHAT = gql`
    mutation createChatMessage($input:saveChatInput) {
        createChatMessage(input:$input) {
            message
            data {
                result
                createdOn
                _id
            }
        }
    }
`
export const UPDATE_CHAT = gql`
    mutation updateChatMessage($input:updateChatInput) {
        updateChatMessage(input:$input) {
            message
            data {
                updated
            }
        }
    }
`
export const SAVE_ROOM = gql`
    mutation createMessageRoom($input:saveRoomIn) {
        createMessageRoom(input:$input) {
            message
            data {
                result
                _id
            }
        }
    }
`
export const UPDATE_ROOM = gql`
    mutation updateMessageRoom($input:updateRoomIn) {
        updateMessageRoom(input:$input) {
            message
            data {
                updated
            }
        }
    }
`
export const LEAVE_ROOM = gql`
    mutation leaveMessageRoom($input:updateRoomIn) {
        leaveMessageRoom(input:$input) {
            message
            data {
                updated
            }
        }
    }
`
export const DELETE_ROOM = gql`
    mutation deleteMessageRoom($input:deleteRoomIn) {
        deleteMessageRoom(input:$input) {
            message
            data {
                deleted
            }
        }
    }
`
export const SAVE_NOTIFICATION = gql`
    mutation createMessageNotification($input:addNotificationIn) {
        createMessageNotification(input:$input) {
            message
            data {
                result
                id
            }
        }
    }
`
export const UPDATE_NOTIFICATION  = gql`
    mutation updateMessageNotification($input:updateNotificationIn) {
        updateMessageNotification(input:$input) {
            message
            data {
                updated
            }
        }
    }
`
export const SAVE_USER = gql`
    mutation createMessageUser($input:saveUserInput) {
        createMessageUser(input:$input) {
            message
            data {
                result
                _id
            }
        }
    }
`
export const UPDATE_USER_PROFILE_INFO = gql`
    mutation updateMessageUserProfileInfo($input:userUpdateProfileInput) {
        updateMessageUserProfileInfo(input:$input) {
            message
            data {
                updated
            }
        }
    }
`

export const ADD_CONTACTS = gql`
    mutation addMessageContacts($input:addContactsInput) {
        addMessageContacts(input:$input) {
            message
            data {
                result
                fromDate
                _id
            }
        }
    }
`

export const UPDATE_CONTACT = gql`
    mutation updateMessageContactInfo($input:updateContactInfoInput) {
        updateMessageContactInfo(input:$input) {
            message
            data {
                currentTime
            }
        }
    }
`

export const EMAIL_CHAT_MESSAGES = gql`
    mutation emailChatMessages($input:emailChatMessagesIn) {
        emailChatMessages(input:$input) {
          status
          message
        }
    }
`