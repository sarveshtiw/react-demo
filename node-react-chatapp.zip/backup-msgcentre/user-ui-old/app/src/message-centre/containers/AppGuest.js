import React from "react";
import LeftContainer from "./leftContainerGuest";
import MiddleContainer from "./middleContainerGuest";
import EditProfile from "./../components/main/editProfile";
import mcContacts from "../lib/contacts";
import mcCommon from "../lib/common";
import configData from "../data/config";
import mucFilter from "../lib/mucfilter";
import "../components/scss/App.scss";
import { GET_LOGGEDIN_USER_INFO } from "../constants/query";
const _ = require("lodash");

class App extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loggedInUser: {
                status: ""
            },
            sRosterData: {
                all: {},
                filtered: {},
                active: {},
                contactsPopup: false,
                companyUsers: {}
            },
            groupUsers: [],
            roomsInfo: {
                all: {},
                active: {},
                countRoomMembers: 0
            },
            roomsData: {
                all: {},
                filtered: {}
            },
            search: {
                all: {},
                total: "",
                scrollId: ""
            },
            userType: "guest"
        };
        this.getRooms = this.getRooms.bind(this);
    }

    componentWillMount() {
        //all other api's will be called after getting user profile info
        this.getLoggedInUser();
    }

    componentDidMount() {
        document.body.classList.toggle("messageCenter", true);
        //all other api's will be called after getting user profile info
    }

    componentWillReceiveProps(nextProps, nextStates) {
        //for disco caps
        if (
            JSON.stringify(nextProps.sDiscoCaps) !==
            JSON.stringify(this.props.sDiscoCaps)
        ) {
            if (nextProps.sCurrentCap.hasOwnProperty("muc")) {
            } else {
                let withCaps = mcContacts.manageCaps(
                    this.state.sRosterData.all,
                    nextProps.sDiscoCaps
                );
                this.setState(prevState => ({
                    sRosterData: {
                        ...prevState.sRosterData,
                        all: withCaps
                    }
                }));
            }
        }

        //manage unread messages
        if (nextProps.sMessages !== this.props.sMessages) {
            let lastMessage = Object.values(nextProps.sMessages)[
                Object.keys(nextProps.sMessages).length - 1
            ];
            if (
                lastMessage.type === "groupchat" &&
                this.state.sRosterData.active.jid.bare !== lastMessage.from.bare
            ) {
                this.state.roomsData.all.find((v, i) => {
                    if (v.jid.bare.toLowerCase() === lastMessage.from.bare) {
                        const rAll = this.state.roomsData.all;
                        rAll[i].unread = rAll[i].unread + 1;

                        //update state
                        this.setState(
                            prevState => ({
                                roomsData: {
                                    ...prevState.roomsData,
                                    all: rAll
                                }
                            }),
                            () => {
                                this.playSound();
                            }
                        );
                    }
                });
            }
        }

        //update conferences on new invitation
        if (
            Object.keys(nextProps.sMucInvitation).length &&
            nextProps.sMucInvitation !== this.props.sMucInvitation
        ) {
            let conferenceObj = mucFilter.addRoom(
                nextProps.sMucInvitation,
                this.props.roomsData
            );
            let conference = this.state.roomsData.all.concat([
                conferenceObj[0].conference
            ]);
            this.setState(
                prevState => ({
                    roomsData: {
                        ...prevState.roomsData,
                        all: conference,
                        filtered: conference
                    }
                }),
                () => {
                    let displayName = this.state.loggedInUser.displayName;
                    let opts = {
                        status: ""
                    };
                    this.props.sObject.joinChannel(conferenceObj, displayName, opts);
                }
            );
        }
    }

    shouldComponentUpdate(nextProps, nextState) {
        if (nextProps.sDiscoCaps !== this.props.sDiscoCaps) {
            return true;
        }
        return true;
    }

    //play sound when new message received
    playSound = () => {
        const audio = new Audio("./audio/notification.mp3");
        audio.play();
    };

    //get current loggedin user
    getLoggedInUser = async () => {
        let response = await this.props.sObject.getLoggedInUser();
        if (response.errors) {
            this.setState({
                errorMsg: response.errors
            });
        } else {
            let sRosterData = {
                autojoin: true,
                jid: {
                    bare: response.data.jid
                }
            };

            this.setState(
                prevState => ({
                    loggedInUser: {
                        ...prevState.loggedInUser,
                        jid: response.data.jid,
                        displayName: response.data.displayName,
                        fullName: response.data.fullName,
                        showtypes: response.data.showtypes,
                        status: response.data.status,
                        userImage: response.data.userImage ? response.data.userImage : "",
                        cid: response.data.cid
                    }
                }),
                () => {
                    //call dependent api's
                    this.getRooms();
                }
            );
        }
    };

    //set active roster.
    updateChatSection = async value => {
        //manage unread messages when active changes
        let rAll = {};
        if (value.hasOwnProperty("autojoin")) {
            let response = await this.props.sObject.getRoomMembers(value.jid.bare);
            if (response.errors) {
                this.setState({
                    errorMsg: response.errors
                });
            } else {
                //update unread message status
                this.state.roomsData.all.find((v, i) => {
                    if (v.jid.bare === value.jid.bare) {
                        rAll = this.state.roomsData.all;
                        rAll[i].unread = 0;
                    }
                });

                //set state value
                this.setState(
                    prevState => ({
                        sRosterData: {
                            ...prevState.sRosterData,
                            active: Object.keys(value).length ? value : {}
                        },
                        roomsData: {
                            ...prevState.roomsData,
                            all: rAll
                        },
                        roomsInfo: {
                            ...prevState.roomsInfo,
                            all: response.data.getMessageRoomMembers.data,
                            countRoomMembers: response.data.getMessageRoomMembers.data.length
                        }
                    }),
                    () => { }
                );
            }
        } 
    };

    //update roster value
    updateRosterState = (key, value) => {
        if (this.state.sRosterData.active.hasOwnProperty("autojoin")) {
            this.state.roomsData.all.find((v, i) => {
                if (v.jid.bare === this.state.sRosterData.active.jid.bare) {
                    const rAll = this.state.roomsData.all;
                    rAll[i][key] = value;

                    //update state
                    this.setState(prevState => ({
                        roomsData: {
                            ...prevState.roomsData,
                            all: rAll
                        },
                        sRosterData: {
                            ...prevState.sRosterData,
                            active: {
                                ...prevState.sRosterData.active,
                                [key]: value
                            }
                        }
                    }));
                } else {
                    return null;
                }
            });
        } 
    };

    async getRooms() {
        const getRoomsObj = {
            companyId: this.state.loggedInUser.cid,
            jid: this.props.sObject.sClient.config.jid.bare
        };
        if (!mcCommon.ckeckIsEmpty(getRoomsObj)) {
            let response = await this.props.sObject.getRooms(getRoomsObj);
            if (response.status) {
                this.setState({
                    sRosterData: {
                        all: response.data,
                        filtered: response.data,
                        active: Object.keys(response.data).length ? response.data[0] : {},
                        sCaps: []
                    },
                    roomsData: {
                        all: response.data,
                        filtered: response.data
                    }
                },() => {
                    this.updateChatSection(response.data[0]);
                });
            } else {
                this.setState({
                    errorMsg: response.errors
                });
            }
        }
    }

    render() {
        //console.log("guest =>>>>>>>>>>>>>>>>>>>>",this.state);
        return (
            <div className="middleArea">
                <div className="msgApp">
                    <LeftContainer
                        {...this.props}
                        {...this.state}
                        updateChatSection={this.updateChatSection}
                    />

                    <div className="col-sm-9 msgMain">
                        <MiddleContainer
                            {...this.props}
                            {...this.state}
                            loggedInUserType={this.state.userType}
                            updateRosterState={this.updateRosterState}
                        />
                    </div>
                </div>
            </div>
        );
    }
}

export default App;
