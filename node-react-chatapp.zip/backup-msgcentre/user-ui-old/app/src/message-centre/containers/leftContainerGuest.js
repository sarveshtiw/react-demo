import React, { Component } from "react";
import LeftSection from "../components/left/guest";

class LeftContainer extends Component {
    constructor(props) {
        super(props);
    }

    componentWillMount() {
        //console.log("called");
    }

    componentDidMount() { 
        //console.log("called");
    }

    componentWillUpdate(nextProps, nextState) {
        //console.log("WillUpdate", nextProps, nextState);
    }

    componentDidUpdate(prevProps, prevState) {
        //console.log("called");
    }

    componentDidCatch(error, info) {
        //console.log("error", error, info);
    }

    componentWillReceiveProps(nextProps) {
        //console.log("error", error, info);
    }

    render() {
        return (
            <LeftSection
                {...this.props}
                {...this.state}
            />
        );
    }
}

export default LeftContainer;
