import React from 'react';
import { Col } from 'react-bootstrap';
import { Scrollbars } from 'react-custom-scrollbars';
import ConversationDetails from '../components/right/conversationDetails';
import messageFilter from '../lib/messagefilter';

class Right extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            userInfo: {
                fullName: '',
                displayName: '',
                status: ''
            },
            conversation: {
                starClass: false,
                sharedClass: false,
                groupMembers: false,
            },
            favChatData: {
                all: {},
                total: 0,
                scrollId: ""
            },
            sharedChatData: {
                all: {},
                total: 0,
                scrollId: ""
            },
            groupUsersData: {
                all: {},
                total: 0,
                scrollId: ""
            }
        };
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.sRosterData.active.jid.bare !== this.props.sRosterData.active.jid.bare) {
            this.setState((prevState) => ({
                conversation: { 
                    ...prevState.conversation,
                    starClass: false,
                    sharedClass: false,
                    groupMembers: false
                },
                favChatData: {
                    all: {},
                    total: 0,
                    scrollId: ""
                },
                sharedChatData: {
                    all: {},
                    total: 0,
                    scrollId: ""
                },
                groupUsersData: {
                    all: {},
                    total: 0,
                    scrollId: ""
                }
            }));
        }
    }

    showStarChats = () => {
        this.setState((prevState) => ({
            conversation: { 
                ...prevState.conversation,
                starClass: !prevState.conversation.starClass,
                sharedClass: false,
                groupMembers: false
            }
        }));
        let inObj = {
            type: "isFavourite",
            toJid: this.props.sRosterData.active.jid.bare
        }
        this.getChatMessagesByCategory(inObj);
    }

    showAttachmentChats = () => {
        this.setState((prevState) => ({
            conversation: { 
                ...prevState.conversation,
                starClass: false,
                sharedClass: !prevState.conversation.sharedClass,
                groupMembers: false
            }
        }));
        let inObj = {
            type: "isAttachment",
            toJid: this.props.sRosterData.active.jid.bare
        }
        this.getChatMessagesByCategory(inObj);
    }

    getChatMessagesByCategory = async (inObj) => {
        let response = await this.props.sObject.getChatMessagesByCategory(inObj);
        if(!response.status) {
            this.setState({
                errorMsg: response.message
            });                
        } else {
            if(response.data.length > 0){
                if(inObj.type === "isFavourite"){
                    let messages = messageFilter.manageChatHistoryByCategory(response.data, this.state.favChatData.all);
                    //console.log("messages =>>>>>>>>>>..", messages, response.data, this.state.favChatData.all);
                    if((Object.keys(this.state.favChatData.all).length || messages.length) !== this.state.favChatData.total){
                        this.setState({
                            favChatData: {
                                all: messages,
                                total: response.total,
                                scrollId: response.scrollId
                            }
                        });
                    }
                } else {
                    let messages = messageFilter.manageChatHistoryByCategory(response.data, this.state.sharedChatData.all);
                    //console.log("messages =>>>>>>>>>>..", messages, response.data, this.state.favChatData.all);
                    if((Object.keys(this.state.sharedChatData.all).length || messages.length) !== this.state.sharedChatData.total){
                        this.setState({
                            sharedChatData: {
                                all: messages,
                                total: response.total,
                                scrollId: response.scrollId
                            }
                        });
                    }
                }
            }
        }
    }

    showGroupChatUsers = () => {
        this.setState((prevState) => ({
            conversation: { 
                ...prevState.conversation,
                starClass: false,
                sharedClass: false,
                groupMembers: !prevState.conversation.groupMembers
            }
        }));
        let inObj = {
            companyId: 6,
            conferenceName: this.props.sRosterData.active.jid.bare
        } 
        this.getGroupUsersData(inObj);
    }

    getGroupUsersData = async (obj) => {
        let response = await this.props.sObject.getGroupUsersData(obj);
               
        if(response.errors) {
            this.setState({
                errorMsg: response.message
            });                
        } else {
            let users = response.data.getGroupMembersData.data;
            let total = response.data.getGroupMembersData.total;
            let scrollId = response.data.getGroupMembersData.scrollId;
            if(users.length > 0){
                let messages = messageFilter.manageGroupUsers(users, this.state.groupUsersData.all);
                if((Object.keys(this.state.groupUsersData.all).length || messages.length) !== this.state.groupUsersData.total){
                    this.setState({
                        groupUsersData: {
                            all: messages,
                            total: total,
                            scrollId: scrollId
                        }
                    });
                }
            }
        }
    }

    handleScrollGroupUsers = (event) => {
        if((event.scrollHeight - 20) < (event.clientHeight + event.scrollTop)){
            let length = 0;
            if(Object.keys(this.state.groupUsersData.all).length > 0){
                length = Object.keys(this.state.groupUsersData.all).length;
                //console.log("len =>>>>>>>>>",length);
            }
                          
            let inObj = {
                companyId: 6,
                conferenceName: this.props.sRosterData.active.jid.bare,
                scrollId: this.state.groupUsersData.scrollId
            } 
            
            if(length < this.state.groupUsersData.total){
                this.setState((prevState) => ({
                    groupUsersData: {
                        ...prevState.groupUsersData,
                        all: this.state.groupUsersData.all,
                        total: this.state.groupUsersData.total,
                        scrollId: this.state.groupUsersData.scrollId
                    }
                }), () => {     
                    this.getGroupUsersData(inObj);
                });
            }   
        }
    }

    handleScrollStarMessages = (event) => {
        if((event.scrollHeight - 20) < (event.clientHeight + event.scrollTop)){
            let length = 0;
            if(Object.keys(this.state.favChatData.all).length > 0){
                length = Object.keys(this.state.favChatData.all).length;
                //console.log("len =>>>>>>>>>",length);
            }
                          
            let inObj = {
                type: "isFavourite",
                toJid: this.props.sRosterData.active.jid.bare,
                scrollId: this.state.favChatData.scrollId
            } 
            
            if(length < this.state.favChatData.total){
                this.setState((prevState) => ({
                    favChatData: {
                        ...prevState.favChatData,
                        all: this.state.favChatData.all,
                        total: this.state.favChatData.total,
                        scrollId: this.state.favChatData.scrollId
                    }
                }), () => {     
                    this.getChatMessagesByCategory(inObj);
                });
            }   
        }
    }

    handleScrollAttachmentMessages = (event) => {
        if((event.scrollHeight - 20) < (event.clientHeight + event.scrollTop)){
            let length = 0;
            if(Object.keys(this.state.sharedChatData.all).length > 0){
                length = Object.keys(this.state.sharedChatData.all).length;
                //console.log("len =>>>>>>>>>",length);
            }
                          
            let inObj = {
                type: "isAttachment",
                toJid: this.props.sRosterData.active.jid.bare,
                scrollId: this.state.sharedChatData.scrollId
            } 
            
            if(length < this.state.sharedChatData.total){
                this.setState((prevState) => ({
                    sharedChatData: {
                        ...prevState.sharedChatData,
                        all: this.state.sharedChatData.all,
                        total: this.state.sharedChatData.total,
                        scrollId: this.state.sharedChatData.scrollId
                    }
                }), () => {     
                    this.getChatMessagesByCategory(inObj);
                });
            }   
        }
    }

    render() {
        return (
            [ 
                <Col sm={4} className="rightSidebar" key="right">
                    <Scrollbars className="rightScroll row" style={{ height: '100%' }}
                        autoHide
                        autoHeight
                        autoHeightMin={300}>
                        <ConversationDetails 
                            {...this.props}
                            {...this.state}
                            conversationState = {this.state.conversation}
                            showStarChats = {this.showStarChats}
                            showAttachmentChats = {this.showAttachmentChats}
                            favChatData = {this.state.favChatData}
                            sharedChatData = {this.state.sharedChatData}
                            showGroupChatUsers = {this.showGroupChatUsers}
                            handleScrollStarMessages = {this.handleScrollStarMessages}
                            handleScrollGroupUsers = {this.handleScrollGroupUsers}
                            handleScrollAttachmentMessages = {this.handleScrollAttachmentMessages}
                        />
                    </Scrollbars>
                </Col>,
                <div className="rightOverlay" key="rightOverlay"></div>
            ]
        )
    }
}

export default Right;
