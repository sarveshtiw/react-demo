import React from 'react';

class TopMenu extends React.Component {

    constructor(props) {
        super(props);       
        this.state = {
            topMenu: {
                memberList: false,
                inChat: false,
                popoverMenu: false,
                search: ''
            }
        };
    }

    render() {
        return (
            <div></div>
        )
    }
}

export default TopMenu;
