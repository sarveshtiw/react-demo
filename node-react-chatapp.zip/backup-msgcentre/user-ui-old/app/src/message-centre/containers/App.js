import React from 'react';
import LeftContainer from './leftContainer'
import MiddleContainer from './middleContainer'
import RightContainer from './rightContainer'
import TopMenuContainer from './topMenuContainer'
import EditProfile from './../components/main/editProfile';
import mcContacts from '../lib/contacts';
import mcCommon from "../lib/common";
import configData from '../data/config';
import mucFilter from '../lib/mucfilter';
import '../components/scss/App.scss';
import { GET_LOGGEDIN_USER_INFO } from '../constants/query';
const _ = require('lodash');

class App extends React.Component {

    constructor(props) {
        super(props);
        this.state = {            
            loggedInUser: {
                status: '',
            },
            notificationData: {
                all: [],
                active: {}
            },
            sRosterData: {
                all: {},
                filtered: {},
                active: {},
                contactsPopup: false,
                companyUsers: {}
            },
            groupUsers: [],
            roomsInfo: {
                all: {},
                active: {},
                countRoomMembers: 0,
            },
            roomsData: {
                all: {},
                filtered: {},
            },          
            group: {
                show: false,
                showPopup: false,
                group_name: '',
                group_purpose: ''
            },
            errorGroup: {
                group_name: '',
                group_purpose: ''
            },
            droppedOption: {
                dropped: []
            },
            header: { 
                inviteGroupBox: false, 
                conversationBox: false, 
                moreVertBox: false,  
                addToGroup: false
            },
            search: {
                all: {},
                total: '',
                scrollId: ''
            }
        };
        this.getRooms = this.getRooms.bind(this);
        this.showModal = this.showModal.bind(this);
        this.hideModal = this.hideModal.bind(this);
        this.handleGroupChange = this.handleGroupChange.bind(this);
        this.removeContact = this.removeContact.bind(this);
        this.createGroupChat = this.createGroupChat.bind(this);
        this.leaveGroup = this.leaveGroup.bind(this);
        this.deleteGroup = this.deleteGroup.bind(this);
        this.renameGroup = this.renameGroup.bind(this);
        this.updateGroupPurpose = this.updateGroupPurpose.bind(this); 
        this.onDrop = this.onDrop.bind(this);
    }

    componentWillMount() {
        //all other api's will be called after getting user profile info
        this.getLoggedInUser();
    }

    componentDidMount() {
        document.body.classList.toggle('messageCenter', true)
        //all other api's will be called after getting user profile info
    }

    componentWillReceiveProps(nextProps, nextStates) {
        //for disco caps
        if(JSON.stringify(nextProps.sDiscoCaps) !== JSON.stringify(this.props.sDiscoCaps)) {
            if(nextProps.sCurrentCap.hasOwnProperty('muc')){

            }else{
                let withCaps = mcContacts.manageCaps(this.state.sRosterData.all, nextProps.sDiscoCaps);
                this.setState((prevState) => ({
                    sRosterData: {
                        ...prevState.sRosterData,
                        all: withCaps,                   
                    }
                }));
            }    
        }

        //for new notifications       
        if(nextProps.sNotifications.recentNotifation !== this.props.sNotifications.recentNotifation) {
            this.setState((prevState) => ({
                notificationData: {
                    ...prevState.notificationData,
                    all: [...prevState.notificationData.all, nextProps.sNotifications.recentNotifation],
                    status: isNaN(prevState.notificationData.status) ? 1 : prevState.notificationData.status + 1
                }
            }));
        }

        //manage unread messages
        if(nextProps.sMessages !== this.props.sMessages){

            let lastMessage = Object.values(nextProps.sMessages)[Object.keys(nextProps.sMessages).length-1];            
            if(lastMessage.type === 'groupchat' && this.state.sRosterData.active.jid.bare !== lastMessage.from.bare){                
                this.state.roomsData.all.find((v, i) => {
                    if(v.jid.bare.toLowerCase() === lastMessage.from.bare){                        
                        const rAll = this.state.roomsData.all;                    
                        rAll[i].unread = rAll[i].unread + 1;
                        
                        //update state
                        this.setState((prevState) => ({            
                            roomsData: {
                                ...prevState.roomsData,
                                all: rAll    
                            }
                        }), ()=>{
                            this.playSound();
                        });                        
                    }
                });
            }else if(this.state.sRosterData.active.jid.bare !== lastMessage.from.bare){
                this.state.sRosterData.all.find((v, i) => {
                    if(v.jid.bare === lastMessage.from.bare){
                        const rAll = this.state.sRosterData.all;
                        rAll[i].unread = rAll[i].unread + 1;

                        //update state
                        this.setState((prevState) => ({            
                            sRosterData: {
                                ...prevState.sRosterData,
                                all: rAll
                            }
                        }), ()=>{
                            this.playSound();
                        });
                    }
                });
            }           
        }

        //update conferences on new invitation
        if(Object.keys(nextProps.sMucInvitation).length && nextProps.sMucInvitation !== this.props.sMucInvitation){
            let conferenceObj = mucFilter.addRoom(nextProps.sMucInvitation, this.props.roomsData);
            let conference = this.state.roomsData.all.concat([conferenceObj[0].conference]);
            this.setState((prevState) => ({            
                roomsData: {
                    ...prevState.roomsData,
                    all: conference,
                    filtered: conference
                }
            }), ()=>{
                let displayName = this.state.loggedInUser.displayName;
                let opts = {
                    status: '',                    
                };
                this.props.sObject.joinChannel(conferenceObj, displayName, opts);
            });
        }
    }

    shouldComponentUpdate(nextProps, nextState){
        if((nextProps.sDiscoCaps !== this.props.sDiscoCaps)) {
            return true
        }

        if(nextState.notificationData !== this.state.notificationData){ 
            return true
        }else{
            return true
        }
    }

    //play sound when new message received
    playSound = () => {
        const audio = new Audio("./audio/notification.mp3")
        audio.play()
    }

    //get current loggedin user
    getLoggedInUser = async () => {
        let response = await this.props.sObject.getLoggedInUser();
        if(response.errors) {
            this.setState({
                errorMsg: response.errors
            });
        } else {
            this.setState((prevState) => ({            
                loggedInUser: {
                    ...prevState.loggedInUser,
                    jid: response.data.jid,
                    displayName: response.data.displayName,
                    fullName: response.data.fullName,
                    showtypes: response.data.showtypes,
                    status: response.data.status,
                    userImage: response.data.userImage ? response.data.userImage : '',
                    cid: response.data.cid
                }
            }), ()=>{
                
                //call dependent api's
                this.getRosterData();
                this.getNotifications();
                this.getRooms();
            });
        }        
    }

    //reset notification status
    resetNotificationStatus = () => {
        this.setState((prevState) => ({            
            notificationData: {
                ...prevState.notificationData,
                status: 0
            }
        }));         
    }
    
    //get previous notifications from database
    getNotifications = async () => {        
        let response = await this.props.sObject.getNotifications();
        if(response.status) {            
            this.setState((prevState) => ({            
                notificationData: {
                    ...prevState.notificationData,
                    all: response.data
                }
            }), () => {
                //console.log('1111', this.state.notificationData)
            });
        } else {
            this.setState({
                errorMsg: response.message
            });
        }
    }

    //get roster information
    getRosterData = async () => {      
        let response = await this.props.sObject.getContactsInfo();
        if(response.errors) {
            this.setState({
                errorMsg: response.errors
            });
        } else {
            this.setState((prevState) => ({            
                sRosterData: {
                    ...prevState.sRosterData,
                    all: response,
                    filtered: response,
                    active: Object.keys(response).length ? response[0] : {},
                    sCaps: []
                }
            }), () => {
                //console.log('____', this.state.sRosterData)
            });
        }
    }

    //set active roster.
    updateChatSection = async (value) => {
        //manage unread messages when active changes
        let rAll = {};  
        if(value.hasOwnProperty("autojoin")) {
            let response = await this.props.sObject.getRoomMembers(value.jid.bare);
            if(response.errors) {
                this.setState({
                    errorMsg: response.errors
                });
            } else {
                //update unread message status
                this.state.roomsData.all.find((v, i) => {
                    if(v.jid.bare === value.jid.bare){
                        rAll = this.state.roomsData.all;
                        rAll[i].unread = 0;
                    }
                });
                
                //set state value
                this.setState((prevState) => ({
                    sRosterData: {
                        ...prevState.sRosterData,
                        active: Object.keys(value).length ? value : {},
                    },      
                    roomsData: {
                        ...prevState.roomsData,
                        all: rAll
                    },      
                    roomsInfo: {
                        ...prevState.roomsInfo,
                        all: response.data.getMessageRoomMembers.data,
                        countRoomMembers: response.data.getMessageRoomMembers.data.length
                    },
                }), () => {
                    
                });
            }
        } else {
            //update unread message status
            this.state.sRosterData.all.find((v, i) => {
                if(v.jid.bare === value.jid.bare){
                    rAll = this.state.sRosterData.all;
                    rAll[i].unread = 0;
                }
            });

            //update status
            this.setState((prevState) => ({
                sRosterData: {
                    ...prevState.sRosterData,
                    active: Object.keys(value).length ? value : {},
                    all: rAll
                }
            }))
        }
    }

    //search contacts
    searchContacts = (event) => {
        event.preventDefault();
        
        let rosterdata = mcCommon.searchByText(
            this.state.sRosterData.all, 
            event.target.value,
            ['status', 'showtypes', 'jid']
        );

        let roomdata = mcCommon.searchByText(
            this.state.roomsData.all, event.target.value, 
            ['affiliation', 'autojoin', 'bare', 'jid', 'nick', 'name', 'unread', 'role']
        );
        
        this.setState((prevState) => ({
            sRosterData: {
                ...prevState.sRosterData,
                filtered: rosterdata,
            },
            roomsData: {
                ...prevState.roomsData,
                filtered: roomdata,
            }
        }))
    }

    //set contacts
    handleSelectChange = (e) => {
        this.setState((prevState) => ({
            sRosterData: {
                ...prevState.sRosterData,
                selectValue: e
            }
        }))
    }

    //add contacts
    manageContactsPopup = (event) => {
        this.setState((prevState) => ({
            sRosterData: {
                ...prevState.sRosterData,
                contactsPopup: event ? true : false,
            }
        }))

        //unset popup value
        if(!event){
            this.setState((prevState) => ({
                sRosterData: {
                    ...prevState.sRosterData,
                    selectValue: ""
                }
            }))
        }
    }

    //get all users list in popup
    getUsersList = async () => { 
        let result = await this.props.sObject.getCompanyUsers();    
        let sendInvites = [];
        let contacts = Object.keys(result).length;
        if (contacts) {
            for (let i = 0, l = contacts; i < l; i++) {
                sendInvites.push({ 
                    'label' : result[i].fullName, 
                    'value' : result[i].jid, 
                    'displayName' : result[i].displayName,
                    'showtypes' : result[i].showtypes,
                    'status' : result[i].status,
                    'is_starred' : result[i].is_starred,                    
                    'type' : ''
                });
            }
        }

        this.setState((prevState) => ({
            sRosterData: {
                ...prevState.sRosterData,
                companyUsers: result,
                selectInvites: sendInvites,
            },
            groupUsers: result
        }))       
    }

    //add users to my contact list
    addToContacts = async (e) => { 
        e.preventDefault();       
        if(this.state.sRosterData.selectValue){
            let contacts = this.state.sRosterData.selectValue.split(",");
            let response = await this.props.sObject.addToMyContact(contacts);
            if(response.status){
                const result = mcContacts.manageUserContacts(this.state.sRosterData, contacts, response);
                this.setState((prevState) => ({            
                    sRosterData: {
                        ...prevState.sRosterData,
                        all: result,
                        filtered: result,
                        active: Object.keys(result).length ? result[0] : {},
                        sCaps: []
                    }
                }), () => {
                    this.manageContactsPopup(0);
                });
            }else{
                this.setState({
                    errorMsg: response.message
                });
            }
        }        
    } 
    
    //update roster value
    updateRosterState = (key, value) => {
        if(this.state.sRosterData.active.hasOwnProperty('autojoin')){
            this.state.roomsData.all.find((v, i) => {
                if(v.jid.bare === this.state.sRosterData.active.jid.bare){
                    const rAll = this.state.roomsData.all;
                    rAll[i][key] = value;

                    //update state
                    this.setState((prevState) => ({            
                        roomsData: {
                            ...prevState.roomsData,
                            all: rAll                                  
                        },
                        sRosterData: {
                            ...prevState.sRosterData,
                            active: {...prevState.sRosterData.active,
                                [key]: value       
                            }  
                        }
                    }));
                }else{
                    return null;
                }
            });
        }else{
            this.state.sRosterData.all.find((v, i) => {
                if(v.jid.bare === this.state.sRosterData.active.jid.bare){
                    const rAll = this.state.sRosterData.all;
                    rAll[i][key] = value;

                    //update state
                    this.setState((prevState) => ({            
                        sRosterData: {
                            ...prevState.sRosterData,
                            all: rAll,
                            active: {...prevState.sRosterData.active,
                                [key]: value       
                            }  
                        }
                    }),()=>{
                        //console.log('-=-=-=-=-=-', this.state.sRosterData);
                    });
                }else{
                    return null;
                }
            });
        }
    }

    //set user as starred
    setUserStar = async () => {
        let is_starred = this.state.sRosterData.active.is_starred === true ? false : true;  
        let fields = [{"key": "is_starred", "value": is_starred}];
              
        let response = await this.props.sObject.updateContacts(this.state.sRosterData.active, fields);
        
        if(response.status){
            this.updateRosterState("is_starred", is_starred);       
        }else{
            this.setState({
                errorMsg: response.error
            });
        }    
    }

    async getRooms() {
        const getRoomsObj = {
            companyId: this.state.loggedInUser.cid,
            jid: this.props.sObject.sClient.config.jid.bare
        }; 
        if(!mcCommon.ckeckIsEmpty(getRoomsObj)) {  
            let response = await this.props.sObject.getRooms(getRoomsObj);
            if(response.status) {
                this.setState({
                    roomsData: {
                        all: response.data,
                        filtered: response.data                       
                    }
                });                
            } else {
                this.setState({
                    errorMsg: response.errors
                });
            }
        }
    }

    async createGroupChat(e) {
        e.preventDefault();
        const groupName = this.state.group.group_name.toLowerCase();
        const groupPurpose = this.state.group.group_purpose;
        const inviteUsers = this.state.droppedOption.dropped; //this.state.group.value.split(',');
        
        let errorConference = this.state.errorGroup;
        let roomExists = await this.props.sObject.getRoomMembers(groupName + configData.GROUP_DOMAIN);
        let countMembers = !roomExists.errors ? roomExists.data.getMessageRoomMembers.data.length : 0;
        let validation = mcCommon.groupValidation(this.state.group, countMembers);
        if(validation.error) {
            this.setState((prevState) => ({   
                errorGroup: {
                    ...prevState.errorGroup,
                    group_name: validation.group_name,
                    group_purpose: validation.group_purpose
                }
            }));  

        } else{

            if (inviteUsers) {
                const response = await this.props.sObject.createRoom(groupName,groupPurpose,inviteUsers);
                if(!response.status) {
                    this.setState({
                        errorMsg: response.message
                    });
                } else {             
                    let conference = this.state.roomsData.all.concat([response.data]);
                    this.setState((prevState) => ({            
                        roomsData: {
                            ...prevState.roomsData,
                            all: conference,
                            filtered: conference
                        }
                    }));  
                }      
            }

            this.setState((prevState) => ({            
                group: {
                    ...prevState.group,
                    group_name: '',
                    group_purpose: '',
                    show: false
                },
                groupUsers: this.state.sRosterData.companyUsers,
                droppedOption: {
                    dropped: []
                },
                errorGroup: {
                    ...prevState.errorGroup,
                    group_name: "",
                    group_purpose: ""
                }
            }));
        }
    }   

    async leaveGroup(roomVal) {
        let groupName = this.state.roomsData.all[roomVal].bare || this.state.roomsData.all[roomVal].jid.bare;
        if(groupName !== 'undefined') {  
            let displayName = this.props.sObject.sClient.config.jid.bare;
            let leaveParams = { 
                companyId: this.state.loggedInUser.cid,
                jid: displayName,
                conferenceName: groupName,
                conferenceFields: [{key: "isDelete", value:"true"}]
            };
            let response = await this.props.sObject.updateRoom(leaveParams);
            if(response.errors) {
                this.setState({
                    errorMsg: response.errors
                });
            } else {
                let roomArr = this.state.roomsData.all;
                roomArr = roomArr.filter(value => value !== this.state.roomsData.all[roomVal]);
                this.setState((prevState) => ({            
                    roomsData: {
                        ...prevState.roomsData,
                        all: roomArr,
                        filtered: roomArr
                    }
                }));    
            }
        }
    }

    async deleteGroup(roomVal) {
        let groupName = this.state.roomsData.all[roomVal].bare || this.state.roomsData.all[roomVal].jid.bare;
        if(groupName !== 'undefined') {  
            let deleteParams = { 
                companyId: this.state.loggedInUser.cid,
                conferenceName: groupName
            };
            let response = await this.props.sObject.deleteRoom(deleteParams);
            //console.log("response",response)
            if(response.status) {
                let roomArr = this.state.roomsData.all;
                roomArr = roomArr.filter(value => value !== this.state.roomsData.all[roomVal]);

                this.setState((prevState) => ({            
                    roomsData: {
                        ...prevState.roomsData,
                        all: roomArr,
                        filtered: roomArr
                    }
                }));                  
            } else {
                this.setState({
                    errorMsg: response.message
                });
            }
        }
    }

    async renameGroup(value){
        const group_name = this.state.roomsData.all[value].bare;
        const group_purpose = this.state.roomsData.all[value].description;
        
        if (group_name !== 'undefined') {
            this.setState((prevState) => ({            
                group: {
                    ...prevState.group,
                    group_name: group_name,
                    group_purpose: group_purpose,
                    keyIndex: value,
                    showPopup: true
                }
            }));
            this.showModal();
        }
    }

    async updateGroupPurpose(e) {
        e.preventDefault();
        const roomVal = this.state.group.keyIndex;
        const groupName = this.state.roomsData.all[roomVal].bare || this.state.roomsData.all[roomVal].jid.bare;
        const groupPurpose = this.state.group.group_purpose;
        let errorConference = this.state.errorGroup;
        let validation = mcCommon.editGroupValidation(this.state.group);
        if(validation.error) {
            this.setState((prevState) => ({   
                errorGroup: {
                    ...prevState.errorGroup,
                    group_purpose: validation.group_purpose
                }
            }));  

        } else{
            if(groupName !== 'undefined') {  
                let displayName = this.props.sObject.sClient.config.jid.bare;
                let updateParams = { 
                    companyId: this.state.loggedInUser.cid,
                    jid: displayName,
                    conferenceName: groupName,
                    conferenceFields: [{key: "description", value: groupPurpose}]
                };
                let response = await this.props.sObject.updateRoom(updateParams);           
                if(response.errors) {
                    this.setState({
                        errorMsg: response.errors
                    });
                } else {
                    let roomArr = this.state.roomsData.all;
                    let updateRoomArr = [];
                    roomArr.forEach(function(roomValue, keyIndex) {
                        if(keyIndex === roomVal) {
                            let prevStateValue = {
                                affiliation: roomArr[roomVal].affiliation,
                                autojoin: roomArr[roomVal].autojoin,
                                bare: roomArr[roomVal].bare,
                                description: groupPurpose,
                                jid: roomArr[roomVal].jid,
                                local: roomArr[roomVal].local,
                                name: roomArr[roomVal].name,
                                nick: roomArr[roomVal].nick,
                                role: roomArr[roomVal].role,
                                unread: roomArr[roomVal].unread,
                                type: roomArr[roomVal].type || ''
                            }
                            updateRoomArr[keyIndex] = prevStateValue;
                        } else {
                            updateRoomArr[keyIndex] = roomValue;
                        }
                    });
                    this.setState((prevState) => ({            
                        roomsData: {
                            ...prevState.roomsData,
                            all: updateRoomArr,
                            filtered: updateRoomArr
                        }
                    }));  
                }
            }
            this.hideModal(); 
        }
    }


    showModal() {
        this.setState((prevState) => ({
            group: {
                ...prevState.group,
                show: true
            }
        }))
    };

    hideModal() {
        this.setState((prevState) => ({
            group: {
                ...prevState.group,
                show: false,
                showPopup: false
            },
            droppedOption: {
                dropped: []
            },
            groupUsers: this.state.sRosterData.companyUsers,
            errorGroup: {
                ...prevState.errorGroup,
                group_name: "",
                group_purpose: ""
            }
        }))
    };
    
    onToggle() {
        this.setState((prevState) => ({
            group: {
                ...prevState.group,
                toggleActive: !prevState.group.toggleActive,
            }
        }))
    }

    onDrop(event) {
        let arrStr = event.contacts.split('?');
        let index = parseInt(arrStr[1]);
        let stringToJson = JSON.parse(arrStr[0]);
        let droppedOption = this.state.droppedOption;
        droppedOption.dropped = droppedOption.dropped.concat([stringToJson]);
        let groupUsers = this.state.groupUsers;
        groupUsers = groupUsers.filter(value => value !== this.state.groupUsers[index]);
        this.setState({
            droppedOption,
            groupUsers
        });
    }

    removeContact(row, index) {
        let groupUsers = this.state.groupUsers;
        groupUsers = groupUsers.concat([row]);
        let droppedOption = this.state.droppedOption;
        droppedOption.dropped = droppedOption.dropped.filter((s, sidx) => parseInt(index) !== sidx);
        this.setState({
            droppedOption,
            groupUsers
        });
    }

    //search contacts
    searchGroupChatContacts = (event) => {
        event.preventDefault();
        let groupUsers = mcCommon.searchByText(
            this.state.groupUsers, 
            event.target.value, 
            ['affiliation', 'autojoin', 'bare', 'jid', 'nick', 'name', 'unread', 'role']
        );

        if(event.target.value !== "") {
            this.setState({ groupUsers });
        } else {
            let groupUsers = this.state.sRosterData.companyUsers;
            this.setState({ groupUsers });
        }
    }

    handleGroupChange(e) {
        let name = e.target.name;
        let value = e.target.value;
        if("group_name" === name) {
            value = e.target.value.replace(/\s/g,'-');
        }

        this.setState((prevState) => ({            
            group: {
                ...prevState.group,
                [name]: value
            }
        }));
    }
    
    //track changes in input fields and set values
    handleUserStatusChange = async (status, e) => { 
        if(status){
            //types: One of: available, unavailable, error, probe, subscribe, subscribed, unsubscribe, and unsubscribed.
            //showtypes: One of: away, chat, dnd, and xa (extended away)
            let updateParams = [{"key": "showtypes", "value": status}];
            let response = await this.props.sObject.updateUserProfileInfo(updateParams);           
            if(response.status) {
                this.setState((prevState) => ({  
                    loggedInUser: {
                        ...prevState.loggedInUser,
                        showtypes: status
                    }
                }));                
            }else{
                this.setState({
                    errorMsg: response.message
                });
            } 
        }else{
            var element = e.target.value;
            this.setState((prevState) => ({
                loggedInUser: {
                    ...prevState.loggedInUser,
                    status: element
                }
           }))
        }
    }

    favOpen = () => {
        this.setState((prevState) => ({
            header: { 
                ...prevState.header,
                inviteGroupBox: !prevState.header.inviteGroupBox,
                conversationBox: false,
                moreVertBox: false
            }
        }));
    }

    infoOpen = () => {
        this.setState((prevState) => ({
            header: { 
                ...prevState.header,
                inviteGroupBox: false,
                conversationBox: !prevState.header.conversationBox,
                moreVertBox: false,
                searchBox: false
            }
        }));
    }

    settOpen = () => {
        this.setState((prevState) => ({
            header: { 
                ...prevState.header,
                inviteGroupBox: false,
                conversationBox: false,
                moreVertBox: true
            }
        }));
    }

    addToGroup = (i) => {
        this.setState((prevState) => ({
            header: { 
                ...prevState.header,
                inviteGroupBox: !this.state.header.inviteGroupBox,
                addToGroup: !this.state.header.addToGroup
            }
        }));
    }

    //close right panel
    closePanel = () => {
        this.setState((prevState) => ({
            header: { 
                ...prevState.header,
                conversationBox: false
            }
        }));
    }

    handleSearch = async (e) => {
        e.preventDefault();
        this.setState((prevState) => ({
            header: { 
                ...prevState.header,
                conversationBox: true,
                searchBox: true
            }
        }));       

        let data = {
            active: this.state.sRosterData.active,
            scrollId: '',
            search: e.target.searchinput.value          
        }
        let response = await this.props.sObject.searchMessages(data);
        if(response.status){
            this.setState((prevState) => ({
                search: { 
                    ...prevState.search,
                    all: response.data.data,
                    total: response.total,
                    scrollId: response.scrollId
                }
            }));
        }else{
            this.setState({
                errorMsg: response.message
            });
        }
    }

    render() {      
        let conversationBox = this.state.header.conversationBox;
        return (
            <div className='middleArea'>
                <div className="msgApp">
                    <LeftContainer
                        {...this.props} 
                        {...this.state}                       
                        resetNotificationStatus = {this.resetNotificationStatus}
                        getUsersList = {this.getUsersList}
                        addToContacts = {this.addToContacts}
                        manageContactsPopup = {this.manageContactsPopup}
                        handleSelectChange = {this.handleSelectChange}
                        searchContacts = {this.searchContacts}
                        updateChatSection = {this.updateChatSection}
                        createGroupChat = {this.createGroupChat}
                        leaveGroup = {this.leaveGroup}
                        deleteGroup = {this.deleteGroup}
                        renameGroup = {this.renameGroup}
                        updateGroupPurpose = {this.updateGroupPurpose}
                        showModal = {this.showModal} 
                        hideModal = {this.hideModal}
                        handleGroupChange = {this.handleGroupChange}         
                        removeContact = {this.removeContact}           
                        onDrop = {this.onDrop}
                        errorGroup = {this.state.errorGroup}
                        searchGroupChatContacts = {this.searchGroupChatContacts}
                        handleUserStatusChange = {this.handleUserStatusChange}  />

                    <div className="col-sm-9 msgMain">
                        <TopMenuContainer {...this.props} />

                        {this.state.editProfile ?
                            <EditProfile  {...this.state} /> :

                            <MiddleContainer
                                {...this.props}
                                {...this.state}
                                headerState = {this.state.header}
                                favOpen = {this.favOpen} 
                                settOpen = {this.settOpen}
                                infoOpen = {this.infoOpen} 
                                addToGroup = {this.addToGroup}
                                resetNotificationStatus = {this.resetNotificationStatus}
                                setUserStar = {this.setUserStar}
                                updateRosterState = {this.updateRosterState}
                                handleSearch = {this.handleSearch} />
                        }

                        {conversationBox ?
                        <RightContainer
                            {...this.props}  
                            {...this.state}
                            closePanel = {this.closePanel}
                            handleSearch = {this.handleSearch} />
                        : '' }
                    </div>
                </div>
            </div>
        )
    }
}

export default App;