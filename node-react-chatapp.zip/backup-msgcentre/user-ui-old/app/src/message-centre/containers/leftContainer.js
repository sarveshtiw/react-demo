import React, { Component } from 'react';
import LeftSection from '../components/left';

class LeftContainer extends Component {

    constructor(props) {
        super(props);
        this.state = {
            filter: {
                all: true,
                unread: false,
                starred: false,
                archive: false
            },
            header: {
                notify: false,
                notification: '',
                notificationStatus: 0,
                showEmojiBox: false,
                showDialogBox: false,
                confMenu: false,
                subMenu: false,
                userquote: '',
                userstatus: ''
            }
        };
        this.handleClick = this.handleClick.bind(this);
        this.subDropDown = this.subDropDown.bind(this);
        this.showEmojiPicker = this.showEmojiPicker.bind(this);
        this.showConfMenu = this.showConfMenu.bind(this);
        this.setEmoji = this.setEmoji.bind(this);
        this.showUserStatus = this.showUserStatus.bind(this);
        this.manageOutsideClick = this.manageOutsideClick.bind(this);
    }

    componentWillMount() {
        //console.log("called");
    }

    componentDidMount() {

    }

    componentWillUpdate(nextProps, nextState) {
        //console.log("WillUpdate", nextProps, nextState);  
    }

    componentDidUpdate(prevProps, prevState) {
        //console.log("called");        
    }

    componentDidCatch(error, info) {
        //console.log("error", error, info);
    }

    componentWillReceiveProps(nextProps) {
        /*
        //for user images
        if(nextProps.sAvatar !== this.props.sAvatar) {
            let withAvatar = mcContacts.manageAvatars(this.state.sRosterData.all, nextProps.sAvatar);
            console.log(withAvatar);
            
            this.setState((prevState) => ({
                sRosterData: {
                    ...prevState.sRosterData,
                    all: allRosters,                   
                }
            }));            
        }
        
        this.setState({
            groupUsers: nextProps.groupUsers
        });   */
    }

    setValue = (event, field) => {
        var object = {};
        object[field] = event.target.value;
        this.setState(object);
    }

    //filter contacts
    filterButtons = (objName) => {
        this.setState((prevState) => ({
            filter: {
                ...prevState.filter,
                all: objName === 'all' ? true : false,
                unread: objName === 'unread' ? true : false,
                starred: objName === 'starred' ? true : false,
                archive: objName === 'archive' ? true : false
            }
        }))
    }

    notify() {
        this.setState((prevState) => ({
            header: {
                ...prevState.header,
                notify: !prevState.header.notify
            }
        }))
    }

    handleClick() {
        this.setState((prevState) => ({
            header: {
                ...prevState.header,
                isShow: !prevState.header.isShow
            }
        }))
    }

    subDropDown() {
        this.setState((prevState) => ({
            header: {
                ...prevState.header,
                showDialogBox: !prevState.header.showDialogBox
            }
        }))
    }

    //toggle dropdown
    showConfMenu() {
        this.setState((prevState) => ({
            header: {
                ...prevState.header,
                confMenu: !prevState.header.confMenu
            }
        }))
    }

    //open/close user status subdropdown
    showUserStatus() {
        this.setState((prevState) => ({
            header: {
                ...prevState.header,
                subMenu: !prevState.header.subMenu
            }
        }))
    }

    //toggle popup
    showEmojiPicker() {
        this.setState((prevState) => ({
            header: {
                ...prevState.header,
                showEmojiBox: !prevState.header.showEmojiBox
            }
        }))
    }

    //set emoji on selection
    setEmoji(emoji) {
        this.setState((prevState) => ({
            header: {
                ...prevState.header,
                userquote: prevState.header.userquote + ' ' + emoji.native
            }
        }))
    }

    //set user status
    setUserStatus = async (e) => {
        e.preventDefault();
        let updateParams = [{"key": "status", "value": this.props.loggedInUser.status}];
        let response = await this.props.sObject.updateUserProfileInfo(updateParams);           
        if(!response.status) {
            this.setState({
                errorMsg: response.message
            });                
        }
    }

    // ..handling code goes here...
    manageOutsideClick() {
        this.setState((prevState) => ({
            header: {
                ...prevState.header,
                //isShow: prevState.header.isShow ? !prevState.header.isShow : prevState.header.isShow,
                //notify: prevState.header.notify ? !prevState.header.notify : prevState.header.notify,
                //confMenu: prevState.header.confMenu ? !prevState.header.confMenu : prevState.header.confMenu,
                subMenu: prevState.header.subMenu ? !prevState.header.subMenu : prevState.header.subMenu,
            }
        }))
    }

    render() {
        return (
            <LeftSection
                {...this.props}
                {...this.state}
                setValue={this.setValue}
                filterButtons={this.filterButtons}
                notify={this.notify}
                showEmojiPicker={this.showEmojiPicker}
                showConfMenu={this.showConfMenu}
                setUserStatus={this.setUserStatus}
                showUserStatus={this.showUserStatus}
                setEmoji={this.setEmoji}
                manageOutsideClick={this.manageOutsideClick} />
        )
    }
}

export default LeftContainer;