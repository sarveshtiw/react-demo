import React, {Component} from 'react';
import ChatMain from '../components/main';
import messageFilter from '../lib/messagefilter';
import mcContacts from '../lib/contacts';
import { GET_URL_INFO } from '../constants/query';
import mcCommon from '../lib/common';
import {
    toast
} from 'react-toastify';
import Toaster from "../../common/containers/toaster";
var _ = require('lodash');

class Middle extends Component {
    constructor(props) {
        super(props);
        this.state = {
            chat: {
                all:{},
                search:{},
                editmessage:{},
                history:{},
                message:'',
                oldMessage: {},
                loading: false,
                emojiPicker: false,
                dropzoneActive: false,
                url_meta_info: false,
                favourite: false,
                editMode: false,
            },
            roster: {
                clickedRoster:'',
                rosterValues:''
            },
            notification: {
                all:[],
                active:[],
                users:[]
            },
            topMenu: {
                search: ''
            },
            inviteModal: false,
            inviteMembers: [
                {
                    email: '',
                    name: ''
                },
                {
                    email: '',
                    name: ''
                },
                {
                    email: '',
                    name: ''
                }
            ],
            errorInvites: {
                errors: [{
                    email: "",
                    name: ""
                },{
                    email: "",
                    name: ""
                },{
                    email: "",
                    name: ""
                }]
            },
            shareLocation:{
                error: "",
                msgLocation: false
            }
        }
        this.handleSubmit = this.handleSubmit.bind(this);
        this.getUrlMetaData = this.getUrlMetaData.bind(this);
        this.handleTextareaKeypress = this.handleTextareaKeypress.bind(this);
        this.addNewInviteMember = this.addNewInviteMember.bind(this);
        this.deleteInviteMember = this.deleteInviteMember.bind(this);
        this.inviteModalHandle = this.inviteModalHandle.bind(this);
        this.handleInviteInputChange = this.handleInviteInputChange.bind(this);
        this.sendInviteModalClick = this.sendInviteModalClick.bind(this);
    }


    componentWillMount() {
        //console.log("called");
    }

    componentDidMount() {
        //console.log("called");
    }

    componentWillUpdate(nextProps, nextState) {
        //console.log("WillUpdate", nextProps, nextState);
    }

    componentDidUpdate(prevProps, prevState) {
        //console.log("called");
    }

    componentDidCatch(error, info) {
        //console.log("error", error, info);
    }

    componentWillReceiveProps(nextProps) {
        //check if roster data is updated
        if (nextProps.sRosterData.all !== this.props.sRosterData.all) {
            let rosterData = [];

            _.each(nextProps.sRosterData.all, function (item, i) {
                rosterData.push({
                    id: item.jid.bare,
                    display: item.fullName ? item.fullName : item.displayName
                });
            });

            this.setState((prevState) => ({
                roster: {
                    ...prevState.roster,
                    rosterValues: rosterData
                }
            }));
        }

        //check if there is any change in messages
        if(nextProps.sMessages !== this.props.sMessages){
            //manage chat messages
            let lastMessage = Object.values(nextProps.sMessages)[Object.keys(nextProps.sMessages).length-1];
            const jid = lastMessage.from.bare;
            const mid = lastMessage.createdOn;
            lastMessage.from.name = lastMessage.from.resource; //name of the user that he is using for chat
            lastMessage.to.name = lastMessage.to.local;
            lastMessage.isDeleted = false;
            lastMessage.isLocation = false;
            if(lastMessage.hasOwnProperty('messageAttribute')){
                if(lastMessage.isDeleted = lastMessage.messageAttribute.key === 'isDeleted'){
                    lastMessage.isDeleted = true;
                
                } else if(lastMessage.isLocation = lastMessage.messageAttribute.key === 'isLocation'){
                    lastMessage.isLocation = true;
                }
            }

            var messages = {
                ...this.state,
                chat: {...this.state.chat,
                    all:{...this.state.chat.all,
                        [jid]: {...this.state.chat.all[jid],
                            [mid]: lastMessage,
                        }
                    }
                },
            }
            
            this.setState(messages, () => {
                this.setScrollerToBottm();
            });
        }

        //check active roster has been updated
        if (Object.keys(nextProps.sRosterData.active).length && (nextProps.sRosterData.active !== this.props.sRosterData.active)) {
            //update chat data
            this.setState((prevState) => ({
                chat: {
                    ...prevState.chat,
                    loading: true,
                }
            }), () => {
                this.getChatHistoryMessages(nextProps.sRosterData.active);
            });

            //update mention users
            if(this.state.roster.rosterValues.length){
                let rValues = mcContacts.getMetionsUsers(this.state.roster.rosterValues, nextProps.sRosterData.active);
                this.setState((prevState) => ({
                    roster: {...prevState.roster,
                        rosterValues: rValues
                    }
                }));
            }
        }
    }

    shouldComponentUpdate(nextProps, nextState){
        if(nextState.chat.all !== this.state.chat.all){
            return true
        }else{
            return true
        }
    }

    handleInviteInputChange(e, id){
        let name = e.target.dataset.name;
        let value = e.target.value;
        this.setState((prevState)=>{
            let a = [...prevState.inviteMembers];
            a[id][name] = value;
            return {
                inviteMembers: a
            }
        })
    }

    // add new invite member
    addNewInviteMember(){
        this.setState((prevState)=>{
            let a = [...prevState.inviteMembers];
            a.push({email:'',name:''})
            return {
                inviteMembers: a
            }
        })
    }

    // delete invite member
    deleteInviteMember(id){
        this.setState((prevState)=>{
            let a = [...prevState.inviteMembers];
            a.splice(id, 1)
            return {
                inviteMembers: a
            }
        })
    }

    // invite modal handel close and open
    inviteModalHandle(){
        this.setState((prevState)=>{
            return {
                inviteModal: !prevState.inviteModal
            }
        })
    }

    // send invite modal submit data
    async sendInviteModalClick(e) {
        e.preventDefault();
        const inviteMembers = this.state.inviteMembers;
        let errorInvites = this.state.errorInvites;
        let confFullName =  this.props.sRosterData.active.jid.bare ? this.props.sRosterData.active.jid.bare : this.props.sRosterData.active.jid.bare;
        let existMembersData = await this.props.sObject.getRoomMembers(confFullName);
        if(existMembersData.errors) {
            toast(<Toaster notifyType="error"
                msg="some error occured" />, {
                    position: toast.POSITION.BOTTOM_RIGHT,
                    hideProgressBar: true
            });
        } else {
            let existMembersJid = existMembersData.data.getMessageRoomMembers.data;
            let existMembers = [];
            Object.keys(existMembersJid).forEach(key => {
                var val = existMembersJid[key]["jid"];
                existMembers.push(val);
            });
            let validation = mcCommon.sendInvitesValidation(inviteMembers,existMembers);
            if(validation.status) {
                this.setState((prevState) => ({   
                    errorInvites: {
                        ...prevState.errorInvites,
                        errors: validation.errors,
                    }
                }));  

            } else{

                if (inviteMembers) {
                    let confName = this.props.sRosterData.active.local ? this.props.sRosterData.active.local : this.props.sRosterData.active.nick;
                    let groupPurpose = this.props.sRosterData.active.description ? this.props.sRosterData.active.description : this.props.sRosterData.active.local + ' group';
                    let fromEmail = this.props.loggedInUser.jid;
                    let fromName = this.props.loggedInUser.displayName;
                    let obj = {
                        confName: confName,
                        from: {email: "ravi.kant@asergis.in", name: fromName},
                        inviteMembers: inviteMembers
                    }
                    const response = await this.props.sObject.sendInvites(obj);
                    if(!response.status) {
                        toast(<Toaster notifyType="error"
                            msg={response.message} />, {
                                position: toast.POSITION.BOTTOM_RIGHT,
                                hideProgressBar: true
                        });
                    } else {   
                        const resp = await this.props.sObject.createExternalUserRoom(confName,groupPurpose,inviteMembers);
                        if(!resp.status) {
                            toast(<Toaster notifyType="error"
                                msg={resp.message} />, {
                                    position: toast.POSITION.BOTTOM_RIGHT,
                                    hideProgressBar: true
                            });
                        } else {       
                            toast(<Toaster notifyType="success"
                                msg={response.message} />, {
                                    position: toast.POSITION.BOTTOM_RIGHT,
                                    hideProgressBar: true
                            });
                        }
                    }   
                }

                this.setState((prevState) => ({   
                    inviteModal: false,        
                    inviteMembers: [{
                            email: '',name: ''
                        },{
                            email: '',name: ''
                        },{
                            email: '',name: ''
                        }
                    ],
                    errorInvites: {
                        errors: [{
                            email: '',name: ''
                        },{
                            email: '',name: ''
                        },{
                            email: '',name: ''
                        }]
                    }
                }));
                
            }
        }
    }

    //get messages from chat history
    getChatHistoryMessages = async (active, sid=false) => {
        let data = {
            fromJid: active.jid.bare,
            scrollId: sid ? sid : '',
            type: active.hasOwnProperty('autojoin') ? 'groupchat' : 'chat',
            fromDate: active.fromDate,
            archiveDate: active.archiveDate
        }

        let response = await this.props.sObject.getChatHistory(data);
        if(response.status){
            let messages = messageFilter.manageHistory(
                Object.assign([], response.data.data).reverse(), active, this.state.chat
            );

            this.setState((prevState) => ({
                chat: {
                    ...prevState.chat,
                    all: messages,
                    total: response.data.total,
                    scrollId: response.data.scrollId,
                    loading: false,
                }
            }), () => {
                //scroll to bottom
                if(!data.scrollId){
                    this.setScrollerToBottm();
                }
                this.getHttpUrlMetaInfo(active.jid.bare,messages);
            });
        }
    }

    //scroll to bottom
    setScrollerToBottm = () => {
        setTimeout(function() {
            this.refs.bars.refs.cmain.refs.scrollbars.scrollToBottom();
        }.bind(this), 0);
    }

    // get Http URL's meta Info
    getHttpUrlMetaInfo = async (jid,messages) => {
        let fileObjectData = messages.fileObject;
        let chatMessages = messages[jid];
        let response = await this.props.client.query({
            query: GET_URL_INFO,
            variables: { input: {fileObject: fileObjectData} }
        });
        if(response.errors) {
            this.setState({
                errorMsg: response.message
            });
        } else {
            let httpUrlData = [];
            _.each(response.data.getMessageScraperUrlInfo.data, function(message) {
                let chatId = message.chatId;
                httpUrlData[chatId] = message;
            });
            let self = this;
            _.each(chatMessages, function(chatObj) {
                let chatId = chatObj.id;
                let newChatObj = Object.assign({}, chatObj);
                if(httpUrlData.hasOwnProperty(chatId)) {
                    newChatObj.url_meta_info = [httpUrlData[chatId]];
                    self.addMessageToState(newChatObj, newChatObj.createdOn, 0);
                }
            });
        }
    }

    //on submit send message
    handleSubmit(e) {
        e.preventDefault();
        this.sendMessage();
    }

    //set mention input value
    handleMentionChange = (e) => {
        this.setState((prevState) => ({
            chat: {
                ...prevState.chat,
                message: e.target.value
            }
        }));
    }

    //on enter press send text message
    handleTextareaKeypress(e){
        if (e.which === 13 && !e.shiftKey){
            e.preventDefault();
            this.sendMessage();
        }
    }

    //handling validation and message sending
    async sendMessage(){
        let date = new Date();
        let toName = this.props.sRosterData.active.local ? this.props.sRosterData.active.local : this.props.sRosterData.active.jid.local;
        if(this.state.chat.message.trim()){
            const oldMessage = this.state.chat.oldMessage;
            let chatObj = {
                id: Object.keys(oldMessage).length > 0 ? oldMessage.id : 'synthesis' + date.getTime(),
                to: {
                    name: this.props.sRosterData.active.hasOwnProperty('autojoin') ? toName : this.props.sRosterData.active.displayName,
                    jid: this.props.sRosterData.active.jid.bare ? this.props.sRosterData.active.jid.bare : '',
                },
                from: {
                    name: this.props.loggedInUser.displayName,
                    jid: this.props.sObject.sClient.config.jid.bare,
                },
                type: this.props.sRosterData.active.hasOwnProperty('autojoin') ? 'groupchat' : 'chat',
                body: this.state.chat.message.trim(),
                createdOn: Object.keys(oldMessage).length ? oldMessage.createdOn : date.getTime(),
                requestReceipt: true,
                chatState: 'active',
                oldMessage: oldMessage,
                isAttachment: false,
                isEdited: Object.keys(oldMessage).length ? true : false,
                isFavourite: Object.keys(oldMessage).length && oldMessage.isFavourite ? oldMessage.isFavourite : false,
                isDeleted: false,
                isLocation: this.state.shareLocation.msgLocation === true ? true : false
            };
            let response;
            if(Object.keys(oldMessage).length > 0){
                response = await this.props.sObject.updateChat(chatObj, this.state.notification.users, this.props.roomsInfo.all, this.props.sRosterData.all);
            }else{
                response = await this.props.sObject.saveChat(chatObj, this.state.notification.users, this.props.roomsInfo.all, this.props.sRosterData.all);
            }

            if(!response.status) {
                this.setState({
                    errorMsg: response.message
                });
            } else {
                //add message to state for rendring
                chatObj.id = Object.keys(oldMessage).length > 0 ? chatObj.id : 'synthesis' + response.data.createdOn;
                this.addMessageToState(chatObj, response.data.createdOn);
            }
        }
    }

    //handle messages container scrolling
    handleScroll = (event) => {
        if(event.scrollTop <= 0) {
            let length = 0;

            if(this.state.chat.all.hasOwnProperty(this.props.sRosterData.active.jid.bare)){
                length = Object.keys(this.state.chat.all[this.props.sRosterData.active.jid.bare]).length;
            }

            if(length < this.state.chat.total && !this.state.chat.loading){
                this.setState((prevState) => ({
                    chat: {
                        ...prevState.chat,
                        loading: true,
                    }
                }), () => {
                    this.getChatHistoryMessages(this.props.sRosterData.active, this.state.chat.scrollId);
                });
            }
        }
    }

    fileOnChange = async(e) => {
        //console.log("file =>>>>>>>>>>",e,e.target.files[0]);
        e.preventDefault();
        let date = new Date();
        let attachmentType = "";
        let fileName = e.target.files[0].name;
        let fileType = fileName.split('.');
        attachmentType = fileType[fileType.length - 1];
        let checkExtension = mcCommon.checkFileExtension(attachmentType);
        if(checkExtension) {
            toast(<Toaster notifyType="error"
                        msg="File extensions not allowed, please upload another image." />, {
                            position: toast.POSITION.BOTTOM_RIGHT,
                            hideProgressBar: true
                        });
        } else{
            let chatObj = {
                id: 'synthesis' + date.getTime(),
                to: {
                    name: this.props.sRosterData.active.hasOwnProperty('autojoin') ? this.props.sRosterData.active.local : this.props.sRosterData.active.displayName,
                    jid: this.props.sRosterData.active.jid.bare ? this.props.sRosterData.active.jid.bare : '',
                },
                from: {
                    name: this.props.loggedInUser.displayName,
                    jid: this.props.sObject.sClient.config.jid.bare,
                },
                type: this.props.sRosterData.active.hasOwnProperty('autojoin') ? 'groupchat' : 'chat',
                body: "",
                createdOn: date.getTime(),
                requestReceipt: true,
                chatState: 'active',
                isAttachment: true,
                oldMessage: '',
                isEdited: false,
                isFavourite: false,
                isDeleted: false,
                isLocation: false
            };

            let response = await this.props.sObject.sendAttachment(chatObj, e.target.files[0]);
            if(response.status) {
                let newChatObj = response.data;
                newChatObj.body = newChatObj.filePath;
                newChatObj.isDeleted = false;
                //add message to state for rendring
                newChatObj.id = 'synthesis' + response.createdOn;
                this.addMessageToState(newChatObj, response.createdOn, 0);
            } else {
                toast(<Toaster notifyType="error"
                    msg={response.message} />, {
                        position: toast.POSITION.BOTTOM_RIGHT,
                        hideProgressBar: true
                });
            }
        }
    }

    //add message to state for rendring
    addMessageToState = (chatObj, createdOn, getMeta=1, isScroll=true) => {
        chatObj['createdOn'] = createdOn ? createdOn : chatObj.createdOn;
        const jid = chatObj.to.jid;
        const mid = Number(createdOn);        

        var messages = {
            ...this.state,
            chat: {...this.state.chat,
                all:{...this.state.chat.all,
                    [jid]: {...this.state.chat.all[jid],
                        [mid]: chatObj,
                    }
                },
                message: '',
                oldMessage: {},
            },
            notification: {...this.state.notification,
                users: []
            },
            shareLocation:{               
                msgLocation: false
            }
        }

        this.setState(messages, () => {
            if(isScroll) {
                this.setScrollerToBottm();
            }
            if(getMeta && chatObj.isLocation === false){
                this.getUrlMetaData(chatObj)
            }
        });
    }

    async getUrlMetaData(chatObj) {
        let regexHttp = /(http|https):\/\/(\w+:{0,1}\w*)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%!\-\/]))?/;

        if (regexHttp.test(chatObj.body)) {
            const inputObj = {
                fileObject: [{
                    chatId: chatObj.id,
                    url: chatObj.body
                }]
            }
            let response = await this.props.client.query({
                query: GET_URL_INFO,
                variables: { input: inputObj }
            });
            if(response.errors) {
                this.setState({
                    errorMsg: response.message
                });
            } else {
                chatObj['url_meta_info'] = response.data.getMessageScraperUrlInfo.data;
                this.addMessageToState(chatObj, chatObj.createdOn, 0);
            }
        }
    }

    //close emoji popup when click outside
    handleOutsideClick = () => {
        this.setState((prevState) => ({
            chat: {
                ...prevState.chat,
                emojiPicker: false,
            }
        }));
    }

    //show emoji picket
    showChatEmojiPicker = () => {
        this.setState((prevState) => ({
            chat: {
                ...prevState.chat,
                emojiPicker: true,
            }
        }));
    }

    //on selection on emoji set its value in message
    setEmoji = (emoji) => {
        console.log(emoji);
        this.setState((prevState) => ({
            chat: {
                ...prevState.chat,
                message: prevState.chat.message + '' + emoji.native
            }
        }));
    }

    customDrop() {
        this.setState((prevState) => ({
            chat: {
                ...prevState.chat,
                customDropShow: !prevState.chat.customDropShow
            }
        }));
    }

    //when file dragging start
    onDragEnter = () => {
        this.setState((prevState) => ({
            chat: {
                ...prevState.chat,
                dropzoneActive: true
            }
        }));
    }

    //when file dragging stop
    onDragLeave = () => {
        this.setState((prevState) => ({
            chat: {
                ...prevState.chat,
                dropzoneActive: false
            }
        }));
    }

    //get dropped files
    onDrop = async(acceptedFiles) => {
        this.setState((prevState) => ({
            chat: {
                ...prevState.chat,
                dropzoneActive: false
            }
        }));

        acceptedFiles.forEach(async file => {
            let date = new Date();
            let chatObj = {
                id: 'synthesis' + date.getTime(),
                to: {
                    name: this.props.sRosterData.active.displayName,
                    jid: this.props.sRosterData.active.jid.bare ? this.props.sRosterData.active.jid.bare : '',
                },
                from: {
                    name: this.props.sObject.sClient.config.jid.local,
                    jid: this.props.sObject.sClient.config.jid.bare,
                },
                type: this.props.sRosterData.active.hasOwnProperty('autoJoin') ? 'groupchat' : 'chat',
                body: "",
                isAttachment: true,
                createdOn: date.getTime(),
                requestReceipt: true,
                chatState: 'active'
            };

            let response = await this.props.sObject.sendAttachment(chatObj, file);
            if(response.status) {
                let newChatObj = response.data;
                newChatObj.body = newChatObj.filePath;
                newChatObj.isDeleted = false;
                //add message to state for rendering
                this.addMessageToState(newChatObj, response.createdOn, 0);
            } else {
                toast(<Toaster notifyType="error"
                    msg={response.message} />, {
                        position: toast.POSITION.BOTTOM_RIGHT,
                        hideProgressBar: true
                });
            }
        });
    }

    //get users list for @ mention
    getUsersForNotification = (value) => {
        var users = this.state.notification.users.slice();
        users.push({
            toUser: value,
            from: this.props.loggedInUser.fullName,
            subject: 'Notification from Message Centre',
            desc: ''
        });

        this.setState((prevState) => ({
            notification: {
                ...prevState.notification,
                users: users
            }
        }));
    }

    //delete message
    deleteMessage = async (chatObj) => {
        console.log('!!!!!!!!!', chatObj);
        //return false;
        let chatFields = [{
                key: "isDeleted",
                value: "true"
        }]        
        const response = await this.props.sObject.updateChatByChatId(chatObj, chatFields, 'delete');
        if(response.errors) {
            this.setState({
                errorMsg: response.errors
            });
        } else {
            let userChatObj = Object.assign({}, chatObj);//this.state.chat
            userChatObj.isDeleted = true;
            this.addMessageToState(userChatObj, userChatObj.createdOn, 0, false);
        }
    }

    //favourite message
    favMessage = async (chatObj) => {
        let isFav = chatObj.isFavourite ? false : true;
        let chatFields =  [{
            key: "isFavourite",
            value: isFav
        }]
        
        const response = await this.props.sObject.updateChatByChatId(chatObj, chatFields);
        if(response.errors) {
            this.setState({
                errorMsg: response.errors
            });
        } else {
            let userChatObj = Object.assign({}, chatObj);//this.state.chat
            userChatObj.isFavourite = isFav;
            this.addMessageToState(userChatObj, userChatObj.createdOn, 0, false);
        }     
    }

    //edit chat message
    editMessage = (chatArray) => {
        this.setState((prevState) => ({
            chat: {
                ...prevState.chat,
                editMode: true,
                //editmessage: prevState.chat.editMode === true ? chatArray : {},
                message: chatArray.body,
                oldMessage: chatArray
            }
        }));
    }

    //clear chat history
    clearChatHistory = async () => {
        let fields = [{"key":"fromDate", "value": new Date().getTime()}];
        let response = await this.props.sObject.updateContacts(this.props.sRosterData.active, fields);

        if(response.status){
            this.props.updateRosterState("fromDate", response.data.currentTime);
        }else{

            this.setState({
                errorMsg: response.message
            });
        }
    }

    //archive chat history
    archiveChat = async () => {
        let fields = [{"key":"archiveDate", "value": new Date().getTime()}];
        let response = await this.props.sObject.updateContacts(this.props.sRosterData.active, fields);
        if(response.status){
            this.props.updateRosterState("archiveDate", response.data.currentTime);
        }else{

            this.setState({
                errorMsg: response.message
            });
        }
    }

    setInput = (event) => {
        this.setState({
            topMenu: {
                search: event.target.value
            }
        });
    }

    //email chat history
    emailChatMessages = async () => {
        let activeJid = this.props.sRosterData.active.jid.bare;
        let configJid = this.props.sObject.sClient.config.jid.bare;
        let chatData = this.state.chat.all[activeJid];
        let chatIdsArr = [];
        Object.keys(chatData || {}).map((keyName, keyIndex) => {
            let chatId = chatData[keyName].id;
            chatIdsArr.push(chatId);
        })

        let obj = {
            companyId: this.props.loggedInUser.cid,
            fromJid: configJid,
            chatIds: chatIdsArr
        }
        let response = await this.props.sObject.sendEmailChatMessages(obj);
        if(!response.status){
            this.setState({
                errorMsg: response.message
            });
        }
    }

    getPosition = () => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(this.shareLocation, this.checkLocationErrors);
        } else {
            //x.innerHTML = "Geolocation is not supported by this browser.";
            alert("Geolocation is not supported by this browser.");
        }
    }

    checkLocationErrors = (error) => {
        let errormsg;
        switch(error.code) {
            case error.PERMISSION_DENIED:
                errormsg = "User denied the request for Geolocation."
            break;
            case error.POSITION_UNAVAILABLE:
                errormsg = "Location information is unavailable."
            break;
            case error.TIMEOUT:
                errormsg = "The request to get user location timed out."
            break;
            case error.UNKNOWN_ERROR:
                errormsg = "An unknown error occurred."
            break;
        }

        alert(errormsg);
    }

    shareLocation = (position) => {
        let latlon = position.coords.latitude + "," + position.coords.longitude;
        let img_url = "https://maps.googleapis.com/maps/api/staticmap?center=" + latlon + "&zoom=14&size=400x300&key=AIzaSyBu-916DdpKAjTmJNIgngS6HL_kDIKU0aU";
        this.setState((prevState) => ({
            chat: {
                ...prevState.chat,
                message: img_url,
            },
            shareLocation:{
                msgLocation: true
            }
        }), () => {
            this.sendMessage();
        });
    }

    render() {
        return (
            <ChatMain
                {...this.props}
                {...this.state}
                handleSubmit = {this.handleSubmit}
                handleMentionChange = {this.handleMentionChange}
                handleTextareaKeypress = {this.handleTextareaKeypress}
                handleScroll = {this.handleScroll}
                handleUpdate = {this.handleUpdate}
                ref="bars"
                handleOutsideClick = {this.handleOutsideClick}
                showChatEmojiPicker = {this.showChatEmojiPicker}
                setEmoji = {this.setEmoji}
                parseContent = {this.parseContent}
                onDragEnter = {this.onDragEnter}
                onDragLeave = {this.onDragLeave}
                onDrop = {this.onDrop}
                fileOnChange = {this.fileOnChange}
                getUsersForNotification = {this.getUsersForNotification}
                deleteMessage = {this.deleteMessage}
                favMessage = {this.favMessage}
                chatState = {this.state.chat}
                editMessage = {this.editMessage}
                clearChatHistory = {this.clearChatHistory}
                archiveChat = {this.archiveChat}
                setInput = {this.setInput}
                emailChatMessages = {this.emailChatMessages}
                addNewInviteMember = {this.addNewInviteMember}
                deleteInviteMember = {this.deleteInviteMember}
                inviteModalHandle = {this.inviteModalHandle}
                sendInviteModalClick = {this.sendInviteModalClick}
                errorInvites = {this.state.errorInvites}
                handleInviteInputChange = {this.handleInviteInputChange}
                getPosition = {this.getPosition}
            />
        )
    }
}
export default Middle;
