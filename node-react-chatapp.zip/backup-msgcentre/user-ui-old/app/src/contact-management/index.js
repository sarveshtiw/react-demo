import React from 'react';
import { compose, withApollo } from 'react-apollo';
import TopMenu from '../common/containers/MainTopMenu'
import Dashboard from './containers/dashboard/Content'

const menu = {
    title: "Contact Management",
    // menuItem: [
    //     {
    //         title: "Contacts",
    //         route: "",
    //         subNav: [
    //             {
    //                 title: "Add new contact",
    //                 route: "/contact-management/add-new-contact",
    //             }
    //         ]
    //     },
    //     {
    //         title: "Group Management",
    //         route: "",
    //         subNav: [
    //             {
    //                 title: "Contact and Groups",
    //                 route: "/contact-management/group-management/contacts-and-groups",
    //             }
    //         ]
    //     }
    // ]
}


class ContactManagement extends React.Component {
    render() {
        return (
            <div className="main">
                <TopMenu {...this.props} menu={menu} />
                <Dashboard {...this.props} />
            </div>
        );
    }
}

export default compose(withApollo)(ContactManagement);