import React from 'react';

const ContactList =
    ({
        contactList,
        getContactCheckedValue,
        contactType,
        contactInfo,
        checkboxVisible,
        checkedContacts,
        contactId
    }) => (
            <ul>
                {contactList.map((item, index) =>
                    <li key={index} id={'contactId' + index}>
                        <div className={contactType === 'contact' ? checkboxVisible ? 'mainCHeck single checked' : 'mainCHeck single' : ''}>
                            <div className={contactType === 'contact' ? "checkbox checkbox-week checkbox-inline" : 'pl-5'}>
                                {contactType === 'contact' ? <input type="checkbox" id={'cont-' + index} value={item.id_contact} name="radioInline" onChange={() => getContactCheckedValue(item.id_contact)} checked={checkedContacts.indexOf(item.id_contact) > -1} /> : ''}

                                <label className="mb-0" onClick={() => contactInfo(item)} >{contactType === 'contact' ? item.lname !== null ? item.fname + ' ' + item.lname : item.fname : item.Contact.lname !== null ? item.Contact.fname + ' ' + item.Contact.lname : item.Contact.fname}</label>
                            </div>
                        </div>
                    </li>
                )}
            </ul>
        )

export default ContactList; 