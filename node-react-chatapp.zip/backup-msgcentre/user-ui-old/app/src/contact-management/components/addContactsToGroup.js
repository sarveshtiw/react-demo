import React from 'react'
import { Row, Col, FormGroup, InputGroup, FormControl, Button, Modal } from 'react-bootstrap'
import { Scrollbars } from 'react-custom-scrollbars'
import { Draggable, Droppable } from 'react-drag-and-drop'
import Switch from 'react-switch_case'
let Case = Switch.Case

const AddContactToGroups =
    ({
        contactList,
        onDrop,
        droppedContacts,
        closeDropModal,
        removeDroppedContact,
        submitParticipants,
        searchStr,
        clearSearch,
        changeInput
    }) => (
            <Modal
                show={true}
                onHide={this.hideModal}
                bsSize="large"
                dialogClassName="custom-modal"
                backdrop="static">
                <Modal.Body>
                    <Row>
                        <Col sm={6}>
                            <h4 className="headerStyle">Add Contacts to Group</h4>
                        </Col>
                    </Row>
                    <Row className="flexRow">
                        <Col sm={6}>
                            <FormGroup className="s-contact">
                                <InputGroup className="fShadow1" >
                                    <FormControl type="text" placeholder="search contact" onChange={(e) => changeInput(e)} value={searchStr} />
                                    <InputGroup.Addon>
                                        <i className={`fa ${searchStr !== '' ? 'fa-times pointer' : 'fa-search'}`} onClick={() => clearSearch()}></i>
                                    </InputGroup.Addon>
                                </InputGroup>
                            </FormGroup>
                            <Scrollbars className="overlayScroll"
                                autoHeight
                                autoHeightMin={500}
                            >

                                <ul className="partList">
                                    {contactList.map((item, index) => {
                                        return (
                                            <Draggable
                                                type="contacts"
                                                data={JSON.stringify(item) + '?' + index}
                                                key={index}
                                            >
                                                <li key={item.id_contact}>
                                                    <h5> {item.lname !== null ? item.fname + ' ' + item.lname : item.fname}</h5>
                                                    <p>{item.contactEmails[0].email}</p>
                                                    <i className="fa fa-arrows"></i>
                                                </li>
                                            </Draggable>
                                        )
                                    })}
                                </ul>

                            </Scrollbars>
                        </Col>
                        <Col sm={6}>
                            <div className="droppable">
                                <Droppable
                                    types={['contacts']}
                                    style={{ height: '100%' }}
                                    onDrop={onDrop}
                                >
                                    {droppedContacts.length > 0 ?
                                        droppedContacts.map((item, index) => (
                                            <span className="dropped-elem" key={index} id={item.id_contact}>
                                                {item.lname !== null ? item.fname + ' ' + item.lname : item.fname}
                                                <i className="material-icons" aria-hidden="true" onClick={() => removeDroppedContact(item)} >close</i>
                                            </span>
                                        )
                                        ) :
                                        <div className="preDrop">
                                            <img src="/images/dragParticipant.png" alt="Tap here to start adding participants" />
                                            <p>Tap here to start adding members</p>
                                        </div>
                                    }

                                </Droppable>
                            </div>
                            <div className="submitArea align-items-center">
                                <Button bsStyle="submit" onClick={() => submitParticipants()}>Submit</Button>
                                <Button bsStyle="cancel" onClick={() => closeDropModal()}>Cancel</Button>
                            </div>
                        </Col>
                    </Row>
                </Modal.Body>
            </Modal>
        );

export default AddContactToGroups