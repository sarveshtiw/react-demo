import gql from 'graphql-tag';

export const CREATE_CONTACT = gql`
  mutation createContact($input: createContact!){
    createContact(input: $input){
      id_contact
      title
      fname
      lname
      dob
      organisation
      designation
      contactNumbers{
        id_contact_phone
        phone
        primary
      }
      contactEmails{
        id_contact_email
        email
        primary
      }
      addresses{
        id
        id_contact
        address1
        city
        city_name
        state
        state_name
        country
        country_name
        zipcode
      }
    }
  }
`;

export const UPDATE_CONTACT = gql`
  mutation updateContact($input:updateContact,$address:[updateAddress],$phone:[Phone],$email:[Email]){
    updateContact(input:$input,address:$address,phone:$phone,email:$email) {
      id_contact
      message
    }
  }
`;

export const DELETE_CONTACT = gql`
 mutation deleteContact($id: [Int]!){
    deleteContact(id: $id){
     message
    }
  }
`;

export const CREATECONTACT_GROUP = gql`
  mutation createContactGroup($input:createContactGroup!){
    createContactGroup(input:$input){
      details{
        id_group
        group_name
        created_at
      }
      GroupMembers{
        id_contact
        Contact{
          id_contact
          fname
          lname
        }
      }
    }
  }
`;

export const UPDATECONTACT_GROUP = gql`
  mutation updateContactGroup($input:updateContactGroup){
    updateContactGroup(input:$input){
      message
    }
  }
`;

export const DELETE_CONTACT_GROUP = gql`
 mutation deleteContactGroup($input: deleteContactGroup){
    deleteContactGroup(input: $input){
     message
    }
  }
`;
