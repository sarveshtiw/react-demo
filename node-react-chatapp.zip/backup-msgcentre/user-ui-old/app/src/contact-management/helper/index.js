import { isArray } from 'util'
import { customJoiNumber, customJoiString } from '../../common/customJoiRules'
const Joi = require('joi-browser');

const schemaCreateContact = Joi.object().keys({
    title: Joi.any().allow('').valid(['Mr', 'Mrs', 'Ms', 'Dr', 'Prof']).optional(),
    fname: Joi.string().required().optional(),
    lname: Joi.string().allow('').optional(),
    designation: Joi.string().allow('').optional(),
    organisation: Joi.string().allow('').optional(),
    primaryPhone: customJoiString.string().isNumber().min(6).max(30).required().optional(),
    secondaryPhone: customJoiString.string().isNumber().min(6).max(30).allow('').optional(),
    primaryEmail: customJoiString.string().email().emailValidation().required().optional(),
    secondaryEmail: customJoiString.string().email().emailValidation().allow('').optional(),
    mailZip: customJoiString.string().isNumber().min(6).max(9).allow('').optional(),
    otherZip: customJoiString.string().isNumber().min(6).max(9).allow('').optional()
})

export const clearEmpties = (o) => {
    for (var k in o) {
        if (!o[k] || typeof o[k] !== "object") {
            (o[k] === undefined || o[k] === null || o[k] == '') && delete o[k]
            continue
        }
        clearEmpties(o[k]);
        if (Object.keys(o[k]).length === 0) {
            delete o[k];
        }
    }
    for (var k in o) {
        if (isArray(o[k])) {
            o[k] = o[k].filter(function (x) {
                return (x !== (undefined || null || ''));
            });
        }
    }
}


export const validateCreateContact = (inputCreateContact) => {
    return Joi.validate(inputCreateContact, schemaCreateContact, { abortEarly: false });
}
