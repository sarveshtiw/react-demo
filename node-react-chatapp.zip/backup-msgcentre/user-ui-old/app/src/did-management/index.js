import React from 'react';
import TopMenu from '../common/containers/MainTopMenu'
import Dashboard from './containers/dashboard/Content'
import { compose, withApollo } from 'react-apollo'

const menu = {
  title: "Did Management",
  menuItem: [
    {
      title: "Dashboard",
      route: "/did-management",
      subNav: []
    },
    {
      title: "request",
      route: "/did-management/request-did-tracking",
      subNav: []
    },
    {
      title: "did numbers",
      route: "/did-management/did-numbers",
      subNav: []
    }
  ]
}

class DidManagement extends React.Component {
  render() {
    return (
      <div className="main">
        <TopMenu {...this.props} menu={menu} />
        <Dashboard {...this.props} />
      </div>
    );
  }
}

export default compose(
  withApollo
)(DidManagement);