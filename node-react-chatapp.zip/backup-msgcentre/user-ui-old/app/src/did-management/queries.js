import gql from 'graphql-tag';

export const GETDID_TYPES = gql`
{ 
    getDidTypes(input:{ }) 
    { 
        details{ 
            id 
            did_type 
        } 
    } 
}
`;



export const GETREQUESTDID_LIST = gql`
query getRequestedDids($input:listRequestDidIn){
    getRequestedDids(input:$input){
        totalPage
        details{
            id
            quantity
            status
            client_id
            client_name
            country_id
            country_name
            city_id
            city_name
            did_type
            tracking_status
            didType{
                did_type
            }
            RequestDidLogs{
                id
                tracking_status
                added_at
            }
        }
    }
}
`;





export const GETREQUESTED_DID_BY_ID = gql`
query getRequestedDidByID($input:getRequestedDidByID){
         getRequestedDidByID(input:$input){
            details{
                id
                quantity
                country_id
                city_id
                did_type
                tracking_status
                status
            }
        }
    }
`;

export const GET_DIDS = gql`
query getDids($input:searchFilter){
         getDids(input:$input){
            page
            limit
            totalPage
            totalCount
            details{
                id
                did
                status
                city_id
                city_name
                country_id
                country_name
                did
                type
                type_name
                app_id
                app_name
            }
        }
    }
`;
