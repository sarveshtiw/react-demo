import gql from 'graphql-tag';

export const SAVEREQUEST_DID = gql`
 mutation saveRequestDid($input: saveDidRequestIn){
    saveRequestDid(input: $input){
     message
    }
  }
`;

export const UPDATEREQUEST_DID = gql`
 mutation updateRequestDid($input: updateRequestIn){
    updateRequestDid(input: $input){
     message
    }
  }
`;

export const CANCELDID_REQUEST = gql`
 mutation CancelDidRequest($input: CancelDidRequestIn){
    CancelDidRequest(input: $input){
     message
    }
  }
`;

export const UPDATE_DID = gql`
 mutation updateDidNumber($input: updateDidIn){
    updateDidNumber(input: $input){
     message
    }
  }
`;