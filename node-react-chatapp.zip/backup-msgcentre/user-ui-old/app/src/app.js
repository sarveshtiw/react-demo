import React from "react";
import { BrowserRouter, Switch, Route, Redirect } from "react-router-dom";
import { ApolloProvider } from "react-apollo";
import LoginPage from "./login";
import DashBoard from "./dashboard";
import AudioConference from "./audio-conference";
// import VideoConference from "./video-conference";
import MessageCentre from "./message-centre";
import MessageCentreGuest from "./message-centre/guest";
import ContactManagement from "./contact-management";
import CRM from "./crm";
import AdminPortal from "./admin-portal";
import DidManagement from "./did-management";
import NotFound from "./common/components/404";
import ServerError from "./common/components/500";
import client from "./apolloClient";
import "./style/style.scss";
import { ToastContainer } from "react-toastify";

const PrivateRoute = ({ component: Component, ...rest }) => {
  let qeryStr = new URLSearchParams(window.location.search);
  let token = qeryStr.has("token")
    ? qeryStr.get("token")
    : localStorage.getItem("token");
  return (
    <Route
      {...rest}
      render={props => (token ? <Component {...props} /> : <Redirect to="/" />)}
    />
  );
};

const LoginRoute = ({ component: Component, ...rest }) => {
  let qeryStr = new URLSearchParams(window.location.search);
  let token = qeryStr.has("token")
    ? qeryStr.get("token")
    : localStorage.getItem("token");
  return (
    <Route
      {...rest}
      render={props =>
        token ? <Redirect to="/dashboard" /> : <Component {...props} />
      }
    />
  );
};

const App = () => {
  return (
    <ApolloProvider client={client}>
      <BrowserRouter>
        <div>
          <ToastContainer />
          <Switch>
            <LoginRoute path="/" component={LoginPage} exact />
            <PrivateRoute path="/dashboard" component={DashBoard} />
            <PrivateRoute
              path="/audio-conference"
              component={AudioConference}
            />
            {/* <PrivateRoute
              path="/video-conference"
              component={VideoConference}
            /> */}
            <PrivateRoute path="/message-centre" component={MessageCentre} />
            <PrivateRoute path="/guest" component={MessageCentreGuest} />
            <PrivateRoute
              path="/contact-management"
              component={ContactManagement}
            />
            <PrivateRoute path="/did-management" component={DidManagement} />
            <PrivateRoute path="/crm" component={CRM} />
            <PrivateRoute path="/admin-portal" component={AdminPortal} />
            <PrivateRoute path="/serverError" component={ServerError} />
            <PrivateRoute component={NotFound} />
          </Switch>
        </div>
      </BrowserRouter>
    </ApolloProvider>
  );
};

export default App;
