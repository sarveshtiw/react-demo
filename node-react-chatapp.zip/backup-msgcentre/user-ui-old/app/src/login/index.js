import React from 'react';
import { Row, Col, FormControl, Button } from 'react-bootstrap';
import axios from 'axios';
import { withRouter } from 'react-router-dom';
// Other file call
import './login.scss'
// Javascript code


class LoginScreen extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      username: '',
      password: '',
      error: ''
    }
    console.log(this.props);
  }
  componentWillMount=() =>{
    console.log(process.env)
  }

  onChange(event) {
    const { value, name } = event.target;
    this.setState({ [name]: value });
    //console.log(this.state);
  }

  onSubmit(event) {
    event.preventDefault();
    this.setState({ loading: true });
    const { authKey, password } = this.state;

    axios.post(`${process.env.REACT_APP_GATEWAY}/login`, { authKey, password }).then((res) => {
      if (res.status === 200) {
        this.setState({ loading: false });
        console.log(res.data);
        if (res.data.token === undefined) {
          this.setState({ error: res.data.message });
        } else {
          localStorage.setItem("token", res.data.token);
          localStorage.setItem("uuid", res.data.uuid);
          this.props.history.push("/dashboard");
          //write user's info into apollo cache
        }
      } else {
        console.log("other status code", res.status);
      }
    }).catch((err) => {
      this.setState({ loading: false });
      console.log(err);
    });
  }

  render() {
    return (
      <div className="signMain">
        <Col md={7}>
          <div className="signLeft">
            <h2><span>Welcome to</span><br />Synthesis Portal</h2>
            <h3>Smart. Simple. Secure</h3>
            <p>Accelerate business growth and profitability in the cloud with Synthesis. Every application and component of the platform is modularized, customizable and can be easily integrated with APIs.</p>
            <img src="/images/devices.png" alt="" />
          </div>
        </Col>

        <Col md={5}>
          {/* Sign in From */}
          <div className="signUpNew">
            <div className="security">
              <img src="images/norton.png" alt="Norton" />
              <img src="images/truste.png" alt="truste" />
            </div>
            <div className="modal-body">
              <p><img className="img-responsive" src="images/login-logo.png" alt="Asergis Logo" /></p>
              <form role="form" autoComplete="off">
                <Row>
                  <Col md={12} className="m-b">
                    <a href="/" className="btn btn-linkedin btn-block">
                      <i className="fa fa-linkedin"></i>Login with Linkedin
					            </a>
                  </Col>
                  <Col md={12} className="m-b">
                    <a href="/" className="btn btn-facebook btn-block">
                      <i className="fa fa-facebook-square"></i>Login with Facebook
					            </a>
                  </Col>
                  <Col md={12} className="m-b">
                    <a href="/" className="btn btn-google btn-block">
                      <i className="fa fa-google-plus"></i>Login with Google
					            </a>
                  </Col>
                </Row>
                <br />
                <Row>
                  <Col sm={12}>
                    <div className="signTxt">
                      {this.state.authKey ? <div className="name siTchange">Username</div> : <div className="name">Username</div>}
                      <input type="text" name="authKey" className="form-control" onChange={this.onChange.bind(this)} />
                    </div>
                  </Col>
                  <Col sm={12}>
                    <div className="signTxt">
                      {this.state.password ? <div className="name siTchange">Password</div> : <div className="name">Password</div>}
                      <FormControl type="password" name="password" onChange={this.onChange.bind(this)}  />
                    </div>
                  </Col>
                </Row>
                <Row>
                  <Col sm={12}>
                    <p style={{ color: '#FF0000' }}>{this.state.error}</p>
                  </Col>
                </Row>
                <div className="signBtnNew">
                  <Button bsClass="btn-sub" onClick={this.onSubmit.bind(this)} >Sign In</Button>
                </div>

                <Row>
                  <Col md={6} sm={6}>
                    <div className="checkbox">
                      <input id="checkbox5" type="checkbox" />
                      <label htmlFor="checkbox5" className="remb">Remember me</label>
                    </div>
                  </Col>
                  <Col md={6} sm={6}>
                    <a href="/" className="signForgot">Forgot Password?</a>
                  </Col>
                </Row>

              </form>
            </div>

            <div className="info">
              © 2017 synthesis, inc. All rights reserved.
					    </div>
          </div>

        </Col>
      </div>
    );
  }
}

export default withRouter(LoginScreen);