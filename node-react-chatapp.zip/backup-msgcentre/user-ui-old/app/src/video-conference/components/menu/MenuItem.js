import React from 'react'
import { Navbar, Nav, NavItem, } from 'react-bootstrap';
import { IndexLinkContainer } from 'react-router-bootstrap'

const MenuItem = ({
    changeState
}) => (
        <Navbar.Collapse>
            <Nav>
                <IndexLinkContainer to="/video-conference">
                    <NavItem eventKey="dashboard">
                        Dashboard
                </NavItem>
                </IndexLinkContainer>
                <IndexLinkContainer to="/video-conference/conference/list">
                    <NavItem eventKey="conference-list">
                        Conference list
                </NavItem>
                </IndexLinkContainer>
            </Nav>
        </Navbar.Collapse>
    );

export default MenuItem;