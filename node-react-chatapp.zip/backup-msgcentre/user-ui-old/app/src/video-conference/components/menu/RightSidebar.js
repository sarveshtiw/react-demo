import React from 'react'
import '../style/right.css'

const RightSidebar = () => (
    <div className="dashright">
        <ul>
            <li>
                <a href="#"><i className="icon-doc"></i></a>
            </li>
            <li>
                <a href="#"><i className="icon-feedback"></i></a>
            </li>
            <li>
                <a href="#"><i className="icon-meetings"></i></a>
            </li>
            <li>
                <a href="#"><i className="icon-preaccount"></i></a>
            </li>
            <li>
                <a href="#"><i className="icon-provisioning"></i></a>
            </li>
            <li>
                <a href="#"><i className="icon-servicemanage"></i></a>
            </li>
            <li>
                <a href="#"><i className="icon-sales-graph"></i></a>
            </li>
            <li>
                <a href="#"><i className="icon-sales-file"></i></a>
            </li>
        </ul>
    </div>
);

export default RightSidebar;