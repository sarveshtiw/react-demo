import React from 'react'
import { Col } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import '../style/live.scss'

const LiveConfHeader = () => (
        <div className="video-section">
            <header className="online-head">
                <Col md={4}>
                    <Link to="/dashboard"><img src="/images/logo.png" alt="Synthesis Dashboard" /></Link>
                </Col>
                <Col md={4} className="text-center">
                    <p>Weekly Video Conference Call</p>
                </Col>
                <Col md={4} className="text-right">
                    <div className="end-conf">
                        <button className="btn btn-default">End Conference</button>
                    </div>
                    <div className="v-time">
                        13 Participants
          <b>08:48</b>
                    </div>
                </Col>
            </header>
        </div>
    )
export default LiveConfHeader;