import React from 'react'
import { Navbar, Nav, NavItem } from 'react-bootstrap';
import { IndexLinkContainer } from 'react-router-bootstrap'

const VcMenuItem = () => (
    <Navbar.Collapse className="thirdlevelMenu">
        <Nav>
            <IndexLinkContainer to="/video-conference/conference/create">
                <NavItem eventKey="create-conference">
                    Create video Conference
                </NavItem>
            </IndexLinkContainer>
            <IndexLinkContainer to="/video-conference/conference/list">
                <NavItem eventKey="conference-list">
                    Conference list
                </NavItem>
            </IndexLinkContainer>           
        </Nav>
    </Navbar.Collapse>
);

export default VcMenuItem;