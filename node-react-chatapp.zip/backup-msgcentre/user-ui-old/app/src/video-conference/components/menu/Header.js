import React from 'react'
import { Link } from 'react-router-dom'
import Switch from 'react-switch_case'
import { Navbar, Nav, NavItem, NavDropdown, FormGroup, MenuItem, FormControl } from 'react-bootstrap'
import MainItem from './MenuItem'
import VcMainItem from './VcMenuItem'
import NavDrop from '../../../common/components/NavDrop';
import '../style/top.css'


let Case = Switch.Case

const Header = ({
    changeState,
    changeStateByName,
    popoverMenu,
    subNavbar,
    subSubNavbar
}) => (
        <div className="navigation">
            <Navbar collapseOnSelect className="nav-audioConf">
                <Navbar.Collapse>
                    <Nav>
                        <Navbar.Brand>
                            <Link to="/"><img src="/images/logo.png" alt="Synthesis Dashboard" /></Link>
                            <a href="#" onClick={(event) => { event.preventDefault(); changeState('subNavbar') }}><i className="icon-app"></i></a>
                        </Navbar.Brand>
                        <Navbar.Toggle />
                    </Nav>
                    <Navbar.Header>
                        <h1>Video Conference</h1>
                    </Navbar.Header>                                       
                    <div className="nav navbar-nav navbar-right">
                        <FormGroup controlId="formBasicText" className={popoverMenu ? "btnGroup focus" : "btnGroup"}>
                            <form name="search-message" autoComplete="off">
                                <FormControl type="text" name="searchInput" placeholder="Search" onBlur={() => { changeStateByName('popoverMenu', false) }} onFocus={() => { changeStateByName('popoverMenu', true) }}></FormControl>
                                <span className="form-control-feedback material-icons">search</span>
                            </form>
                        </FormGroup>
                        <NavDrop />
                    </div>
                </Navbar.Collapse>
            </Navbar>
            <Switch value={subNavbar}>
                <Case value={true}>
                    <Navbar collapseOnSelect className="nav-audioConf bottom">
                        <MainItem changeState={changeState} />
                        <Switch value={subSubNavbar}>
                            <Case value={true}>
                                <VcMainItem />
                            </Case>
                        </Switch>
                    </Navbar>
                </Case>
            </Switch>
        </div>
    );

export default Header;