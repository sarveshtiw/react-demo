import React from 'react'
import { compose, withApollo } from 'react-apollo'
import { Route, Switch } from 'react-router-dom'
import LeftSidebar from '../../components/menu/LeftSidebar'
import RightSidebar from '../../components/menu/RightSidebar'
import ConferenceList from '../conference/List'
import ConferenceCreate from '../conference/Create'
import ConferenceUpdate from '../conference/Update'
import ConferenceView from '../conference/View'
import ConferenceLive from '../../containers/conference/LiveConfDashboard'
import RecordingList from '../conference/RecordingList';

const renderMergedProps = (component, ...rest) => {
    const finalProps = Object.assign({}, ...rest);
    return (
      React.createElement(component, finalProps)
    );
  }
  
  const PropsRoute = ({ component, ...rest }) => {
    return (
      <Route {...rest} render={routeProps => {
        return renderMergedProps(component, routeProps, rest);
      }}/>
    );
  }

class Content extends React.Component {
    /**
     *
     * @param props
     * @param context
     */
    constructor(props, context) {
        super(props, context);  
        this.props = props;             
    }

    /**
     *
     * @returns {XML}
     */
    render() {
        return (
            <div className="container-flud">
                <div className="mainArea">
                    <LeftSidebar />
                    <Switch>
                        <div className="middleArea">                            
                            <PropsRoute exact path="/video-conference/conference/list" component={ConferenceList} props={this.props} />
                            <PropsRoute path='/video-conference/conference/create' component={ConferenceCreate} props={this.props} />
                            <PropsRoute path='/video-conference/conference/update/:id' component={ConferenceUpdate} props={this.props} />
                            <PropsRoute exact path="/video-conference/conference/view/:id" component={ConferenceView} props={this.props} />                            
                            <PropsRoute exact path="/video-conference/conference/live/:id" component={ConferenceLive} props={this.props}/>
                            <PropsRoute exact path="/video-conference/conference/recording/:id" component={RecordingList} props={this.props}/>
                            <div className="clearfix"></div>
                        </div>
                    </Switch>
                    <RightSidebar />
                </div>
            </div>
        )
    }
}

export default compose(
    withApollo
)(Content)