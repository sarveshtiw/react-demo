import React from 'react'
import Header from '../../components/menu/Header'

class TopMenu extends React.Component {

    constructor(props, context) {
        super(props, context);
        this.state = {
            popoverMenu: {
                status: false
            },
            subNavbar: {
                status: true
            },
            subSubNavbar: {
                status: false
            }
        }
        this.changeState = this.changeState.bind(this)
        this.changeStateByName = this.changeStateByName.bind(this)
    }

    changeState(key) {
        let currentValue = this.state[key]
        let updatedValue = currentValue.status ? false : true

        currentValue.status = updatedValue
        this.setState({
            currentValue
        })
    }

    changeStateByName(key, value) {
        let currentValue = this.state[key]
        currentValue.status = value
        this.setState({
            currentValue
        })
    }

    render() {
        return (
            <Header
                changeState={this.changeState}
                changeStateByName={this.changeStateByName}
                popoverMenu={this.state.popoverMenu.status}
                subNavbar={this.state.subNavbar.status}
                subSubNavbar={this.state.subSubNavbar.status}
            />
        )
    }
}
export default TopMenu;