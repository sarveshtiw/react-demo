import React from 'react'
import {compose, withApollo} from 'react-apollo'
import { Route, Switch } from 'react-router-dom'
import ConferenceLive from './Live'

class LiveConfDashboard extends React.Component {

    /**
     *
     * @param props
     * @param context
     */
    constructor(props, context) {
        super(props, context);
    }

    /**
     *
     * @returns {XML}
     */
    render() {
        return (
            <Switch>
                <Route path="/video-conference/conference/live" component={ConferenceLive} />
            </Switch>
        )
    }
}
export default compose(
    withApollo
)(LiveConfDashboard)