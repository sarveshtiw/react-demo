import React from 'react'
import asyncLoop from 'node-async-loop'
import moment from 'moment'
import _ from 'lodash';
import { compose, withApollo, graphql } from 'react-apollo'
import { CREATE_CONTACT } from '../../constants/mutation'
import {
    CHECK_EMAIL_EXISTS,
    CHECK_PHONE_EXISTS
} from '../../constants/query'
import { validateCreateContact, addParticipantError} from "../../validation/contact";
import AddParticipantForm from '../../components/vcManagement/dialogBox/AddParticipant'
import helper from '../../lib/common'
import { toast } from 'react-toastify';
import Toaster from "../../../common/containers/toaster";
let helperObj = new helper

const errorParticipant = {
    fname: '',
    lname: '',
    email: new Array(2).fill(''),
    phone: new Array(5).fill(''),
    designation: '',
    department: '',
    organisation: ''
}

class AddParticipant extends React.Component {

    /**
     * @param props
     * @param context
     */
    constructor(props, context) {
        super(props, context)
        // set default state
        this.state = {
            dialog: {
                status: false
            },
            addParticipantForm: {
                fname: '',
                lname: '',
                email: [{ email: '', primary: true, errorMsg: '' }],
                phone: [{ phone: '', primary: true, errorMsg: '' }],
                designation: '',
                department: '',
                organisation: '',
                errorMsg: ''
            },
            errorParticipant: {
                fname: '',
                lname: '',
                email: new Array(2).fill(''),
                phone: new Array(5).fill(''),
                designation: '',
                department: '',
                organisation: ''
            },
            errorMsg: ""
        }
        // Bind event to class
        this.participantFormData = Object.assign({}, this.state.addParticipantForm);
        this.errorParticipantClearData = Object.assign({}, this.state.errorParticipant);
        this.onAddSubmitParticipant = this.onAddSubmitParticipant.bind(this)
        this.onChangeAddParticipant = this.onChangeAddParticipant.bind(this)
        this.onChangeAddMore = this.onChangeAddMore.bind(this)
        this.addMore = this.addMore.bind(this)
        this.removeAddMore = this.removeAddMore.bind(this)
        this.openDialog = this.openDialog.bind(this)
        this.addMoreValidate = this.addMoreValidate.bind(this)
    }

    componentWillMount
    componentWillReceiveProps(nextProps) {       
        let dialog = this.state.dialog;
        dialog.status = nextProps.dialogStatus
        this.setState({
            dialog
        })
    }

    /**
     ** onSubmit add participant form
     * @param event
     */
    async onAddSubmitParticipant(event) {
        event.preventDefault()
        let formData = this.state.addParticipantForm;
        let errorParticipant = this.state.errorParticipant;
        let getErrorRes = addParticipantError(errorParticipant);
        try {
       
        let obj = {
            fname: formData.fname,
            lname: formData.lname,
            email: formData.email.map((row, index) => {
                return row.email;
            }),
            phone: formData.phone.map((row, index) => {
                return row.phone;
            }),
            designation: formData.designation,
            department: formData.department,
            organisation: formData.organisation
        };
        let errorData = validateCreateContact(obj);
         if (errorData.error != null) {
            let err = errorData.error.details[0];
            if (err.path[0] === Object.keys(errorParticipant).find(k => k == err.path[0])) {
                if (err.path[0] == 'email' || err.path[0] == 'phone') {
                    `"${err.context.key}"`
                    errorParticipant[err.path[0]][err.context.key] = err.message.replace(`"${err.context.key}"`, `"${err.path[0]}"`);
                } else {
                    errorParticipant[err.path[0]] = err.message;
                }
                this.setState({
                    errorParticipant
                })
            } else {
                errorParticipant[err.path[0]] = '';
                this.setState({
                    errorParticipant
                })
            }

        }else if(getErrorRes) {
           //console.log("already exist");
        }else {
            let obj = {
                fname: formData.fname,
                lname: formData.lname,
                designation: formData.designation,
                department: formData.department,
                organisation: formData.organisation,
                serviceIds: [1],
                contactEmails: formData.email,
                contactNumbers: formData.phone,
                intl_code: "IND"
            }
             let response = await this.props.createContact({
                variables: {
                    input: obj
                }
            })
            if (response.hasOwnProperty('errors')) {
                formData.errorMsg = JSON.stringify(response.errors)
                this.setState({
                    addParticipantForm: formData
                })
            } else {
                this.props.updateParticipantList(response.data.createContact);
                this.setState((prevState) => ({
                    addParticipantForm: {
                        ...this.participantFormData
                    }
                }));
                this.openDialog('addParticipant');
            }
        } 
        } catch (ex) {
            this.setState((prevState) => ({
                addParticipantForm: {
                    ...prevState.addParticipantForm,
                    errorMsg: ex.message
                }
            }));

        }
    }

     /**
     ** onChange add participant field
     * @param event
     */
    onChangeAddParticipant = (event) => {
        let addParticipantForm = this.state.addParticipantForm;
        addParticipantForm[event.target.name] = event.target.value;
        let errorParticipant = this.state.errorParticipant;
        this.setState({
            addParticipantForm
        });
        let errorData = validateCreateContact({
            [event.target.name]: event.target.value
        });
        if (errorData.error != null) {
            let err = errorData.error.details[0];
            if (err.context['key'] === event.target.name) {
                errorParticipant[event.target.name] = err.message;
                this.setState({
                    errorParticipant
                })
            } else {
                errorParticipant[event.target.name] = '';
                this.setState({
                    errorParticipant
                })
            }

        } else {
            errorParticipant[event.target.name] = '';
            this.setState({
                errorParticipant
            })
        }
    }

    /**
     ** onChange add more field
     * @param event
     */
    onChangeAddMore(event) {
        let addParticipantForm = this.state.addParticipantForm[event.target.name].map((item, index) => {
            if (parseInt(event.target.id) !== index){
                return item
            }else{
                if(event.target.name == 'email')
                {
                    return { ...item,
                        email: event.target.value
                    }
                }else{
                    return { ...item,
                        phone: event.target.value
                    }
                }
            }
        })
        let updated = this.state.addParticipantForm
        updated[event.target.name] = addParticipantForm
        this.setState({
            updated
        })
        let errorParticipant = this.state.errorParticipant;
        let errorData = validateCreateContact({
            [event.target.name]: [event.target.value]
        });
        if (errorData.error != null) {
            let err = errorData.error.details[0];
            if (err.path[0] === event.target.name) {
                errorParticipant[event.target.name][event.target.id] = err.message.replace(`"${err.context.key}"`, `"${err.path[0]}"`);
                this.setState({
                    errorParticipant
                })
            } else {
                errorParticipant[event.target.name][event.target.id] = '';
                this.setState({
                    errorParticipant
                })
            }

        } else {
            errorParticipant[event.target.name][event.target.id] = '';
            this.setState({
                errorParticipant
            })
        }
    }

    /**
     ** add more option
     * @param key
     */
    addMore(key, max) {
        let addParticipantForm = this.state.addParticipantForm
        if (addParticipantForm[key].length < max) {
            let objAddmore;
            if(key == 'email'){
                objAddmore = {
                    email: '',
                    primary: false,
                    errorMsg: ''
                }
            }else{
                objAddmore = {
                    phone: '',
                    primary: false,
                    errorMsg: ''
                }
            }
            addParticipantForm[key] = addParticipantForm[key].concat([objAddmore])
            this.setState({
                addParticipantForm
            })
        } else {
            toast( < Toaster notifyType = "info"
                msg = {
                    `only ${max-1} alternative ${key} can be used`
                }
                />, {                  
                position: toast.POSITION.BOTTOM_RIGHT,
                hideProgressBar: true
            });
    }
}

    /**
     ** remove option
     * @param key
     * @param index
     */
    removeAddMore(key, index) {
        let addParticipantForm = this.state.addParticipantForm
        addParticipantForm[key] = addParticipantForm[key].filter((s, sidx) => parseInt(index) !== sidx)
        this.setState({
            addParticipantForm
        });
    }
    /**
     ** open dialogbox
     * @param type
     */
    openDialog(type, cancel = false) {       
        let dialog = this.state.dialog;
        dialog.status = dialog.status ? false : true
        this.setState({ dialog }, () => { this.props.openDialog() })
        if (type === 'addParticipant') {
            this.setState((prevState) => ({
                addParticipantForm: {
                    ...this.participantFormData
                },
                errorParticipant: {
                    ...this.errorParticipantClearData,
                    email: new Array(2).fill(''),
                    phone: new Array(5).fill('')
                }
            }));
        }
    }
    addMoreValidate(arrData, type) {
        return new Promise(resolve => {
            let error = false
    
            return asyncLoop(arrData, (item, callback) => {
                if (!item.value.trim() && item.primary) {
                    item.errorMsg = `${type} cannot be blank.`
                    error = true
                } else if (item[type].trim() && !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(item[type]) && type == 'email') {
                    item.errorMsg = 'Invalid email format'
                    error = true
                } else if (item[type].trim() && type == 'phone' && !item[type].match(/^[0-9]+$/)) {
                    item.errorMsg = 'Invalid phone number'
                    error = true
                } else {
                    item.errorMsg = ''
                }
                callback()
            }, err => {
                let addParticipantForm = this.state.addParticipantForm
                addParticipantForm[type] = arrData
                this.setState({
                    addParticipantForm
                })
                return resolve({
                    error: error
                })
            })
        })
    }
    checkExistEmail = async (event, rowData) => {
        event.preventDefault();
        let errorParticipant = this.state.errorParticipant;
        let name = event.target.name,
            id = event.target.id;
        try {
            let response = await this.props.client.query({
                query: CHECK_EMAIL_EXISTS,
                variables: {
                    input: {
                        email: rowData.email
                    }
                }
            });
            errorParticipant[name][id] = response.data.isEmailExist.isExist == 1 ? 'email is already exists' : '';
            this.setState({
                errorParticipant
            })
        } catch (ex) {
            errorParticipant[name][id] = ex.message;
            this.setState({
                errorParticipant
            })
        }
    }
    
    checkExistPhone = async (event, rowData) => {
        event.preventDefault();
        let errorParticipant = this.state.errorParticipant;
        let name = event.target.name,
            id = event.target.id;
        let errorData = validateCreateContact({
            [event.target.name]: [event.target.value]
        });
        try {
            if (errorData.error != null) {
                let err = errorData.error.details[0];
                if (err.path[0] === event.target.name) {
                    errorParticipant[name][id] = err.message.replace(`"${err.context.key}"`, `"${err.path[0]}"`);
                    this.setState({
                        errorParticipant
                    })
                } else {
                    errorParticipant[name][id] = '';
                    this.setState({
                        errorParticipant
                    })
                }
    
            } else {
                errorParticipant[name][id] = '';
                this.setState({
                    errorParticipant
                })
                let response = await this.props.client.query({
                    query: CHECK_PHONE_EXISTS,
                    variables: {
                        input: {
                            number: rowData.phone
                        }
                    }
                });
                errorParticipant[name][id] = response.data.isNumberExist.isExist == 1 ? 'phone number is already exists' : '';
                this.setState({
                    errorParticipant
                })
            }
    
        } catch (ex) {
            errorParticipant[name][id] = ex.graphQLErrors[0].message;
            this.setState({
                errorParticipant
            })
        }
    }

    /**
     * @returns {XML}
     */
    render() {
        return (
            <AddParticipantForm
                dialogStatus={this.state.dialog}
                openDialog={this.openDialog}
                onAddSubmitParticipant={this.onAddSubmitParticipant}
                onChangeAddParticipant={this.onChangeAddParticipant}
                onChangeAddMore={this.onChangeAddMore}
                addParticipantForm={this.state.addParticipantForm}
                error={this.state.errorParticipant}
                addMore={this.addMore}
                removeAddMore={this.removeAddMore}
                checkExistEmail={this.checkExistEmail}
                contactErrData={this.state.errorParticipant}
                checkExistPhone={this.checkExistPhone}
            />
        )
    }
}

export default compose(
    withApollo,
    graphql(CREATE_CONTACT, {
        name: 'createContact'
    })
)(AddParticipant)
