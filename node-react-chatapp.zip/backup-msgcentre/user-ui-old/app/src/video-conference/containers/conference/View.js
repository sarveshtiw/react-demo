import React from 'react'
import {compose, withApollo} from 'react-apollo'
import asyncLoop from 'node-async-loop'
import ConferenceView from '../../components/vcManagement/conference/View'
import { CONFERENCE_DETAIL, CONTACT_LIST_BY_CONF } from '../../constants/query'
import helper from '../../lib/common'
let helperObj = new helper

class View extends React.Component {

    /**
     * @param props
     * @param context
     */
    constructor(props, context) {
        super(props, context)

        // set default state
        this.state = {
            id: this.props.match.params.id ? this.props.match.params.id : null,
            objData: {},
            participant: [],
            errorMsg: ''
        }
        // Bind event to class
        this.getConferenceDetail = this.getConferenceDetail.bind(this);
        this.contactListTravers = this.contactListTravers.bind(this);
    }

    componentDidMount() {
        this.getConferenceDetail(this.state.id)
    }

    async getConferenceDetail(id) {

        let response = await this.props.client.query({
            query: CONFERENCE_DETAIL,
            variables: { id: id }
        });
        response = response.data.getVideoConferenceById;
        if (response.error) {

        } else {
            let selectedParticipant = [];
            if (response.result[0].VcConfParticipants.length >0) {
                let confParticipantList = await this.contactListTravers(response.result[0].VcConfParticipants);
                if(confParticipantList.length >0)
                {
                    let responseContactList = await this.props.client.query({
                        query: CONTACT_LIST_BY_CONF,
                        variables: { id: confParticipantList }
                    });
                    //console.log("responseContactList =>>", responseContactList);
                    if (responseContactList.data.hasOwnProperty('getContactById')) {
                        selectedParticipant = responseContactList.data.getContactById.contact
                    }
                }
            }
            this.setState({
                objData: response.result.length ? response.result[0] : {},
                participant: selectedParticipant
            })
        }       
    }
    contactListTravers(arrData)
    {
        let result =[];
        return new Promise(resolve =>{
            return asyncLoop(arrData, (item, callback) => {
                if (item) {
                    result.push(parseInt(item.cms_contact_id));
                    callback();
                }else{
                    callback();
                }
            }, err => {
                return resolve(result);
            });
         })
    }
    /**
     * @returns {XML}
     */
    render() {
        return (
            <ConferenceView
                objData={this.state.objData}
                participant={this.state.participant}
                errorMsg={this.state.errorMsg}
            />
        )
    }
}

export default compose(
    withApollo
)(View)