import React from 'react'
import { compose, withApollo, graphql } from 'react-apollo'
import asyncLoop from 'node-async-loop'
import { toast } from 'react-toastify';
import {
    CONFERENCE_DETAIL,
    CONTACT_LIST_BY_CONF,
    VALIDATE_USER,
    CONTACT_LIST,
    SEARCH_CONTACT,
    GROUP_LIST,
    SEARCH_CONTACT_GROUP
} from '../../constants/query'
import {
    CREATE_CONTACT,
    SEND_EMAIL_TO_PARTICIPANT,
    PARTICIPANT_ADDTO_CONFERENCE
} from '../../constants/mutation'
import helper from '../../lib/common'
import LiveConference from '../../lib/LiveConference'
import ConferenceLive from '../../components/vcManagement/conference/Live'
import Toaster from "../../../common/containers/toaster";

let helperObj = new helper;
let liveConferenceObj = new LiveConference;

class Live extends React.Component {
    /**
     * @param props
     * @param context
     */
    constructor(props, context) {
        super(props, context)
        this.qeryStr = new URLSearchParams(this.props.location.search)
        this.state = {
            conferenceStatus: 'ready', // ready, process, live
            message: '',
            confDetail: {},
            participantList: [],
            kurentoConnectionStatus: false,
            tabOption: '',
            participantInfo: {},
            contactList: [],
            groupList: [],
            dialogStatus: false,
            groupDetail: false,
            groupDetailShow: '',
            confExitstStatus: true
        }

        this.connectionInitilize = this.connectionInitilize.bind(this)
        this.kurentoConnectionStatus = this.kurentoConnectionStatus.bind(this)
        this.joinRoomRes = this.joinRoomRes.bind(this)
        this.changeConfStatus = this.changeConfStatus.bind(this)
        // Socket response
        this.getResponse = this.getResponse.bind(this)
        // Custom events
        this.validateUser = this.validateUser.bind(this)
        this.makeCall = this.makeCall.bind(this)
        this.disconnectCall = this.disconnectCall.bind(this)
        this.changeTab = this.changeTab.bind(this);
        this.getContactList = this.getContactList.bind(this)
        this.getGroupList = this.getGroupList.bind(this)
        this.searchContact = this.searchContact.bind(this)

        this.openDialog = this.openDialog.bind(this)
        this.updateParticipantList = this.updateParticipantList.bind(this)
        this.sendInvitation = this.sendInvitation.bind(this)
        this.addParticipantToConference = this.addParticipantToConference.bind(this)
        this.notificationMsg = this.notificationMsg.bind(this)
        this.notification = this.notification.bind(this)
        this.groupDetail = this.groupDetail.bind(this)
        this.addGroupParticipantToConference = this.addGroupParticipantToConference.bind(this);
        // Get contact list
        this.contactListTravers = this.contactListTravers.bind(this);
        this.searchGroup = this.searchGroup.bind(this);
        this.addParticipantToLiveConference = this.addParticipantToLiveConference.bind(this);        
    }
    /**
     * Call after rendring
     */
    componentDidMount() {
        document.addEventListener("keydown", this.escFunction, false); 
        this.validateUser()
        window.addEventListener('beforeunload', this.connectionInitilize)
        liveConferenceObj.socket.on('message', this.getResponse)  
    }
    /**
     * @returns {Promise.<void>}
     */
    componentWillMount() {
        this.connectionInitilize();
        window.removeEventListener('beforeunload', this.connectionInitilize); // remove the event handler for normal unmounting
    }
    /**
     * @call on page refresh,
     * @doing this rebuild connection with socket
     * @and user unregister from kurento server
     */
    connectionInitilize() {
        liveConferenceObj.sendMessage({ id: 'leaveRoom' });
    }
    /**
     * @update status in state
     * @param response
     */
    kurentoConnectionStatus(response) {
        this.setState({ kurentoConnectionStatus: response.status }, () => {
            if (!this.state.kurentoConnectionStatus) {
                toast(<Toaster notifyType="error" msg="Kurento server is not connected." />, {
                    position: toast.POSITION.BOTTOM_RIGHT,
                    hideProgressBar: true
                });
            }
        })
    }
    /**
     * @param {*} response 
     */
    joinRoomRes(response) {
        this.setState({
            message: response.message,
            conferenceStatus: response.status
        })
    }
    /**
    * Self Call Disconnect
    * @param response
    */
    changeConfStatus(response) {
        this.setState({
            message: 'Call has been disconnected',
            conferenceStatus: 'ready'
        })
    }
    /**
     * @Call after getting response from socket to client
     * @param response
     */
    getResponse(response) {
         // console.log("response: =>", response);
        switch (response.id) {
            case 'makeConnection':
                this.kurentoConnectionStatus(response);
                break;
            case 'existingParticipants':
                liveConferenceObj.onExistingParticipants(response);
                break;
            case 'newParticipantArrived':
                liveConferenceObj.onNewParticipant(response);
                break;
            case 'participantLeft':
                liveConferenceObj.onParticipantLeft(response);
                break;
            case 'selfCallDisconnect':
                liveConferenceObj.onSelfCallDisconnect(response);
                this.changeConfStatus(response)
                break;
            case 'receiveVideoAnswer':
                liveConferenceObj.receiveVideoResponse(response);
                break;
            case 'iceCandidate':
                liveConferenceObj.participants[response.name].rtcPeer.addIceCandidate(response.candidate, function (error) {
                    if (error) {
                        console.error("Error adding candidate: " + error);
                        return;
                    }
                });
                break; 
            case 'joinRoom':
                this.joinRoomRes(response);
                break;
            case 'CustomRequest':
                if (typeof liveConferenceObj[response.action] !== "undefined") {
                    liveConferenceObj[response.action](response)
                }
                if (response.action == 'onRaiseHand') {
                    this.notificationMsg(response)
                } else if (response.action == 'notification') {
                    this.notification(response)
                }
                break;
            case 'adminKickoutParticipant':
                    response.errorMsg !=='' ?  toast(<Toaster notifyType="info" msg={response.errorMsg} />, {
                        position: toast.POSITION.BOTTOM_RIGHT,
                        hideProgressBar: true
                    }) : this.disconnectCall() ;
                    break;    
            default:
                console.error('Unrecognized message', response);
        }
    }
    /**
     * @user validate here
     */
    async validateUser() {
        let confId = this.qeryStr.has('id') ? this.qeryStr.get('id') : 0
        let response = await this.props.client.query({
            query: VALIDATE_USER,
            variables: { confId: confId }
        });
        response = response.data.validateUserVideoConference;
        if (response.error) {
            this.setState({
                message: response.error,
                confDetail: {},
                participantList: []
            })
        } else {
            let selectedParticipant = [];
            let confRes = JSON.parse(response.result)
            if (confRes.length > 0) {
                if (confRes[0].VcConfParticipants) {
                    let confParticipantList = await this.contactListTravers(confRes[0].VcConfParticipants);
                    if (confParticipantList.length > 0) {
                        let responseContactList = await this.props.client.query({
                            query: CONTACT_LIST_BY_CONF,
                            variables: { id: confParticipantList }
                        });
                        if (responseContactList.data.hasOwnProperty('getContactById')) {
                            selectedParticipant = responseContactList.data.getContactById.contact
                        }
                    }
                }
                // User Info
                let participantInfo = {}
                let tokenData = JSON.parse(response.tokenData)
                if (response.userType == 'P') {
                    let currentParticipant = selectedParticipant.filter(item => { return item.id_contact == tokenData.user.id })
                    participantInfo.userType = response.userType;
                    participantInfo.email = (currentParticipant.length > 0 && currentParticipant[0].contactEmails.length > 0) ? currentParticipant[0].contactEmails[0].email : null;
                    participantInfo.name = currentParticipant.length > 0 ? `${currentParticipant[0].fname + ' ' + currentParticipant[0].lname}` : '';
                    participantInfo.confId = confRes[0].id;
                } else {
                    participantInfo.userType = response.userType;
                    participantInfo.email = tokenData.user.email;
                    participantInfo.name = 'Admin';
                    participantInfo.confId = confRes[0].id;  
                    this.getContactList();
                    this.getGroupList();                  
                }

                this.setState({
                    message: '',
                    confDetail: confRes.length && confRes[0].id ? confRes[0] : {},
                    participantList: selectedParticipant,
                    participantInfo: participantInfo,
                    tabOption: response.userType == "P" ? 'chat' : 'contacts'
                }, () => {                   
                    if (participantInfo.email == null) {
                        toast(<Toaster notifyType="info" msg={"Your are not allowed to Join the conference " + this.state.confDetail.name} />, {
                            position: toast.POSITION.BOTTOM_RIGHT,
                            hideProgressBar: true
                        });
                    }
                })
            } else {
                toast(<Toaster notifyType="info" msg="conference not exists." />, {
                    position: toast.POSITION.BOTTOM_RIGHT,
                    hideProgressBar: true
                });
                this.setState({
                    confExitstStatus: false
                })
            }
        }
    }
    /**
    * @make call
    */
    makeCall() {
        let participantInfo = this.state.participantInfo,
            kurentoConnectionStatus = this.state.participantInfo;
        if (kurentoConnectionStatus &&
            participantInfo.userType &&
            participantInfo.email &&
            participantInfo.name &&
            participantInfo.confId) {
            this.setState({
                message: "Connecting...",
                conferenceStatus: 'process' 
            }, () =>{
                liveConferenceObj.sendMessage({ id: 'joinRoom', data: participantInfo })
            })
        } else if (!kurentoConnectionStatus) {
            toast(<Toaster notifyType="error" msg="kurento server is down" />, {
                position: toast.POSITION.BOTTOM_RIGHT,
                hideProgressBar: true
            });
        } else {
            toast(<Toaster notifyType="error" msg="User detail is missing." />, {
                position: toast.POSITION.BOTTOM_RIGHT,
                hideProgressBar: true
            });
        }
    }
    /**
     * @disconnect call
     */
    disconnectCall() {
        liveConferenceObj.sendMessage({ id: 'leaveRoom', data: this.state.participantInfo });
    }
    
    notificationMsg(response) { 
                     
        toast(<Toaster notifyType="info" msg={response.msg + ' ' + response.displayName} />, {
            position: toast.POSITION.BOTTOM_RIGHT,
            hideProgressBar: true
        });
    }
    //This function is used to request a raise down by Admin
    notification(response) {               
        let participantRaiseHand = document.getElementById("icon-hand-on-"+response.name); 
        if(response.allowType == 0){
            participantRaiseHand.classList.remove('icon-hand-off');
            participantRaiseHand.classList.add('icon-hand-on'); // adding new class name         */           
        }else{
            participantRaiseHand.classList.add('active'); // adding new class name         */           
       }
        toast(<Toaster notifyType="info" msg={response.msg} />, {
            position: toast.POSITION.BOTTOM_RIGHT,
            hideProgressBar: true
        });

        
    }
    /**
     * @options for tab
     */
    changeTab(type) {
        this.setState({
            tabOption: type
        })
    }
    // function to get all contact list
    async getContactList() {
        let response = await this.props.client.query({
            query: CONTACT_LIST
        });
        this.setState({
            contactList: (response.hasOwnProperty('errors') && response.errors.length > 0) ? [] : response.data.getContacts.contact
        })
    }
    async getGroupList() {
        let response = await this.props.client.query({
            query: GROUP_LIST
        });
        this.setState({
            groupList: response.data.getContactGroups.groups
        })
    }
    async searchContact(e) {
        e.preventDefault()
        if (e.target.value.trim().length > 3 || e.target.value.trim() == 0) {
            let response = await this.props.client.query({
                query: SEARCH_CONTACT,
                variables: { input: { keyword: e.target.value } }
            });
            this.setState({
                contactList: response.data.hasOwnProperty('searchContact') ? response.data.searchContact.contact : []
            })
        }
    }


    async searchGroup(e) {
        e.preventDefault();
        if (e.target.value.trim().length > 3 || e.target.value.trim() == 0) {
            let response = await this.props.client.query({
                query: SEARCH_CONTACT_GROUP,
                variables: { name: e.target.value }
            });
            this.setState({
                groupList: response.data.hasOwnProperty('searchContactGroup') ? response.data.searchContactGroup.groups : []
            })
        }
    }
    /*********************/
    groupDetail(item) {
        console.log(item)
        this.setState({
            groupDetail: !this.state.groupDetail,
            groupDetailShow: item
        })
    }
    /********************/
    openDialog() {
        this.setState(prevState => ({
            dialogStatus: prevState.dialogStatus ? false : true
        }));
    }
    updateParticipantList(detail) {
        this.addParticipantToLiveConference(detail)
        let contactList = this.state.contactList;
        contactList = contactList.concat([detail])
        this.setState({ contactList })
    }
    async sendInvitation(id, name, email) {
        let obj = {
            id: id,
            confId: this.state.confDetail.id,
            name: name,
            email: email
        }
        let response = await this.props.inviteParticipant({ variables: { input: obj } })
        if (!response.data.inviteParticipantVideoConference.error) {
            toast(<Toaster notifyType="success" msg={response.data.inviteParticipantVideoConference.success} />, {
                position: toast.POSITION.BOTTOM_RIGHT,
                hideProgressBar: true
            });
        } else {
            toast(<Toaster notifyType="error" msg={response.data.inviteParticipantVideoConference.error} />, {
                position: toast.POSITION.BOTTOM_RIGHT,
                hideProgressBar: true
            });
        }
    }

    async addGroupParticipantToConference(event, row) {
        console.log("dfsdfds")
        let obj = {
            id: row.id_contact,
            confId: this.state.confDetail.id,
            name: row.name,
            email: row.email
        }
        let personId = document.getElementById(row.id + '-' + row.id_contact + '-person');
        let loaderId = document.getElementById(row.id + '-' + row.id_contact + '-loader');
        personId.style.display = 'none';
        loaderId.style.display = 'inline-block';
        let response = await this.props.participantAddToConference({ variables: { input: obj } });
        personId.style.display = 'inline-block';
        loaderId.style.display = 'none';
        if (!response.data.addParticipantToVideoConference.error) {
            let participantList = this.state.participantList
            participantList = participantList.concat([row])
            this.setState({
                participantList
            })
            toast(<Toaster notifyType="success" msg={response.data.addParticipantToVideoConference.success} />, {
                position: toast.POSITION.BOTTOM_RIGHT,
                hideProgressBar: true
            });
        } else {
            toast(<Toaster notifyType="error" msg={response.data.addParticipantToVideoConference.error} />, {
                position: toast.POSITION.BOTTOM_RIGHT,
                hideProgressBar: true
            });
        }
    }

    async addParticipantToLiveConference(row) {
        let obj = {
            id: row.id_contact,
            confId: this.state.confDetail.id,
            name: row.fname + ' ' + row.lname,
            email: row.contactEmails[0].email
        }
        let response = await this.props.participantAddToConference({ variables: { input: obj } });
        if (!response.data.addParticipantToVideoConference.error) {
            let participantList = this.state.participantList
            participantList = participantList.concat([row])
            this.setState({
                participantList
            })
            toast(<Toaster notifyType="success" msg={response.data.addParticipantToVideoConference.success} />, {
                position: toast.POSITION.BOTTOM_RIGHT,
                hideProgressBar: true
            });
        } else {
            toast(<Toaster notifyType="error" msg={response.data.addParticipantToVideoConference.error} />, {
                position: toast.POSITION.BOTTOM_RIGHT,
                hideProgressBar: true
            });
        }
    }

    async addParticipantToConference(row) {
        let obj = {
            id: row.id_contact,
            confId: this.state.confDetail.id,
            name: row.fname + ' ' + row.lname,
            email: row.contactEmails[0].email
        }
        let personId = document.getElementById(row.id_contact + '-person');
        let loaderId = document.getElementById(row.id_contact + '-loader');
        personId.style.display = 'none';
        loaderId.style.display = 'inline-block';
        let response = await this.props.participantAddToConference({ variables: { input: obj } });
        personId.style.display = 'inline-block';
        loaderId.style.display = 'none';
        if (!response.data.addParticipantToVideoConference.error) {
            let participantList = this.state.participantList
            participantList = participantList.concat([row])
            this.setState({
                participantList
            })
            toast(<Toaster notifyType="success" msg={response.data.addParticipantToVideoConference.success} />, {
                position: toast.POSITION.BOTTOM_RIGHT,
                hideProgressBar: true
            });
        } else {
            toast(<Toaster notifyType="error" msg={response.data.addParticipantToVideoConference.error} />, {
                position: toast.POSITION.BOTTOM_RIGHT,
                hideProgressBar: true
            });
        }
    }

    contactListTravers(arrData) {
        let result = [];
        return new Promise(resolve => {
            return asyncLoop(arrData, (item, callback) => {
                if (item) {
                    result.push(parseInt(item.cms_contact_id));
                    callback();
                } else {
                    callback();
                }
            }, err => {
                return resolve(result);
            });
        })
    }
    // for full screen on full screen
    escFunction=(event)=>{
        let fullScreen = document.getElementById(this.state.participantInfo.email);
        if(event.keyCode === 27 && fullScreen.classList.contains("fullScreen")) {                       
            fullScreen.classList.remove('fullScreen');
        }
    }    
    /**
     * @returns {XML}
     */
    render() {
        return (
            <div className>
                {
                    //this.state.confExitstStatus && this.state.participantInfo.email != null ?
                    <ConferenceLive
                        {...this.state}
                        changeTab={this.changeTab}
                        makeCall={this.makeCall}
                        disconnectCall={this.disconnectCall}
                        searchContact={this.searchContact}
                        openDialog={this.openDialog}
                        sendInvitation={this.sendInvitation}
                        addParticipantToConference={this.addParticipantToConference}
                        updateParticipantList={this.updateParticipantList}
                        groupDetail={this.groupDetail}
                        addGroupParticipantToConference={this.addGroupParticipantToConference}
                        searchGroup={this.searchGroup}
                    />
                }
            </div>
        )
    }
}
export default compose(
    withApollo,
    graphql(SEND_EMAIL_TO_PARTICIPANT, {
        name: 'inviteParticipant'
    }),
    graphql(PARTICIPANT_ADDTO_CONFERENCE, {
        name: 'participantAddToConference'
    })
)(Live)
