import React from 'react'
import asyncLoop from 'node-async-loop'
import moment from 'moment'
import _ from 'lodash';
import './../../components/style/timepicker.scss'
import {
    compose,
    withApollo,
    graphql
} from 'react-apollo'
import ConferenceCreate from '../../components/vcManagement/conference/Create'
import {
    CREATE_CONTACT,
    CREATE_CONFERENCE,
    SAVE_ROOM
} from '../../constants/mutation'
import {
    CONTACT_LIST,
    GROUP_LIST,
    SEARCH_CONTACT,
    SEARCH_CONTACT_GROUP,
    CHECK_EMAIL_EXISTS,
    CHECK_PHONE_EXISTS
} from '../../constants/query'
import helper from '../../lib/common'
import {
    toast
} from 'react-toastify';
import Toaster from "../../../common/containers/toaster";
import {
    validateCreateConference
} from "../../validation/conference";
import {
    validateCreateContact,
    addParticipantError
} from "../../validation/contact";
import mucFilter from '../../lib/mucfilter';
let helperObj = new helper;

class Create extends React.Component {
    /**
     * @param props
     * @param context
     */
    constructor(props, context) {
        super(props, context)
        // set default state
        this.state = {
            formData: {
                name: '',
                server_location: 1,
                conf_type: 1,
                server_location: 1,
                start_date_at: '',
                start_time_at: null,
                conference_agenda: '',
                recording: 0,
                participant_join_mute: 0,
                participant_onhold_leader_join: 0,
                participant_name_announce_in_join: 0,
                conference_end_admin_hangs_up: 0,
                music_play_on_join: 0,
                selectedParticipant: []
            },
            timepickerDialog: false,
            errorConference: {
                name: '',
                start_date_at: '',
                start_time_at: ''
            },
            openDialogStatus: {
                selectParticipant: {
                    status: false
                },
                addParticipant: {
                    status: false
                }
            },
            contactList: [],
            droppedOption: {
                dropped: []
            },
            addParticipantForm: {
                fname: '',
                lname: '',
                email: [{
                    email: '',
                    primary: true
                }],
                phone: [{
                    phone: '',
                    primary: true
                }],
                designation: '',
                department: '',
                organisation: '',
                errorMsg: ''
            },
            errorParticipant: {
                fname: '',
                lname: '',
                email: new Array(2).fill(''),
                phone: new Array(5).fill(''),
                designation: '',
                department: '',
                organisation: ''
            },
            errorMsg: "",
            groups: {
                selectedTab: "participant",
                list: []
            }
        }

        // Bind event to class
        this.participantFormData = Object.assign({}, this.state.addParticipantForm);
        this.errorParticipantClearData = Object.assign({}, this.state.errorParticipant);
        this.getContactList = this.getContactList.bind(this)
        this.onChange = this.onChange.bind(this)
        this.onSubmit = this.onSubmit.bind(this)
        this.onSelectSubmitParticipant = this.onSelectSubmitParticipant.bind(this)
        this.onAddSubmitParticipant = this.onAddSubmitParticipant.bind(this)
        this.onChangeAddParticipant = this.onChangeAddParticipant.bind(this)
        this.onChangeAddMore = this.onChangeAddMore.bind(this)
        this.addMore = this.addMore.bind(this)
        this.removeAddMore = this.removeAddMore.bind(this)
        this.onDrop = this.onDrop.bind(this)
        this.onDropContacts = this.onDropContacts.bind(this)
        this.removeContact = this.removeContact.bind(this)
        this.openDialog = this.openDialog.bind(this)
        this.addMoreValidate = this.addMoreValidate.bind(this)
        this.onChangeDateTime = this.onChangeDateTime.bind(this)
        this.updateContactList = this.updateContactList.bind(this);

        // Timepicker
        this.updateTimepicker = this.updateTimepicker.bind(this)
        this.timepickerOption = this.timepickerOption.bind(this)
        // tab on select participant
        this.tabOption = this.tabOption.bind(this)
        this.getGroups = this.getGroups.bind(this)
        this.participantExpands = this.participantExpands.bind(this)
        this.onDropGroups = this.onDropGroups.bind(this)
        this.onDropGroupsParticipants = this.onDropGroupsParticipants.bind(this)
        // Search on select
        this.searchContact = this.searchContact.bind(this)
        this.changeConfType = this.changeConfType.bind(this)
        this.changeServerLocation = this.changeServerLocation.bind(this)
    }


    componentDidMount() {
        this.getContactList()
        this.getGroups()
    }

    getContactList = async () => {
        let response = await this.props.client.query({
            query: CONTACT_LIST
        });
        this.setState({
            contactList: (response.hasOwnProperty('errors') && response.errors.length > 0) ? [] : response.data.getContacts.contact
        })
    }

    /**
     ** form submit
     * @param event
     */
    async onSubmit(event) {
        event.preventDefault();
        let arrTemp = [];
        let inviteUsers = [];
        let errorConference = this.state.errorConference;
        asyncLoop(this.state.formData.selectedParticipant, (item, callback) => {
            if (item) {
                arrTemp.push({
                    id: item.id_contact,
                    name: item.fname + ' ' + item.lname,
                    email: item.contactEmails[0].email
                })
                inviteUsers.push(item.contactEmails[0].email);
            }
            callback()
        }, async (err) => {
            let obj = {
                name: this.state.formData.name,
                recording: this.state.formData.recording,
                participant_join_mute: this.state.formData.participant_join_mute,
                participant_onhold_leader_join: this.state.formData.participant_onhold_leader_join,
                participant_name_announce_in_join: this.state.formData.participant_name_announce_in_join,
                conference_end_admin_hangs_up: this.state.formData.conference_end_admin_hangs_up,
                music_play_on_join: this.state.formData.music_play_on_join,
                conf_type: this.state.formData.conf_type,
                server_location: this.state.formData.server_location,
                conference_agenda: this.state.formData.conference_agenda,
                start_date_at: this.state.formData.conf_type == 1 ? this.state.formData.start_date_at : '',
                start_time_at: this.state.formData.conf_type == 1 ? this.state.formData.start_time_at : '',
                participant: arrTemp
            }
            let errorData = validateCreateConference(obj);
            if (errorData.error != null) {
                let err = errorData.error.details[0];
                if (err.path[0] === Object.keys(errorConference).find(k => k == err.path[0])) {
                    errorConference[err.path[0]] = err.message.replace(/['"]+/g, '');
                    this.setState({
                        errorConference
                    })
                } else {
                    errorConference[err.path[0]] = '';
                    this.setState({
                        errorConference
                    })
                }
            } else {
                let responseData = await this.props.createConference({
                    variables: {
                        input: obj
                    }
                })
                if (responseData.data.createVideoConference.error) {
                    this.setState({
                        errorMsg: responseData.data.createVideoConference.error
                    })
                } else {
                    toast(<Toaster notifyType="success"
                        msg="Conference Has been created successfully." />, {
                            position: toast.POSITION.BOTTOM_RIGHT,
                            hideProgressBar: true
                        });
                    this.props.history.push('/video-conference/conference/list');
                    /*  let obj = {
                        name: responseData.data.createVideoConference.uuid, 
                        contacts: inviteUsers, 
                        purpose: "Testing",
                        jid: this.props.props.sObject.sClient.config.jid.bare.replace(/\s/g,'-'),
                    };                                     
                    const conferenceObj = mucFilter.selfJoinRoom(obj);                                        
                    let roomInvitationObj = Object.assign({
                                                indexName: "videoconf", 
                                                data: conferenceObj[0] 
                                            });
                    let response = await this.props.saveRoom({ variables: { input: roomInvitationObj } });                                       
                    if(response.errors) {
                        this.setState({
                            errorMsg: response.errors
                        });
                    } else {
                        //let response = await this.props.sObject.getLoggedInUser();                       
                        toast(<Toaster notifyType="success" msg="Conference Has been created successfully." />, {                  
                            position: toast.POSITION.BOTTOM_RIGHT,
                            hideProgressBar: true
                        });                   
                        this.props.history.push('/video-conference/conference/list');      
                    }*/
                }
            }
        });
    }

    /**
     ** onChange field
     * @param event
     */
    onChange(event) {
        let formData = this.state.formData;
        let errorConference = this.state.errorConference;
        let value = (event.target.type === 'checkbox' ? (formData[event.target.name] ? 0 : 1) : event.target.value)
        formData[event.target.name] = value;
        this.setState({
            formData
        });
        let errorData = validateCreateConference({
            [event.target.name]: event.target.value
        });
        if (errorData.error != null) {
            let err = errorData.error.details[0];
            if (err.context['key'] === event.target.name) {
                errorConference[event.target.name] = err.message.replace(/['"]+/g, '');
                this.setState({
                    errorConference
                })
            } else {
                errorConference[event.target.name] = '';
                this.setState({
                    errorConference
                })
            }
        } else {
            errorConference[event.target.name] = '';
            this.setState({
                errorConference
            })
        }
    }

    /**
     ** onChangeDateTime field
     * @param event
     */

    onChangeDateTime(event, type) {
        if (type === 'start_date_at') {
            let formData = this.state.formData
            let errorConference = this.state.errorConference;
            formData.start_date_at = event == null ? '' : moment(event).format('YYYY-MM-DD')
            this.setState({
                formData
            })
            let errorData = validateCreateConference({
                'conf_type': formData.conf_type,
                'start_date_at': formData.start_date_at
            });
            if (errorData.error != null) {
                let err = errorData.error.details[0];
                if (err.context['key'] === type) {
                    errorConference[type] = err.message.replace(/['"]+/g, '');
                    this.setState({
                        errorConference
                    })
                } else {
                    errorConference[type] = '';
                    this.setState({
                        errorConference
                    })
                }
            } else {
                errorConference[type] = '';
                this.setState({
                    errorConference
                })
            }
        }
    }

    /**
     ** onSubmit add participant form
     * @param event
     */
    async onAddSubmitParticipant(event) {
        event.preventDefault()
        let formData = this.state.addParticipantForm;
        let errorParticipant = this.state.errorParticipant;
        let getErrorRes = addParticipantError(errorParticipant);

        let obj = {
            fname: formData.fname,
            lname: formData.lname,
            email: formData.email.map((row, index) => {
                return row.email;
            }),
            phone: formData.phone.map((row, index) => {
                return row.phone;
            }),
            designation: formData.designation,
            department: formData.department,
            organisation: formData.organisation
        };
        let errorData = validateCreateContact(obj);
        if (errorData.error != null) {
            let err = errorData.error.details[0];
            if (err.path[0] === Object.keys(errorParticipant).find(k => k == err.path[0])) {
                if (err.path[0] == 'email' || err.path[0] == 'phone') {
                    `"${err.context.key}"`
                    errorParticipant[err.path[0]][err.context.key] = err.message.replace(/['"]+/g, '');
                } else {
                    errorParticipant[err.path[0]] = err.message.replace(/['"]+/g, '');
                }
                this.setState({
                    errorParticipant
                })
            } else {
                errorParticipant[err.path[0]] = '';
                this.setState({
                    errorParticipant
                })
            }

        } else if (getErrorRes) {
            //console.log("already exist");
        } else {
            let obj = {
                fname: formData.fname,
                lname: formData.lname,
                designation: formData.designation,
                department: formData.department,
                organisation: formData.organisation,
                serviceIds: [1],
                contactEmails: formData.email,
                contactNumbers: formData.phone,
                intl_code: "IND"
            }
            let response = await this.props.createContact({
                variables: {
                    input: obj
                }
            })
            if (response.hasOwnProperty('errors')) {
                formData.errorMsg = JSON.stringify(response.errors)
                this.setState({
                    addParticipantForm: formData
                })
            } else {
                let contactList = this.state.contactList
                contactList = contactList.concat([response.data.createContact])
                this.setState({
                    contactList: contactList
                })
                this.openDialog('addParticipant')
            }
        }
    }

    /**
     ** onChange add participant field
     * @param event
     */
    onChangeAddParticipant = (event) => {
        let addParticipantForm = this.state.addParticipantForm;
        addParticipantForm[event.target.name] = event.target.value;
        let errorParticipant = this.state.errorParticipant;
        this.setState({
            addParticipantForm
        });
        let errorData = validateCreateContact({
            [event.target.name]: event.target.value
        });
        if (errorData.error != null) {
            let err = errorData.error.details[0];
            if (err.context['key'] === event.target.name) {
                errorParticipant[event.target.name] = err.message.replace(/['"]+/g, '');
                this.setState({
                    errorParticipant
                })
            } else {
                errorParticipant[event.target.name] = '';
                this.setState({
                    errorParticipant
                })
            }

        } else {
            errorParticipant[event.target.name] = '';
            this.setState({
                errorParticipant
            })
        }
    }

    /**
     ** onChange add more field
     * @param event
     */
    onChangeAddMore(event) {
        let addParticipantForm = this.state.addParticipantForm[event.target.name].map((item, index) => {
            if (parseInt(event.target.id) !== index) {
                return item
            } else {
                if (event.target.name == 'email') {
                    return {
                        ...item,
                        email: event.target.value
                    }
                } else {
                    return {
                        ...item,
                        phone: event.target.value
                    }
                }
            }
        })
        let updated = this.state.addParticipantForm
        updated[event.target.name] = addParticipantForm
        this.setState({
            updated
        })
        let errorParticipant = this.state.errorParticipant;
        let errorData = validateCreateContact({
            [event.target.name]: [event.target.value]
        });
        if (errorData.error != null) {
            let err = errorData.error.details[0];
            if (err.path[0] === event.target.name) {                                
                errorParticipant[event.target.name][event.target.id] = err.message.replace(/['"]+/g, '');
                this.setState({
                    errorParticipant
                })
            } else {
                errorParticipant[event.target.name][event.target.id] = '';
                this.setState({
                    errorParticipant
                })
            }

        } else {
            errorParticipant[event.target.name][event.target.id] = '';
            this.setState({
                errorParticipant
            })
        }
    }

    /**
     ** add more option
     * @param key
     */
    addMore(key, max) {
        let addParticipantForm = this.state.addParticipantForm
        if (addParticipantForm[key].length < max) {
            let objAddmore;
            if (key == 'email') {
                objAddmore = {
                    email: '',
                    primary: false,
                    errorMsg: ''
                }
            } else {
                objAddmore = {
                    phone: '',
                    primary: false,
                    errorMsg: ''
                }
            }
            addParticipantForm[key] = addParticipantForm[key].concat([objAddmore])
            this.setState({
                addParticipantForm
            })
        } else {
            toast(< Toaster notifyType="info"
                msg={
                    `only ${max - 1} alternative ${key} can be used`
                }
            />, {
                    position: toast.POSITION.BOTTOM_RIGHT,
                    hideProgressBar: true
                });
        }
    }

    /**
     ** remove option
     * @param key
     * @param index
     */
    removeAddMore(key, index) {
        let addParticipantForm = this.state.addParticipantForm
        addParticipantForm[key] = addParticipantForm[key].filter((s, sidx) => parseInt(index) !== sidx)
        this.setState({
            addParticipantForm
        });
    }

    onDrop(event) {
        event.contacts ? this.onDropContacts(event) : (event.groups) ? this.onDropGroups(event) : this.onDropGroupsParticipants(event);
    }

    removeContact(row, index) {
        if (row.hasOwnProperty('type') && row.type == 'group') {
            let droppedOption = this.state.droppedOption;
            droppedOption.dropped = droppedOption.dropped.filter((s, sidx) => parseInt(index) !== sidx)
            this.setState({
                droppedOption
            });
        } else if (row.hasOwnProperty('type') && row.type == 'participants') {
            let droppedOption = this.state.droppedOption;
            droppedOption.dropped = droppedOption.dropped.filter((s, sidx) => parseInt(index) !== sidx)
            this.setState({
                droppedOption
            });
        } else {
            let contactList = this.state.contactList,
                droppedOption = this.state.droppedOption;
            droppedOption.dropped = droppedOption.dropped.filter((s, sidx) => parseInt(index) !== sidx)

            let findDuplicate = contactList.find(item => {
                return item.id_contact == row.id_contact
            });
            if (!findDuplicate) {
                contactList = contactList.concat([row])
                this.setState({
                    droppedOption,
                    contactList
                })
            } else {
                this.setState({
                    droppedOption
                })
            }

        }
    }

    /**
     ** onSubmit select participant form
     * @param event
     */
    onSelectSubmitParticipant(event) {
        event.preventDefault()
        let formData = this.state.formData
        formData.selectedParticipant = this.state.droppedOption.dropped
        this.setState({
            formData
        })
        this.openDialog('selectParticipant')
    }


    /**
     ** open dialogbox
     * @param type
     */
    openDialog(type, cancel = false) {
        let openDialogStatus = this.state.openDialogStatus;
        if (type === 'selectParticipant' && openDialogStatus[type].status && cancel) {
            this.updateContactList();
        }
        if (type === 'addParticipant') {
            this.setState((prevState) => ({
                addParticipantForm: {
                    ...this.participantFormData
                },
                errorParticipant: {
                    ...this.errorParticipantClearData,
                    email: new Array(2).fill(''),
                    phone: new Array(5).fill('')
                }
            }));
        }
        openDialogStatus[type].status = openDialogStatus[type].status ? false : true
        this.setState({
            openDialogStatus
        })
    }


    addMoreValidate(arrData, type) {
        return new Promise(resolve => {
            let error = false
            return asyncLoop(arrData, (item, callback) => {
                if (!item.value.trim() && item.primary) {
                    item.errorMsg = `${type} cannot be blank.`
                    error = true
                } else if (item.value.trim() && !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(item.value) && type == 'email') {
                    item.errorMsg = 'Invalid email format'
                    error = true
                } else if (item.value.trim() && type == 'phone' && !item.value.match(/^[0-9]+$/)) {
                    item.errorMsg = 'Invalid phone number'
                    error = true
                } else {
                    item.errorMsg = ''
                }
                callback()
            }, err => {
                let addParticipantForm = this.state.addParticipantForm
                addParticipantForm[type] = arrData
                this.setState({
                    addParticipantForm
                })
                return resolve({
                    error: error
                })
            })
        })
    }
    /**
     * Set updateTimepicker 
     */

    updateTimepicker(time, timeString) {
        let formData = this.state.formData;
        let errorConference = this.state.errorConference;
        formData.start_time_at = (time == null ? '' : moment(time).format('hh:mm A'))

        let errorData = validateCreateConference(formData);
        if (errorData.error != null) {
            let err = errorData.error.details[0];
            if (err.context['key'] === 'start_time_at') {
                errorConference['start_time_at'] = err.message.replace(/['"]+/g, '');
                this.setState({
                    errorConference
                })
            } else {
                errorConference['start_time_at'] = '';
                this.setState({
                    errorConference
                })
            }
        } else {
            errorConference['start_time_at'] = '';
            this.setState({
                errorConference
            })
        }
    }
    timepickerOption() {
        this.setState(prevState => {
            return {
                timepickerDialog: !prevState.timepickerDialog
            }
        })
    }

    onDropContacts(event) {
        let arrStr = event.contacts.split('?'),
            index = parseInt(arrStr[1]),
            stringToJson = JSON.parse(arrStr[0]),
            droppedOption = this.state.droppedOption;

        let obj = droppedOption.dropped.find(item => {
            return item.id_contact == stringToJson.id_contact
        });
        if (!obj) {
            droppedOption.dropped = droppedOption.dropped.concat([stringToJson]);
            let contactList = this.state.contactList;
            contactList = contactList.filter((s, sidx) => index !== sidx)
            this.setState({
                droppedOption,
                contactList
            })
        } else {
            toast(< Toaster notifyType="info"
                msg="Participant is already exist" />, {
                    position: toast.POSITION.BOTTOM_RIGHT,
                    hideProgressBar: true
                });
        }
    }

    // Group implement on select participant
    tabOption(type) {
        this.setState(prevState => ({
            groups: {
                ...prevState.groups,
                selectedTab: type
            }
        }))
    }
    async getGroups() {
        let response = await this.props.client.query({
            query: GROUP_LIST
        });
        if (!response.hasOwnProperty('errors')) {
            let list = await helperObj.traverseGroupData(response.data.getContactGroups.groups);

            this.setState(prevState => ({
                groups: {
                    ...prevState.groups,
                    list: list
                }
            }))
        } else {
            this.setState(prevState => ({
                groups: {
                    ...prevState.groups,
                    list: []
                }
            }))
        }
    }
    participantExpands(id, event) {
        let circleType = event.target.id === 'add_circle' ? 'remove_circle' : 'add_circle';
        document.getElementById(`group_participant_${id}`).style.display = circleType == 'remove_circle' ? 'block' : 'none';
        event.target.innerHTML = circleType;
        event.target.id = circleType;
    }
    onDropGroups(event) {
        let stringToJson = JSON.parse(event.groups),
            filteredContact = stringToJson.contacts,
            droppedOption = this.state.droppedOption;
        if (droppedOption.dropped.length > 0) {
            asyncLoop(droppedOption.dropped, async (item, callback) => {
                let index = await helperObj.findObjectByKeyValue(stringToJson.contacts, 'id_contact', item.id_contact, true)
                if (index || index == 0) {
                    filteredContact.splice(index, 1);
                }
                callback();
            }, err => {
                if (filteredContact.length > 0) {
                    droppedOption.dropped = droppedOption.dropped.concat(filteredContact);
                    this.setState({
                        droppedOption
                    })
                }
            })
        } else {
            droppedOption.dropped = droppedOption.dropped.concat(stringToJson.contacts);
            this.setState({
                droppedOption
            })
        }
    }

    onDropGroupsParticipants(event) {
        let stringToJson = JSON.parse(event.participants),
            droppedOption = this.state.droppedOption;

        let checkDuplicate = droppedOption.dropped.find(item => {
            return item.id_contact == stringToJson.id_contact
        });
        if (checkDuplicate) {
            toast(< Toaster notifyType="info"
                msg="Participant is already exist" />, {
                    position: toast.POSITION.BOTTOM_RIGHT,
                    hideProgressBar: true
                });
            console.log("Duplicate Item")
        } else {
            droppedOption.dropped = droppedOption.dropped.concat([stringToJson]);
            this.setState({
                droppedOption
            })
        }
    }

    // Search on Select page
    async searchContact(e) {
        e.preventDefault()
        //if (e.target.value.trim().length > 3 || e.target.value.trim() == 0) {
        if (this.state.groups.selectedTab == 'participant') {
            let response = await this.props.client.query({
                query: SEARCH_CONTACT,
                variables: {
                    input: {
                        keyword: e.target.value
                    }
                }
            });
            this.setState({
                contactList: response.data.hasOwnProperty('searchContact') ? response.data.searchContact.contact : []
            })
        } else {
            let response = await this.props.client.query({
                query: SEARCH_CONTACT_GROUP,
                variables: {
                    name: e.target.value
                }
            });
            let list = [];
            if (response.data.hasOwnProperty('searchContactGroup')) {
                list = await helperObj.traverseGroupData(response.data.searchContactGroup.groups);
            }
            this.setState(prevState => ({
                groups: {
                    ...prevState.groups,
                    list: list
                }
            }))
        }

        //}
    }

    updateContactList() {

        let selectedParticipant = this.state.formData.selectedParticipant;
        let droppedOption = this.state.droppedOption;
        let contactList = this.state.contactList;
        let meargeUnique = _.uniq(droppedOption.dropped.concat(selectedParticipant), 'id_contact');

        let arrTemp = [];
        asyncLoop(meargeUnique, async (items, callback) => {
            if (items) {
                let obj = await helperObj.findObjectByKeyValue(selectedParticipant, 'id_contact', items.id_contact)
                if (!obj) {
                    arrTemp.push(items)
                }
            }
            callback()
        }, err => {

            let updatedContactList = _.uniq(contactList.concat(arrTemp), 'id_contact');
            asyncLoop(selectedParticipant, async (item, callbackInner) => {
                if (item) {
                    let key = await helperObj.findObjectByKeyValue(updatedContactList, 'id_contact', item.id_contact, true)
                    if (key || key == 0) {
                        updatedContactList.splice(key, 1)
                    }
                }
                callbackInner()
            }, error => {
                droppedOption.dropped = selectedParticipant
                this.setState({
                    contactList: updatedContactList,
                    droppedOption
                })
            })
        })
    }


    checkExistEmail = async (event, rowData) => {
        event.preventDefault();
        let errorParticipant = this.state.errorParticipant;
        let name = event.target.name,
            id = event.target.id;
        try {
            let response = await this.props.client.query({
                query: CHECK_EMAIL_EXISTS,
                variables: {
                    input: {
                        email: rowData.email
                    }
                }
            });
            errorParticipant[name][id] = response.data.isEmailExist.isExist == 1 ? 'email is already exists' : '';
            this.setState({
                errorParticipant
            })
        } catch (ex) {
            errorParticipant[name][id] = ex.message;
            this.setState({
                errorParticipant
            })
        }
    }
 
    checkExistPhone = async (event, rowData) => {
        event.preventDefault();
        let errorParticipant = this.state.errorParticipant;
        let name = event.target.name,
            id = event.target.id;
        let errorData = validateCreateContact({
            [event.target.name]: [event.target.value]
        });
        try {
            if (errorData.error != null) {
                let err = errorData.error.details[0];                
                if (err.path[0] === event.target.name) {
                    errorParticipant[name][id] = err.message.replace(/['"]+/g, '');
                    this.setState({
                        errorParticipant
                    })
                } else {
                    errorParticipant[name][id] = '';
                    this.setState({
                        errorParticipant
                    })
                }
 
            } else {
                errorParticipant[name][id] = '';
                this.setState({
                    errorParticipant
                })
                let response = await this.props.client.query({
                    query: CHECK_PHONE_EXISTS,
                    variables: {
                        input: {
                            number: rowData.phone
                        }
                    }
                });
                errorParticipant[name][id] = response.data.isNumberExist.isExist == 1 ? 'Pnone Number is already exists' : '';
                this.setState({
                    errorParticipant
                })
            }
 
        } catch (ex) {
            errorParticipant[name][id] = ex.graphQLErrors[0].message.replace(/['"]+/g, '');
            this.setState({
                errorParticipant
            })
        }
    }
    // for clear time out
    clearTimepicker = () => {
        this.setState(prevState => ({
            formData: {
                ...prevState.formData,
                start_time_at: ''
            }
        }))
    }
    // for conference type radio button
    changeConfType = (event) => {
        let formData = this.state.formData;
        formData['conf_type'] = event.target.value;
        this.setState({
            formData
        });
    }

    changeServerLocation = (event) => {
        let formData = this.state.formData;
        formData['server_location'] = event.target.value;
        this.setState({
            formData
        });
    }

    /**
     * @returns {XML}
     */
    render() {
        return (<
            ConferenceCreate { ...this.state
            }
            onSubmit={
                this.onSubmit
            }
            onChange={
                this.onChange
            }
            onChangeDateTime={
                this.onChangeDateTime
            }
            openDialog={
                this.openDialog
            }
            onSelectSubmitParticipant={
                this.onSelectSubmitParticipant
            }
            onAddSubmitParticipant={
                this.onAddSubmitParticipant
            }
            onChangeAddParticipant={
                this.onChangeAddParticipant
            }
            onChangeAddMore={
                this.onChangeAddMore
            }
            addMore={
                this.addMore
            }
            removeAddMore={
                this.removeAddMore
            }
            onDrop={
                this.onDrop
            }
            removeContact={
                this.removeContact
            }
            timepickerOption={
                this.timepickerOption
            }
            updateTimepicker={
                this.updateTimepicker
            }
            tabOption={
                this.tabOption
            }
            participantExpands={
                this.participantExpands
            }
            searchContact={
                this.searchContact
            }
            checkExistEmail={
                this.checkExistEmail
            }
            checkExistPhone={
                this.checkExistPhone
            }
            clearTimepicker={
                this.clearTimepicker
            }
            changeConfType={
                this.changeConfType
            }
            changeServerLocation={
                this.changeServerLocation
            }
        />
        )
    }
}

export default compose(
    withApollo,
    graphql(SAVE_ROOM, {
        name: 'saveRoom'
    }),
    graphql(CREATE_CONTACT, {
        name: 'createContact'
    }),
    graphql(CREATE_CONFERENCE, {
        name: 'createConference'
    })
)(Create)