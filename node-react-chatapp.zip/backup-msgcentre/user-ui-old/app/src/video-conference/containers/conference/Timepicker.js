import React from 'react'
import TimepickerForm from '../../components/vcManagement/dialogBox/TimepickerForm'

class Timepicker extends React.Component {

    /**
     * @param props
     * @param context
     */
    constructor(props, context) {
        super(props, context)
        // set default state
        this.state = {
            timepicker:{
                status:false,
                hour:0,
                minute:0,
                meridiam:'AM'
            }
        }
        this.onChange = this.onChange.bind(this);
        this.onAction = this.onAction.bind(this);
        this.onDateTimeFormat = this.onDateTimeFormat.bind(this);
    }
    componentWillReceiveProps(nextProps) {
        let timepickerArr = [], 
            timepickerMeridiamArr = []; 

        if(nextProps.defValues)
        {
           timepickerArr =  nextProps.defValues.split(":");
           timepickerMeridiamArr = timepickerArr.length >1 ? timepickerArr[1].split(" "):[]; 
       }
        this.setState((prevState) =>({
            timepicker:{
                ...prevState.timepicker,
                status: nextProps.status,
                hour: timepickerArr.length >0 ? parseInt(timepickerArr[0]) : 0,
                minute: timepickerMeridiamArr.length >0 ? parseInt(timepickerMeridiamArr[0]) : 0,
                meridiam: timepickerMeridiamArr.length >1 ? timepickerMeridiamArr[1] : 'AM'
            }
        }))
    }
    /**
     * Timepicker
     */
    
    onAction(type, action, event)
    {
        event.preventDefault();
        switch(type)
        {
            case "hour" : 

                if(action == 'up')
                {
                    this.setState((prevState) => ({
                        timepicker: {
                            ...prevState.timepicker,
                            hour: (prevState.timepicker.hour == 12) ? 0 : prevState.timepicker.hour +1
                        }
                    }), () =>{
                        this.props.updateTimepicker(this.state.timepicker)
                    })
                }else{
                    this.setState((prevState) => ({
                        timepicker: {
                            ...prevState.timepicker,
                            hour:  (prevState.timepicker.hour == 0) ? 0 : prevState.timepicker.hour -1
                        }
                    }), () =>{
                        this.props.updateTimepicker(this.state.timepicker)
                    })
                } 
                break;
            case "minute" : 
                    if(action == 'up')
                    {
                        this.setState((prevState) => ({
                            timepicker: {
                                ...prevState.timepicker,
                                minute: (prevState.timepicker.minute == 60) ? 0 : prevState.timepicker.minute +1
                            }
                        }), () =>{
                            this.props.updateTimepicker(this.state.timepicker)
                        })
                    }else{
                        this.setState((prevState) => ({
                            timepicker: {
                                ...prevState.timepicker,
                                minute:  (prevState.timepicker.minute == 0) ? 0 : prevState.timepicker.minute -1
                            }
                        }), () =>{
                            this.props.updateTimepicker(this.state.timepicker)
                        })
                    }
                break;
            case "meridiam" : 
                    this.setState((prevState) => ({
                        timepicker: {
                            ...prevState.timepicker,
                            meridiam: prevState.timepicker.meridiam == 'AM' ? 'PM' : 'AM'
                        }
                    }), () =>{
                        this.props.updateTimepicker(this.state.timepicker)
                    })
                break;
            default:
                console.log("default =>", action)
                break;
        } 
    }
    onChange(val, max, type)
    { 
        let timeVal = this.onDateTimeFormat(val, max);
        let timeData = this.state.timepicker;
        timeData[type] = timeVal;
        this.setState((prevState)=>({
            timepicker:{
                ...prevState,timepicker:timeData
            }
        }),()=>{                                     
            this.props.updateTimepicker(this.state.timepicker); 
        });
        this.props.updateTimepicker(this.state.timepicker);                                 
    }
    
     onDateTimeFormat(val, max){       
          if (val.length === 1 && val[0] > max[0]) {
            val = '0' + val;
          }          
          if (val.length === 2) {
            if (Number(val) === 0) {
              val = '00';       
          } else if (val > max) {
              val = max;
            }
          }                  
          return val;                                                
    }
    /**
     * @returns {XML}
     */
    render() {
        return (
            <div>
            <TimepickerForm
                {...this.state}
                onChange={this.onChange}
                onAction={this.onAction}
                onDateTimeFormat = {this.onDateTimeFormat}
            />
            </div>
        )
    }
}

export default Timepicker