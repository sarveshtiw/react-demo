import React from 'react';
import {compose, withApollo, graphql} from 'react-apollo'
import { Row, Col, Grid, Table, FormControl, Pagination, OverlayTrigger, Tooltip, SplitButton, MenuItem, FormGroup, InputGroup } from 'react-bootstrap';
import Dropdown from 'react-dropdown';
import Slider, { Range } from 'rc-slider';
import ConfRecordingList from '../../components/vcManagement/conference/RecordingList'
import {RECORDING_LIST_BY_CONF} from '../../constants/query'
var createReactClass = require('create-react-class');
const LinkWithTooltip = createReactClass({
    render() {
        let tooltip = <Tooltip id={this.props.id}>{this.props.tooltip}</Tooltip>;
        return (
            <OverlayTrigger
                overlay={tooltip}
                placement="top"
                delayShow={300}
                delayHide={150}
            >
                <a href={this.props.href}>{this.props.children}</a>
            </OverlayTrigger>
        );
    }
});

class RecordingList extends React.Component {

    /**
     * @param props
     * @param context
     */
    constructor(props) {
        super(props);
        this.state = {
            confId:this.props.match.params.id ? this.props.match.params.id:null,
            audioPlay: false,
            audioPause: false,
            audioDownload: false,
            audioDelete: false,
            data: [],
            pages: null,
            loading: false,
            conf_name:'',
            conf_type:''
        };
        this.handleClick = this.handleClick.bind(this);
        this.audioPlay = this.audioPlay.bind(this);
        this.audioPause = this.audioPause.bind(this);
        this.audioDownload = this.audioDownload.bind(this);
        this.audioDelete = this.audioDelete.bind(this);
        this.fetchData = this.fetchData.bind(this);
    }
    async fetchData(state) {                
        this.setState({ loading: true });
        let conferenceListResp = await this.props.client.query({
            query: RECORDING_LIST_BY_CONF,
            variables:{input:{page: state.page, pageSize: state.pageSize,sorted: state.sorted,filtered: state.filtered,confId:this.state.confId}}
        });               
        this.setState({
            conf_name:conferenceListResp.data.getRecordingVideoConferenceById.result.conf_name,
            conf_type:conferenceListResp.data.getRecordingVideoConferenceById.result.conf_type,
            data: conferenceListResp.data.getRecordingVideoConferenceById.result.vc_recording,
            pages: conferenceListResp.data.getRecordingVideoConferenceById.pages,
            loading: false
        })        
    }    
    handleClick(item) {
        let updatedList = this.state.list.map(obj => {
            if (obj.id === item.id) {
                return Object.assign({}, obj, {
                    hidden: !item.hidden
                });
            }
            return obj;
        });
        this.setState({
            list: updatedList,
        });
    }
    audioPlay(e) {
        this.setState(
            function (prevState) {
                var audioElement = document.getElementById('beep-' + 1);
                audioElement.setAttribute("preload", "auto");
                audioElement.autobuffer = true;
                audioElement.load();
                audioElement.play();
                return {
                    audioPlay: true
                };
            });
    }

    audioPause(e) {
        if (this.state.audioPlay) {
            this.setState({
                audioPlay: false,
            }, function () {
                var audioElement = document.getElementById('beep-' + 1);
                audioElement.pause();
            });
        }
    }

    audioDownload(e) {
        if (this.state.audioDownload) {
            this.setState({
                audioDownload: false,
            }, function () {
                var audioElement = document.getElementById('beep');
                audioElement.download();
            });
        }
    }
    audioDelete(e) {
        alert('Delete');
        if (this.state.audioDelete) {
            this.setState({
                audioDelete: false,
            }, function () {
                var audioElement = document.getElementById('beep');
                audioElement.pause();
            });
        }
    }

    playLine(e) {

    }

    render() {
        console.log("=======================1",this.state.conf_type)
        return (
            <div className="ibox">
                <div className="ibox-title">
                    <h5>Recording List</h5>
                    <div className="topBarbtn">
                        <SplitButton title="Dropdown" pullRight id="split-button-pull-right">
                            <MenuItem eventKey="3">Download CSV</MenuItem>
                            <MenuItem divider />
                            <MenuItem eventKey="4">Download Excel</MenuItem>
                        </SplitButton>
                    </div>

                    <Row className="cdrGroupinfo">
                        <Row>
                            <Col md={4}>
                                <Row>
                                    <div className="form-group">
                                        <div className="col-sm-12">
                                            Conference Name: &nbsp;&nbsp;<span>{this.state.conf_name}</span>
                                        </div>
                                    </div>
                                </Row>
                            </Col>
                            <Col md={4}>
                                <Row>
                                    <div className="form-group">
                                        <div className="col-sm-12">
                                            Call Type: &nbsp;&nbsp;<span>{this.state.conf_type==1?'Reserved-Call':'Un-Reserved Call'}</span>
                                        </div>
                                    </div>
                                </Row>
                            </Col>
                        </Row>
                    </Row>
                </div>
                <div className="ibox-content" style={{padding: "0px 15px 0px 15px"}}>
                    <Row className="mainTable">
                        <ConfRecordingList
                            data = {this.state.data}
                            pages={this.state.pages}
                            loading={this.state.loading}
                            fetchData={this.fetchData}
                        />
                    </Row>
                </div>
            </div>
        );
    }
}
export default compose(
    withApollo
)(RecordingList);