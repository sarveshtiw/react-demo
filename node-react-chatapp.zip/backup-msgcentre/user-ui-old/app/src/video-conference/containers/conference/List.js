import React from 'react'
import { compose, withApollo, graphql } from 'react-apollo'
import asyncLoop from 'node-async-loop'
import Switch from 'react-switch_case'
import { toast } from 'react-toastify'
import { Link } from 'react-router-dom'
import { Row, Col, Table, FormControl, Pagination, OverlayTrigger, Tooltip, FormGroup, InputGroup, SplitButton, MenuItem, ButtonGroup, Button, ButtonToolbar, DropdownButton } from 'react-bootstrap';
import Dropdown from 'react-dropdown'
import NoResult from '../../../common/components/noResult'
import ReactExport from 'react-data-export';
import jsPDF from 'jspdf'
import 'jspdf-autotable'
import { CSVLink } from 'react-csv'

import ActiveConferenceList from '../../components/vcManagement/conference/ActiveList'
import {
    CONFERENCE_LIST_BY_USER,
    CONFERENCE_DETAIL,
    CONTACT_LIST_BY_CONF
} from '../../constants/query'
import {
    UPDATE_CONFERENCE_STATUS,
    DELETE_ROOM
} from '../../constants/mutation'
import Toaster from "../../../common/containers/toaster"
import ViwConference from '../../components/vcManagement/dialogBox/ViewConference'

let Case = Switch.Case;
const xlsColumns = ["Conference Name", "Total Member", "Start Date", "Start Time", "Status", "Conference Type"];
const headers = [
    { label: 'Conference Name', key: 'name' },
    { label: 'Total Member', key: 'totalMember' },
    { label: 'Start Date', key: 'start_date_at' },
    { label: 'Start Time', key: 'start_time_at' },
    { label: 'Status', key: 'live' },
    { label: 'Conference Type', key: 'conf_type' },
];
const ExcelFile = ReactExport.ExcelFile;
const ExcelSheet = ReactExport.ExcelFile.ExcelSheet;

class List extends React.Component {
    /**
     * @param props
     * @param context
     */
    constructor(props, context) {
        super(props, context);
        this.state = {
            data: [],
            xlsxData: [
                {
                    columns: [],
                    data: []
                }
            ],
            csvData: {
                columns: [],
                data: []
            },
            pages: null,
            loading: false,
            selected: {},
            selectAll: 0,
            dateValue: null,
            viewDetails: false,
            objData: {},
            participant: []
        };
        this.fetchData = this.fetchData.bind(this);
        this.updateStatus = this.updateStatus.bind(this);
        this.toggleRow = this.toggleRow.bind(this);
        this.toggleSelectAll = this.toggleSelectAll.bind(this);
        this.contactListTravers = this.contactListTravers.bind(this);
    }

    toggleRow(id) {
        const newSelected = Object.assign({}, this.state.selected);
        newSelected[id] = !this.state.selected[id];
        this.setState({
            selected: newSelected,
            selectAll: 2
        });
    }
    toggleSelectAll() {
        let newSelected = {};
        if (this.state.selectAll === 0) {
            this.state.data.forEach(x => {
                newSelected[x.id] = true;
            });
        }
        this.setState({
            selected: newSelected,
            selectAll: this.state.selectAll === 0 ? 1 : 0
        });
    }
    componentDidMount(){
        this.fetchData({page: 0, pageSize: 5, sorted: [], filtered: [], confListType: this.state.confList});
    }
    async fetchData(state) {
        this.setState({ loading: true });
        let conferenceListResp = await this.props.client.query({
            query: CONFERENCE_LIST_BY_USER,
            variables: { input: { page: state.page, pageSize: state.pageSize, sorted: state.sorted, filtered: state.filtered, confListType: this.state.confList } }
        });
        let result = conferenceListResp.data.getVideoConferences.result;
        let objData = [], csvData = [];
        for (let item of result) {
            let Obj = Object.assign({}, item);
            delete Obj.id;
            delete Obj.__typename;
            Obj.conf_type = Obj.conf_type ? 'Reserved' : 'Un-Reserved';
            Obj.live = Obj.live ? 'Live' : 'Non-Live';
            Obj.start_date_at = Obj.start_date_at == null ? '' : Obj.start_date_at;
            csvData.push(Obj);
            objData.push(Object.values(Obj));
        }
        this.setState({
            data: conferenceListResp.data.getVideoConferences.result,
            pages: conferenceListResp.data.getVideoConferences.pages,
            xlsxData: [{
                columns: xlsColumns,
                data: objData
            }],
            csvData: {
                columns: xlsColumns,
                data: csvData
            },
            loading: false
        });
    }

    async updateStatus(id, event) {
        // event.preventDefault();
        let responseData = await this.props.updateConferenceStatus({ variables: { conference_id: id } });
        if (!responseData.data.updateStatusVideoConference.error) {
            toast(<Toaster notifyType="info" msg="Conference Has been deleted successfully." />, {
                position: toast.POSITION.BOTTOM_RIGHT,
                hideProgressBar: true
            });
            this.fetchData({ page: 0, pageSize: 5, sorted: [], filtered: [], confListType: this.state.confList });
            /*            let deleteParams = {
                            indexName: 'videoconf',
                            conferenceName: responseData.data.updateStatusVideoConference.uuid
                        };
                        let response = await this.props.deleteRoom({ variables: { input: deleteParams } });
                        if(response.errors) {
                            toast(<Toaster notifyType="error" msg={response.errors}/>, {
                                position: toast.POSITION.BOTTOM_RIGHT,
                                hideProgressBar: true
                            });
                            this.setState({
                                errorMsg: response.errors
                            });
                        } else {
                            toast(<Toaster notifyType="info" msg="Conference Has been deleted successfully." />, {
                                position: toast.POSITION.BOTTOM_RIGHT,
                                hideProgressBar: true
                            });
                        }  */
        } else {
            toast(<Toaster notifyType="error" msg={responseData.data.updateStatusVideoConference.error} />, {
                position: toast.POSITION.BOTTOM_RIGHT,
                hideProgressBar: true
            });
        }
    }

    viewConfDetails = async (data) => {
        let response = await this.props.client.query({
            query: CONFERENCE_DETAIL,
            variables: { id: data }
        });
        response = response.data.getVideoConferenceById;
        if (response.error) {

        } else {
            let selectedParticipant = [];
            if (response.result[0].VcConfParticipants.length > 0) {
                let confParticipantList = await this.contactListTravers(response.result[0].VcConfParticipants);
                if (confParticipantList.length > 0) {
                    let responseContactList = await this.props.client.query({
                        query: CONTACT_LIST_BY_CONF,
                        variables: { id: confParticipantList }
                    });
                    if (responseContactList.data.hasOwnProperty('getContactById')) {
                        selectedParticipant = responseContactList.data.getContactById.contact
                    }
                }
            }
            this.setState({
                objData: response.result.length ? response.result[0] : {},
                participant: selectedParticipant,
                viewDetails: true
            })
        }
    }

    contactListTravers(arrData) {
        let result = [];
        return new Promise(resolve => {
            return asyncLoop(arrData, (item, callback) => {
                if (item) {
                    result.push(parseInt(item.cms_contact_id));
                    callback();
                } else {
                    callback();
                }
            }, err => {
                return resolve(result);
            });
        })
    }

    tableToPdf() {
        var doc = new jsPDF('p', 'pt');
        doc.autoTable(this.state.xlsxData[0].columns, this.state.xlsxData[0].data, {
            styles: { fillColor: [100, 255, 255] },
            columnStyles: {
                id: { fillColor: 255 }
            },
            margin: { top: 60 },
            addPageContent: function (data) {
                doc.text("Asergis Video Conferencing", 40, 30);
            }
        });
        doc.save('vc-' + Math.floor(Date.now() / 1000) + '.pdf');
    }
    /**
     * @returns {XML}
     */

    render() {
        if(!this.state.data.length){
            return <NoResult
                        data='Create Conference'
                        clickRef={()=>this.props.history.push('/video-conference/conference/create')}
                    />
        }

        return (
            <div className="ibox">
                <div className="ibox-title clearfix mng-toparea">
                    <h5>Conference List</h5>
                    <div className="topBarbtn">
                        <ButtonToolbar>
                            <Link className="btn btn-default" to="./create">
                                <i className="material-icons">add</i>
                            </Link>
                        </ButtonToolbar>
                         <ButtonToolbar>
                            <DropdownButton title={<i className="material-icons">file_download</i>} pullRight noCaret>
                                <MenuItem eventKey="1">
                                    <ExcelFile
                                        filename={'vc-' + Math.floor(Date.now() / 1000) + '.xlsx'}
                                        element={'Download Excel'}
                                    >
                                        <ExcelSheet dataSet={this.state.xlsxData} name="Organization" />
                                    </ExcelFile>
                                </MenuItem>
                                <MenuItem divider />
                                <MenuItem eventKey="2" onClick={this.tableToPdf.bind(this)}>Download Pdf</MenuItem>
                                <MenuItem divider />
                                <li eventKey="3">
                                    <CSVLink
                                        data={this.state.csvData.data}
                                        headers={headers}
                                        filename={'vc-' + Math.floor(Date.now() / 1000) + '.csv'}
                                        target="_blank"
                                    >Download CSV
                                    </CSVLink>
                                </li>
                            </DropdownButton>
                        </ButtonToolbar>
                    </div>
                </div>
                <div className="ibox-content">
                    <Row className="gTable-new mainTable">
                        <ActiveConferenceList
                            data={this.state.data}
                            pages={this.state.pages}
                            loading={this.state.loading}
                            fetchData={this.fetchData}
                            updateStatus={this.updateStatus}
                            selected={this.state.selected}
                            selectAll={this.state.selectAll}
                            toggleRow={this.toggleRow}
                            toggleSelectAll={this.toggleSelectAll}
                            dateValue={this.state.dateValue}
                            viewConfDetails={this.viewConfDetails}
                        />
                    </Row>
                </div>
                {this.state.viewDetails &&
                    <ViwConference
                        customClass="customModal"
                        confData={this.state.objData}
                        participant={this.state.participant}
                        upperClose={true}
                        closeModal={() => this.setState({ viewDetails: false })}
                    />}
            </div>
        )
    }
}
export default compose(
    withApollo,
    graphql(DELETE_ROOM, {
        name: 'deleteRoom'
    }),
    graphql(UPDATE_CONFERENCE_STATUS, {
        name: 'updateConferenceStatus'
    })
)(List)