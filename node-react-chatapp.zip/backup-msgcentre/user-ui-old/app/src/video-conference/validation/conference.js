const Joi = require('joi-browser');
const dateFormat = require('dateformat');
var emailRegex = /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;


let participantListValid = {
    id:Joi.number().integer().required(),
    name:Joi.string().required(),
    email:Joi.string().email().regex(emailRegex).error(new Error('pincode is missing')).required()
};

let schemaCreateConference = Joi.object().keys({    
    name: Joi.string().min(5).max(100).required().label("Conference Name").trim().regex(/^[\w\-\s]+$/).optional(),
    recording:Joi.number().valid(0,1).required().optional(),
    participant_join_mute: Joi.number().valid(0,1).required().optional(),
    participant_onhold_leader_join: Joi.number().valid(0,1).required().optional(),
    participant_name_announce_in_join: Joi.number().valid(0,1).required().optional(),
    conference_end_admin_hangs_up: Joi.number().valid(0,1).required().optional(),
    music_play_on_join: Joi.number().valid(0,1).required().optional(),
    conf_type: Joi.number().valid(0,1).required().optional(),
    server_location:Joi.number().valid(1,2,3).required().optional(),
    conf_agenda:Joi.string().min(3).max(255).allow('').optional(),
    start_date_at : Joi.when('conf_type',{
        is:1,
        then :
        Joi.date().min(dateFormat(new Date(), "yyyy-mm-dd")).required().label("Start Date"),
        otherwise:Joi.optional()
    }),
    start_time_at : Joi.when('conf_type',{
        is:1,
        then :
        Joi.string().regex(/^([0-1]?[0-9]|2[0-3])(:[0-5][0-9]) ([AaPp][Mm])?$/).required().label("Start Time"),
        otherwise:Joi.optional()
    }),
    participant:Joi.array().items(participantListValid)
});

let schemaUpdateConference = Joi.object().keys({  
    id:Joi.number().integer().required().optional(),  
    name: Joi.string().min(5).max(100).required().label("Conference Name").trim().regex(/^[\w\-\s]+$/).optional(),
    recording:Joi.number().valid(0,1).required().optional(),
    participant_join_mute: Joi.number().valid(0,1).required().optional(),
    participant_onhold_leader_join: Joi.number().valid(0,1).required().optional(),
    participant_name_announce_in_join: Joi.number().valid(0,1).required().optional(),
    conference_end_admin_hangs_up: Joi.number().valid(0,1).required().optional(),
    music_play_on_join: Joi.number().valid(0,1).required().optional(),
    conf_type: Joi.number().valid(0,1).required().optional(),
    server_location:Joi.number().valid(1,2,3).required().optional(),
    conf_agenda:Joi.string().min(3).max(255).allow('').optional(),
    start_date_at : Joi.when('conf_type',{
        is:1,
        then :
        Joi.date().min(dateFormat(new Date(), "yyyy-mm-dd")).required().label("Start Date"),
        otherwise:Joi.optional()
    }),
    start_time_at : Joi.when('conf_type',{
        is:1,
        then :
        Joi.string().regex(/^([0-1]?[0-9]|2[0-3])(:[0-5][0-9]) ([AaPp][Mm])?$/).required().label("Start Time"),
        otherwise:Joi.optional()
    }),
    participant:Joi.array().items(participantListValid)  
});

const validateCreateConference = (inputCreateConference) => { // Validate validateAddContact API
    return Joi.validate(inputCreateConference, schemaCreateConference,{ abortEarly: true,stripUnknown: true});
}

const validateUpdateConference = (inputUpdateConference) => { // Validate validateAddContact API
    return Joi.validate(inputUpdateConference, schemaUpdateConference, { abortEarly: true,stripUnknown: true});
}

module.exports = {
    validateCreateConference,
    validateUpdateConference
}