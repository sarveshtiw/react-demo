const Joi = require('joi-browser');
const dateFormat = require('dateformat');

var emailRegex = /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;

const schemaCreateContact = Joi.object().keys({
    fname: Joi.string().min(3).max(30).required().label('First Name').optional(),
    lname: Joi.string().min(3).max(30).label('Last Name').allow('').optional(),
    email: Joi.array().items(Joi.string().email().regex(emailRegex).required().label('Email')).optional().options({
        language: {
            string: {
                regex: {
                base: 'Please enter valid email'
                }
            }
        }
    }),
    phone: Joi.array().items(Joi.number().integer().required().label('Phone Number')).optional(),
    designation: Joi.string().min(2).max(30).label('Designation').allow('').optional(),
    department: Joi.string().min(2).max(30).label('Department').allow('').optional(),
    organisation: Joi.string().min(2).max(30).label('Organisation').allow('').optional()
});

const validateCreateContact = (inputCreateContact) => {
   // console.log("inputCreateContact =>", inputCreateContact);
    return Joi.validate(inputCreateContact, schemaCreateContact, { abortEarly: false });
}

const validateUpdateContact = (inputCreateContact) => {        
    return Joi.validate(inputCreateContact, schemaCreateContact,{ abortEarly: false });
}

const addParticipantError = (errorParticipant) => { 
    
    let emailError = errorParticipant.email.find(item =>{ return item !=""}) ? true:false;
    let phoneError = errorParticipant.phone.find(item =>{ return item !=""}) ? true:false;
    
    if(emailError || phoneError) return true;
    return false;
}

module.exports = {
    validateCreateContact,
    validateUpdateContact,
    addParticipantError
}