import gql from 'graphql-tag';

export const CONFERENCE_LIST_BY_USER = gql`
     query getVideoConferences($input:VconfListInput) {
      getVideoConferences(input:$input){
          error
          result {
            id
            name  
            totalMember
            start_date_at
            start_time_at                                          
            live
            conf_type
          }
          pages
         }
     }
`
export const CONFERENCE_DETAIL = gql`
     query getVideoConferenceById($id: Int) {
      getVideoConferenceById(id:$id){
          error
          result{
            id
            uid_ua_user
            name
            recording
            participant_join_mute
            participant_onhold_leader_join
            participant_name_announce_in_join
            conference_end_admin_hangs_up
            music_play_on_join
            live
            conf_type
            server_location
            conference_agenda
            start_date_at
            start_time_at
            is_deleted  
            VcConfParticipants{
              cms_contact_id
            }
          }
       }       
    }
`
export const CONTACT_LIST = gql`
query{
  getContacts{
    contact{
      id_contact
      uid_ua_user
      fname
      lname
      intl_code
      designation
      department
      organisation
      contactEmails{
        id_contact_email
        id_contact
        email
        primary
        status
      }
      contactNumbers{
        id_contact_phone
        id_contact
        phone
        primary
        status
      }
    }
  }
}`
export const CONTACT_LIST_BY_CONF = gql`
query getContactById($id: [Int]) {
  getContactById(id:$id){
            contact{
              id_contact
              uid_ua_user
              fname
              lname
              intl_code
              designation
              department
              organisation
              contactEmails{
                id_contact_email
                id_contact
                email
                primary
                status
              }
              contactNumbers{
                id_contact_phone
                id_contact
                phone
                primary
                status
              }
            }
          }
        }
        `
  export const SEARCH_CONTACT = gql`
    query searchContact($input:searchContact!){
      searchContact(input:$input){
        contact{
          id_contact
          uid_ua_user
          fname
          lname
          intl_code
          designation
          department
          organisation
          contactEmails{
            id_contact_email
            id_contact
            email
            primary
            status
          }
          contactNumbers{
            id_contact_phone
            id_contact
            phone
            primary
            status
          }
        }
      }  
    }
  `        
  export const RECORDING_LIST_BY_CONF = gql`
        query getRecordingVideoConferenceById($input:VcRecordingInput){
          getRecordingVideoConferenceById(input:$input){
            error
            result{
              conf_name
              conf_type
              vc_recording{
                id
                start_date_time
                end_date_time
              }
            }
            pages
          }
        }
  
  `  
  export const VALIDATE_USER = gql`
  query validateUserVideoConference($confId:Int){
    validateUserVideoConference(confId:$confId){
      error
      userType
      tokenData
      result
    }
  } 
  ` 
  
  export const GROUP_LIST = gql`
    query getContactGroups{
      getContactGroups{
        groups{
          id_group
          group_name
          GroupMembers{
            Contact{
              id_contact
              fname
              lname
              contactEmails{
                id_contact_email
                email
              }
            }
          }
        }
      }
    }
  `


  export const SEARCH_CONTACT_GROUP = gql`
    query searchContactGroup($name: String){
      searchContactGroup(name:$name){
        groups{
          id_group
          group_name
          GroupMembers{
            Contact{
              id_contact
              fname
              lname
              contactEmails{
                id_contact_email
                email
              }
            }
          }
        }    
      }
    }
  `
  
  export const CHECK_EMAIL_EXISTS = gql`
    query isEmailExist($input:isEmailExistIn){
      isEmailExist(input:$input){
        isExist
      }
    }
  `
  export const CHECK_PHONE_EXISTS = gql`
    query isNumberExist($input:isNumberExistIn){
      isNumberExist(input:$input){
        isExist
      }
    }
  `
  
// Query for Message Centre API
  export const GET_CHAT_MESSAGES = gql`
      query getChatMessages($input:getChatsInput) {
          getChatMessages(input:$input) {
              message
              total
              scrollId
              data {
                  type
                  id
                  body
                  from {
                      name
                      jid
                  }
                  to {
                      name
                      jid
                  }
                  isAttachment
                  isEdited
                  isFavourite
                  isDeleted
                  createdOn
              }
          }
      }
  `
  export const GET_ROOM_LISTS = gql`
      query getMessageRooms($input:getRoomListIn){
          getMessageRooms(input:$input){
              message
              data {
                  name
                  nick
                  jid {
                      bare
                  }
                  autojoin
                  unread
                  description
                  role
                  affiliation
                  local
                  type
              }
          }
      }
  `
  export const GET_ROOM_MEMBERS = gql`
      query getMessageRoomMembers($input:getRoomMembersIn) {
          getMessageRoomMembers(input:$input) {
              message
              data {
                  jid
              }
          }
      }
  `
  
  export const GET_NOTIFICATION_LIST = gql`
      query getMessageNotifications($input:getNotificationListIn) {
          getMessageNotifications(input:$input) {
              message
              data {
                  id
                  type
                  status
                  body
                  from {
                    bare
                    full
                    local
                  }
                  to {
                    bare
                    full
                    local
                  }
                  createdOn
              }
          }
      }
  `
  
  export const GET_USER_STATUS = gql`
      query getMessageUserStatus($input:getUserStatusInput) {
          getMessageUserStatus(input:$input) {
              message
              data {
                  jid
                  status
                  showtypes
                  fullName
                  displayName
                  cap {
                      node
                      hash
                      ver
                  }
              }
          }
      }
  `
  
  export const GET_ACTIVE_USERS = gql`
      query getMessageActiveUsers($input:getActiveUsersInput) {
          getMessageActiveUsers(input:$input){
              message
              data{
                  jid
                  displayName
                  fullName
                  showtypes
                  status
              }
          }
      }    
  `
  
  export const GET_LOGGEDIN_USER_INFO = gql`
      query getMessageUserProfile($input:getUserProfileInput) {
          getMessageUserProfile(input:$input){
              message
              data {
                  jid
                  displayName
                  fullName,
                  showtypes,
                  status,
                  userImage
              }
          }
      }    
  `
  
  export const GET_COMPANY_USERS = gql`
      query getMessageUserProfile($input:getUserProfileInput) {
          getMessageUserProfile(input:$input){
              message,
              data{
                  jid
                  displayName
                  fullName,
                  showtypes,
                  status,
                  userImage
              }
          }
      }    
  `   