
import gql from 'graphql-tag';

export const CREATE_CONTACT = gql`
   mutation createContact($input: createContact!) {
       createContact(input:$input) {
              id_contact
              uid_ua_user
              fname
              lname
              designation
              department
              organisation
              contactEmails{
                id_contact_email
                id_contact
                email
                primary
                status
              }
              contactNumbers{
                id_contact_phone
                id_contact
                phone
                primary
                status
              }
           }
   }
`;


export const CREATE_CONFERENCE = gql`
  mutation createVideoConference($input: createConferenceInput!) {
    createVideoConference(input:$input) {
          error
          result
          uuid
       }
   }
`;
export const UPDATE_CONFERENCE = gql`
  mutation updateVideoConference($input: updateConferenceInput!) {
    updateVideoConference(input:$input) {
          error
          result          
       }
   }
`;

export const UPDATE_CONFERENCE_STATUS = gql`
  mutation updateStatusVideoConference($conference_id:Int){
    updateStatusVideoConference(conference_id:$conference_id){
         error
         success
         uuid         
      }
  }
`;

export const SEND_EMAIL_TO_PARTICIPANT = gql`
    mutation inviteParticipantVideoConference($input:sendEmailToParticipantInput){
      inviteParticipantVideoConference(input:$input){
              error
              success
            }
    }
`;

export const PARTICIPANT_ADDTO_CONFERENCE = gql`
    mutation addParticipantToVideoConference($input:addVcParticipantToConference){
      addParticipantToVideoConference(input:$input){
              error
              success
            }
    }
`;

export const LIVE_PARTICIPANT_VIDEO_CONFERENCE = gql`
    mutation liveParticipantVideoConference($input:LiveParticipantVideoConferenceInput){
      liveParticipantVideoConference(input:$input){
        error
        success
      }
    }
`;
export const AUTH_TOKEN_VERIFY = gql`
    mutation tokenVerify($input:TokenVerifyInput!) {
        tokenVerify(input:$input) {
            user_type
            result
        }
    }
`
export const SAVE_CHAT = gql`
    mutation createChatMessage($input:saveChatInput) {
        createChatMessage(input:$input) {
            message
            data {
                result
                createdOn
                _id
            }
        }
    }
`
export const UPDATE_CHAT = gql`
    mutation updateChatMessage($input:updateChatInput) {
        updateChatMessage(input:$input) {
            message
            data {
                updated
            }
        }
    }
`
export const SAVE_ROOM = gql`
    mutation createMessageRoom($input:saveRoomIn) {
        createMessageRoom(input:$input) {
            message
            data {
                result
                _id
            }
        }
    }
`
export const UPDATE_ROOM = gql`
    mutation updateMessageRoom($input:updateRoomIn) {
        updateMessageRoom(input:$input) {
            message
            data {
                updated
            }
        }
    }
`
export const LEAVE_ROOM = gql`
    mutation leaveMessageRoom($input:updateRoomIn) {
        leaveMessageRoom(input:$input) {
            message
            data {
                updated
            }
        }
    }
`
export const DELETE_ROOM = gql`
    mutation deleteMessageRoom($input:deleteRoomIn) {
        deleteMessageRoom(input:$input) {
            message
            data {
                deleted
            }
        }
    }
`
export const SAVE_NOTIFICATION = gql`
    mutation createMessageNotification($input:addNotificationIn) {
        createMessageNotification(input:$input) {
            message
            data {
                result
                _id
            }
        }
    }
`
export const UPDATE_NOTIFICATION  = gql`
    mutation updateMessageNotification($input:updateNotificationIn) {
        updateMessageNotification(input:$input) {
            message
            data {
                updated
            }
        }
    }
`
export const SAVE_USER = gql`
    mutation createMessageUser($input:saveUserInput) {
        createMessageUser(input:$input) {
            message
            data {
                result
                _id
            }
        }
    }
`
export const UPDATE_USER_PROFILE_INFO = gql`
    mutation updateMessageUserProfileInfo($input:userUpdateProfileInput) {
        updateMessageUserProfileInfo(input:$input) {
            message
            data {
                updated
            }
        }
    }
`
export const GET_URL_INFO = gql`
    mutation getMessageScraperUrlInfo($input:getUrlInfoInput) {
        getMessageScraperUrlInfo(input:$input) {
            status
            message
            data {
                ogTitle
                ogDescription
                ogImage
                ogSiteName
                ogUrl
                ogLocale
            }
        }
    }
`
export const ADD_CONTACTS = gql`
    mutation addMessageContacts($input:addContactsInput) {
        addMessageContacts(input:$input) {
            message
            data {
                result
                _id
            }
        }
    }
`

