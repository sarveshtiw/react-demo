import React from 'react'
import { compose, withApollo } from 'react-apollo'
import Switch from 'react-switch_case'
import TopMenu from './containers/menu/TopMenu'
import Dashboard from './containers/dashboard/Content'
import LiveConfDashboard from './containers/conference/LiveConfDashboard'
//import XmppEventHandlers from './lib/XmppEventHandlers';
let Case = Switch.Case
let self;
class VideoConference extends React.Component {

    constructor(props, context) {
        super(props, context)
        self = this;
        this.actionName = this.props.location.pathname.split('/').find(item => { return item == 'live' })
        let qeryStr = new URLSearchParams(this.props.location.search)
        // this.state = {
        //     actionName: this.actionName ? 'live' : 'not_live',
        //     //sObject: new XmppEventHandlers(localStorage.uuid, localStorage.token, wsUrl, this.props),
        //     sPresence: {},
        //     sMessages: {},
        //     sNotifications: {},
        //     sMucInvitation: {},
        //     sDiscoCaps: [],
        //     sAvatar: {}
        // }
    }
    componentDidMount() {
        /* this.state.sObject.sClient.on('auth:failed', this.handleFailedAuth)
        this.state.sObject.sClient.on('disconnected', '')
        this.state.sObject.sClient.on('session:end', '')
        this.state.sObject.sClient.on('presence', '')
        this.state.sObject.sClient.on('disco:caps', this.handleDiscoCaps)
        this.state.sObject.sClient.on('unavailable', '')
        this.state.sObject.sClient.on('muc:invite', this.handleNewMucInvitation)
        this.state.sObject.sClient.on('attention', this.handleNotifications)
        this.state.sObject.sClient.on('chat', this.handleMessages)
        this.state.sObject.sClient.on('groupchat', this.handleMessages)
        //this.state.sObject.sClient.on('pubsub:event', this.handlePubSub)
        this.state.sObject.sClient.on('avatar', this.handleAvtar) */
    }

    componentWillReceiveProps(nextProps) {
        let actionName = nextProps.location.pathname.split('/').find(item => { return item == 'live' })
        this.setState({
            actionName: actionName ? 'live' : 'not_live'
        })
    }

    handleFailedAuth = (data) => {
        window.location = '/auth';
    }

    //handle user notifications
    handleNotifications = (data) => {
        //update state value
        let notifications = {
            ...self.state,
            sNotifications: {
                ...self.state.sNotifications,
                all: {
                    ...self.state.sNotifications.all,
                    [data.id]: data
                }
            },
            status: 1,
            active: {}
        };
        self.setState(notifications)

        //add new notification into elastic
        this.state.sObject.addToMyContact(data);
    }

    //handle muc invitations
    handleNewMucInvitation = (data) => {
        self.setState({
            sMucInvitation: data
        })
    }

    //handle incoming discocaps
    handleDiscoCaps = (data) => {
        var caps = {
            ...self.state,
            sDiscoCaps: {
                ...self.state.sDiscoCaps,
                [data.from.bare]: data
            }
        }
        self.setState(caps)
    }

    //handle incoming messages
    handleMessages = async (data) => {
        //check if message is coming from a different source like pidgin
        let mid;
        if (data.id.indexOf('synthesis') >= 0) {
            mid = Number(data.id.replace("synthesis", ""));
            data.createdOn = Number(mid); //change with server value

        } else {
            data.createdOn = new Date().getTime(); //assign a random value
            let response = await self.state.sObject.saveChat(data);
            mid = Number(response.data.createdOn);
            data.createdOn = Number(response.data.createdOn); //change with server value
        }

        //const jid = (data.from.channel ? data.from.channel : data.from.bare);
        let messages = {
            ...self.state,
            sMessages: [...self.state.sMessages, data]
        }
        self.setState(messages, () => {

        })
    }

    handlePubSub = (data) => {
        console.log('handlepubsub', data);
    }

    //handle avtars
    handleAvtar = (data) => {
        var avt = {
            ...self.state,
            sAvatar: {
                ...self.state.sAvatar,
                [data.jid.bare]: data
            }
        }
        self.setState(avt)
    }
    /**
     * @returns {XML}
     */
    render() {
        return (
            <div>
                <Switch value={this.state.actionName}>
                    <Case value="live">
                        <LiveConfDashboard {...this.props} />
                    </Case>
                    <Case value="not_live">
                        <TopMenu {...this.props} />
                        <Dashboard {...this.props} {...this.state} />
                    </Case>
                    </Switch>
            </div>
        )
    }
}

export default compose(
    withApollo
)(VideoConference)