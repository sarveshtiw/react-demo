import React from "react";
import { compose, withApollo } from "react-apollo";
import TopMenu from "../common/containers/MainTopMenu";
import Dashboard from "./containers/dashboard/Content";

const menu = {
  title: "synthesis admin portal",
  menuItem: [
    {
      title: "Dashboard",
      route: "/admin-portal",
      subNav: []
    },
    {
      title: "Company Management",
      route: "/admin-portal/company",
      subNav: [
        {
          title: "Create Domain Company",
          route: "/admin-portal/company/create",
          subNav: []
        },
        {
          title: "Domain Company List",
          route: "/admin-portal/company/company-list",
          subNav: []
        },
        {
          title: "Document Title List",
          route: "/admin-portal/company/document-list",
          subNav: []
        },
        {
          title: "Company In-Process",
          route: "/admin-portal/company/process",
          subNav: []
        },
        {
          title: "Create Reseller",
          route: "/admin-portal/company/reseller/create",
          subNav: []
        },
        {
          title: "Reseller List",
          route: "/admin-portal/company/reseller/list",
          subNav: []
        },
        {
          title: "Reseller in-Process",
          route: "/admin-portal/company/reseller/process",
          subNav: []
        },
      ]
    },
    {
      title: "Billing",
      route: "/admin-portal/billing",
      subNav: []
    }
  ]
};

class AdminPortal extends React.Component {
  render() {
    return (
      <div className="main">
        <TopMenu {...this.props} menu={menu} />
        <Dashboard {...this.props} />
      </div>
    );
  }
}

export default compose(withApollo)(AdminPortal);
