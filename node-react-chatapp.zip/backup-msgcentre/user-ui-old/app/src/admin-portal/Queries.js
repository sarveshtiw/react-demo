import gql from 'graphql-tag';

export const GEtCREATECOMPANYDATA = gql`
  query {
    ownership: getOwnershipData {
      id
      name_ownership
    }
    industry: getIndustryData {
      id
      name_industry
    }
  }
`;
