import gql from 'graphql-tag';

export const CREATE_COMPANY = gql`
  mutation createAdminCompany($input: createCompanyIn) {
    createAdminCompany(input: $input) {
      message
    }
  }
`;
