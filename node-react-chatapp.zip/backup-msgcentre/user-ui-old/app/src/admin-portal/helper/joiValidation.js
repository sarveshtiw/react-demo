import Joi from 'joi-browser';
import dateFormat from 'dateformat';
const emailRegex = /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;

const WebsiteRegex = /^((ftp|http|https):\/\/)?(www.)?(?!.*(ftp|http|https|www.))[a-zA-Z0-9_-]+(\.[a-zA-Z]+)+((\/)[\w#]+)*(\/\w+\?[a-zA-Z0-9_]+=\w+(&[a-zA-Z0-9_]+=\w+)*)?$/gm;

let participantListValid = {
  id: Joi.number()
    .integer()
    .required(),
  name: Joi.string().required(),
  email: Joi.string()
    .email()
    .regex(emailRegex)
    .error(new Error('pincode is missing'))
    .required(),
};

let schemaCreateConference = Joi.object().keys({
  name: Joi.string()
    .min(5)
    .max(100)
    .required()
    .trim()
    .regex(/^[\w\-\s]+$/)
    .optional(),
  recording: Joi.number()
    .valid(0, 1)
    .required()
    .optional(),
  participant_join_mute: Joi.number()
    .valid(0, 1)
    .required()
    .optional(),
  participant_onhold_leader_join: Joi.number()
    .valid(0, 1)
    .required()
    .optional(),
  participant_name_announce_in_join: Joi.number()
    .valid(0, 1)
    .required()
    .optional(),
  conference_end_admin_hangs_up: Joi.number()
    .valid(0, 1)
    .required()
    .optional(),
  music_play_on_join: Joi.number()
    .valid(0, 1)
    .required()
    .optional(),
  conf_type: Joi.number()
    .valid(0, 1)
    .required()
    .optional(),
  //start_date_at: Joi.date().min(dateFormat(new Date(), "yyyy-mm-dd")).optional().allow(''),
  start_date_at: Joi.when('start_time_at', {
    is: '',
    then: Joi.empty(''),
    otherwise: Joi.date().min(dateFormat(new Date(), 'yyyy-mm-dd')),
  }),
  //start_time_at:Joi.alternatives().when('start_date_at', { is: '', then: Joi.empty(''), otherwise: Joi.string().regex(/^([0-1]?[0-9]|2[0-3])(:[0-5][0-9]) ([AaPp][Mm])?$/) }),
  start_time_at: Joi.string()
    .regex(/^([0-1]?[0-9]|2[0-3])(:[0-5][0-9]) ([AaPp][Mm])?$/)
    .allow(''),
  participant: Joi.array().items(participantListValid),
});

let schemaUpdateConference = Joi.object().keys({
  id: Joi.number()
    .integer()
    .required()
    .optional(),
  name: Joi.string()
    .min(5)
    .max(100)
    .required()
    .trim()
    .regex(/^[\w\-\s]+$/)
    .optional(),
  recording: Joi.number()
    .valid(0, 1)
    .required()
    .optional(),
  participant_join_mute: Joi.number()
    .valid(0, 1)
    .required()
    .optional(),
  participant_onhold_leader_join: Joi.number()
    .valid(0, 1)
    .required()
    .optional(),
  participant_name_announce_in_join: Joi.number()
    .valid(0, 1)
    .required()
    .optional(),
  conference_end_admin_hangs_up: Joi.number()
    .valid(0, 1)
    .required()
    .optional(),
  music_play_on_join: Joi.number()
    .valid(0, 1)
    .required()
    .optional(),
  conf_type: Joi.number()
    .valid(0, 1)
    .required()
    .optional(),
  //start_date_at: Joi.date().min(dateFormat(new Date(), "yyyy-mm-dd")).optional().allow(''),
  start_date_at: Joi.when('start_time_at', {
    is: '',
    then: Joi.empty(''),
    otherwise: Joi.date().min(dateFormat(new Date(), 'yyyy-mm-dd')),
  }),
  //start_time_at:Joi.alternatives().when('start_date_at', { is: '', then: Joi.empty(''), otherwise: Joi.string().regex(/^([0-1]?[0-9]|2[0-3])(:[0-5][0-9]) ([AaPp][Mm])?$/) }),
  start_time_at: Joi.string()
    .regex(/^([0-1]?[0-9]|2[0-3])(:[0-5][0-9]) ([AaPp][Mm])?$/)
    .allow(''),
  participant: Joi.array().items(participantListValid),
});

let schemaCreateCompany = Joi.object().keys({
  company_name: Joi.string()
    .required()
    .optional(),
  registration_number: Joi.string()
    .required()
    .optional(),
  industry: Joi.number()
    .integer()
    .invalid(0)
    .required()
    .optional(),
  ownership: Joi.number()
    .integer()
    .allow('')
    .optional(),
  noOfEmployees: Joi.number()
    .integer()
    .allow('')
    .optional(),
  website: Joi.string()
    .trim()
    .regex(WebsiteRegex)
    .allow('')
    .optional()
    .error(errors => {
      console.log(errors[0].type);
      return {
        template: 'must be valid',
        context: {
          errors: errors.length,
          codes: errors.map(err => err.type),
        },
      };
    }),
  phone: Joi.number()
    .integer()
    .required()
    .allow('')
    .optional(),
  fax: Joi.number()
    .integer()
    .required()
    .allow('')
    .optional(),
  email: Joi.string()
    .email()
    .regex(emailRegex)
    .required()
    .optional()
    .error(errors => {
      return {
        template: 'must be valid',
        context: {
          errors: errors.length,
          codes: errors.map(err => err.type),
        },
      };
    }),
  confirmEmail: Joi.any().valid(Joi.ref('email')),
});

let schemaAddresses = Joi.object().keys({
  address_line1: Joi.string()
    .required()
    .optional(),
  address_line2: Joi.string().allow(''),
  address_line3: Joi.string().allow(''),
  id_country: Joi.number()
    .integer()
    .required()
    .optional(),
  id_city: Joi.number()
    .integer()
    .required()
    .optional(),
  id_state: Joi.number()
    .integer()
    .required()
    .optional(),
  pincode: Joi.number()
    .greater(5)
    .integer()
    .required()
    .optional(),
});

const validateCreateConference = inputCreateConference => {
  // Validate validateAddContact API
  return Joi.validate(inputCreateConference, schemaCreateConference, {
    abortEarly: true,
    stripUnknown: true,
  });
};

const validateUpdateConference = inputUpdateConference => {
  // Validate validateAddContact API
  return Joi.validate(inputUpdateConference, schemaUpdateConference, {
    abortEarly: true,
    stripUnknown: true,
  });
};

export const validateCreateCompany = inputCreateCompany => {
  // Validate validateAddContact API
  return Joi.validate(inputCreateCompany, schemaCreateCompany, {
    abortEarly: true,
    stripUnknown: true,
  });
};

export const validateAddress = inputAddress => {
  // Validate validateAddContact API
  return Joi.validate(inputAddress, schemaAddresses, {
    abortEarly: true,
    stripUnknown: true,
  });
};
