import React from "react";
import PropTypes from "prop-types";

import "../style/tabs_wizard.scss";

const Wizard = ({}) => (
  <div className="stepper stepper--flexbox">
    <div className="stepper__step active">
      <label className="stepper__button">Domain Company Details</label>
    </div>

    <div className="stepper__step">
      <label className="stepper__button">Domain Company Details</label>
    </div>

    <div className="stepper__step">
      <label className="stepper__button">Domain Company Details</label>
    </div>

    <div className="stepper__step">
      <label className="stepper__button">Domain Company Details</label>
    </div>

    <div className="stepper__step">
      <label className="stepper__button">Domain Company Details</label>
    </div>

    <div className="stepper__step">
      <label className="stepper__button">Domain Company Details</label>
    </div>

    <div className="stepper__step">
      <label className="stepper__button">Domain Company Details</label>
    </div>

    <div className="stepper__step">
      <label className="stepper__button">Domain Company Details</label>
    </div>
  </div>
);

export default Wizard;
