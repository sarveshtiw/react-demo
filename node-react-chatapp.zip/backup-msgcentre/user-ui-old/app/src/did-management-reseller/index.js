import React from 'react';
import TopMenu from '../common/containers/MainTopMenu'
import Dashboard from './containers/dashboard/Content'
import { compose, withApollo } from 'react-apollo'

const menu = {
  title: "Did Management Reseller",
  menuItem: [
    {
      title: "Dashboard",
      route: "/did-management-reseller",
      subNav: [
        {
          title: "Hello",
          route: "/did-management-reseller/hello",
        },
        {
          title: "Hello123",
          route: "/did-management-reseller/hello123",
        },
        {
          title: "Hello234",
          route: "/did-management-reseller/hello234",
        }
      ]
    },
    {
      title: "view did",
      route: "/did-management-reseller/view-did",
      subNav: []
    },
    {
      title: "manage did",
      route: "/did-management-reseller/manage-did",
      subNav: []
    },
    {
      title: "view customers",
      route: "/did-management-reseller/view-customers",
      subNav: []
    },
    {
      title: "call detail record",
      route: "/did-management-reseller/call-details-record",
      subNav: []
    },
    {
      title: "Support",
      route: "/did-management-reseller/support",
      subNav: [
        {
          title: "Support 1",
          route: "/did-management-reseller/support1",
        },
        {
          title: "Support 123",
          route: "/did-management-reseller/hello123",
        },
        {
          title: "Hello234",
          route: "/did-management-reseller/hello234",
        }
      ]
    }
  ]
}

class DidManagementReseller extends React.Component {
  render() {
    return (
      <div className="main">
        <TopMenu {...this.props} menu={menu} />
        <Dashboard {...this.props} />
      </div>
    );
  }
}

export default compose(
  withApollo
)(DidManagementReseller);