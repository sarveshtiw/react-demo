import React from 'react';
import DashLeftMenu from '../components/DashLeft';
import DashRightMenu from '../components/DashRight';
import Content from '../components/Content';
import '../styles/components/content.css';

class MainDashboard extends React.Component {
    render() {
        return (
            <div className="container-mine">
                <div className="mainArea">
                    <DashLeftMenu />
                    <Content />
                    <DashRightMenu />
                </div>
            </div>
        );
    }
};

export default MainDashboard; 