import React from 'react';
import { Button, Navbar, Nav, NavItem, NavDropdown, DropdownButton, FormGroup, MenuItem, FormControl, Col } from 'react-bootstrap';
import { IndexLinkContainer } from 'react-router-bootstrap';
import {
  Link
} from 'react-router-dom'
import NavDrop from '../../common/components/NavDrop';
import '../styles/components/topbar.css';

const abc = () => {
  console.log('testing arrow func');
}
class Topbar extends React.Component {


  constructor(props) {
    super(props);
    this.state = {
      popoverMenu: false,
      subNavbar: false

    };
    this.popoverShow = this.popoverShow.bind(this);
    this.popoverHide = this.popoverHide.bind(this);
    this.subNavbar = this.subNavbar.bind(this);
  }

  componentWillMount = () => {
    abc();
  }

  popoverShow() {
    this.setState({
      popoverMenu: true
    });
  }

  popoverHide() {
    this.setState({
      popoverMenu: false
    });
  }
  subNavbar(callback) {
    //console.log("onclick");
    if (!this.state.subNavbar) {
      this.setState({
        subNavbar: true,
      })
    } else {
      this.setState({
        subNavbar: false
      })
    }
  }

  render() {
    return (
      <div className="navigation">
        <Navbar collapseOnSelect className="nav-synthesis">
          <Navbar.Collapse>
            <Nav>
              <NavItem eventKey={1} href="#"><i className="icon-dashboard"></i> Dashboard</NavItem>
              <NavItem eventKey={2} href="#"><i className="icon-myaccount"></i> My Account</NavItem>
              <NavItem eventKey={2} href="#"><i className="icon-support"></i> Support</NavItem>
            </Nav>
            <Navbar.Header>
              <Navbar.Brand>
                <a href="#"><img src="./images/logo.png" alt="Synthesis Dashboard" /></a>
                <a href="#" onClick={this.subNavbar}><i className="icon-app"></i></a>
              </Navbar.Brand>
              <Navbar.Toggle />
            </Navbar.Header>
            <div className="nav navbar-nav navbar-right">
              <FormGroup controlId="formBasicText" className={!this.state.popoverMenu ? "btnGroup" : "btnGroup focus"}>
                <form name="search-message" onSubmit={this.props.handleSearch} autoComplete="off">
                  <FormControl type="text" name="searchInput" placeholder="Search" onBlur={this.popoverHide} value={this.state.search} onFocus={this.popoverShow}></FormControl>
                  <span className="form-control-feedback material-icons">search</span>
                </form>
              </FormGroup>
              <NavDrop />
            </div>
          </Navbar.Collapse>
        </Navbar>
        {this.state.subNavbar &&
          <Navbar collapseOnSelect className="nav-synthesis bottom">
            <Navbar.Collapse>
              <Nav>
                <IndexLinkContainer to="/audio-conference">
                  <NavItem eventKey={2}>
                    <i className="material-icons">headset_mic</i> Audio Conferencing
                  </NavItem>
                </IndexLinkContainer>
                <IndexLinkContainer to="/video-conference">
                  <NavItem eventKey={3}>
                    <i className="material-icons">ondemand_video</i> Video Conferencing
                </NavItem>
                </IndexLinkContainer>
                <IndexLinkContainer to="/crm">
                  <NavItem eventKey={2} href="#">
                    <i className="material-icons">contacts</i>CRM</NavItem>
                </IndexLinkContainer>
                <IndexLinkContainer to="/message-centre">
                  <NavItem eventKey={2} href="#"><i className="material-icons">forum</i> Message Centre</NavItem>
                </IndexLinkContainer>
                <IndexLinkContainer to="/did-management/request-did-tracking">
                  <NavItem eventKey={2}><i className="material-icons">dialpad</i> DID Management</NavItem>
                </IndexLinkContainer>
                <IndexLinkContainer to="/did-management-reseller">
                  <NavItem eventKey={2}><i className="material-icons">dialpad</i> DID Management Reseller</NavItem>
                </IndexLinkContainer>
                <IndexLinkContainer to="/contact-management">
                  <NavItem eventKey={2}><i className="material-icons">contact_phone</i> Contact Management</NavItem>
                </IndexLinkContainer>
                <IndexLinkContainer to="/admin-portal">
                  <NavItem eventKey={2}><i className="material-icons">contact_phone</i>Admin Portal</NavItem>
                </IndexLinkContainer>
              </Nav>
            </Navbar.Collapse>
          </Navbar>
        }
      </div>
    )
  }
}

export default Topbar;
