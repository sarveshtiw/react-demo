import React from 'react';
import '../styles/components/dashLeft.css';

class DashLeftMenu extends React.Component {
  render() {
    return (
      <div className="dashleft">
        <ul>
          <li>
            <a href="#"><i className="icon-sub"></i></a>
          </li>
          <li>
            <a href="#"><i className="icon-services"></i></a>
          </li>
          <li>
            <a href="#"><i className="icon-did"></i></a>
          </li>
          <li>
            <a href="#"><i className="icon-invoices"></i></a>
          </li>
          <li>
            <a href="#"><i className="icon-account"></i></a>
          </li>
          <li>
            <a href="#"><i className="icon-channel"></i></a>
          </li>
          <li>
            <a href="#"><i className="icon-demo"></i></a>
          </li>
          <li>
            <a href="#"><i className="icon-customer-list"></i></a>
          </li>
        </ul>
      </div>
    );
  }
}

export default DashLeftMenu;