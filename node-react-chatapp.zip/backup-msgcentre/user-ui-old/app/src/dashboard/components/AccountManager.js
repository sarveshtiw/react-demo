import React from 'react';
import { Row, Col, Image } from 'react-bootstrap';
import '../styles/components/accountManager.css';

class AccountManager extends React.Component {


  componentWillReceiveProps(nextprops) {
    //console.log("dsfdsfsdf===", nextprops)
  }

  render() {
    const { profileDetails } = this.props
    return (
      <div>
        {
          Object.keys(profileDetails).length != 0 ? <div className="ibox">
            <div className="ibox-content">
              <div className="accountHead">
                <Row>
                  <Col md={4} className="img">
                    <Image src="../images/account-icon.jpg" circle />
                  </Col>
                  <Col md={8} className="ac-info">
                    <h4>{profileDetails.Profile.title + ' ' + profileDetails.Profile.fname + ' ' + profileDetails.Profile.lname}</h4>
                    <p>{profileDetails.Profile.Designation !== null ? profileDetails.Profile.Designation.designation_name : ''}</p>
                    <p><i className="material-icons">location_on</i> {profileDetails.Profile.Country !== null ? profileDetails.Profile.Country.country_name : ''}</p>
                  </Col>
                </Row>
                <hr />
                <Row>
                  <Col md={12} className="ac-details">
                    <p><i className="material-icons">email</i> {profileDetails.email}</p>
                    <p><i className="material-icons">location_on</i> support@asergis.in</p>
                    <p><i className="material-icons">call</i> + 91 (0) 9845562114</p>
                    <p><i className="material-icons">phone_iphone</i> {profileDetails.Profile.phone}</p>
                  </Col>
                </Row>
              </div>
            </div>
          </div> : ''
        }
      </div>
    );
  }
}



export default AccountManager;