import React from 'react';
import { Row, Col, Grid } from 'react-bootstrap';
import { compose, withApollo, graphql } from 'react-apollo';
import { withRouter, Redirect } from 'react-router-dom';
import { PROFILE_DATA } from '../Queries';
import ActivityLog from './ActivityLog';
import AccountManager from './AccountManager';
import CallUsage from './CallUsage';
import FullCalendar from './FullCalender';
import LastLogin from './LastLogin';
import GlobalPopLocation from './GlobalPopLocation';
import MyServices from './MyServices';
import DashInvoice from './DashInvoice';

import '../styles/components/dashboard.css';

class MainDashboard extends React.Component {

  state = {
    profileDetails: {}
  }

  componentDidMount = async () => {
    await this.getProfileData()
  }


  getProfileData = async () => {
    try {
      let response = await this.props.client.query({
        query: PROFILE_DATA
      })
      this.setState({
        profileDetails: response.data.profile
      })
    } catch (err) {
      console.log(err);
    }
  }

  render() {
    const { profileDetails } = this.state
    return (
      <div className="middleArea">
        <Grid fluid>
          {/* <Row>
            <Col md={4}>
              <ActivityLog />
            </Col>
            <Col md={6}>
            </Col>
            <Col md={3}>
              <MyServices />
            </Col>
            <Col md={9}>
              <GlobalPopLocation />
            </Col>
          </Row> */}
          <Row>
            <Col md={8}>
              <CallUsage />
            </Col>
            <Col md={4}>
              <LastLogin />
              <MyServices />
            </Col>
          </Row>
          <Row>
            <Col md={4}>
              <AccountManager profileDetails={profileDetails} />
              <DashInvoice />
            </Col>
            <Col md={8}>
              <FullCalendar />
            </Col>
          </Row>
          <Row>
            <Col md={4}>

            </Col>
            <Col md={4}>
              Hello 2
            </Col>
            <Col md={4}>
              Hello 3
            </Col>
          </Row>
        </Grid>
        <div className="clearfix"></div>
      </div>
    );
  }
}

export default compose(
  withApollo,
  withRouter
)(MainDashboard);