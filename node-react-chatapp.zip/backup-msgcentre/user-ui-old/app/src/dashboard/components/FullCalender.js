import React from 'react';
import { Row, Col, ButtonToolbar, DropdownButton, MenuItem } from 'react-bootstrap';
import moment from 'moment';
import BigCalendar from 'react-big-calendar';
import events from '../constants/event';
import '../styles/components/fullCalender.css';

BigCalendar.momentLocalizer(moment);
let allViews = Object.keys(BigCalendar.Views).map(k => BigCalendar.Views[k]);

class FullCalendar extends React.Component {
    render() {
        return (
            <div className="ibox">
                <div className="ibox-title">
                    <h5>Calendar</h5>
                    <div className="barBtn">
                        <ButtonToolbar>
                            <DropdownButton title="Audio Conferencing" id="dropdown-size-medium">
                                <MenuItem eventKey="1">Video Conferencing</MenuItem>
                                <MenuItem eventKey="2">Voice Over</MenuItem>
                                <MenuItem eventKey="3">Interactive Voice</MenuItem>
                                {/* <MenuItem divider />
                                    <MenuItem eventKey="4">Separated link</MenuItem> */}
                            </DropdownButton>
                        </ButtonToolbar>
                    </div>
                </div>
                <div className="ibox-content">
                    <div className="toplegend2">
                        <div>
                            <span><b className="color1"></b></span> Reserved Conference
                            </div>
                        <div>
                            <span><b className="color3"></b></span> Recurring Conference
                            </div>
                    </div>
                    <div className="calenderHeight">
                        <BigCalendar
                            {...this.props}
                            events={events}
                            views={['month', 'week', 'day']}
                            step={60}
                            popup={true}
                            defaultDate={new Date(2017, 11, 1)}
                        />
                    </div>
                </div>
            </div>
        );
    }
}

export default FullCalendar;