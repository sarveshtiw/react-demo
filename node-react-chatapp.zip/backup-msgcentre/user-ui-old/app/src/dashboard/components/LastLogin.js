import React from 'react';
import { Row, Col, Image } from 'react-bootstrap';

import '../styles/components/lastLogin.css';

class LastLogin extends React.Component {
  render() {
    return (
      <div className="ibox">
        <div className="ibox-content">
          <div className="last-login">
            <Row>
              <Col md={12}>
                <div><i className="material-icons">notifications_active</i></div>
                <div>
                  Today 
                  <span>December 11, 2017, 02:24 PM</span>
                </div>
              </Col>
            </Row>
            <p>Last account activity: <span>1 minute ago</span></p>
          </div>
        </div>
      </div>
    );
  }
}

export default LastLogin;