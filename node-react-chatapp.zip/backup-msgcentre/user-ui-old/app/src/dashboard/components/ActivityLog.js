import React from 'react';
import '../styles/components/acticitylog.css';

class ActivityLog extends React.Component {
  render() {
    return (
        <div className="ibox">
            <div className="ibox-title">
                <h5>Activity Log</h5>
            </div>
            <div className="ibox-content">
                <div className="feed-activity-list">
                    <div className="feed-element">
                        <div>
                            <small className="pull-right">3 minuts ago</small>
                            <h6 className="text-navy">@ryan</h6>
                            <p>selected audio conferencing  service and made changes to the settings</p>
                        </div>
                    </div>
                    <div className="feed-element">
                        <div>
                            <small className="pull-right">5 minuts ago</small>
                            <h6 className="text-navy">@john</h6>
                            <p>selected audio conferencing  service and made changes to the settings</p>
                        </div>
                    </div>
                    <div className="feed-element">
                        <div>
                            <small className="pull-right">9 minuts ago</small>
                            <h6 className="text-navy">@david</h6>
                            <p>selected audio conferencing  service and made changes to the settings</p>
                        </div>
                    </div>
                    <div className="feed-element">
                        <div>
                            <small className="pull-right">15 minuts ago</small>
                            <h6 className="text-navy">@alia</h6>
                            <p>selected audio conferencing  service and made changes to the settings</p>
                        </div>
                    </div>
                    <div className="feed-element">
                        <div>
                            <small className="pull-right">17 minuts ago</small>
                            <h6 className="text-navy">@rajesh</h6>
                            <p>selected audio conferencing  service and made changes to the settings</p>
                        </div>
                    </div>
                    <div className="feed-element">
                        <div>
                            <small className="pull-right">18 minuts ago</small>
                            <h6 className="text-navy">@jetlee</h6>
                            <p>selected audio conferencing  service and made changes to the settings</p>
                        </div>
                    </div>
                    <div className="feed-element">
                        <div>
                            <small className="pull-right">20 minuts ago</small>
                            <h6 className="text-navy">@sandra</h6>
                            <p>selected audio conferencing  service and made changes to the settings</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>        
    );
  }
}

export default ActivityLog;