import React from 'react';
import { Row, Col } from 'react-bootstrap';
import { Chart } from 'react-google-charts';
import '../styles/components/globalPopLocation.css';

class GlobalPopLocation extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      options: {
        sizeAxis: { minValue: 0, maxValue: 100 },
        displayMode: 'markers',
        legend: 'none',
        // region: '155', // Western Europe
        // colorAxis: { colors: ['#e7711c', '#4374e0'] } // orange to blue
      },
      data: [
        ['Country', 'Active'],
        ['India', 600],
        ['UK', 500],
        ['China', 600]
      ],
    };
  }
  render() {
    return (
      <div className="ibox">
        <div className="ibox-title">
          <h5>Global POP Server Locations</h5>
        </div>
        <div className="ibox-content globalPop clearfix">
          <Col md={7}>
            <Chart
              chartType="GeoChart"
              data={this.state.data}
              options={this.state.options}
              graph_id="geochart"
              width="100%"
              mapsApiKey='AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY'
            // height="400px"
            />
          </Col>
          <Col md={5}>
            <div className="globalPopIn">
              <h5>Active POP Server</h5>
              <ul className="clearfix">
                <li>
                  <small className="active-2">Active</small>
                  Bangalore
                </li>
                <li>
                  <small className="connected">Connected</small>
                  Delhi
                </li>
                <li>
                  <small className="active-2">Active</small>
                  London
                </li>
                <li>
                  <small className="active-2">Active</small>
                  Mumbai
                </li>
                <li>
                  <small className="connected">Connected</small>
                  China
                </li>
              </ul>
            </div>
          </Col>
        </div>
      </div>
    );
  }
}

export default GlobalPopLocation;