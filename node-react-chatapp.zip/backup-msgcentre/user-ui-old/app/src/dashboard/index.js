import React from 'react';
import Topbar from './components/Topbar';
import Dashboar from './containers/Dashboard';


class Dashboard extends React.Component {
    render() {
        return (
            <div>
                <Topbar />
                <Dashboar />
            </div>
        );
    }

}

export default Dashboard;