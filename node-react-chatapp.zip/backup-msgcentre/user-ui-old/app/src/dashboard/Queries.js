import gql from 'graphql-tag';

export const PROFILE_DATA = gql`
{
       profile{
            id
            uuid
            last_access
            email
            Profile{
                id
                title
                fname
                lname
                gender
                phone
                Country{
                    country_name
                }
                Company{
                    company_name
                }
                Role{
                    name
                    type
                }
                Designation{
                    designation_name
                }
            }
        }
    }
`;
