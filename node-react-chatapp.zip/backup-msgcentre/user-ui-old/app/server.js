const Axios = require('axios');

const express = require('express');
const path = require('path');
const app = express();
const port = process.env.PORT || 3000;
const host = process.env.HOST || '0.0.0.0'
app.use(express.static(path.join(__dirname, 'build')));

app.get('/healthz/liveness', function (req, res) {
  res.sendStatus(200);
});

app.get('/healthz/readiness', function (req, res) {
  let result = { Status: 'Red', Services: { Gateway: { Status: 'Failed' } } };

  Axios.get(`${process.env.REACT_APP_GATEWAY}/healthz/readiness`).then(({ data }) => {

    if (data.Status === 'Green') {
      result.Status = 'Green'
      result.Services.Gateway.Status = 'Running'
      res.send(result);
    } else {
      res.send(result);
    }
  }).catch((err) => {
    console.log(err);
    res.send(result);
  })
})

app.get('*', function (req, res) {
  res.sendFile(path.join(__dirname, 'build', 'index.html'));
});

app.listen(port, host, () => {
  console.log(`Server started on port: ${port}. Now browse http://${host}:${port}`);
});

