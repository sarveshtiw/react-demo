Synthesis UI Application
========================

## Introduction
This is an ui application for synthesis. This is for users and developed with React.js, Apollo.js, Redux.js

## How to run on developer machine
Run following commands
<pre><code>cd app
npm install
npm start</code></pre>

## Deployment Instructions
Take a pull from git repo.
Run following commands
<pre><code>cd app
npm install
npm run build</code></pre>

This will create a dist directory. Place contents of dist directory on any file distribution server (like nginx or apache)

## Dependencies
This application required following connections to run:
- Graphql Gateway App
- Video Conferencing socket server
- Ejabberd


## Environment variables
Environment variables is the main mechanism of manipulating application settings. Currently application recognizes
following environment variables:

| Variable          | Default value          | Description          |
| ----------------- | ---------------------- | -------------------- |
| NODE_ENV          | null                   | Sets current environment. Allows application to manipulate some settings automatically |
| HOST              | 0.0.0.0                | Address to listen on |
| PORT              | 3000                   | Port to listen on    |
| REACT_APP_GATEWAY | https://development.synthesis-gateway.asergiscloud.com | Graphql gateway host |
| REACT_APP_VIDEO_SOCKET_URL | ${REACT_APP_GATEWAY}/vcsocket | Video conferencing engine host |
| REACT_APP_EJABBERD_URL     | unset         | Message centre engine host |
