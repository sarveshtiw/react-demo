Email Application
=================

## Introduction
This is a Microservice App for Emailing developed in Express.js

## How to run
This application requires node to be installed on your system. Please check [upstream documentation](https://nodejs.org/en/download/)
for how to install node on your system.

### Development build
In application root path run following commands
```bash
cd app; npm install
npm start
```
### Production build
Run following commands
```bash
cd app; npm install --only=production
npm start
```

## Dependencies
This application required following two connections to run.
- auth-server 
- smtp

## Environment variables
Environment variables is the main mechanism of manipulating application settings. Currently application recognizes
following environment variables:

| Variable            | Default value | Description                   |
| ------------------- | ------------- | ----------------------------- |
| NODE_ENV            | null          | Sets current environment. Allows application to manipulate some settings automatically |
| HOST                | 0.0.0.0       | Sets an address to listen on  |
| PORT                | 3000          | Sets a port to listen on      |
| SMTP_SERVICE_HOST   | localhost     | smtp host address             |
| SMTP_SERVICE_PORT   | 25            | smtp port                     |
| SMTP_SERVICE_SECURE | false         | enable secure connection      |
| AUTH_SERVER_SERVICE_SCHEME | http   | Sets auth-server  scheme http or https |
| AUTH_SERVER_SERVICE_HOST   |        | Sets auth-server host         |
| AUTH_SERVER_SERVICE_PORT   |        | Sets auth-server port         |
| AUTH_SERVER_SERVICE_PATH   | /      | Sets auth-server path         |

## Testing with docker
To test application in docker you need first docker to be installed. Check [upstream documentation](https://docs.docker.com/install)
for how to install docker on your system.
To bring up all services run in repository root path
```bash
docker-compose -f docker/docker-compose.yml pull --ignore-pull-failures
docker-compose -f docker/docker-compose.yml up
```
