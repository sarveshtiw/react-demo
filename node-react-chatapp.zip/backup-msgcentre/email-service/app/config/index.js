module.exports = {
    host: process.env.HOST || '0.0.0.0',
    port: process.env.PORT || 3000,
    smtp: {
        host: process.env.SMTP_SERVICE_HOST || 'localhost',
        port: process.env.SMTP_SERVICE_PORT || 25,
        secure: process.env.SMTP_SERVICE_SECURE || false,
        tlsRejectUnauthorized: process.env.SMTP_SERVICE_TLSREJECTUNAUTHORIZED || false
    },
    authAPI: `${process.env.AUTH_SERVER_SERVICE_SCHEME || 'http'}://${process.env.AUTH_SERVER_SERVICE_HOST}:${process.env.AUTH_SERVER_SERVICE_PORT}${process.env.AUTH_SERVER_SERVICE_PATH || '/'}`
}
