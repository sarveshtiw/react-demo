if(process.env.NODE_ENV==='local'){
  require('dotenv').config();
}
const express = require('express')
const app = express()
const bodyParser = require('body-parser')
const cors = require('cors')

const routes = require('./routes');
const swaggerUi = require('swagger-ui-express');
const swaggerDocument = require('./swagger.json');
const auth = require('./lib/auth');
const HTTPStatus = require('http-status')

const config = require('./config');

app.use(cors())
app.use('/docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

app.use('/', routes)

const server = app.listen(config.port, () => {
  console.log(`Server listening on ${config.host}:${config.port}`);
});
