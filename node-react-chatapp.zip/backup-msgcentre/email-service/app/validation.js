const Joi = require('joi')

const schema = Joi.object().keys({
  from: Joi.string().email().optional(),
  to: Joi.string().email().optional(),
  subject: Joi.string().min(3).optional(),
  message: Joi.string().min(5).optional()
})

exports.validate = params => {
  let errors = []
  const {error} = Joi.validate({from: params.from, to: params.to, subject: params.subject, message: params.message}, schema, {abortEarly: false})
  if(error) {
    error.details.forEach(error => {
      let obj = {}
      obj.key = error.message.match(/"([^"]+)"/)[1]
      obj.message = error.message.split(/ (.+)/)[1]
      errors.push(obj)
    })
  }
  return errors
}
