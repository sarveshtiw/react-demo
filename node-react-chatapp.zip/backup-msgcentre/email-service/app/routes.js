const express = require('express')
const router = express.Router()
const multer  = require('multer')
const upload = multer({})
const controllers = require('./controllers');

router.get('/healthz/liveness', controllers.healthCheck.liveness);
router.get('/healthz/readiness', controllers.healthCheck.readiness);
router.post('/send-mail', upload.array('attachments', 10), controllers.mailer.sendMail)

module.exports = router
