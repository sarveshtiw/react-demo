const nodeMailer = require('./../lib/nodeMailer')
const HTTPStatus = require('http-status')
const validation = require('./../validation')

let message, status = false

class mailController {

    async sendMail(req, res) {
        let output = {}
        output.errors = []
        output.result = {}
        let validate = await validation.validate(req.body)
        if(validate.length > 0) {
            output.errors = validate
            res.status(HTTPStatus.BAD_REQUEST).send(output)
        } else {
            let result = await nodeMailer.sendMail(req);
            if(result) {
                output.result = {
                    status: true,
                    message: 'Mail Send'
                }
                res.status(HTTPStatus.OK).send(output)
            } else {
                output.result = {
                    status,
                    message: 'Server Error'
                }
                res.status(HTTPStatus.INTERNAL_SERVER_ERROR).send(output)
            }
        }
    }
}

module.exports = new mailController()
