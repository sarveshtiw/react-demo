const nodemailer = require('nodemailer');
const {smtp} = require('./../config');

const liveness = (req, res) => {
   res.sendStatus(200);
};

const readiness = async (req, res) => {
    const result = {Status: 'Red', Services:{ }};
    smtpResult = await checkSmtpConfiguration();
    result.Services = smtpResult;
    if (smtpResult.smtpServer.Status === 'OK') {
        result.Status = 'Green';
        res.status(200).json(result);
    } else {
        res.status(500).json(result);
    }    
};

const checkSmtpConfiguration = async () => {
    const result = {smtpServer:{ Status:'Failed'}};
    try{
        if(process.env.SMTP_SERVICE_HOST && process.env.SMTP_SERVICE_PORT) {
            let smtpClient = nodemailer.createTransport({
                host: smtp.host,
                port: parseInt(smtp.port),
                secure: 'true'==smtp.secure,
                tls: {rejectUnauthorized: 'true'== smtp.tlsRejectUnauthorized}
            })
            let connection = await smtpClient.verify()
            if(connection) {
                result.smtpServer.Status = 'OK';
                return result
            }
            result.smtpServer.Message = 'Unable to connect to smtp server';
            return result
        }
        result.smtpServer.Message= 'Invalid smtp configuration'
        return result
    }
    catch (error){
        console.log(error);
        result.smtpServer.Message= 'Error while connecting to smtp server';
        return result

    }
}

module.exports = {
    liveness,
    readiness
}