const mailer = require('./mailer');
const healthCheck = require('./healthCheck');

module.exports = {
    mailer,
    healthCheck
}
