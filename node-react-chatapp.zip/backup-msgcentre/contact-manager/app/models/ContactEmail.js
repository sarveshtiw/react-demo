module.exports = function(sequelize, DataTypes) {
    const ContactEmail = sequelize.define("ContactEmail", {
        id_contact_email: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
        id_contact: { type: DataTypes.INTEGER, foreignKey: true, allowNull: false },
        email: { type: DataTypes.STRING, allowNull: false },
        status: { type: DataTypes.INTEGER, defaultValue:1, allowNull: true },
        created_at: { type: DataTypes.DATE, defaultValue: sequelize.literal('CURRENT_TIMESTAMP'), allowNull: true },
        updated_at: { type: DataTypes.DATE, defaultValue: sequelize.literal('CURRENT_TIMESTAMP'), allowNull: true },
        primary: {type: DataTypes.INTEGER, defaultValue:false, allowNull: true}
    }, {
        tableName: 'cms_contact_email'
    });
   
    return ContactEmail;
};