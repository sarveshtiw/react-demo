module.exports = function(sequelize, DataTypes) {
  var ServiceDetails = sequelize.define("ServiceDetails", {
    id_contact_service: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    id_contact: { type: DataTypes.INTEGER, foreignKey: true, allowNull: true },
    to_uid: { type: DataTypes.INTEGER, allowNull: true },
    id_group: { type: DataTypes.INTEGER, foreignKey: false, allowNull: true },
    id_service: { type: DataTypes.INTEGER, foreignKey:true, allowNull: true },
    is_shared: { type: DataTypes.INTEGER, defaultValue:0, allowNull: true },
    status: { type: DataTypes.INTEGER, defaultValue:1, allowNull: true },
    created_at: { type: DataTypes.DATE, defaultValue: sequelize.literal('CURRENT_TIMESTAMP'), allowNull: true },
    updated_at: { type: DataTypes.DATE, defaultValue: sequelize.literal('CURRENT_TIMESTAMP'), allowNull: true }
  }, {
    tableName: 'cms_contact_service',
  });
  return ServiceDetails;
};
