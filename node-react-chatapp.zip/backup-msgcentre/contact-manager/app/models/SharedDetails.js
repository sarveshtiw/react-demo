module.exports = function(sequelize, DataTypes) {
    var SharedDetails = sequelize.define("SharedDetails", {
        id_shared: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: false },
        id_contact: { type: DataTypes.INTEGER, foreignKey: true, allowNull: false },
        id_group: { type: DataTypes.INTEGER, foreignKey: true, allowNull: false },
        from_uid: { type: DataTypes.INTEGER, allowNull: false },
        to_uid: { type: DataTypes.INTEGER, allowNull: true },
        status: { type: DataTypes.INTEGER, defaultValue:1, allowNull: true },
    created_at: { type: DataTypes.DATE, defaultValue: sequelize.literal('CURRENT_TIMESTAMP'), allowNull: true },
    updated_at: { type: DataTypes.DATE, defaultValue: sequelize.literal('CURRENT_TIMESTAMP'), allowNull: true }
    }, {
        tableName: 'cms_shared_details',
        underscored: true
    });
    return SharedDetails;
};