module.exports = function(sequelize, DataTypes) {
    const Contact = sequelize.define("Contact", {
        id_contact: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
        dob: {type: DataTypes.DATE, allowNull: true},
        title: {type: DataTypes.STRING, allowNull: true},
        uid_ua_user: { type: DataTypes.STRING, allowNull: false },
        fname: { type: DataTypes.STRING, allowNull: false },
        lname: { type: DataTypes.STRING, allowNull: true },
        intl_code: { type: DataTypes.STRING, allowNull: true },
        designation: { type: DataTypes.STRING, allowNull: true },
        department: { type: DataTypes.STRING, allowNull: true },
        organisation: { type: DataTypes.STRING, allowNull: true },
        last_active_time: { type: DataTypes.DATE, allowNull: true },
        is_online: { type: DataTypes.INTEGER, allowNull: true, defaultValue:0 },
        status: { type: DataTypes.INTEGER, allowNull: true, defaultValue:1 },
        created_at: { type: DataTypes.DATE, defaultValue: sequelize.literal('CURRENT_TIMESTAMP'), allowNull: true },
        updated_at: { type: DataTypes.DATE, defaultValue: sequelize.literal('CURRENT_TIMESTAMP'), allowNull: true }
    }, {
        tableName: 'cms_contact'
    });

    Contact.associate = models => {
        models.Contact.hasMany(models.ContactEmail, { foreignKey: 'id_contact',constraints: true, as: 'contactEmails'});
        models.Contact.hasMany(models.ContactNumber, { foreignKey: 'id_contact', constraints: true, as: 'contactNumbers' });
        models.Contact.hasMany(models.GroupMember, { foreignKey: 'id_contact', constraints: true, as: 'groups' });
        models.Contact.hasMany(models.ServiceDetails, { foreignKey: 'id_contact', constraints: true, as: 'serviceIds' });
        models.Contact.hasMany(models.ContactAddress, { foreignKey: 'id_contact', constraints: true, as: 'addresses' });
    };

    return Contact;
};