module.exports = function(sequelize, DataTypes) {
  var ContactNumber = sequelize.define("ContactNumber", {
    id_contact_phone: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    id_contact: { type: DataTypes.INTEGER, foreignKey: true, allowNull: false},
    phone: { type: DataTypes.STRING, allowNull: true },
    status: { type: DataTypes.INTEGER, defaultValue:1, allowNull: true },
    created_at: { type: DataTypes.DATE, defaultValue: sequelize.literal('CURRENT_TIMESTAMP'), allowNull: true },
    updated_at: { type: DataTypes.DATE, defaultValue: sequelize.literal('CURRENT_TIMESTAMP'), allowNull: true },
    primary: {type: DataTypes.INTEGER, defaultValue:false, allowNull: true}
  }, {
    tableName: 'cms_contact_phone'
  });
  return ContactNumber;
};
