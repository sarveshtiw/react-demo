module.exports = function(sequelize, DataTypes) {
    const ContactAddress = sequelize.define("ContactAddress", {
        id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
        id_contact: {type: DataTypes.INTEGER, foreignKey: true, allowNull: true},
        address_type: {type: DataTypes.INTEGER, allowNull: true},
        address1: { type: DataTypes.STRING, allowNull: true},
        address2: { type: DataTypes.STRING, allowNull: true},
        address3: { type: DataTypes.STRING, allowNull: true},
        city: { type: DataTypes.INTEGER, allowNull: true},
        state: { type: DataTypes.INTEGER, allowNull: true },
        country: { type: DataTypes.INTEGER, allowNull: true},
        zipcode: { type: DataTypes.STRING, allowNull: true },
        is_deleted: { type: DataTypes.INTEGER, allowNull: true, defaultValue:0 },
        created_at: { type: DataTypes.DATE, defaultValue: sequelize.literal('CURRENT_TIMESTAMP'), allowNull: true },
        updated_at: { type: DataTypes.DATE, defaultValue: sequelize.literal('CURRENT_TIMESTAMP'), allowNull: true }
    }, {
        tableName: 'cms_contact_address'
    });
    return ContactAddress;
};