module.exports = function(sequelize, DataTypes) {
    var Group = sequelize.define("Group", {
        id_group: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
        uid: { type: DataTypes.STRING, foreignKey: true, allowNull: true },
        group_name: { type: DataTypes.STRING, allowNull: true },
        purpose: {type: DataTypes.STRING, defaultValue: null, allowNull: true},
        status: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 1 },
        created_at: { type: DataTypes.DATE, defaultValue: sequelize.NOW },
        updated_at: { type: DataTypes.DATE, defaultValue: sequelize.NOW }
    }, {
        tableName: 'cms_group',
    });

    Group.associate = models => {
        models.Group.hasMany(models.GroupMember, { foreignKey: 'id_group', constraints: true});
    };

    return Group;
};