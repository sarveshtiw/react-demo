const Joi = require('joi');
let ErrorArr = [];

/********************************************** Starts: Validation schema  ***************************************************/

// Make Schema for validate schemaserviceDetails
let schemaserviceDetails = Joi.object().keys({
    id_contact: Joi.number(),
    to_uid: Joi.number().required(),
    id_group: Joi.number(),
    id_service: Joi.number().required(),
    is_shared: Joi.number().required()
});



/********************************************** Starts: Validation function  ***************************************************/

// function for validate scheme validateserviceDetails
const validateserviceDetails = (ServiceTypeInput) => { // Validate validateAddContact API
    return Joi.validate(ServiceTypeInput, schemaserviceDetails);
}


module.exports = {
    validateserviceDetails
}