const Joi = require('joi');
let ErrorArr = [];

/********************************************** Starts: Validation schema  ***************************************************/

// Make Schema for validate schemaGetContact
let schemaGetContactById = Joi.object().keys({
    id: Joi.array().items(Joi.number()).required()
});


// Make Schema for validate schemaCreateContact

let schemaEmail = Joi.object().keys({
    email: Joi.string().email().required(),
    primary: Joi.bool().optional(),
    errorMsg: Joi.string().allow('').optional()
})

let schemaNumber = Joi.object().keys({
    phone: Joi.string().required(),
    primary: Joi.bool().optional(),
    errorMsg: Joi.string().allow('').optional()
})

let schemaAddress = Joi.object().keys({
    address1: Joi.string().optional(),
    address2: Joi.string().optional(),
    address3: Joi.string().optional(),
    address_type: Joi.number().optional(),
    city: Joi.number().optional(),
    state: Joi.number().optional(),
    country: Joi.number().optional(),
    zipcode: Joi.string().optional(),
})

let schemaAddContact = {
    fname: Joi.string().required(),
    title: Joi.string().allow('').optional(),
    dob: Joi.string().allow('').optional(),
    lname: Joi.string().allow('').optional(),
    intl_code: Joi.string().allow('').optional(),
    designation: Joi.string().allow('').optional(),
    department: Joi.string().allow('').optional(),
    organisation: Joi.string().allow('').optional(),
    contactEmails: Joi.array().min(1).items(schemaEmail).required(),
    contactNumbers: Joi.array().min(1).items(schemaNumber).required(),
    groups: Joi.number().optional(),
    serviceIds: Joi.array().items(Joi.number().required()).optional(),
    addresses: Joi.array().items(schemaAddress).optional()
};

let updateContact = Joi.object().keys({
    id_contact: Joi.number().required(),
    title: Joi.string().allow('').optional(),
    dob: Joi.string().allow(null).optional(),
    fname: Joi.string().optional(),
    lname: Joi.string().allow('').optional(),
    intl_code: Joi.string().optional(),
    designation: Joi.string().allow('').optional(),
    department: Joi.string().allow('').optional(),
    organisation: Joi.string().allow('').optional(),
    group: Joi.number().optional(),
})

let updateEmail = Joi.object().keys({
    id_contact_email: Joi.number().optional(),
    email: Joi.string().email().optional(),
    primary: Joi.boolean().optional()
})

let updatePhone = Joi.object().keys({
    id_contact_phone: Joi.number().optional(),
    phone: Joi.string().optional(),
    primary: Joi.boolean().optional()
})

let updateAddress = Joi.object().keys({
    id: Joi.number().optional(),
    address1: Joi.string().optional(),
    address2: Joi.string().optional(),
    address3: Joi.string().optional(),
    address_type: Joi.number().optional(),
    city: Joi.number().allow(null).optional(),
    state: Joi.number().allow(null).optional(),
    country: Joi.number().allow(null).optional(),
    zipcode: Joi.string().allow(null).optional()
})

// Make Schema for validate schemaupdateContact
let schemaupdateContact = Joi.object().keys({
    input: updateContact,
    email: Joi.array().items(updateEmail).optional(),
    phone: Joi.array().items(updatePhone).optional(),
    address: Joi.array().items(updateAddress).optional()

});


// Make Schema for validate schemaRemoveContact
let schemaRemoveContact = Joi.object().keys({
    id: Joi.array().items(Joi.number().required())
});


// Make Schema for validate schemaSearchContact
let schemaSearchContact = Joi.object().keys({
    keyword: Joi.string().required()
});

// Make Schema for validate schemaSearchContact
let schemaIsEmailExist = Joi.object().keys({
    email: Joi.string().email().required()
});

// Make Schema for validate schemaSearchContact
let schemaIsNumberExist = Joi.object().keys({
    number: Joi.string().required()
});
/********************************************** Starts: Validation function  ***************************************************/

// function for validate scheme validateGetContact
const validateGetContactById = (ServiceTypeInput) => { // Validate validateGetContact API
    return Joi.validate(ServiceTypeInput, schemaGetContactById, { presence: 'required' });
}

// function for validate scheme validateAddContact
const validateAddContact = (ServiceTypeInput) => { // Validate validateAddContact API
    return Joi.validate(ServiceTypeInput, schemaAddContact, { presence: 'required' });
}

// function for validate scheme validateUpdateContact
const validateUpdateContact = (ServiceTypeInput) => { // Validate validateUpdateContact API
    return Joi.validate(ServiceTypeInput, schemaupdateContact, { presence: 'required' });
}

// function for validate scheme validateDeleteContact
const validateDeleteContact = (ServiceTypeInput) => { // Validate validateDeleteContact API
    return Joi.validate(ServiceTypeInput, schemaRemoveContact);
}

// function for validate scheme validateSearchContact
const validateSearchContact = (ServiceTypeInput) => { // Validate validateSearchContact API
    return Joi.validate(ServiceTypeInput, schemaSearchContact);
}

// function for validate scheme validateSearchContact
const validateIsEmailExist = (ServiceTypeInput) => { // Validate validateSearchContact API
    return Joi.validate(ServiceTypeInput, schemaIsEmailExist);
}

// function for validate scheme validateSearchContact
const validateIsNumberExist = (ServiceTypeInput) => { // Validate validateSearchContact API
    return Joi.validate(ServiceTypeInput, schemaIsNumberExist);
}



module.exports = {
    validateGetContactById,
    validateAddContact,
    validateUpdateContact,
    validateDeleteContact,
    validateSearchContact,
    validateIsEmailExist,
    validateIsNumberExist,
}
