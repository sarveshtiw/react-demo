ALTER TABLE `cms_group` 
ADD COLUMN `purpose` VARCHAR(45) NULL DEFAULT NULL ;

ALTER TABLE `cms_contact_address` 
CHANGE COLUMN `zipcode` `zipcode` VARCHAR(25) NULL DEFAULT NULL ;