DROP TABLE IF EXISTS `cms_contact`;

CREATE TABLE `cms_contact` (
  `id_contact` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'conference phone book auto incremented id',
  `uid_ua_user` int(11) unsigned NOT NULL DEFAULT '0',
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) DEFAULT NULL,
  `intl_code` varchar(50) DEFAULT '0',
  `designation` varchar(255) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `organisation` varchar(255) DEFAULT NULL,
  `last_active_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_online` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0=offline, 1=online',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '0=inactive, 1= active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_contact`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='phone book table';

/*Data for the table `cms_contact` */

/*Table structure for table `cms_contact_address` */

DROP TABLE IF EXISTS `cms_contact_address`;

CREATE TABLE `cms_contact_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_contact` int(11) unsigned DEFAULT NULL,
  `address_type` tinyint(1) DEFAULT '0' COMMENT '0=common, 1=billing,2=mailing',
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `address3` varchar(255) DEFAULT NULL,
  `city` int(11) DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `country` int(11) DEFAULT NULL,
  `zipcode` int(10) DEFAULT NULL,
  `is_deleted` tinyint(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `address_contact_id` (`id_contact`),
  CONSTRAINT `cms_contact_address_ibfk_1` FOREIGN KEY (`id_contact`) REFERENCES `cms_contact` (`id_contact`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `cms_contact_address` */

/*Table structure for table `cms_contact_email` */

DROP TABLE IF EXISTS `cms_contact_email`;

CREATE TABLE `cms_contact_email` (
  `id_contact_email` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_contact` int(10) unsigned NOT NULL,
  `email` varchar(255) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `primary` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_contact_email`),
  KEY `contact_id` (`id_contact`),
  CONSTRAINT `cms_contact_email_ibfk_1` FOREIGN KEY (`id_contact`) REFERENCES `cms_contact` (`id_contact`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `cms_contact_email` */

/*Table structure for table `cms_contact_phone` */

DROP TABLE IF EXISTS `cms_contact_phone`;

CREATE TABLE `cms_contact_phone` (
  `id_contact_phone` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_contact` int(10) unsigned NOT NULL,
  `phone` varchar(15) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `primary` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_contact_phone`),
  KEY `id_contact` (`id_contact`),
  CONSTRAINT `cms_contact_phone_ibfk_1` FOREIGN KEY (`id_contact`) REFERENCES `cms_contact` (`id_contact`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `cms_contact_phone` */

/*Table structure for table `cms_contact_service` */

DROP TABLE IF EXISTS `cms_contact_service`;

CREATE TABLE `cms_contact_service` (
  `id_contact_service` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_contact` int(10) unsigned NOT NULL,
  `to_uid` int(10) unsigned NOT NULL,
  `id_group` int(10) unsigned DEFAULT NULL,
  `id_service` int(11) DEFAULT NULL,
  `is_shared` tinyint(1) DEFAULT '0' COMMENT '0=not shared, 1=shared',
  `status` tinyint(1) unsigned DEFAULT NULL COMMENT '0=inactive, 1=active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_contact_service`),
  KEY `id_contact` (`id_contact`),
  KEY `dfdf` (`id_group`),
  CONSTRAINT `cms_contact_service_ibfk_1` FOREIGN KEY (`id_contact`) REFERENCES `cms_contact` (`id_contact`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `cms_contact_service` */

/*Table structure for table `cms_group` */

DROP TABLE IF EXISTS `cms_group`;

CREATE TABLE `cms_group` (
  `id_group` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_name` varchar(255) NOT NULL,
  `uid` int(10) unsigned DEFAULT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_group`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `cms_group` */

/*Table structure for table `cms_group_member` */

DROP TABLE IF EXISTS `cms_group_member`;

CREATE TABLE `cms_group_member` (
  `id_group_member` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_contact` int(10) unsigned NOT NULL,
  `id_group` int(10) unsigned NOT NULL,
  `status` tinyint(1) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_group_member`),
  KEY `id_contact` (`id_contact`),
  KEY `id_group` (`id_group`),
  CONSTRAINT `cms_group_member_ibfk_1` FOREIGN KEY (`id_contact`) REFERENCES `cms_contact` (`id_contact`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `cms_group_member_ibfk_2` FOREIGN KEY (`id_group`) REFERENCES `cms_group` (`id_group`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `cms_group_member` */

/*Table structure for table `cms_shared_details` */

DROP TABLE IF EXISTS `cms_shared_details`;

CREATE TABLE `cms_shared_details` (
  `id_shared` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_contact` int(10) unsigned DEFAULT NULL,
  `id_group` int(10) unsigned DEFAULT NULL,
  `from_uid` int(10) unsigned DEFAULT NULL,
  `to_uid` int(10) unsigned DEFAULT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '0=inactive, 2=active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_shared`),
  KEY `vxv` (`id_contact`),
  KEY `dgdf` (`id_group`),
  KEY `dfgdfgfgdfg` (`from_uid`),
  KEY `dfggr` (`to_uid`),
  CONSTRAINT `cms_shared_details_ibfk_1` FOREIGN KEY (`id_contact`) REFERENCES `cms_contact` (`id_contact`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `cms_shared_details_ibfk_2` FOREIGN KEY (`id_group`) REFERENCES `cms_group` (`id_group`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

