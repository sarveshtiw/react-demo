const model = require('../../models');
const validation = require('../../validation/contactValidation');

module.exports = {
    Mutation: {
        deleteContact: async(obj, args, context, info) => {
            try {
                // Validate request
                let contactIdDoesNotExist = [];
                ErrorArr = [];
                ErrorArr = validation.validateDeleteContact({'id': args.id});
                // validate ErrorArr, If it is not null. that's mean an error occured.
                if (ErrorArr.error != null) {
                    throw new Error(ErrorArr.error.details[0].message);
                }

                let contact = await model
                    .Contact
                    .findAll({
                        where: {
                            id_contact: args.id,
                            uid_ua_user: context.user.id
                        },
                        raw: true
                    })
                // check id_contact exist in Db and get in array which does not exist
                if (contact.length) {
                    let idExist = 0;
                    for (let i = 0; i < args.id.length; i++) {
                        idExist = 0;
                        for (let k = 0; k < contact.length; k++) {
                            if(contact[k].id_contact == args.id[i]){
                                idExist = 1;
                            }
                        }
                        // put ids in array which are not exist and remove from args
                        if(idExist == 0 || idExist === 0){
                            contactIdDoesNotExist.push(args.id[i]);
                        }
                    }
                }else{
                    // nothing exist
                    contactIdDoesNotExist = args.id;
                }
                
                if (contact) {
                    let p1 = await model
                        .Contact
                        .update({
                            status: 0
                        }, {
                            where: {
                                id_contact: args.id,
                                uid_ua_user: context.user.id
                            }
                        })
                    let p2 = await model
                        .ContactEmail
                        .update({
                            status: 0
                        }, {
                            where: {
                                id_contact: args.id
                            }
                        })
                    let p3 = await model
                        .ContactNumber
                        .update({
                            status: 0
                        }, {
                            where: {
                                id_contact: args.id
                            }
                        })
                    let p4 = await model
                        .GroupMember
                        .update({
                            status: 0
                        }, {
                            where: {
                                id_contact: args.id
                            }
                        })
                    let p5 = await model
                        .ServiceDetails
                        .update({
                            status: 0
                        }, {
                            where: {
                                id_contact: args.id
                            }
                        })
                    let p6 = await model
                        .ContactAddress
                        .update({
                            is_deleted: 1
                        }, {
                            where: {
                                id_contact: args.id
                            }
                        })
                    return {id_contact: args.id, message: 'Contact deleted successfully', 'contactIdDoesNotExist':contactIdDoesNotExist}
                } else {
                    throw new Error('Contact does not exist')
                }
            } catch (err) {
                console.log('error', err)
                return err
            }
        }
    }
}