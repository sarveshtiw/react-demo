/*
@Author : sanjay Verma
@Date : 20/11/2017
@Description : This schema use to manage group like create group, get group by id or fetch all groups, delete group and update group
*/
const model = require('../../models');
const validation = require('../../validation/groupValidation');
let  limit = 10; // 10 records fetch, set limit
const Op = model.ampDb.Op;

let getContactGroups = async condition => {
    try {
        let data = await model.Group.findAll({ where: condition, 
            include: [{
                model: model.GroupMember,
                attributes: ['id_contact'],
                include: [{
                    model: model.Contact,
                    attributes: ['id_contact','fname', 'lname'],
                    include: [{
                        model: model.ContactEmail,
                        as: 'contactEmails',
                        attributes: ['email']
                    }],
                    where:{status:1},
                }]
            }],
            //offset: pagination * 10
        })
        return data

    } catch(err) {
        return err
    }    
}

module.exports = {
    Query: {
        getContactGroupById: async(obj, args, context, info) => {
            try {
                console.log(context);
                // Prepare array to validate fields
                var paramArr = {};
                let groupObj = [];
                let ErrorArr = [];
                let condition = {}

                let pagination 
                if (args.input && args.input.page) {
                    pagination = args.input.page
                    paramArr['page'] = args.input.page;
                } else {
                    pagination = 0
                    paramArr['page'] = 0;
                }
                if (args.input && args.input.group_id) {
                    paramArr['group_id'] = args.input.group_id;
                    condition.id_group =   {
                        [model.Sequelize.Op.in]: [args.input.group_id]
                    }
                }
                condition.status = 1
                //condition.uid = context.user.id
                condition.uid =  context.user.id,
                
                //console.log('156534534', condition)

                // Validate request
                ErrorArr = validation.validategetGroups(paramArr);
                // validate Keys
                if (ErrorArr.error != null) {
                    throw new Error(ErrorArr.error.details[0].message);
                } else {
                    
                    let data = await getContactGroups(condition)
                    //console.log('133131312535346363', data)
                    return { groups: data, page: pagination };
                    
                }
            } catch(err) {
                return err
            }
        },

        getContactGroups: async(obj, args, context, info) => {
            try {
                let condition = {
                    status: 1,
                    uid: context.user.id
                }
                let data = await getContactGroups(condition)
                return { groups: data, page: 0 };
            } catch(err) {
                return serr
            }
        },

        searchContactGroup: async(obj, args, context, info) => {           
            try {
                let condition = {
                    status: 1,
                    uid: context.user.id,
                    group_name: { $like: args.name + '%' }
                }
                let data = await getContactGroups(condition)
                return { groups: data, page: 0 };
            } catch(err) {
                return err
            }
        }

        // Query END
    },
    Mutation: {
        createContactGroup: async(obj, args, context, info) => { // Muttion for create the group by group id
            
            // Prepare array to validate fields
            let groupObj = {};
            let ErrorArr = [];
            let contactNotExistArr = [];
            let simpleArr = [];
            let GroupMembers = [];
            // Validate prepared array
            ErrorArr = validation.validateCreateGroup(args.input);
            // validate Keys
            try {
                if (ErrorArr.error != null) {
                    throw new Error(ErrorArr.error.details[0].message);
                } else {
                    // Process the API
                    if(args.input.contacts && args.input.contacts.length){
                        const contactsArr = await model.Contact.findAll({ where : { id_contact:args.input.contacts} }); 
                        // check contacts exist or not. If contacts does not exist then return those contacts 
                        if(args.input && args.input.contacts && args.input.contacts.length && contactsArr && contactsArr.length){
                            for(let i=0; i < contactsArr.length;i++){
                                simpleArr.push(contactsArr[i].id_contact);    
                            }
                            contactNotExistArr = distinctValues(args.input.contacts, simpleArr);
                        }
                    }
                    groupObj = await model.Group.findOrCreate({ where: { group_name: args.input.group_name, status:1 }, defaults: { group_name: args.input.group_name, uid: context.user.id, created_at: new Date(), updated_at: new Date() } })
                    if (!groupObj[1]) {
                        throw new Error('Already exist');
                    }else{
                        // assign contacts to groups
                        let bulkIns = [];
                        simpleArr.map((id_contact) => {
                            bulkIns.push({id_contact:id_contact, id_group:groupObj[0].id_group, status:1});
                        })
                        
                        await model.GroupMember.bulkCreate(bulkIns); 
                        // fetch all members , id_group:groupObj[0].id_group = id_group
                        GroupMembers = await model.GroupMember.findAll({
                            where:{
                                id_group:groupObj[0].id_group
                            },
                            include:[
                                {
                                    model:model.Contact
                                }
                            ]
                        })
                    }
                }
            } catch (err) {
                return err;
            }
            
            return {details:groupObj[0], contactNotExist : contactNotExistArr, GroupMembers: GroupMembers}          
            return groupObj[0];
        },
        updateContactGroup: async(obj, args, context, info) => {
            try {
                let groupObj = {};
                let ErrorArr = [];
                
                // Validate request 
                ErrorArr = validation.validateUpdateGroup(args.input);
                // validate Keys
                if (ErrorArr.error != null) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                // Process the API
                // groupObj = await model.Group.findOne({
                //     where: {
				// 		[Op.or]:{
                //             group_name:args.input.group_name,
                //             id_group: args.input.group_id,
                //         }
                //     }
                // });
                groupObj = await model.Group.findOne({
                    where: {
                            id_group: args.input.group_id,
                    }
                });
                if(!groupObj){
                    throw new Error("Group does not exist");
                }
                groupObj = await model.Group.findOne({
                    where: {
                        group_name:args.input.group_name,
                        id_group: {
                            [Op.ne]: args.input.group_id
                          },
                          status:1
                        }
                });
                
                if(groupObj){ // check same group name
                    throw new Error("Group name is already Exist");
                }
              
               
                
                    let is_update = await model.Group.update({ group_name: args.input.group_name }, { where: { id_group: args.input.group_id } })
                    // delete assigned memberas first
                    await model.GroupMember.destroy({where:{id_group:args.input.group_id}})
                    // assign contacts to groups
                    if(args.input.contacts && args.input.contacts.length){
                        let bulkIns = [];
                        for(let i = 0; i < args.input.contacts.length; i++){
                            bulkIns.push({id_contact:args.input.contacts[i], id_group:args.input.group_id, status:1});
                        }
                        await model.GroupMember.bulkCreate(bulkIns);
                    }
                    return { group_id: args.input.group_id, message: 'Group updated successfully' }    
              
            } catch(err) {
                return err
            }
        },
        deleteContactGroup: async(obj, args, context, info) => { 
            try {
                let groupObj = {};
                let ErrorArr = [];
                let groupIdDoesNotExist = [];

                // Validate request
                ErrorArr = validation.validateRemoveGroup({ group_id: args.input.group_id });
                // validate Keys
                if (ErrorArr.error != null) {
                    throw new Error(ErrorArr.error.details[0].message);
                } else {
                    // Process the API
                    
                    groupObj = await model.Group.findAll({ where: { id_group: args.input.group_id, status: 1, uid:context.user.id }, raw:true })
                    // check id_contact exist in Db and get in array which does not exist
                if (groupObj.length) {
                    let idExist = 0;
                    for (let i = 0; i < args.input.group_id.length; i++) {
                        idExist = 0;
                        for (let k = 0; k < groupObj.length; k++) {
                            if(groupObj[k].id_group == args.input.group_id[i]){
                                idExist = 1;
                            }
                        }
                        // put ids in array which are not exist and remove from args
                        if(idExist == 0 || idExist === 0){
                            groupIdDoesNotExist.push(args.input.group_id[i]);
                        }
                    }
                }else{
                    // nothing exist
                    groupIdDoesNotExist = args.input.id;
                }

                    if (groupObj) { // GROUP Exist
                        let is_remove = await model.Group.update({ status: 0 }, { where: { id_group: args.input.group_id } })
                        return {
                            group_id: args.input.group_id,
                            message: 'Group deleted successfully',
                            groupIdDoesNotExist:groupIdDoesNotExist
                        }

                    } else { // Can't find the group by group ID
                        throw new Error("Group does not exist");
                    }      

                }
                return { status: status };
            } catch(err) {
                return err
            }    
        },




        // Mutation END Here
        // Mutation END Here
        // Mutation END Here
    }

}

const distinctValues = (arr1, arr2) => {
    return arr1.filter(val => {
        return arr2.indexOf(val) === -1
    })
}
