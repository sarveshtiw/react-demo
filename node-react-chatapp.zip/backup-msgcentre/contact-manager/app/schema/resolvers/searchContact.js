const model = require('../../models');
const validation = require('../../validation/contactValidation');

module.exports = {

    Query: {

        searchContact: async(obj, args, context, info) => { // This is for searching contact by fname, lname and email
            try {
                /*let ErrorArr = validation.validateSearchContact(args.input); // validate request input
                if (ErrorArr.error) { // validation check fail, so thow an error
                    throw new Error(ErrorArr.error.details[0].message); // throw error and recieve by the catch block
                }*/

                let searchResults = {
                   contact: [], 
                }
                
                const contacts = await model.Contact.findAll({
                    
                    include: [{
                        model: model.ContactEmail,
                        as: 'contactEmails',
                        required: false
                    }, {
                        model: model.ContactNumber,
                        as: 'contactNumbers'
                    }, {
                        model: model.GroupMember,
                        as: 'groups'
                    }, {
                        model: model.ServiceDetails,
                        as: 'serviceIds'
                    }, {
                        model: model.ContactAddress,
                        as: 'addresses'
                    }],
                    where: {
                        $or: [{ 'fname': { $like: args.input.keyword + '%' } }, { 'lname': { $like: args.input.keyword + '%' }},
                        { '$contactEmails.email$' : { $like: args.input.keyword + '%' } }, model.Sequelize.where(model.Sequelize.fn('concat', model.Sequelize.col('fname'), ' ', model.Sequelize.col('lname')), {
                            like: args.input.keyword + '%'
                          })],
                        uid_ua_user: context.user.id 
                    },
                })

                searchResults.contact = contacts               
                return searchResults
            } catch (err) {
                return err; // return error object
            }
        }
    },
}