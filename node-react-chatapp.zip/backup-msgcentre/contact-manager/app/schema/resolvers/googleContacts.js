const google = require('googleapis')
const Promise = require("bluebird")

const model = require('../../models')
const {OAuth} = require('../../config')

const OAuth2Client = google.auth.OAuth2
const oauth2Client = new OAuth2Client(OAuth.clientId, OAuth.clientSecret, OAuth.redirectUrl)

const insertContact = async contacts => {
    try {
        for (let i = 0; i < contacts.length; i++) {
            console.log('______________________________',contacts[i])
            let insert = await model.Contact.create(contacts[i], {
                include: [{
                    model: model.ContactEmail,
                    as: 'contactEmails'
                }, {
                    model: model.ContactNumber,
                    as: 'contactNumbers'
                }]
            })
        }
        return 1
    } catch (err) {
        return err
    }
}

const updateContactNumber = async numbers => {
    try {
        await model.ContactNumber.bulkCreate(numbers, {
            raw: true
        })
        return 1
    } catch (err) {
        return err
    }
}

const updateContactEmail = async emails => {
    try {
        await model.ContactEmail.bulkCreate(emails, {
            raw: true
        })
        return 1
    } catch (err) {
        return err
    }
}


const distinctValues = (arr1, arr2) => {
    return arr1.filter(val => {
        return arr2.indexOf(val) === -1
    })
}

const checkContact = async (contacts, userId) => {
    let results = await model.Contact.findAll({
        include: [{
            model: model.ContactNumber,
            as: 'contactNumbers',
            required: true,
            attributes: ['phone', 'id_contact']
        }],
        attributes: [],
        where: {
            uid_ua_user: userId
        },
        raw: true
    })
    let emailResult = await model.Contact.findAll({
        include: [{
            model: model.ContactEmail,
            as: 'contactEmails',
            required: true,
            attributes: ['email', 'id_contact']
        }],
        attributes: [],
        where: {
            uid_ua_user: userId
        },
        raw: true
    })
    console.log('results', results, emailResult)
    let existingData = {}
    results.forEach(result => {
        console.log(result)
        existingData[result['contactNumbers.phone']] = result['contactNumbers.id_contact']
    })
    emailResult.forEach(result => {
        console.log(result)
        existingData[result['contactEmails.email']] = result['contactEmails.id_contact']
    })
    console.log('existing data', existingData)
    let difNumbers = [],
        difEmails = [],
        insertNumbers = [],
        insertEmails = [],
        insertContacts = []
    contacts.forEach(contact => {
        let id_contact, existingNumbers = [],
            existingEmails = []
        contact.phoneNumbers.forEach(number => {
            if (existingData.hasOwnProperty(number)) {
                existingNumbers.push(number)
                id_contact = existingData[number]
            }
        })
        contact.emails.forEach(email => {
            if (existingData.hasOwnProperty(email)) {
                existingEmails.push(email)
                id_contact = existingData[email]
            }
        })

        difNumbers = distinctValues(contact.phoneNumbers, existingNumbers)
        difEmails = distinctValues(contact.emails, existingEmails)
        console.log('#######', id_contact, contact.phoneNumbers, existingNumbers, difNumbers)
        console.log('*******', id_contact, contact.emails, existingEmails, difEmails)

        if (difNumbers.length > 0 && existingNumbers.length === 0 && difEmails.length > 0 && existingEmails.length === 0) {
            // new contact
            let obj = {}
            obj.fname = contact.name
            obj.uid_ua_user = userId
            obj.status = 1
            obj.created_at = new Date()
            obj.updated_at = new Date()
            obj.last_active_time = new Date()
            obj.is_online = 1
            if (contact.phoneNumbers) {
                obj.contactNumbers = []
                contact.phoneNumbers.forEach(number => {
                    let num = {}
                    num.phone = number
                    num.status = 1
                    num.created_at = new Date()
                    num.updated_at = new Date()
                    obj.contactNumbers.push(num)
                })
            }
            if (contact.emails) {
                obj.contactEmails = []
                contact.emails.forEach(email => {
                    let mail = {}
                    mail.email = email
                    mail.status = 1
                    mail.created_at = new Date()
                    mail.updated_at = new Date()
                    obj.contactEmails.push(mail)
                })
            }
            console.log('final data', obj)
            insertContacts.push(obj)
        } else if (difNumbers.length > 0 && difEmails.length === 0 && (existingNumbers.length > 0 || existingEmails.length > 0)) {

            // update numbers
            difNumbers.forEach(number => {
                let obj = {}
                obj.id_contact = id_contact
                obj.phone = number
                obj.status = 1
                obj.created_at = new Date()
                obj.updated_at = new Date()
                insertNumbers.push(obj)
            })
        } else if (difNumbers.length === 0 && difEmails.length > 0 && (existingNumbers.length > 0 || existingEmails.length > 0)) {

            // update emails
            difEmails.forEach(email => {
                let obj = {}
                obj.id_contact = id_contact
                obj.email = email
                obj.status = 1
                obj.created_at = new Date()
                obj.updated_at = new Date()
                insertEmails.push(obj)
            })
        } else if (difNumbers.length > 0 && difEmails.length > 0 && (existingNumbers.length > 0 || existingEmails.length > 0)) {

            // update numbers and emails
            difNumbers.forEach(number => {
                let obj = {}
                obj.id_contact = id_contact
                obj.phone = number
                obj.status = 1
                obj.created_at = new Date()
                obj.updated_at = new Date()
                insertNumbers.push(obj)
            })
            difEmails.forEach(email => {
                let obj = {}
                obj.id_contact = id_contact
                obj.email = email
                obj.status = 1
                obj.created_at = new Date()
                obj.updated_at = new Date()
                insertEmails.push(obj)
            })
        }

    })
    console.log('insert contacts', insertContacts)
    console.log('insert numbers', insertNumbers)
    console.log('insert emails', insertEmails)

    let addContacts = await insertContact(insertContacts)
    console.log('result from add contacts', addContacts)

    let updateNumbers = await updateContactNumber(insertNumbers)
    console.log('result from update numbers', updateNumbers)

    let updateEmails = await updateContactEmail(insertEmails)
    console.log('result from update emails', updateEmails)

    return true
}

module.exports = {
    Mutation: {
        addGoogleContacts: async (obj, args, context, info) => {
            try {  
                
                oauth2Client.credentials = args.input;
                let contacts = Promise.promisify(google.people('v1')
                .people.connections.list)

                await contacts({
                    resourceName: 'people/me',
                    pageSize: 1000,
                    personFields: 'phoneNumbers,names,emailAddresses',
                    auth: oauth2Client
                }).then(async (res) => {
                    console.log('#########', res.connections[0].names)
                    //return 0
                    let data = []
                    for(let i=0; i<res.connections.length; i++) {
                        if(res.connections[i].phoneNumbers.length>0 && res.connections[i].emailAddresses.length>0) {
                            let obj = {
                                phoneNumbers: [],
                                emails: []
                            }
                            obj.name = res.connections[i].names[0].displayName
                            for(let j=0; j<res.connections[i].phoneNumbers.length; j++) {
                                obj.phoneNumbers.push(res.connections[i].phoneNumbers[j].value.split(" ").join(""))
                            }
                            for(let k=0; k<res.connections[i].emailAddresses.length; k++) {
                                obj.emails.push(res.connections[i].emailAddresses[k].value)
                            }
                            data.push(obj)
                        }
                    }
                    console.log('11111', data)
                    //return 0
                    let result = await checkContact(data, context.user.id)
                    console.log('##########', result)
                })
                //console.log('%%%%%%%', )
                return {
                    message: 'Contacts Imported Successfully'
                }
            }
            catch (err) {
                return err
            }
        },
    }
}