const model = require('../../models');
const validation = require('../../validation/contactValidation');
const Op = model.Sequelize.Op;

const modifyAdd = async addresses => {
    for (let i = 0; i < addresses.length; i++) {
        let update = await model.ContactAddress.update(addresses[i], {
            where: {
                id: addresses[i].id
            }
        })
    }
    return 1
}

const modifyEmail = async emails => {
    for (let i = 0; i < emails.length; i++) {
        let update = await model.ContactEmail.update({
            email: emails[i].email,
            primary: emails[i].primary || false,
            status: 1,
            updated_at: new Date()
        }, {
            where: {
                id_contact_email: emails[i].id_contact_email
            }
        })
    }
    return 1
}

const modifyPhNum = async numbers => {
    for (let i = 0; i < numbers.length; i++) {
        let update = await model.ContactNumber.update({
            phone: numbers[i].phone,
            primary: numbers[i].primary || false,
            status: 1,
            updated_at: new Date()
        }, {
            where: {
                id_contact_phone: numbers[i].id_contact_phone
            }
        })
    }
    return 1
}

module.exports = {
    Mutation: {
        updateContact: async(obj, args, context, info) => {
            let checkExistingEmails = [];
            let checkExistingNumbers = [];
            let is_exist = [];
            let emailArr = [],numArr = [], existingObj={}, cEmails=[], cNumbers=[];
            try {
                 ErrorArr = validation.validateUpdateContact(args);
                if (ErrorArr.error != null) {
                    throw Error(ErrorArr.error.details[0].message)

                } else {

                    // check email and phone existense
                    if(args.email && args.email.length){
                        for (let i = 0; i < args.email.length; i++) {
                            args.email[i].email = args.email[i].email.toLowerCase();
                            emailArr.push(args.email[i].email)
                        }
                        cEmails = await model.Contact.findAll({
                            attributes: [],
                            include: [{
                                model: model.ContactEmail,
                                as: 'contactEmails',
                                attributes: ['email'],
                                required: true,                        
                                where: {
                                    email: {
                                        [Op.in]: [emailArr]
                                    },
                                    status: 1,
                                    id_contact: {
                                        [Op.ne]: args.input.id_contact
                                      },
                                }
                            }
                        ],
                        where: {
                            status: 1,
                            //uid_ua_user: context.user.id
                        }
                    });
                    }
                    if(args.phone && args.phone.length){
                        for (let i = 0; i < args.phone.length; i++) {
                            numArr.push(args.phone[i].phone)
                        }
                        cNumbers = await model.Contact.findAll({
                            attributes: [],
                            include: [
                                {
                                    model: model.ContactNumber,
                                    as: 'contactNumbers',
                                    attributes: ['phone'],
                                    required: true,
                                    where: {
                                        phone: {
                                            [Op.in]: [numArr]
                                        },
                                        status: 1,
                                        id_contact: {
                                            [Op.ne]: args.input.id_contact
                                          },
                                    }
                                }
                            ],  
                            where: {
                                //uid_ua_user: context.user.id,
                                status: 1
                            }
                        });
                    }
                    
                
                if (cEmails && cEmails.length) {
                    existingObj.email = '';
                    for(let i=0; i < cEmails.length; i++){
                        for(let j=0; j < cEmails[i].contactEmails.length; j++){
                            existingObj.email = existingObj.email + cEmails[i].contactEmails[j].email + ',';
                        }
                    }
                    existingObj.email = existingObj.email.slice(',', -1);
                };
                
                if (cNumbers && cNumbers.length) {
                    existingObj.phone = '';
                    for(let i=0; i < cNumbers.length; i++){
                        for(let j=0; j < cNumbers[i].contactNumbers.length; j++){
                            existingObj.phone = existingObj.phone + cNumbers[i].contactNumbers[j].phone + ',';
                         }
                    }
                    existingObj.phone = existingObj.phone.slice(',', -1);
                }
                if(existingObj && (existingObj['email'] || existingObj['phone'])){ // If any number or email exist, then throw an error
                    throw new Error(JSON.stringify(existingObj));
                }
                // check existence end here

                
                    let result = await model.Contact.find({
                        where: {
                            id_contact: args.input.id_contact,
                            uid_ua_user: context.user.id
                        },
                        raw: true
                    })
                    if (result) {
                        let update = model.Contact.update(args.input, {
                            where: {
                                id_contact: args.input.id_contact
                            }
                        })
                        if (args.input.group) {
                            let group = await model.GroupMember.upsert({
                                id_contact: args.input.id_contact,
                                id_group: args.input.group,
                                created_at: new Date(),
                                updated_at: new Date(),
                                status: 1
                            })
                            //console.log('group', group)
                        }
                        if (args.email) {
                            let updateEmail = [],
                                insertEmail = [],
                                checkEmail = []
                            args.email.forEach(email => {
                                if (email.id_contact_email) {
                                    if(email.email){
                                        updateEmail.push(email.email.toLowerCase())
                                    }
                                } else {
                                    let obj = {}
                                    if(email.email){
                                        obj.email = email.email.toLowerCase()
                                    }
                                    obj.primary = email.primary || false
                                    obj.status = email.status || 1
                                    obj.id_contact = args.input.id_contact
                                    obj.created_at = new Date()
                                    obj.updated_at = new Date()
                                    insertEmail.push(obj)
                                }
                                checkEmail.push(email.email)
                            })
                            updateEmail.forEach(async email => {
                                if (email.primary && email.status === 0) {
                                    throw new Error('cannot delete primary email')
                                }
                                // check existing updated email
                                let is_exist =  await model.ContactEmail.findAll({
                                    attributes: ['email', 'id_contact_email'],
                                    where:{
                                        email:email.email,
                                        id_contact_email:{
                                            $ne:email.id_contact_email
                                        }
                                    }    
                                });
                                if(is_exist){
                                    checkExistingEmails.push(is_exist);
                                }
                            })

                            
                            // check existing new email
                            insertEmail.forEach(async email => {
                                let is_exist =  await model.ContactEmail.findAll({
                                    attributes: ['email', 'id_contact_email'],
                                    where:{
                                        email:email.email
                                    }    
                                });
                                if(is_exist){
                                    checkExistingEmails.push(is_exist);
                                }
                                
                            })
                            if(is_exist){
                                checkExistingEmails.push(is_exist);
                            }
                            
                            if (checkExistingEmails.length) {
                                if (updateEmail.length > 0) {
                                    const modifiedEmails = await modifyEmail(updateEmail)
                                }
                                if (insertEmail.length > 0) {
                                    const newEmails = await model.ContactEmail.bulkCreate(insertEmail)
                                }
                            } else {
                                let existingEmails = []
                                checkExistingEmails.forEach(email => {
                                    existingEmails.push(email['contactEmails.email'])
                                })
                                throw new Error(existingEmails)
                            }
                        }

                        if (args.phone) {
                            let updatePhNum = [],
                                insertPhNum = [],
                                checkPhNum = []
                            args.phone.forEach(number => {
                                if (number.id_contact_phone) {
                                    if (number)
                                        updatePhNum.push(number)
                                } else {
                                    let obj = {}
                                    obj.phone = number.phone
                                    obj.primary = number.primary || false
                                    obj.status = number.primary || 0
                                    obj.id_contact = args.input.id_contact
                                    obj.created_at = new Date()
                                    obj.updated_at = new Date()
                                    insertPhNum.push(obj)
                                }
                                checkPhNum.push(number.phone)
                            })
                            updatePhNum.forEach(async number => {
                                if (number.primary && number.status === 0) {
                                    throw new Error('cannot delete primary number')
                                }
                                // check existence updated number
                                let is_exist =  await model.ContactNumber.findAll({
                                    attributes: ['phone'],
                                    where:{
                                        phone:number.phone,
                                        id_contact_phone:{
                                            $ne:number.id_contact_phone
                                        }
                                    }    
                                });
                                if(is_exist){
                                    checkExistingNumbers.push(is_exist);
                                }
                            })
                            
                            if (checkExistingNumbers.length === 0) {
                                if (updatePhNum.length > 0) {
                                    const modifiedPhNum = await modifyPhNum(updatePhNum)
                                }
                                if (insertPhNum.length > 0) {
                                    const newPhNum = await model.ContactNumber.bulkCreate(insertPhNum)
                                }
                            } else {
                                let existingNumbers = []
                                checkExistingNumbers.forEach(number => {
                                    existingNumbers.push(number['contactNumbers.phone'])
                                })
                                throw new Error(existingNumbers)
                            }

                        }

                        if (args.address) {
                            let updateAddress = [],
                                insertAddress = []
                                args.address.forEach(address => {
                                if (address.id) {
                                    let obj = {}
                                    obj = address
                                    obj.updated_at = new Date()
                                    updateAddress.push(address)
                                } else {
                                    let obj = {}
                                    obj = address
                                    obj.id_contact = args.input.id_contact
                                    obj.is_deleted = 0
                                    obj.created_at = new Date()
                                    obj.updated_at = new Date()
                                    insertAddress.push(obj)
                                }
                            })
                            if (updateAddress.length > 0) {
                                const modifiedAddress = await modifyAdd(updateAddress)
                            }
                            if (insertAddress.length > 0) {
                                const newAddress = await model.ContactAddress.bulkCreate(insertAddress)
                            }
                        }
                        return {
                            id_contact: args.input.id_contact,
                            message: "Contact updated successfully"
                        }

                    } else {
                        throw new Error('Contact does not exist')
                    }
                }
            } catch (err) {
                return err
            }
        },
    }
}