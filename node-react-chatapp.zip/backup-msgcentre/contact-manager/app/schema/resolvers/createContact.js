const model = require('../../models');
const validation = require('../../validation/contactValidation');
const Op = model.Sequelize.Op;
module.exports = {
    Mutation: {
        createContact: async(obj, args, context, info) => {
            let emailArr = [],numArr = [], existingObj={};
            const transaction = await model.ampDb.transaction(); // get transaction
            try {
                ErrorArr = validation.validateAddContact(args.input);
                if (ErrorArr.error != null) {
                    throw Error(ErrorArr.error.details[0].message)
                }
                for (let i = 0; i < args.input.contactEmails.length; i++) {
                    args.input.contactEmails[i].email = args.input.contactEmails[i].email.toLowerCase();
                    emailArr.push(args.input.contactEmails[i].email)
                }
                for (let i = 0; i < args.input.contactNumbers.length; i++) {
                    numArr.push(args.input.contactNumbers[i].phone)
                }
                let cEmails = await model.Contact.findAll({
                    attributes: [],
                    include: [{
                        model: model.ContactEmail,
                        as: 'contactEmails',
                        attributes: ['email'],
                        required: true,                        
                        where: {
                            email: {
                                [Op.in]: [emailArr]
                            },
                            status: 1
                        }
                    }
                ],
                where: {
                    status: 1,
                    uid_ua_user: context.user.id
                }
            });
            let cNumbers = await model.Contact.findAll({
                attributes: [],
                include: [
                    {
                        model: model.ContactNumber,
                        as: 'contactNumbers',
                        attributes: ['phone'],
                        required: true,
                        where: {
                            phone: {
                                [Op.in]: [numArr]
                            },
                            status: 1
                        }
                    }
                ],  
                where: {
                    uid_ua_user: context.user.id,
                    status: 1
                }
            });
            if (cEmails && cEmails.length) {
                existingObj.email = '';
                for(let i=0; i < cEmails.length; i++){
                    for(let j=0; j < cEmails[i].contactEmails.length; j++){
                        existingObj.email = existingObj.email + cEmails[i].contactEmails[j].email + ',';
                    }
                }
                existingObj.email = existingObj.email.slice(',', -1);
            };
            
            if (cNumbers && cNumbers.length) {
                existingObj.phone = '';
                for(let i=0; i < cNumbers.length; i++){
                    for(let j=0; j < cNumbers[i].contactNumbers.length; j++){
                        existingObj.phone = existingObj.phone + cNumbers[i].contactNumbers[j].phone + ',';
                     }
                }
                existingObj.phone = existingObj.phone.slice(',', -1);
            }
            if(existingObj && (existingObj['email'] || existingObj['phone'])){ // If any number or email exist, then throw an error
                throw new Error(JSON.stringify(existingObj));
            }
            let associateData = {include:[]};
            if(!args.input.groups){ // include group
                delete args.input.groups;
            }else{
                args.input.groups = {id_group:args.input.groups}
                associateData.include.push({model: model.GroupMember, as: 'groups'});
            }
            // save contact to contact table and groups member
            args.input = {...args.input, uid_ua_user: context.user.id}
            const result = await model.Contact.create(
                args.input,
                associateData,
                transaction
            )
        if(result.id_contact){
            if(args.input.contactEmails && args.input.contactEmails.length){ // save email
                for(let i=0; i < args.input.contactEmails.length; i++){
                    args.input.contactEmails[i] = {...args.input.contactEmails[i], id_contact:result.id_contact}
                }
                await model.ContactEmail.bulkCreate(args.input.contactEmails);
            }
            if(args.input.contactNumbers && args.input.contactNumbers.length){ // include phone
                for(let i=0; i < args.input.contactNumbers.length; i++){
                    args.input.contactNumbers[i] = {...args.input.contactNumbers[i], id_contact:result.id_contact}
                }
                await model.ContactNumber.bulkCreate(args.input.contactNumbers);
            }
            if(args.input.addresses && args.input.addresses.length){ // include Address
                for(let i=0; i < args.input.addresses.length; i++){
                    args.input.addresses[i] = {...args.input.addresses[i], id_contact:result.id_contact}
                }
                await model.ContactAddress.bulkCreate(args.input.addresses);
            }
            if(args.input.serviceIds && args.input.serviceIds.length){ // include Service
                for(let i=0; i < args.input.serviceIds.length; i++){
                    args.input.serviceIds[i] = {id_service:args.input.serviceIds[i], to_uid:context.user.id, id_contact:result.id_contact}
                }
                await model.ServiceDetails.bulkCreate(args.input.serviceIds);
            }
            // fetch address, emails and numbers
            const detailsArr = await model.Contact.findAll({
                where:{
                    id_contact:result.id_contact
                },
                include:[
                    {
                        model: model.ContactEmail,
                        as: 'contactEmails'
                    },
                    {
                        model: model.ContactNumber,
                        as: 'contactNumbers'
                    },
                    {
                        model: model.ContactAddress,
                        as: 'addresses'
                    }
                ]
            });
            await transaction.commit(); // commit
            return detailsArr[0];
        }
        throw new Error('Error while saving');
            } catch (err) {
                await transaction.rollback(); // Rollback transaction if any errors were encountered
                return err
            }
        }
    }
}