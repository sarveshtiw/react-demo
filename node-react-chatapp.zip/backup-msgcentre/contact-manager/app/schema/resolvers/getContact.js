const axios = require('axios');
const { adminGraphqlService} = require('../../config/index').microservicesLinks;
const model = require('../../models');
const validation = require('../../validation/contactValidation');

let getContactData = async condition => {
    try {

        let result = {
            contact: []
        }

        let contacts = await model.Contact.findAll({
            include: [{
                model: model.ContactEmail,
                as: 'contactEmails'
            }, {
                model: model.ContactNumber,
                as: 'contactNumbers'
            }, {
                model: model.GroupMember,
                as: 'groups'
            }, {
                model: model.ServiceDetails,
                as: 'serviceIds'
            }, {
                model: model.ContactAddress,
                as: 'addresses'
            }],
            where: condition
        })
        result.contact = contacts
        return result
    } catch (err) {
        return err
    }
}
module.exports = {
    Query: {
        getContactById: async(obj, args, context, info) => {
            console.log(context.user.confId);
            try {

                let ErrorArr = validation.validateGetContactById({
                    'id': args.id
                });

                if (ErrorArr.error != null) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                let cond = {
                    id_contact: {
                        [model.Sequelize.Op.in]: [args.id]
                    },
                    uid_ua_user: context.user.hasOwnProperty('confId') ? {
                        [model.Sequelize.Op.ne]: 0
                    } : context.user.id,
                    status: 1
                }

                let data = await getContactData(cond)
                //console.log('13131', JSON.stringify(data))
                let findNameById = {
                    country_id: [],
                    state_id: [],
                    city_id: []
                }
                if(data.contact[0] && data.contact[0].addresses.length>0) {
                    data.contact[0].addresses.forEach(async ({country, state, city}) => {
                        if(country!==null) {
                           findNameById.country_id.push(country) 
                        }
                        if(state!==null) {
                            findNameById.state_id.push(state)
                        }                       
                        if(city!==null) {
                            findNameById.city_id.push(city)
                        }                       
                    })

                    if(process.env.ADMIN_GRAPHQL_SERVICE_HOST && process.env.ADMIN_GRAPHQL_SERVICE_PORT){
                        let resp = await axios.post(adminGraphqlService + 'getBulkDataByID', findNameById );
                        //console.log('####', resp.data)
                        let newAddress = data.contact[0].addresses.map(address => {
                            let city = address.city
                            let city_name = resp.data.city[address.city]
                            let state = address.state
                            let state_name = resp.data.state[address.state]
                            let country = address.country
                            let country_name = resp.data.country[address.country]  
                            return {...address.dataValues, country_name, state_name, city_name}   
                        })
                        data.contact[0].addresses = newAddress;    
                    }                          
                }               
                return data
            } catch (err) {
                return err
            }

        },

        getContacts: async(obj, args, context, info) => {
            try {
                let cond = {
                    status: 1,
                    uid_ua_user: context.user.hasOwnProperty('confId') ? {
                        [model.Sequelize.Op.ne]: 0
                    } : context.user.id
                }
                let data = await getContactData(cond)
                return data
            } catch (err) {
                return err
            }
        },
        isEmailExist: async(obj, args, context, info) => {
            try {
                const ErrorArr = validation.validateIsEmailExist(args.input);
                if (ErrorArr.error != null) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                // Process the API
                let emailObj = await model.Contact.findOne({
                    include: [{
                        model: model.ContactEmail,
                        as: 'contactEmails',
                        required: true,
                        attributes: ['email', 'id_contact_email'],
                        where: {
                            email: args.input.email,
                            status: 1
                        }
                    }],
                    raw: true,
                    attributes: [],
                    where: {
                        uid_ua_user: context.user.id,
                        status: 1
                    }
                })

                if (emailObj) { // email exist
                    return { isExist: 1 };
                } else { // email does not exist
                    return { isExist: 0 };
                }
            } catch (err) {
                return err;
            }
        },
        isNumberExist: async(obj, args, context, info) => {
            try {
                const ErrorArr = validation.validateIsNumberExist(args.input);
                if (ErrorArr.error != null) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                // Process the API
                let numberObj = await model.Contact.findOne({
                    include: [{
                        model: model.ContactNumber,
                        as: 'contactNumbers',
                        required: true,
                        attributes: ['phone'],
                        where: {
                            phone: args.input.number,
                            status: 1
                        },
                    }],
                    raw: true,
                    attributes: [],
                    where: {
                        uid_ua_user: context.user.id,
                        status: 1
                    }
                })
                if (numberObj) { // number exist
                    return { isExist: 1 };
                } else { // number does not exist
                    return { isExist: 0 };
                }
            } catch (err) {
                return err;
            }
        },

    }
}