const { mergeResolvers } = require('merge-graphql-schemas');

const searchContact = require('./searchContact')
const createContact = require('./createContact')
const deleteContact = require('./deleteContact')
const getContact = require('./getContact')
const updateContact = require('./updateContact')
const Group = require('./group');
const SharedDetails = require('./sharedDetails');
const serviceDetails = require('./serviceDetails')
const googleContacts = require('./googleContacts')

const resolvers = [
    createContact,
    deleteContact,
    getContact,
    updateContact,  
    searchContact,
    Group,
    SharedDetails,
    serviceDetails,
    googleContacts,
    {}
]

//model.ampDb.query('SELECT * from contactEmails eml LEFT JOIN Contact cc on eml.cid=cc.cid where cc.user_id=req.user_id and eml.email_id in("sdfsd@asdas.com","fhdh@fdf.com")', (type:model.ampDb.))


module.exports = mergeResolvers(resolvers);