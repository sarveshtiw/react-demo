const model = require('../../models')
const validation = require('../../validation/serviceDetails');

module.exports = {
    Mutation: {
        serviceContactDetails: async(obj, args, context, info) => {
            let output = {}
            output.result = {}
            output.errors = []
            let data = []

            let ErrorArr = [];
            let paramArr = [];
            paramArr['to_uid'] = args.to_uid;
            paramArr['id_service'] = args.id_service;
            paramArr['is_shared'] = args.is_shared;
            if (args.id_contact) {
                paramArr['id_contact'] = args.id_contact;
            }
            if (args.id_group) {
                paramArr['id_group'] = args.id_group;
            }

            // Validate request
            ErrorArr = validation.validateserviceDetails(paramArr);
            // validate ErrorArr, If it is not null. that's mean an error occured.
            if (ErrorArr.error != null) {
                throw new Error(ErrorArr.error.details[0].message);
            }

            args.input.id_service.forEach(serviceId => {
                let obj = {}
                obj.id_contact = args.input.id_contact
                obj.to_uid = args.input.to_uid
                obj.id_group = args.input.id_group
                obj.id_service = serviceId
                obj.is_shared = args.input.is_shared
                obj.status = 1
                obj.created_at = new Date()
                obj.updated_at = new Date()
                data.push(obj)
            })
            let result = await model.serviceDetails.bulkCreate(data)
            console.log('result', result)
            if (result) {
                output.result = {
                    key: 'success',
                    message: 'Services assigned '
                }
                return output
            }
        },
    }
}