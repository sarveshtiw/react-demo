module.exports = `

input createContactGroup {
  group_name: String!,
  purpose: String,
  contacts:[Int]
}

type createContactGroupOutput {
  id_group: Int,
  group_name: String,
  purpose: String,
  uid: Int,
  status: Int,
  created_at: String,
  updated_at: String  
}

type ContactObj{
  id_contact:Int
  Contact: contact
}

type createContactGroupOut{
  details : createContactGroupOutput
  contactNotExist:[Int]
  GroupMembers:[ContactObj]
}

type GroupMemberObj{
  id_contact:Int
  full_name:String
}

input updateContactGroup {
  group_id: Int!,
  group_name: String!
  purpose: String  
  contacts:[Int]
}

type updateContactGroupOutput {
  group_id: Int,
  message: String
  groupIdDoesNotExist:[Int]
}

input deleteContactGroup {
  group_id: [Int]!
}


input getContactGroup {
  group_id: [Int],
  page: Int
}


type getContactGroupByIdOutput {
  id_group: Int,
  group_name: String,
  purpose: String,
  uid: Int,
  status: Int,
  created_at: String,
  updated_at: String,
  GroupMembers: [members]
}

type members {
  id_contact: Int,
  Contact: contact
}

type contact {
  id_contact:Int,
  fname: String,
  lname: String,
  contactEmails: [emailData]
}

type emailData {
  id_contact_email: Int,
  email: String
}


type getContactGroups {
  groups: [getContactGroupByIdOutput],
  page: Int
}


type Query {
  getContactGroupById(input: getContactGroup) : getContactGroups
  getContactGroups : getContactGroups
  searchContactGroup(name: String): getContactGroups
}

type Mutation {
  createContactGroup(input:createContactGroup) : createContactGroupOut
  updateContactGroup(input:updateContactGroup) : updateContactGroupOutput
  deleteContactGroup(input:deleteContactGroup) : updateContactGroupOutput
}

`;