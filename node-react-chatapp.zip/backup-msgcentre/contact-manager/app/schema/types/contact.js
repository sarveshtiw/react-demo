module.exports = `

  input createContact {
    title: String,
    dob: String,
    fname: String!,
    lname: String,
    intl_code: String,
    addresses: [Address],
    designation: String,
    department: String,
    organisation: String,
    groups: Int,
    serviceIds: [Int],
    contactEmails: [email_id]!,
    contactNumbers: [number]!
  }

  input Address {
    address1: String,
    address2: String,
    address3: String,
    address_type: Int,
    city: Int,
    state: Int,
    country: Int,
    zipcode: String
  }

  input email_id {
    email: String,
    primary: Boolean,
    errorMsg: String
  }

  input number {
    phone: String,
    primary: Boolean,
    errorMsg: String
  }

  type createContactResult {
    title: String,
    dob: String,
    id_contact: Int,
    uid_ua_user: Int,
    fname: String,
    lname: String,
    intl_code: String,
    addresses: [address], 
    designation: String,
    department: String,
    organisation: String,
    groups: GrpMem,
    serviceIds: [service],
    last_active_time: String,
    is_online: Int,
    status: Int,
    created_at: String,
    updated_at: String,
    contactEmails: [contactEmail],
    contactNumbers: [contactNumber]
  }

  type address {
    id: Int,
    id_contact: Int,
    address1: String,
    address2: String,
    address3: String,
    address_type: Int,
    city: Int,
    city_name: String,
    state: Int,
    state_name: String,
    country: Int,
    country_name: String,
    zipcode: String,
    is_deleted: Int,
    created_at: String,
    updated_at: String
  }

  type GrpMem {
    id_group_member: Int,
    id_contact: Int,
    id_group: Int,
    created_at: String,
    updated_at: String
  }

  type service {
    id_contact_service: Int,
    id_contact: Int,
    to_uid: Int,
    id_group: Int,
    id_service: Int,
    is_shared: Int,
    status: Int,
    created_at: String,
    updated_at: String
  }

  type contactEmail {
    id_contact_email: Int,
    id_contact: Int,
    email: String,
    primary: Int,
    status: Int,
    created_at: String,
    updated_at: String
  }

  type contactNumber {
    id_contact_phone: Int,
    id_contact: Int,
    phone: String,
    primary: Int,
    status: Int,
    created_at: String,
    updated_at: String
  }

  input updateContact {
    title: String,
    dob: String,
    id_contact: Int!,
    fname: String,
    lname: String,
    intl_code: String,
    designation: String,
    department: String,
    organisation: String,
    group: Int,
  }

  input Email {
    id_contact_email: Int,
    email: String,
    primary: Boolean,
    status: Int
  }

  input Phone {
    id_contact_phone: Int,
    phone: String,
    primary: Boolean,
    status: Int
  }

  input updateAddress {
    id: Int,
    id_contact: Int,
    address1: String,
    address2: String,
    address3: String,
    address_type: Int,
    city: Int,
    state: Int,
    country: Int,
    zipcode: String
  }

  type updateContactResult {
    id_contact: Int,
    message: String   
  }

  input searchContact{
    keyword : String!
  }
 
  type getContactResult {
    contact: [createContactResult]    
  }

  input isEmailExistIn{
    email:String
  }

  input isNumberExistIn{
    number:String
  }

  type isEmailExistOut{
    isExist:Int
  }

  type deleteContactOut{
    id_contact: [Int]
    message: String   
    contactIdDoesNotExist:[Int]
  }

  
  type Mutation {
    createContact(input: createContact!): createContactResult
    updateContact(input: updateContact, email: [Email], phone: [Phone], address: [updateAddress]): updateContactResult
    deleteContact(id: [Int]!): deleteContactOut 
  }

  type Query {
    searchContact(input : searchContact!) : getContactResult
    getContactById(id: [Int]): getContactResult
    getContacts: getContactResult
    isEmailExist(input:isEmailExistIn) : isEmailExistOut
    isNumberExist(input:isNumberExistIn) : isEmailExistOut
  }

`