module.exports = `
    type result {
        message: String    
    }
    input inputData {
        access_token: String!,
        expiry_date: String,
        token_type: String
    }

    type Mutation {      
    addGoogleContacts(input: inputData!): result            
    }
`