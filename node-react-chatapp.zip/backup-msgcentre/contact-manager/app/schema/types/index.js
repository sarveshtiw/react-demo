const { mergeTypes } = require('merge-graphql-schemas');

const Contact = require('./contact')
const Group = require('./group');
const SharedDetails = require('./sharedDetails');
const serviceDetails = require('./serviceDetails')
const googleContacts = require('./googleContacts')

const types = [
    Contact,
    Group,
    SharedDetails,
    serviceDetails,
    googleContacts,
    `type err {
        key: String
        message: String
      }`
]



module.exports = mergeTypes(types);