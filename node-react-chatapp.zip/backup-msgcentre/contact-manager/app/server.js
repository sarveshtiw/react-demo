if(process.env.NODE_ENV==='local'){
    require('dotenv').config();
}
const bearerToken = require('express-bearer-token');
const bodyParser = require('body-parser');
const app = require('express')();
const cors = require('cors');
const { graphqlExpress, graphiqlExpress } = require('graphql-server-express');

const { formatErr } = require('./utils');
const { server } = require('./config');
const schema = require('./schema');
const auth = require('./lib');
const healthChecks = require('./lib/healthChecks');

app.use(cors());

app.get('/healthz/liveness', healthChecks.liveness);
app.get('/healthz/readiness', healthChecks.readiness);

app.use('/graphiql', graphiqlExpress({
    endpointURL: '/graphql',
}));
app.use(bearerToken());
const buildOptions = async (req, res) => {
  const user = req.token ? auth.getUserFromToken(req.token): null;
  return {
      context: {user},
      formatError: formatErr,
      schema
  }
}
app.use('/graphql', bodyParser.json(), graphqlExpress(buildOptions));

app.get('/test', (req, res) => {
    res.send('test')
})

app.listen(server.port, () => {
    console.log('info', `Running a GraphQL API server at ${server.host}:${server.port}/graphql`);
});
