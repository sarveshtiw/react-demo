Contact Manager backend Application
===================================

## Introduction
This is a backend App for Contact Management, developed in GraphQL.

## How to run
This application requires node to be installed on your system. Please check [upstream documentation](https://nodejs.org/en/download/)
for how to install node on your system.

### Development build
In application root path run following commands
```bash
cd app
npm install
npm start
```
### Production build
Run following commands
```bash
cd app 
npm install --only=production
npm start
```

## Dependencies
This application required following connections to run:
- MySQL
- multi-db-access-manager

## Environment variables
Environment variables is the main mechanism of manipulating application settings. Currently application recognizes
following environment variables:

| Variable           | Default value                                 | Description          |
| -------------------| --------------------------------------------- | -------------------- |
| NODE_ENV           | null   | Sets current environment. Allows application to manipulate some settings automatically |
| HOST               | localhost                                     | Address to listen on |
| PORT               | 3008                                          | Port to listen on    |
| MYSQL_SERVICE_HOST | localhost                                     | Database address     |
| MYSQL_SERVICE_PORT | 3306                                          | Database port        |
| APP_DB_NAME        | contact_manager                               | Database name        |
| APP_DB_USER        | root                                          | Database user        |
| APP_DB_PASS        | 123456                                        | Database password    |
| MULTI_DB_ACCESS_MANAGER_SERVICE_SCHEME | http | Sets multi-db-access-scheme  |
| MULTI_DB_ACCESS_MANAGER_SERVICE_HOST   | null | Sets multi-db-access-host    |
| MULTI_DB_ACCESS_MANAGER_SERVICE_PORT   | null | Sets multi-db-access-port    |
| MULTI_DB_ACCESS_MANAGER_SERVICE_PATH   | / | Sets multi-db-access-path |

## API Documentation
You can get API docs using /graphiql path
