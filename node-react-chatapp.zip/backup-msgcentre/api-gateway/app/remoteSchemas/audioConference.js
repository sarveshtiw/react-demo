const { createApolloFetch } = require('apollo-fetch');
const { makeRemoteExecutableSchema, introspectSchema } = require('graphql-tools');
const axios = require('axios');
const {AudioConference} = require('../config/index').microservicesLinks;

let link = `${AudioConference}graphql`;
const fetcher = createApolloFetch({uri:link});

exports.audioConfSchema = async ()=>{
    try{
        if(process.env.AC_GRAPHQL_SERVICE_HOST && process.env.AC_GRAPHQL_SERVICE_PORT){
            const response = await axios.get(`${AudioConference}healthz/liveness`,{timeout:1000});
            if(response){
                return await makeRemoteExecutableSchema({
                    schema: await introspectSchema(fetcher),
                    fetcher,
                });
            }
            return null;
        }
        return null;
    }
    catch (err){
        console.log('audio conference error',err);
        return null;
    }
}
exports.audioConfFetcher = fetcher;