const { createApolloFetch } = require('apollo-fetch');
const { makeRemoteExecutableSchema, introspectSchema } = require('graphql-tools');
const axios = require('axios');
const {BillingAPI} = require('../config/index').microservicesLinks;

let link = `${BillingAPI}graphql`;
const fetcher = createApolloFetch({uri:link});

exports.billingSchema = async ()=>{
    try{
        if(process.env.BILLING_API_SERVICE_HOST && process.env.BILLING_API_SERVICE_PORT){
            const response = await axios.get(`${BillingAPI}healthz/liveness`,{timeout:1000});
            if(response){
                return await makeRemoteExecutableSchema({
                    schema: await introspectSchema(fetcher),
                    fetcher,
                });
            }
            return null;
        }
        return null;
    }
    catch (err){
        console.log('billing API error',err);
        return null;
    }
}
exports.billingFetcher = fetcher;