const {audioConfSchema} = require('./audioConference');
const {videoConfSchema} = require('./videoConference');
const {contactManagerSchema} = require('./contactManager');
const {didManagerSchema} = require('./didManager');
const {messageCentreSchema} = require('./messageCentre');
const {billingSchema} = require('./billingAPI');
const {crmSchema} = require('./crm');
const {adminSchema} = require('./admin');

const schemaGenerator = async () => {
    const schema = await Promise.all([audioConfSchema(), videoConfSchema(), contactManagerSchema(), didManagerSchema(), messageCentreSchema(),billingSchema(),crmSchema(), adminSchema()]);
    return schema;
}

module.exports = schemaGenerator;