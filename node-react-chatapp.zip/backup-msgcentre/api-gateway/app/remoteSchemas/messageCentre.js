const { createApolloFetch } = require('apollo-fetch');
const { makeRemoteExecutableSchema, introspectSchema } = require('graphql-tools');
const axios = require('axios');
const {MessageCentre} = require('../config/index').microservicesLinks;

let link = `${MessageCentre}graphql`;

const fetcher = createApolloFetch({uri:link});

exports.messageCentreSchema = async ()=>{
    try{
        if(process.env.MESSAGE_CENTRE_API_SERVICE_HOST && process.env.MESSAGE_CENTRE_API_SERVICE_PORT){
            const response = await axios.get(`${MessageCentre}healthz/liveness`,{timeout:1000});
            if(response){
                return await makeRemoteExecutableSchema({
                    schema: await introspectSchema(fetcher),
                    fetcher,
                });
            }
            return null;
        }
        return null;
    }
    catch (err){
        //Todo raise error on health check
        console.log('Message Centre error',err);
        return null;
    }
}
exports.messageCentreFetcher = fetcher;
