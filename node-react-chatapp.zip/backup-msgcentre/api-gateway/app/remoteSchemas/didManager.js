const { createApolloFetch } = require('apollo-fetch');
const { makeRemoteExecutableSchema, introspectSchema } = require('graphql-tools');
const axios = require('axios');
const { DIDManager} = require('../config/index').microservicesLinks;

let link = `${DIDManager}graphql`;

const fetcher = createApolloFetch({uri:link});

exports.didManagerSchema = async ()=>{
    try {
        if(process.env.DID_MANAGER_SERVICE_HOST && process.env.DID_MANAGER_SERVICE_PORT){
            const response = await axios.get(`${DIDManager}healthz/liveness`,{timeout:1000});
            if(response){
                return await makeRemoteExecutableSchema({
                    schema: await introspectSchema(fetcher),
                    fetcher,
                });
            }
            return null;
        }
        return null;
    }
    catch(err){
        //Todo raise error on health check
        console.log('did manager error',err);
        return null;
    }

}
exports.didManagerFetcher = fetcher;