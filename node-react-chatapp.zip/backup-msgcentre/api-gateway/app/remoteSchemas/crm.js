const { createApolloFetch } = require('apollo-fetch');
const { makeRemoteExecutableSchema, introspectSchema } = require('graphql-tools');
const axios = require('axios');
const {Crm} = require('../config/index').microservicesLinks;

let link = `${Crm}graphql`;
const fetcher = createApolloFetch({uri:link});

exports.crmSchema = async ()=>{
    try{
        if(process.env.CRM_GRAPHQL_SERVICE_HOST && process.env.CRM_GRAPHQL_SERVICE_PORT){
            const response = await axios.get(`${Crm}healthz/liveness`,{timeout:1000});
            if(response){
                return await makeRemoteExecutableSchema({
                    schema: await introspectSchema(fetcher),
                    fetcher,
                });
            }
            return null;
        }
        return null;
    }
    catch (err){
        console.log('crm backend error',err);
        return null;
    }
}
exports.crmFetcher = fetcher;