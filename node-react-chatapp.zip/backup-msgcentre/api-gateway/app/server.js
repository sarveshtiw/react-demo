if (process.env.NODE_ENV === 'local') {
    require('dotenv').config();
}
const app = require('express')();
const {graphqlExpress} = require('apollo-server-express');
const {mergeSchemas} = require('graphql-tools');
const cors = require('cors');
const bearerToken = require('express-bearer-token');
const bodyParser = require('body-parser');
const Playground = require('graphql-playground-middleware-express').default;
const morgan = require('morgan');
const {server} = require('./config');
const remoteSchema = require('./remoteSchemas');
const localSchema = require('./schema');
const {tokenValidator, healthCheck, login, fileUpload} = require('./lib')
const multer = require('multer')
const upload = multer({})

app.use(morgan('combined'));
app.use(cors());
app.use(bodyParser.json());
app.get('/', function (req, res) {
    res.send({message: 'This as an API Gateway application. You can communicate to all micro services from here!'});
});
app.get('/healthz/liveness', healthCheck.liveness);
app.get('/healthz/readiness', healthCheck.readiness);

app.post('/login', (req, res) => {
    login(req, res);
});

app.use('/graphiql', Playground({endpoint: '/graphql'}));


// file upload with authentication

app.post('/files-upload-external', upload.array('files', 10), function (req, res) {
    fileUpload(req, res)

});

app.use(bearerToken());
app.use(tokenValidator);

app.post('/files-upload', upload.array('files', 10), function (req, res) {
    //console.log('@@@@@@@@@@@', req.files)
    //return 0
    fileUpload(req, res)
});
//Code to generate schema once when server starts

// remoteSchema().then(schemas => {
//     schemas.push(localSchema);
//     const schema = mergeSchemas({
//         schemas
//     })
//     const buildOptions = (req, res) => {
//         return {schema, context:{token:req.token, user:req.token}, tracing: true}
//     }
//     app.use('/graphql', graphqlExpress(buildOptions));
// });

//code to generate schema on each request

const buildOptions = async (req, res) => {
    const schemas = await remoteSchema();
    schemas.push(localSchema);
    const schema = mergeSchemas({
        schemas
    });
    return {schema, context: {token: req.token}, tracing: false}
}

app.use('/graphql', graphqlExpress(buildOptions));

app.listen(server.port, server.host, () => {
    console.log('info', `Running a GraphQL API server at http://${server.host}:${server.port}`);
});