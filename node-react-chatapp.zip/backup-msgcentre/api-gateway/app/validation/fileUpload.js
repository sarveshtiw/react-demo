const Joi = require('joi')

const schema = Joi.object().keys({
  asergisPopId: Joi.string()
})


const fileUpload = (file, asergisPopId) => { 
  let errors = []
  if(!file) {
    errors.push({
      key: 'file',
      message: 'is required'
    })
  }
  const {error} = Joi.validate({asergisPopId: asergisPopId}, schema, {abortEarly: false})
  if(error) {
    error.details.forEach(error => {
      let obj = {}
      obj.key = error.message.match(/"([^"]+)"/)[1]
      obj.message = error.message.split(/ (.+)/)[1]
      errors.push(obj)
    })
  }
  return errors
}

module.exports = {
  fileUpload
}

