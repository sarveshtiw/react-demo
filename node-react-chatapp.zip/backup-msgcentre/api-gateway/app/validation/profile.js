const Joi = require('joi');

/********************************************** Starts: Validation schema  ***************************************************/
const schemaEditProfileInput = Joi.object().keys({
    title: Joi.string(),
    fname: Joi.string(),
    mname: Joi.string(),
    lname: Joi.string(),
    gender: Joi.string(),
    phone: Joi.string(),
    faxno: Joi.string(),
    address_line1: Joi.string(),
    address_line2: Joi.string(),
    address_line3: Joi.string(),
    id_amp_country: Joi.number(),
    state: Joi.string(),
    city: Joi.string(),
    pincode: Joi.string()
})

/********************************************** Starts: Validation function  ***************************************************/

const validateEditProfile = (EditProfileInput) => { // Validate listdidtype API
    return Joi.validate(EditProfileInput, schemaEditProfileInput, { abortEarly: true });
}

module.exports = {
    validateEditProfile,
}