const axios = require('axios');
const {server} = require('./../../config').auth;
module.exports = {
    Query: {
        portalPermissions: async (obj, args, context, info)=>{
          try {
              const permissions = await axios.get(server+'portal-permission',  {
                  headers: {
                      'Authorization':`Bearer ${context.token}`
                  }
              });
              return permissions.data
          }
          catch(error){
             throw new Error(error);
          }
        },
        servicePermissions: async (obj, args, context, info)=>{
            try {
                const permissions = await axios.post(server+'service-permission',args ,{
                    headers: {
                        'Authorization':`Bearer ${context.token}`
                    }
                });
                return permissions.data
            }
            catch(error){
                throw new Error(error);
            }
        }
    }
}