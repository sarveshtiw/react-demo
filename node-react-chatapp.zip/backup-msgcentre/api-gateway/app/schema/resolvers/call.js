module.exports = {
    Query: {
        hello : async (obj, args, context, info)=>{
            console.log(context);
            return 'Call API is not implemented yet'
        }
    }
}