const axios = require('axios');
const { server } = require('./../../config').auth;
const validation = require('../../validation/profile');
module.exports = {
    Query: {
        profile: async(obj, args, context, info) => {
            try {
                const permissions = await axios.get(server + 'profile', {
                    headers: {
                        'Authorization': `Bearer ${context.token}`
                    }
                });
                return permissions.data
            } catch (error) {
                throw new Error(error);
            }
        }
    },
    Mutation: {
        editProfile: async(obj, args, context, info) => {
            try {
                // Validate prepared array with JOI
                ErrorArr = validation.validateEditProfile(args.input);
                if (ErrorArr.error != null) {
                    throw new Error(ErrorArr.error.details[0].message);
                }
                // Process the API, call auth-server api to process
                const editProfile = await axios.post(server + '/editUserProfile', args.input, {
                    headers: {
                        'Authorization': `Bearer ${context.token}`
                    }
                });
                if (editProfile.data.errors) { // error occured
                    throw new Error(editProfile.data.errors);
                } else { // no errora, it's success
                    return { message: 'Success' };
                }
            } catch (err) {
                return err;
            }
        }
    }
}