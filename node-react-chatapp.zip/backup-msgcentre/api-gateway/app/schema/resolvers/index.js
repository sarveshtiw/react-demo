const {mergeResolvers} = require('merge-graphql-schemas');
const calls = require('./call');
const permissions = require('./permissions');
const profile = require('./profile');

const resolvers = [
    calls,
    permissions,
    profile
]
module.exports = mergeResolvers(resolvers);
