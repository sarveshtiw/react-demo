module.exports = {
    server: {
        host: process.env.HOST || '0.0.0.0',
        port: process.env.PORT || 3000
    },
    whitelistDomains: process.env.WHITELIST_DOMAINS || 'http://localhost:3000',
    microservicesLinks: {
        ContactCentre: `${process.env.CONTACT_CENTRE_SERVICE_SCHEME || 'http'}://${process.env.CONTACT_CENTRE_SERVICE_HOST}:${process.env.CONTACT_CENTRE_SERVICE_PORT}${process.env.CONTACT_CENTRE_SERVICE_PATH || '/'}`,
        ContactManager: `${process.env.CONTACT_MANAGER_SERVICE_SCHEME || 'http'}://${process.env.CONTACT_MANAGER_SERVICE_HOST}:${process.env.CONTACT_MANAGER_SERVICE_PORT}${process.env.CONTACT_MANAGER_SERVICE_PATH || '/'}`,
        CloudTelephony: `${process.env.CLOUD_TELEPHONY_SERVICE_SCHEME || 'http'}://${process.env.CLOUD_TELEPHONY_SERVICE_HOST}:${process.env.CLOUD_TELEPHONY_SERVICE_PORT}${process.env.CLOUD_TELEPHONY_SERVICE_PATH || '/'}`,
        AudioConference: `${process.env.AC_GRAPHQL_SERVICE_SCHEME || 'http'}://${process.env.AC_GRAPHQL_SERVICE_HOST}:${process.env.AC_GRAPHQL_SERVICE_PORT}${process.env.AC_GRAPHQL_SERVICE_PATH || '/'}`,
        VideoConference: `${process.env.VC_GRAPHQL_SERVICE_SCHEME || 'http'}://${process.env.VC_GRAPHQL_SERVICE_HOST}:${process.env.VC_GRAPHQL_SERVICE_PORT}${process.env.VC_GRAPHQL_SERVICE_PATH || '/'}`,
        DIDManager: `${process.env.DID_MANAGER_SERVICE_SCHEME || 'http'}://${process.env.DID_MANAGER_SERVICE_HOST}:${process.env.DID_MANAGER_SERVICE_PORT}${process.env.DID_MANAGER_SERVICE_PATH || '/'}`,
        MessageCentre: `${process.env.MESSAGE_CENTRE_API_SERVICE_SCHEME || 'http'}://${process.env.MESSAGE_CENTRE_API_SERVICE_HOST}:${process.env.MESSAGE_CENTRE_API_SERVICE_PORT}${process.env.MESSAGE_CENTRE_API_SERVICE_PATH || '/'}`,
        BillingAPI: `${process.env.BILLING_API_SERVICE_SCHEME || 'http'}://${process.env.BILLING_API_SERVICE_HOST}:${process.env.BILLING_API_SERVICE_PORT}${process.env.BILLING_API_SERVICE_PATH || '/'}`,
        Crm: `${process.env.CRM_GRAPHQL_SERVICE_SCHEME || 'http'}://${process.env.CRM_GRAPHQL_SERVICE_HOST}:${process.env.CRM_GRAPHQL_SERVICE_PORT}${process.env.CRM_GRAPHQL_SERVICE_PATH || '/'}`,
        Admin: `${process.env.ADMIN_GRAPHQL_SERVICE_SCHEME || 'http'}://${process.env.ADMIN_GRAPHQL_SERVICE_HOST}:${process.env.ADMIN_GRAPHQL_SERVICE_PORT}${process.env.ADMIN_GRAPHQL_SERVICE_PATH || '/'}`
    },
    minioServer: {
        endPoint: process.env.MINIO_SERVICE_HOST || 'minio.pwg.asergis.net',
        accessKey: process.env.MINIO_SERVICE_ACCESS_KEY || 'ZNUVUYB88Q0D3Y6AOPF8',
        secretKey: process.env.MINIO_SERVICE_SECRET_KEY || 'K16nnO42QwpBbJcfgeBliPFrZyYvC+r0mpsb/KJv'
    },
    fileStorageServer: {
        scheme: process.env.FILE_STORAGE_API_SERVICE_SCHEME || 'http',
        host: process.env.FILE_STORAGE_API_SERVICE_HOST,
        port: process.env.FILE_STORAGE_API_SERVICE_PORT,
        path: process.env.FILE_STORAGE_API_SERVICE_PATH || '/'
    },
    auth: {
        server: `${process.env.AUTH_SERVER_SERVICE_SCHEME || 'http'}://${process.env.AUTH_SERVER_SERVICE_HOST}:${process.env.AUTH_SERVER_SERVICE_PORT}${process.env.AUTH_SERVER_SERVICE_PATH || '/'}`,
        secret: 'super_secret_word'
    }
};
