Synthesis API Gateway Application
=================================

## Introduction
This is a gateway application for all backend microservices. This is an backend API developed in GraphQL to provide a common place for communication with all microservices.

## How to run
This application requires node to be installed on your system. Please check [upstream documentation](https://nodejs.org/en/download/)
for how to install node on your system.

### Development build
In application root path run following commands
```bash
cd app
npm install
npm start
```
### Production build
Run following commands
```bash
cd app
npm install --only=production
npm start
```

### Dependencies
This application required following connections to run.
- Message Centre Host
- Contact Centre Host
- Audio Conference Host
- Video Conference Host
- Contact Manager Host
- Cloud Telephony Host
- DID Manager Host
- Auth Server Host
- Billing API Host
- CRM backend Host
- Admin backend Host

### Environment variables
Environment variables is the main mechanism of manipulating application settings. Currently application recognizes
following environment variables:

| Variable                       | Default value | Description             |
| ------------------------------ | ------------- | ----------------------- |
| NODE_ENV                       | null          | Sets current environment. Allows application to manipulate some settings automatically |
| HOST                           | 0.0.0.0       | Address to listen on    |
| PORT                           | 3000          | Port to listen on       |
| CONTACT_MANAGER_SERVICE_SCHEME | http          | contact-manager connection scheme (http or https) |
| CONTACT_MANAGER_SERVICE_HOST   | null          | contact-manager address |
| CONTACT_MANAGER_SERVICE_PORT   | null          | contact-manager port    |
| CONTACT_MANAGER_SERVICE_PATH   | /      | Path contact-manager accepts requests on |
| AC_GRAPHQL_SERVICE_SCHEME      | http          | ac-graphql connection scheme (http or https) |
| AC_GRAPHQL_SERVICE_HOST        | null          | ac-graphql address      |
| AC_GRAPHQL_SERVICE_PORT        | null          | ac-graphql port         |
| AC_GRAPHQL_SERVICE_PATH        | /      | Path ac-graphql accepts requests on |
| VC_GRAPHQL_SERVICE_SCHEME      | http          | vc-graphql connection scheme (http or https) |
| VC_GRAPHQL_SERVICE_HOST        | null          | vc-grqaphql address     |
| VC_GRAPHQL_SERVICE_PORT        | null          | vc-grqaphql port        |
| VC_GRAPHQL_SERVICE_PATH        | /      | Path vc-graphql accepts requests on |
| DID_MANAGER_SERVICE_SCHEME     | http          | did-manager connection scheme (http or https) |
| DID_MANAGER_SERVICE_HOST       | null          | did-manager address     |
| DID_MANAGER_SERVICE_PORT       | null          | did-manager port        |
| DID_MANAGER_SERVICE_PATH       | /      | Path did-manager accepts requests on |
| CONTACT_CENTRE_SERVICE_SCHEME  | http          | contact-centre connection scheme (http or https) |
| CONTACT_CENTRE_SERVICE_HOST    | null          | contact-ventre address  |
| CONTACT_CENTRE_SERVICE_PORT    | null          | contact-centre port     |
| CONTACT_CENTRE_SERVICE_PATH    | /      | Path contact-centre accepts requests on |
| CLOUD_TELEPHONY_SERVICE_SCHEME | http          | cloud-telephony connection scheme (http or https) |
| CLOUD_TELEPHONY_SERVICE_HOST   | null          | cloud-telephony address |
| CLOUD_TELEPHONY_SERVICE_PORT   | null          | cloud-telephony port    |
| CLOUD_TELEPHONY_SERVICE_PATH   | /      | Path cloud-telephony accepts requests on |
| AUTH_SERVER_SERVICE_SCHEME     | http          | auth-server connection scheme (http or https) |
| AUTH_SERVER_SERVICE_HOST       | null          | auth-server address     |
| AUTH_SERVER_SERVICE_PORT       | null          | auth-server port        |
| AUTH_SERVER_SERVICE_PATH       | /             | Path auth-server accepts requests on |
| MESSAGE_CENTRE_API_SERVICE_SCHEME  | http          | message-centre-api connection scheme (http or https) |
| MESSAGE_CENTRE_API_SERVICE_HOST    | null          | message-centre-api address     |
| MESSAGE_CENTRE_API_SERVICE_PORT    | null          | message-centre-api port        |
| MESSAGE_CENTRE_API_SERVICE_PATH    | /      | Path message-centre-api accepts requests on |
| BILLING_API_SERVICE_SCHEME  | http          | billing-api connection scheme (http or https) |
| BILLING_API_SERVICE_HOST    | null          | billing-api address     |
| BILLING_API_SERVICE_PORT    | null          | billing-api port        |
| BILLING_API_SERVICE_PATH    | /      | Path billing-api accepts requests on |
| CRM_GRAPHQL_SERVICE_SCHEME  | http          | crm-graphql connection scheme (http or https) |
| CRM_GRAPHQL_SERVICE_HOST    | null          | crm-graphql address     |
| CRM_GRAPHQL_SERVICE_PORT    | null          | crm-graphql port        |
| CRM_GRAPHQL_SERVICE_PATH    | /      | Path crm-graphql accepts requests on |
| ADMIN_GRAPHQL_SERVICE_SCHEME  | http          | admin-graphql connection scheme (http or https) |
| ADMIN_GRAPHQL_SERVICE_HOST    | null          | admin-graphql address     |
| ADMIN_GRAPHQL_SERVICE_PORT    | null          | admin-graphql port        |
| ADMIN_GRAPHQL_SERVICE_PATH    | /      | Path admin-graphql accepts requests on |

## API Documentation
You can get API docs on {API_HOST_ADDRESS}/graphiql
