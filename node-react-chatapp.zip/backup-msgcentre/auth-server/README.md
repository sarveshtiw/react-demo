Authentication Application
==========================

## Introduction
This is a simple auth application required to make a secure cross service communication. This is an backend API developed in Express.

## How to run
This application requires node to be installed on your system. Please check [upstream documentation](https://nodejs.org/en/download/)
for how to install node on your system.

### Development build
In application root path run following commands
```bash
cd app
npm install
npm start
```
### Production build
Run following commands
```bash
cd app 
npm install --only=production
npm start
```

## Dependencies
This application required following connections to run:
- Redis
- MySQL

## Environment variables
Environment variables is the main mechanism of manipulating application settings. Currently application recognizes
following environment variables:

| Variable           | Default value | Description             |
| ------------------ | ------------- | ----------------------- |
| NODE_ENV           | null          | Sets current environment. Allows application to manipulate some settings automatically |
| HOST               | 0.0.0.0       | Address to listen on    |
| PORT               | 3000          | Port to listen on       |
| MYSQL_SERVICE_HOST | localhost     | Database engine address |
| MYSQL_SERVICE_PORT | 3306          | Database engine port    |
| APP_DB_NAME        | null          | Database name           |
| APP_DB_USER        | null          | Database user           |
| APP_DB_PASS        | null          | Database password       |
| REDIS_SERVICE_HOST | localhost     | Redis address           |
| REDIS_SERVICE_PORT | 6379          | Redis port              |
| REDIS_SERVICE_DB   | 0             | Redis database index    |
| REDIS_SERVICE_PASS | unset         | Redis password          |

## File System Access
Application does not require any kind of persistent or temporary volumes

## Testing with docker
To test application in docker you need first docker to be installed. Check [upstream documentation](https://docs.docker.com/install)
for how to install docker on your system.
To bring up all services run in repository root path
```bash
docker-compose -f docker/docker-compose.yml pull --ignore-pull-failures
docker-compose -f docker/docker-compose.yml up
```

## API Documentation
You can get API docs using /docs path
