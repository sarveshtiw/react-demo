const jwt = require('jsonwebtoken');
const asyncLoop = require('node-async-loop');
const config = require('./../config');

let generateToken = (req, res) => {

   let participantList = req.body.participants;
   let result = [];
   asyncLoop(participantList, (item, callback) =>{
       if(item)
       {
         result.push({id:item.id, token:createToken(item)}) 
       }
       callback()
   }, error =>{
        if(error)
        {
            res.status(200).json({error:JSON.stringify(error)});
        }else{
            res.status(200).json({error:null, result:result});
        }
   })
  /* for(let i=0; i<participantList.length; i++){
       let participant = participantList[i];
       const token = createToken(participant);
       result.push({id:participant.id, token})
   }*/
}

let createToken = (payload) => jwt.sign({
    data: payload
}, config.auth.secret, { expiresIn: config.auth.participantExpireIn });

module.exports = generateToken;