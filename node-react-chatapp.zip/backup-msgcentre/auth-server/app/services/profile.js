const jwtDecode = require('jwt-decode');
const models = require('./../models');
const validation = require('../validation/profileValidation');
module.exports = async(req, res) => {
    const payload = jwtDecode(req.token).data;
    const profile = await models.User.find({
            where: { uuid: payload.uuid },
            attributes: ['uid', 'uuid', 'id_amp_user_profile', 'email', 'last_access'],
            include: [{
                model: models.Profile,
                attributes: ['id', 'title', 'fname', 'mname', 'lname', 'gender', 'phone', 'faxno', 'address_line1', 'address_line2', 'address_line3'],
                include: [{
                        model: models.Role,
                        attributes: ['name', 'type']
                    },
                    {
                        model: models.Designation,
                        attributes: ['designation_name']
                    },
                    {
                        model: models.Country,
                        attributes: ['country_name']
                    },
                    {
                        model: models.Company,
                        attributes: ['id', 'id_company_parent', 'uuid_amp_user_login', 'company_name', 'id_amp_user_profile'],
                        include: [{
                            model: models.ServiceCompany,
                            attributes: ['id_amp_service', 'service_name'],
                            include: {
                                model: models.Service,
                                attributes: ['service_code']
                            }
                        }]
                    }
                ]
            }]
        }

    );
    res.send(profile);
}

module.exports.editUserProfile = async(req, res) => {
    const payload = jwtDecode(req.token).data;
    let ErrorArr = [];
    try {
        // Validate prepared array
        ErrorArr = validation.validateEditProfile(req.body);
        if (ErrorArr.error != null) {
            throw new Error(ErrorArr.error.details[0].message);
        }
        // Process the API
        const userProfileObj = await models.Profile.findOne({ where: { id: payload.id } });
        if (!userProfileObj) { // user does not exist by id
            throw new Error('User does Not Exist');
        }
        await models.Profile.update(req.body, { where: { id: payload.id } });
        res.send({ message: 'Success' });
    } catch (err) {
        res.send({errors:err.message});
    }

}
