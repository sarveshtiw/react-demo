let model = require('./../models');
const isEmail = require('validator/lib/isEmail');
const config = require('./../config');
const { validateAdminSignUp } = require('./../validation/adminSignup');

let adminSignup = (req, res) => {
    const valid = validateAdminSignUp(req.body);
    if(valid.error){
        res.send({Error:valid.error.details[0].message});
    }
    else if(req.body.adminKey === process.env.ADMIN_KEY){
        model.User.find({include:[{
                model: model.Profile,
                required: false,

            }]}).then((results)=>{
            res.send(results);
        });
    }
}
module.exports = adminSignup;