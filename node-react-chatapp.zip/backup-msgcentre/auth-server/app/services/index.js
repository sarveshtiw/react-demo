let login = require('./login');
let logout = require('./logout');
let tokenValidation = require('./validation');
let userInfo = require('./permissions');
let save = require('./save');
let adminSignup = require('./adminSignup');
let healthCheck = require('./healthCheck');
let generateToken = require('./generateToken');
let {PortalPermissions, ServicePermissions} = require('./permissions');
let profile = require('./profile');

module.exports = {
    login,
    logout,
    tokenValidation,
   // userInfo,
    save,
    adminSignup,
    healthCheck,
    generateToken,
    PortalPermissions,
    ServicePermissions,
    profile
}