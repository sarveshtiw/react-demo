let model = require('./../models');
const isEmail = require('validator/lib/isEmail');
const hash = require('sha256');
const jwt = require('jsonwebtoken');
const config = require('./../config');
const redis = require('./../utils/redis');

let login = (req, res) => {
    let validInput = validateUserInput(req.body);
    console.log(validInput);
    if (validInput.status) {
        let criteria = {};
        if (isEmail(req.body.authKey)) {
            criteria.email = req.body.authKey;
        }
        else {
            criteria.username = req.body.authKey;
        }
        console.log(criteria);
        model.User.find({ where: criteria, include:[{model:model.Profile, attributes:['id_amp_role_master', 'id_amp_company'], include:[{
                    model: model.Role,
                    attributes: ['name', 'type']
                }]}] }).then((user) => {
            if (!user) {
                console.log('no user');
                res.status(200).json({ message: 'User does not exists' });
            } else {
                const validPassword = comparePassword(req.body.password, user.password);
                if (validPassword) {
                    if (user.dataValues.is_active === true) {
                        console.log(user.dataValues.Profile.dataValues.id_amp_company);
                        const token = generateToken(user)
                        //     saveToRedis(token, result);
                        res.status(200).json({ token: token, uuid: user.uuid });
                    }
                    else {
                        res.status(200).json({ message: 'Inactive User' });
                    }
                }
                else {
                    res.status(200).json({ message: 'Incorrect email/username or password' });
                }
            }
        });
    }
    else {
        res.status(200).json({ message: validInput.message });
    }
}
let validateUserInput = (userInput) => {
    let result = { status: false, message:''}
    if (userInput.authKey && userInput.password) {
        result.status = true;
        return result;
    }
    result.message = 'No Email/Username or password provided!';
    return result;
}
let comparePassword = (currentPassword, candidatePassword) => {
    const currentPasswordEncrypted = hash('21' + currentPassword + 'eoka3b');
    if (currentPasswordEncrypted === candidatePassword) {
        return true;
    }
    else {
        return false;
    }
}
let generateToken = (user) => jwt.sign({
    data: { id: user.uid, email: user.email, uuid: user.uuid, rid: user.dataValues.Profile.dataValues.id_amp_role_master, cid: user.dataValues.Profile.dataValues.id_amp_company,  }
}, config.auth.secret, { expiresIn: config.auth.expiresIn });

module.exports = login;