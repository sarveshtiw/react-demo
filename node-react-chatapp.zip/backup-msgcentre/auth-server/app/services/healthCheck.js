const {database, redisConf} = require('./../config');
const sequelize = require('./../models').sequelize;
const redisClient = require('./../utils/redis');

const readiness = async (req, res) => {
    const result = {Status: 'Red', Services: {}};
    result.Services = await Promise.all([checkMysqlConnection(), checkRedisConnection()]);
    for (let i = 0; i < result.Services.length; i++) {
        const health = Object.values(result.Services[i]);
        if (health[0].Status === 'OK') {
            result.Status = 'Green'
        }
        else {
            result.Status = 'Red'
        }
    }
    if (result.Status === 'Green') {
        res.status(200).json(result);
    }
    res.status(500).json(result);
}
const liveness = (req, res) => {
    res.status(200).json({Status: 'Running'});
}

const checkRedisConnection = async () => {
    const result = {Redis: {Status: 'Failed'}};
    try {
        if (redisConf.host && redisConf.port) {
            if (redisClient.ping()) {
                result.Redis.Status = 'OK'
                return result;
            }
            result.Redis.Message = 'Unable to connect with Redis Server';
            return result;
        }
        result.Redis.Message = 'Invalid Redis config found';
        return result;
    }
    catch (err) {
        result.Redis.Message = 'Error while connecting to Redis server';
        return result;
    }
}
const checkMysqlConnection = async () => {
    const result = {Mysql: {Status: 'Failed'}};
    try {
        if (database.name && database.username && database.password && database.options.host) {
            const response = await sequelize.authenticate();
            result.Mysql.Status = 'OK'
            return result;
        }
        result.Mysql.Message = 'Invalid Mysql config found';
        return result;
    }
    catch (err) {
        result.Mysql.Message = 'Error while connecting to Mysql server';
        return result;
    }

}
module.exports = {
    readiness,
    liveness
};