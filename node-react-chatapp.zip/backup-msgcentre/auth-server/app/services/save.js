//const redis = require('./../utils/redis');

let save = (req, res) => {
    let validInput = validateUserInput(req.body);
    res.status(500).json({ message: 'Error occurred while saving data' });
    // if (validInput.status) {
    //     redis.client.hgetall(req.body.token, (err, user) => {
    //         if (!err) {
    //             if (user) {
    //                 redis.client.hmset(req.body.token, req.body.key, req.body.value, function (err, result) {
    //                     if (!err) {
    //                         res.status(200).json({ message: result });
    //                     } else {
    //                         res.status(500).json({ message: 'Error occurred while saving data' });
    //                     }
    //                 })
    //             }
    //             else {
    //                 res.status(404).json({ message: 'Invalid token' });
    //             }
    //         }
    //         else {
    //             res.status(500).json({ message: 'Error occurred while fetching data' });
    //         }
    //     })
    // }
    // else {
    //     res.status(400).json({ message: validInput.message });
    // }
}
let validateUserInput = (userInput) => {
    let result = {}
    if (userInput.token) {
        if (userInput.key && userInput.value) {
            result.status = true;
            result.message = '';
        }
        else {
            result.status = false;
            result.message = ' key and value required';
        }
        return result;
    }
    else {
        result.status = false;
        result.message = 'Token required!';
        return result;
    }
}
module.exports = save;