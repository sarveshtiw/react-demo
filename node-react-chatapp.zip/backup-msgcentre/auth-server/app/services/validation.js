let configurations = require('./../config');
const jwt = require('jsonwebtoken');
const config = require('./../config');
const {tokenValidator} = require('./../utils/auth')


let validator = (req, res) => {
    const validateVal = tokenValidator(req.token);
    if(validateVal.status){
        res.json(validateVal);
    }
    else {
        res.json({status:false , message:'Invalid token'});
    }
    //res.json(validateVal);
    // if (validateVal.status) {
    //     res.status(200).json(validateVal);
    // } else {
    //     res.status(200).json(validateVal);
    // }
}

module.exports = validator;
