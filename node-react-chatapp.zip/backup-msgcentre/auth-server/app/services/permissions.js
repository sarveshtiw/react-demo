const authorization = require('./../utils/authorization');

exports.PortalPermissions = async(req, res) => {
    const permissions = await authorization.PortalPermission(req.token);
    console.log()
    res.send(permissions);
}
exports.ServicePermissions = async(req, res) => {
    if(req.body.serviceId){
        const permissions = await authorization.ServicePermission(req.token, req.body.serviceId);
        res.send(permissions);
    }
    else {
        res.send({Error:'Service id is not available'});
    }
}
