const Joi = require('joi');

let schemaEditProfile = Joi.object().keys({
    title: Joi.string(),
    fname: Joi.string(),
    mname: Joi.string(),
    lname: Joi.string(),
    gender: Joi.string().valid('male', 'female'),
    email: Joi.string().email(),
    phone: Joi.string(),
    faxno: Joi.string(),
    address_line1: Joi.string(),
    address_line2: Joi.string(),
    address_line3: Joi.string(),
    id_amp_country: Joi.number(),
    state: Joi.string(),
    city: Joi.string(),
    pincode: Joi.string()
});

// function for validate scheme validateEditProfile
const validateEditProfile = (EditProfileInput) => {
    return Joi.validate(EditProfileInput, schemaEditProfile, { abortEarly: true });
}

module.exports = {
    validateEditProfile
}
