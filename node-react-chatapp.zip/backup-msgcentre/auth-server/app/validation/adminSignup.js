const Joi = require('joi');

let schemaAdminSignUp = {
    adminKey: Joi.string().required(),
    email: Joi.string().required(),
    userName: Joi.string().required(),
    password: Joi.string().required(),
    confirmPassword: Joi.string().required(),
    title: Joi.string().allow('').optional(),
    fname: Joi.string().allow('').optional(),
    mname: Joi.string().allow('').optional(),
    lname: Joi.string().allow('').optional(),
    gender: Joi.string().allow('').optional(),
    phone: Joi.number().allow('').optional(),
    faxNo: Joi.string().allow('').optional(),
    address_line1: Joi.string().allow('').optional(),
    address_line2: Joi.string().allow('').optional(),
    address_line3: Joi.string().allow('').optional(),
    state: Joi.string().allow('').optional(),
    city: Joi.string().allow('').optional(),
    pincode: Joi.string().allow('').optional(),

};

// function for validate scheme validateGetContact
const validateAdminSignUp = (adminSignUpInput) => {
    return Joi.validate(adminSignUpInput, schemaAdminSignUp, {presence: 'required'});
}





module.exports = {
    validateAdminSignUp
}
