var controllers = require('./controllers');

const routes = require('express').Router();

// routes.get('/validate', (req, res) => {
//     controllers.ValidateController(req, res);
// });
// routes.post('/logout', (req, res) => {
//   controllers.logoutController(req, res);
// });
// routes.post('/info', (req, res) => {
//   controllers.userInfoController(req, res);
// });
// routes.post('/save', (req, res) => {
//   controllers.saveController(req, res);
// })
routes.post('/admin-signup', (req, res) => {
    controllers.AdminSignupController(req, res);
});
routes.post('/participant-token', (req, res) => {
    controllers.GenerateToken(req, res);
});
routes.get('/portal-permission', (req, res) => {
    controllers.PortalPermission(req, res);
});
routes.post('/service-permission', (req, res) => {
    controllers.ServiPermission(req, res);
});
routes.get('/profile', (req, res) => {
    controllers.ProfileController(req, res);
});
routes.post('/editUserProfile', (req, res) => {
    controllers.editUserProfile(req, res);
});

module.exports = routes;
