const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const {auth} = require('./../config');
const redisClient = require('./redis');

exports.comparePassword = (currentPassword, hashedPassword) => {
    bcrypt.compare(currentPassword, hashedPassword).then((result) => {
        return result;
    })
};

exports.generateToken = (user) => {
    return jwt.sign({
        data: {id: user.uuid, email: user.email, profile_id: user.id_amp_user_profile}
    }, auth.secret, {expiresIn: auth.expiresIn});
};

exports.tokenValidationMiddleware = (req, res, next) => {
    if(req.token){
       const valid = tokenValidator(req.token);
       if(valid.status){
           next();
       }
       else {
           res.send({Error:'Invalid token'});
       }
    }
    else {
        res.send({Error:'Token does not exist in request'});
    }
}
const tokenValidator = (token)=>{
        let result = { status: false, message: '' };
        try {
            const decoded = jwt.verify(token, auth.secret);
            if(decoded){
                result.status = true;
                result.message = 'Success';
                return result;
            }
            result.message = 'Token is not valid';
            return result;
        } catch (err) {
            result.message = 'Token is not valid';
            return result;
            console.log(err.message);
        }
}
exports.tokenValidator = tokenValidator;