const jwtDecode = require('jwt-decode');
let redis = require('./../utils/redis');
const models = require('./../models');

// module.exports = async (token) => {
//     try {
//
//         const payload = jwtDecode(token).data;
//         if (payload.uuid) {
//             // const user = await models.User.find({
//             //     where: {uuid: payload.uuid},
//             //     attributes: ['id','uuid', 'id_amp_user_profile','email'],
//             //     include: [{
//             //         model: models.Profile,
//             //         attributes: ['id','id_amp_company', 'id_amp_role_master','title','fname','mname','lname','gender','id_amp_designation_master'],
//             //         include: {
//             //             model: models.Company,
//             //             attributes: ['id','id_company_parent', 'uuid_amp_user_login','id_amp_user_profile'],
//             //             include: [{
//             //                 model:models.ServiceCompany,
//             //                 attributes: ['id_amp_service','service_name']
//             //             }
//             //             ]
//             //         }
//             //     },
//             //         {
//             //              model: models.PortalPermission,
//             //              attributes: ['id', 'id_amp_company','uuid_amp_user_login','id_amp_user_profile','id_amp_admin_permission_master','id_amp_admin_permission_params','permission_type'],
//             //              include: [{
//             //                  model:models.AdminPermission,
//             //                  attributes: ['id', 'name'],
//             //                  where:{is_active:true},
//             //                  include: [{
//             //                      model:models.AdminPermissionParam,
//             //                      attributes: ['id', 'parameter_name'],
//             //                  }]
//             //              }
//             //             ]
//             //         }
//             //     ]
//             // });
//             // const userPermission = await models.UserPermission.findAll({
//             //     where:{uuid_amp_user_login: payload.uuid},
//             //     attributes: ['id','uuid_amp_user_login','id_amp_service_master','scv_module','scv_submodule'],
//             //     include:[
//             //         {
//             //             model:models.ServicePermission,
//             //             attributes: ['id','id_amp_service_master','scv_module','scv_module_description'],
//             //             where:{is_active:true}
//             //         },
//             //         {
//             //             model:models.ServicePermissionParam,
//             //             attributes: ['id','id_amp_service_permission_master','scv_submodule','scv_submodule_description'],
//             //             where:{is_active:true}
//             //         }
//             //     ]
//             // });
//             const userPermission = await models.UserPermission.findAll({
//                 where: {uuid_amp_user_login: payload.uuid}
//             })
//             console.log(userPermission);
//             return {userPermission}
//         }
//
//     }
//     catch (err) {
//
//     }
// }

exports.PortalPermission = async (token) => {
    try {
        const payload = jwtDecode(token).data;
        if (payload.uuid) {
            const portalPermission = await models.PortalPermission.findAll({
                where: {uuid_amp_user_login: payload.uuid},
                attributes: ['portal_permission_key','permission_type']
            });
            return portalPermission
        }
    }
    catch (error) {
        console.log(error);
    }
};
exports.ServicePermission = async (token, serviceid) => {
    try {
        const payload = jwtDecode(token).data;
        if (payload.uuid) {
            const servicePermission = await models.UserPermission.findAll({
                where: {uuid_amp_user_login: payload.uuid, id_amp_service_master:serviceid},
                attributes: ['scv_module_key']
            });
            return servicePermission
        }
    }
    catch (error) {
        console.log(error)
    }
}