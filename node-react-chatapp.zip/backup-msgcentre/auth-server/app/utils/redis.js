const redis = require('redis');
const bluebird = require('bluebird');
bluebird.promisifyAll(redis.RedisClient.prototype);
bluebird.promisifyAll(redis.Multi.prototype);
const {redisConf} = require('./../config');
let options = {
    no_ready_check:true
}
if(redisConf.password){
    options['password']=redisConf.password
}
let client = redis.createClient(redisConf.port, redisConf.host, options);


client.on('connect', function () {
    console.log(`Connecting to Redis server....
.......................`);
});
client.on("error", function (err) {
    console.log("Error while connecting to Redis server", err);
});
client.on("ready", function () {
    console.log("Connected to Redis server ");
});

// exports.saveUserInfo = (token, user) => {
//     if(user.id_ua_role==5){
//         client.hmset(token, 'uid', user.uid, 'email', user.email, 'password', user.password, 'salt', user.salt, 'name', user.name, 'activationcode', user.activationcode, 'isActive', user.isActive, 'createdate', user.createdate, 'updatedate', user.updatedate, 'activationdate', user.activationdate, 'id_ua_role', user.id_ua_role, 'permission', user.permission, 'last_access', user.last_access);
//     }
//     else {
//         client.hmset(token, 'uid', user.uid, 'email', user.email, 'password', user.password, 'salt', user.salt, 'name', user.name, 'activationcode', user.activationcode, 'isActive', user.isActive, 'createdate', user.createdate, 'updatedate', user.updatedate, 'activationdate', user.activationdate, 'id_ua_role', user.id_ua_role, 'permission', user.permission, 'last_access', user.last_access, 'id_am_crm', user.id_am_crm);
//     }}

module.exports = client;