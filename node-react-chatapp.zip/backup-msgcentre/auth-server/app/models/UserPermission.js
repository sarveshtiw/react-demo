module.exports = function (sequelize, DataTypes) {
    var UserPermission = sequelize.define("UserPermission", {
            id: { type: DataTypes.STRING, primaryKey: true},
            uuid_amp_user_login: { type: DataTypes.STRING},
            id_amp_user_profile: { type: DataTypes.INTEGER},
            id_amp_service_master: { type: DataTypes.INTEGER},
            scv_module: { type: DataTypes.INTEGER },
            scv_submodule: { type: DataTypes.INTEGER },
            scv_module_key: { type: DataTypes.STRING },
            created_by: {type: DataTypes.INTEGER},
            allocated_date: {type: DataTypes.INTEGER},
            update_date: {type: DataTypes.INTEGER},
            is_active: { type: DataTypes.TINYINT, defaultValue: 1 },
            is_deleted: { type: DataTypes.TINYINT },
        },
        {
            tableName: 'user_permissions'
        });
    UserPermission.associate = models => {
        models.UserPermission.belongsTo(models.Service, {foreignKey: 'id_amp_service_master', constraints: true});
        models.UserPermission.belongsTo(models.ServicePermission, {foreignKey: 'scv_module', sourceKey:'scv_module', constraints: true});
        models.UserPermission.belongsTo(models.ServicePermissionParam, {foreignKey: 'scv_submodule', sourceKey:'scv_submodule',constraints: true});
    }
    return UserPermission;
}
