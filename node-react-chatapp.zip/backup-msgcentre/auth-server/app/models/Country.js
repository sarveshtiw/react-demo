module.exports = function (sequelize, DataTypes) {
    var Country = sequelize.define("Country", {
            id: {type: DataTypes.INTEGER, primaryKey: true},
            cc_fips: {type: DataTypes.STRING},
            cc_iso: {type: DataTypes.STRING},
            cc3_iso: {type: DataTypes.STRING},
            tld: {type: DataTypes.STRING},
            country_name: {type: DataTypes.STRING},
            prefix: {type: DataTypes.STRING}
        },
        {
            tableName: 'country_master'
        });
    return Country;
}