module.exports = function (sequelize, DataTypes) {
    var AdminPermissionParam = sequelize.define("AdminPermissionParam", {
            id: { type: DataTypes.INTEGER, primaryKey: true},
            id_amp_admin_permission_master: { type: DataTypes.INTEGER, required: true, allowNull: false },
            parameter_name: { type: DataTypes.STRING },
            controller_name: { type: DataTypes.STRING },
            action_name: { type: DataTypes.STRING },
            created_date: { type: DataTypes.DATE },
            is_active: { type: DataTypes.BOOLEAN, defaultValue:true },
        },
        {
            tableName: 'admin_permission_params'
        });

    return AdminPermissionParam;
};
