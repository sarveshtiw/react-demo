module.exports = function (sequelize, DataTypes) {
    var Designation = sequelize.define("Designation", {
            id: { type: DataTypes.INTEGER, primaryKey: true},
            designation_name: { type: DataTypes.STRING, required: true, allowNull: false },
            created_by: { type: DataTypes.INTEGER,  },
            status: { type: DataTypes.BOOLEAN, defaultValue:false },
        },
        {
            tableName: 'designation_master'
        });
    return Designation;
};
