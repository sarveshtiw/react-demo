module.exports = function (sequelize, DataTypes) {
    var Role = sequelize.define("Role", {
            id: { type: DataTypes.INTEGER, primaryKey: true},
            name: { type: DataTypes.STRING },
            type: { type: DataTypes.STRING }
        },
        {
            tableName: 'role_master'
        });
    return Role;
};
