module.exports = function (sequelize, DataTypes) {
    var ServicePermissionParam = sequelize.define("ServicePermissionParam", {
            id: { type: DataTypes.INTEGER, primaryKey: true},
            id_amp_service_permission_master: { type: DataTypes.INTEGER, required: true, allowNull: false },
            scv_submodule: { type: DataTypes.STRING },
            scv_submodule_description: { type: DataTypes.STRING },
            created_date: { type: DataTypes.DATE },
            update_date: { type: DataTypes.DATE },
            input_type: { type: DataTypes.TINYINT, defaultValue:0 },
            is_active:{type: DataTypes.TINYINT, defaultValue:0}
        },
        {
            tableName: 'service_permission_params'
        });
    ServicePermissionParam.associate = models => {
        models.ServicePermissionParam.belongsTo(models.ServicePermission, {foreignKey: 'id_amp_service_permission_master', constraints: true});
    };
    return ServicePermissionParam;
};
