module.exports = function (sequelize, DataTypes) {
    var ServiceCompanyParam = sequelize.define("ServiceCompanyParam", {
            id: {type: DataTypes.INTEGER, primaryKey: true},
            id_amp_user_profile: {type: DataTypes.INTEGER, required: true, allowNull: false},
            id_amp_company: {type: DataTypes.INTEGER, required: true, allowNull: false},
            id_amp_service_master: {type: DataTypes.INTEGER, required: true, allowNull: false},
            payment_type: {type: DataTypes.ENUM('postpaid','prepaid'), defaultValue:'prepaid'},
            account_type: {type: DataTypes.TINYINT, defaultValue:0},
            no_of_users: {type: DataTypes.INTEGER},
            credit: {type: DataTypes.STRING},
            credit_limit: {type: DataTypes.STRING},
            threshold_credit_limit: {type: DataTypes.STRING},
            global_access_no: {type: DataTypes.STRING},
            didtype: {type: DataTypes.STRING},
            did_global_access: {type: DataTypes.TINYINT},
            inbound_call_charge: {type: DataTypes.STRING},
            no_of_channel: {type: DataTypes.STRING},
            bridge_charge: {type: DataTypes.STRING},
            time_zone: {type: DataTypes.STRING},
            status: {type: DataTypes.TINYINT},
            max_no_of_conference: {type: DataTypes.STRING},
            max_no_of_devices: {type: DataTypes.STRING},
            max_no_of_operators: {type: DataTypes.STRING},
            price_per_devices: {type: DataTypes.STRING},
            price_per_users: {type: DataTypes.STRING},
            softphone_activation: {type: DataTypes.STRING},
            did_dedicated_access: {type: DataTypes.TINYINT},
            user_creation: {type: DataTypes.TINYINT},
            no_of_user_account: {type: DataTypes.STRING},
            participant_limit_per_conference: {type: DataTypes.STRING},
            pin_length: {type: DataTypes.STRING},
            recording: {type: DataTypes.STRING},
            recording_download: {type: DataTypes.STRING},
            dialout: {type: DataTypes.TINYINT},
            allow_pop_override: {type: DataTypes.TINYINT},
            preferred_pop: {type: DataTypes.STRING},
            sms_service: {type: DataTypes.TINYINT},
            resend_activation_email: {type: DataTypes.STRING},
            blocker_status: {type: DataTypes.ENUM('block','unblock')},
            alternate_post_email: {type: DataTypes.STRING},
            alternate_invoice_email: {type: DataTypes.STRING},
            dialout_info: {type: DataTypes.STRING},
            created_date: {type: DataTypes.DATE},
            updated_date: {type: DataTypes.DATE},
            created_by: {type: DataTypes.INTEGER},
        },
        {
            tableName: 'service_to_company_params'
        });
    ServiceCompanyParam.associate = models => {
        models.ServiceCompanyParam.belongsTo(models.Profile, {foreignKey: 'id_amp_user_profile', constraints: true});
        models.ServiceCompanyParam.belongsTo(models.Company, {foreignKey: 'id_amp_company', constraints: true});
        models.ServiceCompanyParam.belongsTo(models.Service, {foreignKey: 'id_amp_service_master', constraints: true});
    };
    return ServiceCompanyParam;
};
