module.exports = function (sequelize, DataTypes) {
    var PortalPermission = sequelize.define("PortalPermission", {
            id: {type: DataTypes.INTEGER, primaryKey: true},
            id_amp_company: {type: DataTypes.INTEGER, required: true, allowNull: false},
            uuid_amp_user_login: {type: DataTypes.STRING, required: true, allowNull: false},
            id_amp_user_profile: {type: DataTypes.INTEGER, required: true, allowNull: false},
            id_amp_admin_permission_master: {type: DataTypes.INTEGER, required: true, allowNull: false},
            id_amp_admin_permission_params: {type: DataTypes.INTEGER, required: true, allowNull: false},
            permission_type: {type: DataTypes.STRING},
            created_by: {type: DataTypes.INTEGER, required: true, allowNull: false},
            created_date: {type: DataTypes.DATE, required: true, allowNull: false},
            updated_date: {type: DataTypes.DATE}
        },
        {
            tableName: 'portal_permission'
        });
    PortalPermission.associate = models => {
        models.PortalPermission.belongsTo(models.Company, {foreignKey: 'id_amp_company', constraints: true});
        models.PortalPermission.belongsTo(models.User, {foreignKey: 'uuid_amp_user_login', constraints: true});
        models.PortalPermission.belongsTo(models.Profile, {foreignKey: 'id_amp_user_profile', constraints: true});
        models.PortalPermission.belongsTo(models.AdminPermission, {foreignKey: 'id_amp_admin_permission_master', constraints: true});
        models.PortalPermission.belongsTo(models.AdminPermissionParam, {foreignKey: 'id_amp_admin_permission_params', constraints: true});
    };
    return PortalPermission;
};
