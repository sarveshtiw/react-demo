module.exports = function (sequelize, DataTypes) {
    var ServiceCompany = sequelize.define("ServiceCompany", {
            id: {type: DataTypes.INTEGER, primaryKey: true},
            id_amp_service: {type: DataTypes.INTEGER, required: true, allowNull: false},
            id_amp_company: {type: DataTypes.INTEGER, required: true, allowNull: false},
            service_name: {type: DataTypes.STRING},
            service_type: {type: DataTypes.STRING},
            created_date: {type: DataTypes.DATE},
            updated_date: {type: DataTypes.DATE},
            deactive_date: {type: DataTypes.DATE},
            active_date: {type: DataTypes.DATE},
            created_by: {type: DataTypes.INTEGER}
        },
        {
            tableName: 'service_to_company'
        });
    ServiceCompany.associate = models => {
        models.ServiceCompany.belongsTo(models.Service, {foreignKey: 'id_amp_service', constraints: true});
        models.ServiceCompany.belongsTo(models.Company, {foreignKey: 'id_amp_company', constraints: true});
    };
    return ServiceCompany;
};
