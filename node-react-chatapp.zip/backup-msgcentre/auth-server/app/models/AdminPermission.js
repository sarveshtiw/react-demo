module.exports = function (sequelize, DataTypes) {
    var AdminPermission = sequelize.define("AdminPermission", {
            id: { type: DataTypes.INTEGER, primaryKey: true},
            name: { type: DataTypes.INTEGER, required: true, allowNull: false },
            is_active: { type: DataTypes.BOOLEAN, defaultValue:true },
        },
        {
            tableName: 'admin_permission_master'
        });
        AdminPermission.associate = models =>{
            models.AdminPermission.hasMany(models.AdminPermissionParam, {foreignKey: 'id', targetKey: 'id_amp_admin_permission_master', constraints: true});
            models.AdminPermission.hasMany(models.PortalPermission, {foreignKey: 'id', targetKey: 'id_amp_admin_permission_master', constraints: true});
        }
    return AdminPermission;
};
