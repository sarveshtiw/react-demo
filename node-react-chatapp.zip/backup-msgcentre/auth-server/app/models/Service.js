module.exports = function (sequelize, DataTypes) {
    var Service = sequelize.define("Service", {
            id: { type: DataTypes.INTEGER, primaryKey: true},
            name: { type: DataTypes.STRING, required: true, allowNull: false },
            service_code: { type: DataTypes.STRING, required: true, allowNull: false },
            is_active: { type: DataTypes.BOOLEAN, defaultValue:false },
        },
        {
            tableName: 'service_master'
        });
    return Service;
};
