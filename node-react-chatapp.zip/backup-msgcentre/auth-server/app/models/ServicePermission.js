module.exports = function (sequelize, DataTypes) {
    var ServicePermission = sequelize.define("ServicePermission", {
            id: { type: DataTypes.INTEGER, primaryKey: true},
            id_amp_service_master: { type: DataTypes.INTEGER, required: true, allowNull: false },
            scv_module: { type: DataTypes.STRING },
            scv_module_description: { type: DataTypes.STRING },
            created_date: { type: DataTypes.DATE },
            update_date: { type: DataTypes.DATE },
            is_active: { type: DataTypes.BOOLEAN, defaultValue:false },
            created_by:{type: DataTypes.INTEGER}
        },
        {
            tableName: 'service_permission_master'
        });
    ServicePermission.associate = models => {
        models.ServicePermission.belongsTo(models.Service, {foreignKey: 'id_amp_service_master', constraints: true});
    };
    return ServicePermission;
};
