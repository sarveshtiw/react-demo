module.exports = function (sequelize, DataTypes) {
    var User = sequelize.define("User", {
            uid: {type: DataTypes.INTEGER, primaryKey: true},
            uuid: {type: DataTypes.UUIDV4,required: true, unique: true, allowNull: false},
            id_amp_user_profile: {type: DataTypes.INTEGER,required: true, unique: true, allowNull: false},
            email: {type: DataTypes.STRING, required: true, unique: true, allowNull: false},
            user_name: {type: DataTypes.STRING, required: true, unique: true, allowNull: false},
            password: {type: DataTypes.STRING, required: true, allowNull: false},
            is_active: {type: DataTypes.BOOLEAN, defaultValue: false},
            created_date: {type: DataTypes.DATE},
            updated_date: {type: DataTypes.DATE},
            deleted_date: {type: DataTypes.DATE},
            is_deleted: {type: DataTypes.TINYINT, defaultValue:0},
            activation_code: {type: DataTypes.STRING},
            activation_date: {type: DataTypes.DATE},
            last_access: {type: DataTypes.DATE},
            current_access: {type: DataTypes.DATE},
            last_password_change_date_time: {type: DataTypes.DATE},
            force_password_change_date_time: {type: DataTypes.DATE},
            password_key: {type: DataTypes.STRING},
            gid: {type: DataTypes.INTEGER}
        },
        {
            tableName: 'user_login'
        });

    User.associate = models => {
        models.User.belongsTo(models.Profile, {foreignKey: 'id_amp_user_profile', constraints: true});
        models.User.hasMany(models.PortalPermission, {foreignKey: 'uuid_amp_user_login', sourceKey: 'uuid', constraints: true});
    };

    return User;
}
