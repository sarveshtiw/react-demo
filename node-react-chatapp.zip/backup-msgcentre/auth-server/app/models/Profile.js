module.exports = function (sequelize, DataTypes) {
    var Profile = sequelize.define("Profile", {
            id: { type: DataTypes.INTEGER, primaryKey: true},
            id_amp_company: { type: DataTypes.INTEGER},
            id_amp_role_master: { type: DataTypes.INTEGER, required: true, allowNull: false },
            title: { type: DataTypes.STRING },
            fname: { type: DataTypes.STRING },
            mname: { type: DataTypes.STRING },
            lname: { type: DataTypes.STRING },
            gender: { type: DataTypes.ENUM('male', 'female')},
            email: { type: DataTypes.STRING },
            phone: { type: DataTypes.STRING },
            faxno: { type: DataTypes.STRING },
            id_amp_designation_master: { type: DataTypes.INTEGER},
            address_line1: { type: DataTypes.STRING, required: true, allowNull: false },
            address_line2: { type: DataTypes.STRING },
            address_line3: { type: DataTypes.STRING },
            id_amp_country: { type: DataTypes.INTEGER },
            state: { type: DataTypes.STRING },
            city: { type: DataTypes.STRING },
            pincode: { type: DataTypes.STRING },
            created_by: { type: DataTypes.INTEGER },
            status: { type: DataTypes.TINYINT, defaultValue: 0},
            chat_id: { type: DataTypes.INTEGER },
        },
        {
            tableName: 'user_profile'
        });
    Profile.associate = models => {
        models.Profile.belongsTo(models.Company, {foreignKey: 'id_amp_company', constraints: true});
        models.Profile.belongsTo(models.Role, {foreignKey: 'id_amp_role_master', constraints: true});
        models.Profile.belongsTo(models.Designation, {foreignKey: 'id_amp_designation_master', constraints: true});
        models.Profile.belongsTo(models.Country, {foreignKey: 'id_amp_country', constraints: true});
        models.Profile.hasMany(models.PortalPermission, {foreignKey: 'id_amp_user_profile', sourceKey:'id', constraints: true});
    };
    return Profile;
}
