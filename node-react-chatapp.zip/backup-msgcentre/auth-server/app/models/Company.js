module.exports = function (sequelize, DataTypes) {
    var Company = sequelize.define("Company", {
            id: { type: DataTypes.INTEGER, primaryKey: true},
            id_company_parent: { type: DataTypes.INTEGER},
            reseller: { type: DataTypes.BOOLEAN, defaultValue:false},
            company_status:{ type: DataTypes.ENUM('pending','approved','rejected','provisioned'), defaultValue:'pending'},
            uuid_amp_user_login:{ type: DataTypes.STRING},
            id_amp_user_profile: { type: DataTypes.INTEGER},
            account_unique_number: { type: DataTypes.STRING},
            created_from:{ type: DataTypes.STRING},
            company_name:{ type: DataTypes.STRING},
            id_industry_master:{ type: DataTypes.INTEGER},
            company_email:{ type: DataTypes.STRING},
            company_website:{ type: DataTypes.STRING},
            company_registerno:{ type: DataTypes.STRING},
            company_city:{ type: DataTypes.STRING},
            company_state:{ type: DataTypes.STRING},
            company_pincode:{ type: DataTypes.STRING},
            id_amp_country_master:{ type: DataTypes.INTEGER},
            company_address1:{ type: DataTypes.STRING},
            company_address2:{ type: DataTypes.STRING},
            company_address3:{ type: DataTypes.STRING},
            domainname:{ type: DataTypes.STRING},
            company_phone:{ type: DataTypes.STRING},
            company_additional_phone1:{ type: DataTypes.STRING},
            company_additional_phone2:{ type: DataTypes.STRING},
            company_fax:{ type: DataTypes.STRING},
            id_amp_user_title:{ type: DataTypes.STRING},
            primary_contact_fname:{ type: DataTypes.STRING},
            primary_contact_lname:{ type: DataTypes.STRING},
            primary_contact_email:{ type: DataTypes.STRING},
            primary_contact_phone:{ type: DataTypes.STRING},
            primary_contact_fax:{ type: DataTypes.STRING},
            id_amp_designation_master:{ type: DataTypes.INTEGER},
            company_account_type:{ type: DataTypes.INTEGER, defaultValue:1},
            payment_type:{ type: DataTypes.INTEGER, defaultValue:0},
            created_date:{ type: DataTypes.DATE},
            updated_date:{ type: DataTypes.DATE},
            deleted_date:{ type: DataTypes.DATE},

        },
        {
            tableName: 'company'
        });
    Company.associate = models =>{
        models.Company.belongsTo(models.Profile, {foreignKey: 'id_amp_user_profile', constraints: true});
        models.Company.belongsTo(models.User, {foreignKey: 'uuid_amp_user_login', constraints: true});
        models.Company.belongsTo(models.Country, {foreignKey: 'id_amp_country_master', constraints: true});
        models.Company.belongsTo(models.Designation, {foreignKey: 'id_amp_designation_master', constraints: true});
        models.Company.hasMany(models.ServiceCompany, {foreignKey: 'id_amp_company', constraints: true});
    }

    return Company;
}
