if(process.env.NODE_ENV==='local'){
    require('dotenv').config();
};
const app = require('express')();
const bearerToken = require('express-bearer-token');
const cors = require('cors');
const helmet = require('helmet');
const routes = require('./routes');
const {server} = require('./config');
var bodyParser = require('body-parser');
const swaggerUi = require('swagger-ui-express');
const swaggerDocument = require('./swagger.json');
const {LoginController, ReadinessCheckController, LivenessCheckController, ValidateController}=require('./controllers');
const {tokenValidationMiddleware} =require('./utils/auth')

app.use(cors());
app.use(bodyParser.json());

app.use('/docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));


app.use(helmet({
    hidePoweredBy: {
        setTo: 'PHP 4.2.0'
    },
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"]
        }
    },
    noSniff: true,
    xssFilter: true
}));

//Routes without token restriction
app.get('/', (req, res) => {
    res.status(200).json({ message: 'This is a centralized auth system for synthesis Application!' });
});
app.post('/login', LoginController);
app.get('/healthz/liveness', LivenessCheckController);
app.get('/healthz/readiness', ReadinessCheckController);
app.use(bearerToken());
app.get('/validate', ValidateController);
app.use(tokenValidationMiddleware);
//  Restricted routes
app.use('/', routes);

// Turn on that server!
app.listen(server.port, server.host, () => {
  console.log('App listening on port ',server.port);
  console.log(`Now browse to ${server.host}:${server.port}`);
});
