var services = require('./../services');

exports.LoginController = (req, res) => {
    services.login(req, res);
};
exports.LogoutController = (req, res) => {
    services.logout(req, res);
};
// exports.userInfoController = (req, res) => {
//     services.userInfo(req, res);
// };
exports.ValidateController = (req, res) => {
    services.tokenValidation(req, res);
};
exports.saveController = (req, res) => {
    services.save(req, res);
};
exports.AdminSignupController = (req, res) => {
    services.adminSignup(req, res);
};
exports.ReadinessCheckController = (req, res) => {
    services.healthCheck.readiness(req, res);
};
exports.LivenessCheckController = (req, res) => {
    services.healthCheck.liveness(req, res);
};
exports.GenerateToken = (req, res) => {
    services.generateToken(req, res);
};
exports.PortalPermission = (req, res) => {
    services.PortalPermissions(req, res);
};
exports.ServiPermission = (req, res) => {
    services.ServicePermissions(req, res);
};
exports.ProfileController = (req, res) => {
    services.profile(req, res);
}
exports.editUserProfile = (req, res) => {
    services.profile.editUserProfile(req, res);
}